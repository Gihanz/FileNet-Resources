define("dojox/mobile/app", [
	"./app/_base"
], function(appBase){
	
	/*=====
	return {
		// summary:
		//		Loads dojox/mobile/app/_base. 
		// tags:
		//		private
	};
	=====*/
	return appBase;
});
