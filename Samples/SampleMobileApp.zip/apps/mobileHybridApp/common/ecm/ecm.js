//>>built

require({cache:{"ecm/model/admin/LocaleConfig":function () {
    define("ecm/model/admin/LocaleConfig", ["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var LocaleConfig = declare("ecm.model.admin.LocaleConfig", [_ConfigurationObject], {ID:"id", LABEL:"label", constructor:function (id, name) {
        }, getLabel:function () {
            return this.getValue(this.LABEL);
        }, setLabel:function (name) {
            this.setValue(this.LABEL, name);
        }});
        LocaleConfig.createLocaleConfig = function (id) {
            return new LocaleConfig(id, "LocaleConfig");
        };
        return LocaleConfig;
    });
}, "ecm/model/_ModelObject":function () {
    define("ecm/model/_ModelObject", ["dojo/_base/declare", "dojo/_base/lang", "../LoggerMixin", "../MessagesMixin"], function (declare, lang, LoggerMixin, MessagesMixin) {
        return declare("ecm.model._ModelObject", [LoggerMixin, MessagesMixin], {id:undefined, name:undefined, constructor:function (id, name) {
            if (id instanceof Object && !id.declaredClass) {
                lang.mixin(this, id);
            } else {
                this.id = id;
                this.name = name;
            }
        }, toString:function () {
            return this.declaredClass + "[" + this.id + "]";
        }, onChange:function (modelObject) {
        }, refresh:function () {
            this.onChange(this);
        }});
    });
}, "ecm/model/ChildComponent":function () {
    define("ecm/model/ChildComponent", ["dojo/_base/declare", "dojo/_base/lang", "./Item"], function (declare, lang, Item) {
        return declare("ecm.model.ChildComponent", [Item], {constructor:function () {
            if (this.criterias) {
                this.id = this.template_name;
                delete this.template_name;
                this.name = this.template_label;
                delete this.template_label;
                var attributes = {};
                var attributeLabels = {};
                var attributeTypes = [];
                var attributeFormats = [];
                for (var j in this.criterias) {
                    var attribute = this.criterias[j];
                    var attributeId = attribute.name;
                    attributes[attributeId] = attribute.validValues;
                    attributeLabels[attributeId] = attribute.label;
                    if (attribute.dataType || attribute.dataType == "") {
                        attributeTypes[attributeId] = attribute.dataType;
                    }
                    if (attribute.format || attribute.format == "") {
                        attributeFormats[attributeId] = attribute.format;
                    }
                }
                delete this.criterias;
                this.attributes = attributes;
                this.attributeTypes = attributeTypes;
                this.attributeFormats = attributeFormats;
                this.attributeLabels = attributeLabels;
            }
        }});
    });
}, "ecm/model/SearchTemplateTreeModel":function () {
    define(["dojo/_base/declare", "dojo/_base/connect", "dojo/_base/lang", "dojo/data/util/filter", "./_ModelObject", "./Item"], function (declare, connect, lang, dojoFilter, _ModelObject, Item) {
        return declare("ecm.model.SearchTemplateTreeModel", [_ModelObject], {noAllSearches:false, showRecents:true, showOpenedSearches:false, maxRecents:10, recentNode:null, filter:null, itemsPerPage:100, numPages:1, constructor:function (repository, teamspace) {
            if (teamspace) {
                this.id = teamspace.id;
                this.name = teamspace.name;
            } else {
                this.id = repository.id;
                this.name = repository.name;
            }
            this._teamspace = teamspace;
            this.repository = repository;
            this._rootNode = new _ModelObject("templatesRoot", "");
            if (this.showRecents) {
                this.recentNode = new _ModelObject("recent_open_searches", ecm.messages.recent_searches);
            }
        }, applyFilter:function (filter) {
            if (filter && filter.length > 0) {
                this.filter = dojoFilter.patternToRegExp(filter, true);
            } else {
                this.filter = null;
            }
            this.numPages = 1;
            this.reload();
        }, reload:function () {
            this.getChildren(this._rootNode, lang.hitch(this, function (newChildren) {
                this.onChildrenChange(this._rootNode, newChildren);
                for (var i in newChildren) {
                    var child = newChildren[i];
                    if (this.mayHaveChildren(child)) {
                        this.reloadNode(child);
                    } else {
                        this.onChange(child);
                    }
                }
            }));
        }, reloadNode:function (item) {
            var self = this;
            if (item) {
                this.getChildren(item, function (newChildren) {
                    self.onChildrenChange(item, newChildren);
                });
            }
        }, destroy:function () {
        }, getRoot:function (onItem) {
            onItem(this._rootNode);
        }, mayHaveChildren:function (item) {
            if (item == this._rootNode) {
                return true;
            } else {
                if (item.isInstanceOf && item.isInstanceOf(ecm.model.SearchTemplateFolder)) {
                    return true;
                } else {
                    if (item.id == "recent_open_searches") {
                        return true;
                    } else {
                        if (item.id == "opened_searches") {
                            return true;
                        } else {
                            if (!(item.isInstanceOf && item.isInstanceOf(ecm.model._SearchTemplateBase))) {
                                return false;
                            }
                        }
                    }
                }
            }
            return false;
        }, getChildren:function (parentItem, onComplete) {
            var hideAllSearches = this.noAllSearches;
            var containerRepo = this._getRepository();
            var self = this;
            if (parentItem == this._rootNode) {
                var self = this;
                if (!this.repository) {
                    onComplete([]);
                } else {
                    var request = containerRepo.retrieveSearchTemplateFolders(function (searchTemplateFolders) {
                        var childItems = [];
                        if (!hideAllSearches || searchTemplateFolders.length > 1) {
                            if (self.showRecents) {
                                childItems.push(self.recentNode);
                            }
                            if (self.showOpenedSearches) {
                                if (!self.openedSearchesNode) {
                                    self.openedSearchesNode = new _ModelObject("opened_searches", ecm.messages.opened_searches);
                                }
                                childItems.push(self.openedSearchesNode);
                            }
                            for (var i = 0; i < searchTemplateFolders.length; i++) {
                                var searchTemplateFolder = searchTemplateFolders[i];
                                childItems.push(searchTemplateFolder);
                            }
                            onComplete(childItems);
                        } else {
                            var request = containerRepo.retrieveSearchTemplates(function (searchTemplates) {
                                var maxItems = self.itemsPerPage * self.numPages;
                                var childItems = [];
                                for (var i = 0; i < searchTemplates.length; i++) {
                                    var searchTemplate = searchTemplates[i];
                                    if (self.filter) {
                                        var nameMatch = false;
                                        if (searchTemplate.name) {
                                            nameMatch = searchTemplate.name.match(self.filter);
                                        }
                                        var descMatch = false;
                                        if (searchTemplate.description) {
                                            descMatch = searchTemplate.description.match(self.filter);
                                        }
                                        if (!nameMatch && !descMatch) {
                                            continue;
                                        }
                                    }
                                    if (childItems.length == maxItems) {
                                        childItems.push(self._getMoreLinkItem());
                                        break;
                                    }
                                    self.onChange(searchTemplate);
                                    childItems.push(searchTemplate);
                                }
                                onComplete(childItems);
                            });
                        }
                    });
                }
            } else {
                if (parentItem.isInstanceOf && parentItem.isInstanceOf(ecm.model.SearchTemplateFolder)) {
                    var containerRepo = parentItem;
                    if (this._teamspace) {
                        containerRepo = this._teamspace;
                    }
                    var request = containerRepo.retrieveSearchTemplates(function (searchTemplates) {
                        var maxItems = self.itemsPerPage * self.numPages;
                        var childItems = [];
                        for (var i = 0; i < searchTemplates.length; i++) {
                            var searchTemplate = searchTemplates[i];
                            if (self.filter && !self._isFilterMatched(searchTemplate)) {
                                continue;
                            }
                            if (childItems.length == maxItems) {
                                childItems.push(self._getMoreLinkItem());
                                break;
                            }
                            self.onChange(searchTemplate);
                            childItems.push(searchTemplate);
                        }
                        onComplete(childItems);
                    });
                } else {
                    if (parentItem == this.recentNode) {
                        var containerRepo = this._getRepository();
                        containerRepo.retrieveRecentSearches(function (recentSearches) {
                            var childItems = [];
                            if (recentSearches && recentSearches.length > 0) {
                                for (var i = recentSearches.length - 1; i >= 0; i--) {
                                    if (!self.filter) {
                                        childItems.push(recentSearches[i]);
                                    }
                                    if (self._isFilterMatched(recentSearches[i])) {
                                        childItems.push(recentSearches[i]);
                                    }
                                }
                            }
                            onComplete(childItems);
                        });
                    } else {
                        if (parentItem == this.openedSearchesNode) {
                            var containerRepo = this._getRepository();
                            var openedSearches = containerRepo.getOpenedSearches();
                            var childItems = [];
                            for (var i in openedSearches) {
                                var openedSearch = openedSearches[i];
                                if (!self.filter) {
                                    childItems.push(openedSearch);
                                } else {
                                    if (self._isFilterMatched(openedSearch)) {
                                        childItems.push(openedSearch);
                                    }
                                }
                            }
                            onComplete(childItems);
                        } else {
                            onComplete([]);
                        }
                    }
                }
            }
            if (request) {
                connect.connect(request, "onRequestCompleted", this, function () {
                    this.onProcessingComplete(parentItem);
                });
            }
        }, _isFilterMatched:function (searchTemplate) {
            var matched = false;
            if (searchTemplate.name) {
                matched = searchTemplate.name.match(this.filter);
            }
            if (!matched && searchTemplate.description && this.repository.type == "od") {
                matched = searchTemplate.description.match(this.filter);
            }
            return matched;
        }, _getRepository:function () {
            var containerRepo = this.repository;
            if (this._teamspace) {
                containerRepo = this._teamspace;
            }
            return containerRepo;
        }, isItem:function (something) {
            if (something == this._rootNode || (something != null && something == this.recentNode)) {
                return true;
            }
            if (something && something.isInstanceOf && (something.isInstanceOf(ecm.model.SearchTemplateFolder) || something.isInstanceOf(ecm.model._SearchTemplateBase))) {
                return true;
            }
            return false;
        }, fetchItemByIdentity:function (keywordArgs) {
        }, getIdentity:function (item) {
            var id;
            if (item.isInstanceOf && item.isInstanceOf(ecm.model._SearchTemplateBase)) {
                id = item.generateUUID();
            } else {
                id = item.id;
            }
            return id;
        }, getLabel:function (item) {
            if (this.repository.type == "od" && item.isInstanceOf && item.isInstanceOf(ecm.model._SearchTemplateBase)) {
                var label = item.name;
                var desc = item.description;
                if (desc != null && desc.length > 0) {
                    label += " - " + desc;
                }
                return label;
            } else {
                return item.name;
            }
        }, newItem:function (args, parent, insertIndex) {
        }, pasteItem:function (childItem, oldParentItem, newParentItem, bCopy) {
        }, onChange:function (item) {
        }, onChildrenChange:function (parent, newChildrenList) {
        }, onProcessingStarted:function (item) {
        }, onProcessingComplete:function (item) {
        }, loadMore:function () {
            this.numPages++;
            this.reload();
        }, _getMoreLinkItem:function (parentItem) {
            if (!this._moreLinkItem) {
                var id = "moreLink" + new Date().getTime();
                var name = ecm.messages.more_paging_link;
                this._moreLinkItem = new Item(id, name);
                this._moreLinkItem.isMoreLink = true;
            }
            return this._moreLinkItem;
        }});
    });
}, "ecm/model/UserGroup":function () {
    define("ecm/model/UserGroup", ["dojo/_base/declare", "dojo/_base/array", "./_ModelObject", "./Role"], function (declare, array, _ModelObject, Role) {
        var UserGroup = declare("ecm.model.UserGroup", [_ModelObject], {displayName:null, shortName:null, users:null, roles:null, constructor:function (params) {
            if (params) {
                this._setRoles(params.roles);
            }
        }, _setRoles:function (roles) {
            this.roles = [];
            if (roles) {
                array.forEach(roles, function (obj) {
                    if (obj) {
                        var roleParams = {};
                        if (obj.name) {
                            roleParams.name = obj.name;
                        }
                        if (obj.desc) {
                            roleParams.description = obj.desc;
                        }
                        if (obj.privs) {
                            roleParams.privileges = obj.privs;
                        }
                        var role = new Role(roleParams);
                        this.roles.push(role);
                    }
                }, this);
            }
        }, hasUser:function (userId) {
            var hasUsr = false;
            if (this.users != null) {
                array.forEach(this.users, function (user) {
                    if (user.id == userId || user.name == userId) {
                        hasUsr = true;
                    }
                }, this);
            }
            return hasUsr;
        }, toJSON:function () {
            var jsonUser = {};
            jsonUser.id = this.id;
            jsonUser.name = this.name;
            jsonUser.shortName = this.shortName;
            jsonUser.displayName = this.displayName;
            jsonUser.isGroup = true;
            return jsonUser;
        }});
        UserGroup.AUTHENTICATED_USERS = "#AUTHENTICATED-USERS";
        UserGroup.getAuthenticatedUsersPseudoGroup = function () {
            return new UserGroup({id:UserGroup.AUTHENTICATED_USERS, name:UserGroup.AUTHENTICATED_USERS, shortName:UserGroup.AUTHENTICATED_USERS, displayName:ecm.messages.authenticated_users});
        };
        return UserGroup;
    });
}, "ecm/model/Task":function () {
    define(["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        return declare("ecm.model.Task", [_ModelObject], {doit:function () {
        }, undoit:function () {
        }});
    });
}, "ecm/model/admin/ServerConfig":function () {
    define("ecm/model/admin/ServerConfig", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "./_ConfigurationObject", "./RepositoryConfig"], function (declare, lang, array, _ConfigurationObject, RepositoryConfig) {
        var ServerConfig = declare("ecm.model.admin.ServerConfig", [_ConfigurationObject], {REPOSITORIES:"repositories", CONFIG_INFO:"configInfo", SERVICE_URL:"serviceURL", LABEL_KEY:"labelKey", TYPE:"type", constructor:function (id, name) {
        }, getConfigInfo:function () {
            return this.getValue(this.CONFIG_INFO);
        }, setConfigInfo:function (configInfo) {
            this.setValue(this.CONFIG_INFO, configInfo);
        }, getServiceURL:function () {
            return this.getValue(this.SERVICE_URL);
        }, setServiceURL:function (serviceURL) {
            this.setValue(this.SERVICE_URL, serviceURL);
        }, getLabelKey:function () {
            return this.getValue(this.LABEL_KEY);
        }, setLabelKey:function (labelKey) {
            this.setValue(this.LABEL_KEY, labelKey);
        }, getType:function () {
            return this.getValue(this.TYPE);
        }, setType:function (type) {
            this.setValue(this.TYPE, type);
        }, getRepositoryObjects:function (callback) {
            var repositories = this.getValues(this.REPOSITORIES);
            if (repositories && repositories.length > 0) {
                var repositoryObjects = [];
                array.forEach(repositories, lang.hitch(this, function (entry, index) {
                    var repository = RepositoryConfig.createRepositoryConfig(entry);
                    repository.getConfig(function (response) {
                        repositoryObjects.push(repository);
                        if (repositoryObjects.length == repositories.length && callback) {
                            callback(repositoryObjects);
                        }
                    });
                }));
                return repositoryObjects;
            }
        }});
        ServerConfig.createServerConfig = function (id) {
            return new ServerConfig(id, "ServerConfig");
        };
        return ServerConfig;
    });
}, "ecm/model/admin/PropertyMappingConfig":function () {
    define("ecm/model/admin/PropertyMappingConfig", ["dojo/_base/declare", "ecm/model/admin/_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var PropertyMappingConfig = declare("ecm.model.admin.PropertyMappingConfig", ecm.model.admin._ConfigurationObject, {DATA_TYPE:"dataType", OFFICE_PROPERTIES:"officeProperties", REPOSITORY_PROPERTY:"repositoryProperty", constructor:function (id, name) {
        }, getRepositoryProperty:function () {
            return this.getValue(this.REPOSITORY_PROPERTY);
        }, setRepositoryProperty:function (repoProperty) {
            this.setValue(this.REPOSITORY_PROPERTY, repoProperty);
        }, getDataType:function () {
            return this.getValue(this.DATA_TYPE);
        }, setDataType:function (type) {
            this.setValue(this.DATA_TYPE, type);
        }, getOfficeProperties:function () {
            return this.getValues(this.OFFICE_PROPERTIES);
        }, setOfficeProperties:function (officeProperties) {
            this.setValues(this.OFFICE_PROPERTIES, officeProperties);
        }});
        PropertyMappingConfig.createPropertyMappingConfig = function (id) {
            return new PropertyMappingConfig(id, "PropertyMappingConfig");
        };
        return PropertyMappingConfig;
    });
}, "ecm/model/DataSource":function () {
    define("ecm/model/DataSource", ["dojo/_base/declare", "dojo/_base/lang", "./_ModelObject", "./Request"], function (declare, lang, _ModelObject, Request) {
        return declare("ecm.model.DataSource", [_ModelObject], {connected:false, description:null, userid:null, userDisplayName:null, privilegeMask:0, logon:function (password, callback, reqParams) {
            if (!reqParams) {
                reqParams = {};
            }
            lang.mixin(reqParams, {desktop:ecm.model.desktop.id, dataSourceId:this.id, userid:this.userId, password:password});
            var request = Request.invokeService("logon", "ds", reqParams, lang.hitch(this, function (response) {
                lang.mixin(this, response);
                if (callback) {
                    callback(this);
                }
                if (this.connected) {
                    this.onConnected(this);
                }
            }));
        }, logoff:function () {
            var request = Request.invokeService("logoff", "ds", {desktop:ecm.model.desktop.id, dataSourceId:this.id}, lang.hitch(this, function (response) {
                this.connected = false;
                this.onDisconnected();
            }));
        }, onConnected:function (datasource) {
        }, onDisconnected:function () {
        }, changePassword:function (password, newPassword, callback, reqParams) {
            if (!reqParams) {
                reqParams = {};
            }
            lang.mixin(reqParams, {desktop:ecm.model.desktop.id, dataSourceId:this.id, userid:this.userId, password:password, newPassword:newPassword});
            var request = Request.invokeService("changePassword", "ds", reqParams, lang.hitch(this, function (response) {
                lang.mixin(this, response);
                if (callback) {
                    callback(this);
                }
            }));
        }});
    });
}, "ecm/model/Container":function () {
    define("ecm/model/Container", ["dojo/_base/declare", "./_ModelObject", "./Request"], function (declare, _ModelObject, Request) {
        return declare("ecm.model.Container", [_ModelObject], {connected:false, type:"container", userid:null, userId:null, userDisplayName:null, desktop:null, onChange:function (modelObject) {
            ecm.model.desktop.onChange(modelObject);
        }, onConnected:function (container) {
        }, onDisconnected:function (repository) {
        }, onAddTeamspaceTemplate:function (repository) {
        }, onWorklistContainersRetrieved:function (repository) {
        }, onTeamspaceListChange:function (repository) {
        }, onTeamspaceTemplateListChange:function (repository) {
        }, onAddTeamspace:function (repository) {
        }, containerLogon:function (password, callback) {
            var self = this;
            var enableSecureService = Request.enableSecureService;
            Request.enableSecureService = true;
            var request = Request.invokeService("logon", this.type, {desktop:ecm.model.desktop.id, repositoryId:ecm.model.desktop.getDefaultRepositoryId(), userid:this.userId, password:password}, function (response) {
                Request.enableSecureService = enableSecureService;
                self._containerLogonCompleted(response, callback);
            });
            return request;
        }, _containerLogonCompleted:function (response, callback) {
            this.connected = true;
            this.userId = response.userid;
            this.userDisplayName = response.user_displayname;
            if (response.adminLayout) {
                if (!response.adminLayout.featureTooltip) {
                    response.adminLayout.featureTooltip = ecm.messages.launchbar_admin;
                }
                ecm.model.desktop.createAdminFeature(response.adminLayout);
            }
            this.onChange(this);
            this.onConnected(this);
            if (callback) {
                callback(this);
            }
        }, containerLogoff:function () {
            var self = this;
            var request = Request.invokeService("logoff", this.type, {desktop:ecm.model.desktop.id}, function (response) {
                this.connected = false;
                this.onDisconnected();
            });
            return request;
        }});
    });
}, "ecm/model/ProcessApplicationSpace":function () {
    define("ecm/model/ProcessApplicationSpace", ["dojo/_base/declare", "dojo/_base/lang", "dojo/json", "./WorklistFolder", "./ProcessRole"], function (declare, lang, dojojson, WorklistFolder, ProcessRole) {
        return declare("ecm.model.ProcessApplicationSpace", [WorklistFolder], {connectionPoint:null, retrieveWorklists:function (callback, includeMembers, accessFlag, isBackgroundRequest, onError) {
            if (this._processRoles && includeMembers == undefined) {
                callback(this._processRoles);
            } else {
                if (this._processRoles && (includeMembers && this._processRoles.participants)) {
                    callback(this._processRoles);
                } else {
                    var requestParams = {repositoryId:this.repository.id, appspace_name:encodeURIComponent(this.id), connection_point:this.connectionPoint, include_members:includeMembers ? "true" : "false", access_flag:accessFlag};
                    var self = this;
                    var request = ecm.model.Request.invokeService("getProcessRoles", this.repository.type, requestParams, function (response) {
                        self._retrieveWorklistsCompleted(response, callback);
                    }, false, false, onError, isBackgroundRequest ? isBackgroundRequest : false);
                }
            }
            return request;
        }, _retrieveWorklistsCompleted:function (response, callback) {
            this._processRoles = [];
            if (response.datastore && response.datastore.items) {
                for (var i in response.datastore.items) {
                    var templateJSON = response.datastore.items[i];
                    templateJSON.id = templateJSON.processrole_auth_name;
                    templateJSON.name = templateJSON.processrole_name;
                    templateJSON.description = templateJSON.processrole_desc;
                    templateJSON.repository = this.repository;
                    templateJSON.connectionPoint = this.repository.connectionPoint;
                    templateJSON.parent = this;
                    var template = new ProcessRole(templateJSON);
                    this._processRoles.push(template);
                }
            }
            callback(this._processRoles);
        }, saveProcessRoles:function (roles, callback) {
            var self = this;
            var request = ecm.model.Request.postService("saveProcessRoles", this.repository.type, {repositoryId:this.repository.id, appspace_name:encodeURIComponent(this.id), connection_point:this.connectionPoint}, "text/json", dojojson.stringify(roles), lang.hitch(this, function (response) {
                self._saveProcessRolesCompleted(response, callback);
            }));
        }, _saveProcessRolesCompleted:function (response, callback) {
            if (callback) {
                callback();
            }
        }});
    });
}, "ecm/model/ProcessRole":function () {
    define("ecm/model/ProcessRole", ["dojo/_base/declare", "dojo/_base/lang", "./WorklistFolder", "./ProcessInbasket", "./User", "./UserGroup"], function (declare, lang, WorklistFolder, ProcessInbasket, User, UserGroup) {
        return declare("ecm.model.ProcessRole", [WorklistFolder], {parent:null, attributes:null, worklists:null, participants:null, connectionPoint:null, constructor:function (params) {
            if (!this.attributes) {
                this.attributes = {};
                this.participants = {};
            }
            this._attributeTypes = {};
            this._attributeFormats = {};
            if (params) {
                var attributes = {};
                for (var i in params.attributes) {
                    var jsonAttribute = params.attributes[i];
                    attributes[i] = jsonAttribute[0];
                    if (jsonAttribute.length > 1) {
                        this._attributeTypes[i] = jsonAttribute[1];
                    }
                    if (jsonAttribute.length > 2) {
                        this._attributeFormats[i] = jsonAttribute[2];
                    }
                }
                this.attributes = attributes;
                if (params.participants) {
                    this.participants = this._createUserGroupParticipantValue(params.participants);
                }
            }
        }, containsValue:function (attribute, value) {
            var v = this.attributes[attribute];
            if (value == v) {
                return true;
            } else {
                if (lang.isArray(v)) {
                    for (var i in v) {
                        if (value == v[i]) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }, getValue:function (attribute) {
            return this.attributes[attribute];
        }, getValues:function (attribute) {
            var v = this.attributes[attribute];
            if (lang.isArray(v)) {
                return v;
            } else {
                return [v];
            }
        }, hasAttribute:function (attribute) {
            return (typeof this.attributes[attribute] != "undefined");
        }, getAttributeType:function (attribute) {
            return this._attributeTypes[attribute];
        }, getAttributeFormat:function (attribute) {
            return this._attributeFormats[attribute];
        }, retrieveWorklists:function (callback, includeFetchCount) {
            if (this.worklists) {
                callback(this.worklists);
            } else {
                if (this.id == "all") {
                    this.repository.retrieveWorklists(callback);
                } else {
                    var self = this;
                    var request = ecm.model.Request.invokeService("getProcessInbaskets", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, appspace_name:encodeURIComponent(this.parent.id), processrole_name:encodeURIComponent(this.name), include_fetch_count:includeFetchCount ? "true" : "false"}, function (response) {
                        self._retrieveWorklistsCompleted(response, callback);
                    });
                }
            }
            return request;
        }, _retrieveWorklistsCompleted:function (response, callback) {
            this.worklists = [];
            for (var i in response.datastore.items) {
                var templateJSON = response.datastore.items[i];
                templateJSON.repository = this.repository;
                templateJSON.connectionPoint = this.repository.connectionPoint;
                templateJSON.id = templateJSON.inbasket_auth_name;
                templateJSON.name = templateJSON.inbasket_name;
                templateJSON.description = templateJSON.inbasket_desc;
                templateJSON.parent = this;
                var template = new ProcessInbasket(templateJSON);
                this.worklists.push(template);
            }
            callback(this.worklists);
        }, _createUserGroupParticipantValue:function (members) {
            var participants = [];
            for (var j in members) {
                var member = members[j];
                if (member.isGroup) {
                    var group = new UserGroup(member);
                    participants.push(group);
                } else {
                    var user = new User(member);
                    participants.push(user);
                }
            }
            return participants;
        }});
    });
}, "ecm/model/admin/ViewerConfig":function () {
    define("ecm/model/admin/ViewerConfig", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/json", "./_ConfigurationObject", "./ViewerMappingConfig"], function (declare, lang, dojojson, _ConfigurationObject, ViewerMappingConfig) {
        var ViewerConfig = declare("ecm.model.admin.ViewerConfig", [_ConfigurationObject], {ID:"id", NAME:"name", DESCRIPTION:"description", MAPPINGS:"mappings", constructor:function (id, name) {
        }, getName:function () {
            return this.getValue(this.NAME);
        }, setName:function (name) {
            this.setValue(this.NAME, name);
        }, getDescription:function () {
            return this.getValue(this.DESCRIPTION);
        }, setDescription:function (description) {
            this.setValue(this.DESCRIPTION, description);
        }, getMappings:function () {
            return this.getValues(this.MAPPINGS);
        }, getMappingObjects:function (callback) {
            var mappingObjects = [];
            var mappings = this.getValues(this.MAPPINGS);
            if (mappings && mappings.length > 0) {
                this.listConfig("mappings", lang.hitch(this, function (list) {
                    for (var i in list) {
                        var entry = list[i];
                        var id = entry.id ? entry.id : "" + i;
                        var mapping = ViewerMappingConfig.createViewerMappingConfig(entry);
                        lang.mixin(mapping, {_attributes:entry});
                        mappingObjects.push(mapping);
                    }
                    if (callback) {
                        callback(mappingObjects);
                    }
                }));
                return mappingObjects;
            } else {
                if (callback) {
                    callback(mappingObjects);
                }
                return mappingObjects;
            }
        }, deleteConfigs:function (configs, name, callback) {
            var ids = [];
            for (var i in configs) {
                ids.push(configs[i].id);
            }
            var params = lang.mixin({action:"deleteList", ids:dojojson.toJson(ids), id:this.id, configuration:configs[0].name, "update_app_configuration_type":name}, this.default_params);
            self = this;
            var request = ecm.model.Request.invokeService("admin/configuration", null, params, function (response) {
                if (callback) {
                    callback(response);
                }
            });
        }, addConfig:function (mappingDataArray, name, callback) {
            var actionArray = [];
            var mappingIds = [];
            for (var i in mappingDataArray) {
                var mappingData = mappingDataArray[i];
                var id = this.id + i;
                mappingIds.push(id);
                mappingData.id = id;
            }
            var data = {};
            for (var i in this._attributes) {
                if (i != this.MAPPINGS) {
                    data[i] = this._attributes[i];
                }
            }
            data[this.MAPPINGS] = mappingIds;
            var updateAction = {"action":"add", "configuration":this.name, "id":this.id, "data":data, "update_list_configuration":ecm.model.admin.appCfg.name, "update_list_id":ecm.model.admin.appCfg.id, "update_list_type":ecm.model.admin.appCfg.VIEWERS};
            actionArray.push(updateAction);
            if (mappingDataArray && mappingDataArray.length > 0) {
                var updateListAction = {"action":"addList", "configuration":"ViewerMappingConfig", "data":mappingDataArray};
                actionArray.push(updateListAction);
            }
            var params = lang.mixin({"action":"multiple", "id":this.id, "configuration":this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(actionArray), lang.hitch(this, function (response) {
                lang.mixin(this, {_attributes:response.configuration});
                if (callback) {
                    callback();
                }
            }));
            return this;
        }, updateConfig:function (mappingDataArray, callback) {
            var actionArray = [];
            var mappingIdArray = this.getMappings();
            if (mappingIdArray && mappingIdArray.length > 0) {
                var deleteListAction = {"action":"deleteList", "configuration":"ViewerMappingConfig", "ids":mappingIdArray};
                actionArray.push(deleteListAction);
            }
            var mappingIds = [];
            for (var i in mappingDataArray) {
                var mappingData = mappingDataArray[i];
                var id = this.id + i;
                mappingIds.push(id);
                mappingData.id = id;
            }
            var data = {};
            for (var i in this._attributes) {
                if (i != this.MAPPINGS) {
                    data[i] = this._attributes[i];
                }
            }
            data[this.MAPPINGS] = mappingIds;
            var updateAction = {"action":"update", "configuration":this.name, "id":this.id, "data":data};
            actionArray.push(updateAction);
            if (mappingDataArray && mappingDataArray.length > 0) {
                var updateListAction = {"action":"addList", "configuration":"ViewerMappingConfig", "data":mappingDataArray};
                actionArray.push(updateListAction);
            }
            var params = lang.mixin({"action":"multiple", "id":this.id, "configuration":this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(actionArray), lang.hitch(this, function (response) {
                lang.mixin(this, {_attributes:response.configuration});
                if (callback) {
                    callback();
                }
            }));
            return this;
        }});
        ViewerConfig.createViewerConfig = function (id) {
            return new ViewerConfig(id, "ViewerConfig");
        };
        return ViewerConfig;
    });
}, "ecm/model/admin/SettingsConfig":function () {
    define("ecm/model/admin/SettingsConfig", ["dojo/_base/declare", "dojo/_base/lang", "./_ConfigurationObject", "./FileTypeConfig"], function (declare, lang, _ConfigurationObject, FileTypeConfig) {
        var SettingsConfig = declare("ecm.model.admin.SettingsConfig", [_ConfigurationObject], {LOGGING_LEVEL:"logging.level", LOGGING_CLASS_INCLUDES:"logging.class.includes", LOGGING_CLASS_EXCLUDES:"logging.class.excludes", LOGGING_DEBUG_USERS:"logging.debug.users", LOGGING_DEBUG_HOSTS:"logging.debug.hosts", DISABLE_AUTOCOMPLETE:"disableAutocomplete", CULTURAL_COLLATION:"culturalCollation", OD_LANGUAGE:"odLanguage", OD_TEMPDIR:"odTempdir", OD_TRACEDIR:"odTracedir", OD_TRACELEVEL:"odTracelevel", OD_MAX_TRACE_FILESIZE:"odMaxTraceFilesize", OD_AFP2PDF_INSTALLDIR:"odAfp2pdfInstalldir", OD_CUSTOM_PROPS:"odCustomProperties", TASKMANGER_SERVICE_URL:"taskManagerServiceURL", ADMIN_USERS:"adminUsers", FILE_TYPES:"fileTypes", constructor:function (id, name) {
        }, getLoggingLevel:function () {
            return this.getValue(this.LOGGING_LEVEL, "2");
        }, setLoggingLevel:function (loggingLevel) {
            this.setValue(this.LOGGING_LEVEL, loggingLevel);
        }, getLoggingClassIncludes:function () {
            return this.getValue(this.LOGGING_CLASS_INCLUDES, "");
        }, setLoggingClassIncludes:function (loggingClassIncludes) {
            this.setValue(this.LOGGING_CLASS_INCLUDES, loggingClassIncludes);
        }, getLoggingClassExcludes:function () {
            return this.getValue(this.LOGGING_CLASS_EXCLUDES, "");
        }, setLoggingClassExcludes:function (loggingClassExcludes) {
            this.setValue(this.LOGGING_CLASS_EXCLUDES, loggingClassExcludes);
        }, getLoggingDebugUsers:function () {
            return this.getValue(this.LOGGING_DEBUG_USERS, "");
        }, setLoggingDebugUsers:function (loggingDebugUsers) {
            this.setValue(this.LOGGING_DEBUG_USERS, loggingDebugUsers);
        }, getLoggingDebugHosts:function () {
            return this.getValue(this.LOGGING_DEBUG_HOSTS, "");
        }, setLoggingDebugHosts:function (loggingDebugHosts) {
            this.setValue(this.LOGGING_DEBUG_HOSTS, loggingDebugHosts);
        }, getDisableAutocomplete:function () {
            var disableAutocomplete = this.getValue(this.DISABLE_AUTOCOMPLETE, "false");
            return (disableAutocomplete === true || disableAutocomplete == "true");
        }, setDisableAutocomplete:function (disableAutocomplete) {
            disableAutocomplete = (disableAutocomplete === true || disableAutocomplete == "true");
            this.setValue(this.DISABLE_AUTOCOMPLETE, (disableAutocomplete ? "true" : "false"));
        }, getCulturalCollation:function () {
            var culturalCollation = this.getValue(this.CULTURAL_COLLATION, "false");
            return (culturalCollation === true || culturalCollation == "true");
        }, setCulturalCollation:function (culturalCollation) {
            culturalCollation = (culturalCollation === true || culturalCollation == "true");
            this.setValue(this.CULTURAL_COLLATION, (culturalCollation ? "true" : "false"));
        }, getODLanguage:function () {
            return this.getValue(this.OD_LANGUAGE, "");
        }, setODLanguage:function (language) {
            this.setValue(this.OD_LANGUAGE, language);
        }, getODTempdir:function () {
            return this.getValue(this.OD_TEMPDIR, "");
        }, setODTempdir:function (tempdir) {
            this.setValue(this.OD_TEMPDIR, tempdir);
        }, getODTracedir:function () {
            return this.getValue(this.OD_TRACEDIR, "");
        }, setODTracedir:function (tracedir) {
            this.setValue(this.OD_TRACEDIR, tracedir);
        }, getODTracelevel:function () {
            return this.getValue(this.OD_TRACELEVEL, 1);
        }, setODTracelevel:function (tracelevel) {
            this.setValue(this.OD_TRACELEVEL, tracelevel);
        }, getODMaxTraceFilesize:function () {
            return this.getValue(this.OD_MAX_TRACE_FILESIZE, 0);
        }, setODMaxTraceFilesize:function (maxTraceFilesize) {
            this.setValue(this.OD_MAX_TRACE_FILESIZE, maxTraceFilesize);
        }, getODAfp2pdfInstalldir:function () {
            return this.getValue(this.OD_AFP2PDF_INSTALLDIR, "");
        }, setODAfp2pdfInstalldir:function (afp2pdfInstalldir) {
            this.setValue(this.OD_AFP2PDF_INSTALLDIR, afp2pdfInstalldir);
        }, getCustomProperties:function () {
            return this.getValue(this.OD_CUSTOM_PROPS);
        }, setCustomProperties:function (customProps) {
            this.setValue(this.OD_CUSTOM_PROPS, customProps);
        }, getAdminUsers:function () {
            return this.getValues(this.ADMIN_USERS);
        }, setAdminUsers:function (users) {
            this.setValues(this.ADMIN_USERS, users);
        }, getFileTypes:function () {
            return this.getValues(this.FILE_TYPES);
        }, setFileTypes:function (fileTypes) {
            this.setValues(this.FILE_TYPES, fileTypes);
        }, getTaskManagerServiceURL:function () {
            return this.getValues(this.TASKMANGER_SERVICE_URL);
        }, setTaskManagerServiceURL:function (url) {
            this.setValues(this.TASKMANGER_SERVICE_URL, url);
        }, getFileTypeList:function (callback) {
            var fileTypeObjects = [];
            this.listConfig("fileTypes", lang.hitch(this, function (list) {
                for (var i in list) {
                    var entry = list[i];
                    var fileType = FileTypeConfig.createFileTypeConfig(entry.id);
                    lang.mixin(fileType, {_attributes:entry});
                    if (fileType.getName()) {
                        fileTypeObjects.push(fileType);
                    }
                }
                if (callback) {
                    callback(fileTypeObjects);
                }
            }), "true");
        }, getSettingsConfig:function (callback) {
            this.getConfig(callback);
            return this;
        }, updateSettingsConfig:function (callback) {
            this.updateConfig(callback);
        }});
        SettingsConfig.createSettingsConfig = function (id) {
            return new SettingsConfig(id, "SettingsConfig");
        };
        return SettingsConfig;
    });
}, "dojo/cldr/supplemental":function () {
    define("dojo/cldr/supplemental", ["../_base/lang", "../i18n"], function (lang, i18n) {
        var supplemental = {};
        lang.setObject("dojo.cldr.supplemental", supplemental);
        supplemental.getFirstDayOfWeek = function (locale) {
            var firstDay = {bd:5, mv:5, ae:6, af:6, bh:6, dj:6, dz:6, eg:6, iq:6, ir:6, jo:6, kw:6, ly:6, ma:6, om:6, qa:6, sa:6, sd:6, sy:6, ye:6, ag:0, ar:0, as:0, au:0, br:0, bs:0, bt:0, bw:0, by:0, bz:0, ca:0, cn:0, co:0, dm:0, "do":0, et:0, gt:0, gu:0, hk:0, hn:0, id:0, ie:0, il:0, "in":0, jm:0, jp:0, ke:0, kh:0, kr:0, la:0, mh:0, mm:0, mo:0, mt:0, mx:0, mz:0, ni:0, np:0, nz:0, pa:0, pe:0, ph:0, pk:0, pr:0, py:0, sg:0, sv:0, th:0, tn:0, tt:0, tw:0, um:0, us:0, ve:0, vi:0, ws:0, za:0, zw:0};
            var country = supplemental._region(locale);
            var dow = firstDay[country];
            return (dow === undefined) ? 1 : dow;
        };
        supplemental._region = function (locale) {
            locale = i18n.normalizeLocale(locale);
            var tags = locale.split("-");
            var region = tags[1];
            if (!region) {
                region = {de:"de", en:"us", es:"es", fi:"fi", fr:"fr", he:"il", hu:"hu", it:"it", ja:"jp", ko:"kr", nl:"nl", pt:"br", sv:"se", zh:"cn"}[tags[0]];
            } else {
                if (region.length == 4) {
                    region = tags[2];
                }
            }
            return region;
        };
        supplemental.getWeekend = function (locale) {
            var weekendStart = {"in":0, af:4, dz:4, ir:4, om:4, sa:4, ye:4, ae:5, bh:5, eg:5, il:5, iq:5, jo:5, kw:5, ly:5, ma:5, qa:5, sd:5, sy:5, tn:5}, weekendEnd = {af:5, dz:5, ir:5, om:5, sa:5, ye:5, ae:6, bh:5, eg:6, il:6, iq:6, jo:6, kw:6, ly:6, ma:6, qa:6, sd:6, sy:6, tn:6}, country = supplemental._region(locale), start = weekendStart[country], end = weekendEnd[country];
            if (start === undefined) {
                start = 6;
            }
            if (end === undefined) {
                end = 0;
            }
            return {start:start, end:end};
        };
        return supplemental;
    });
}, "ecm/model/admin/IdLabelConfig":function () {
    define(["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var IdLabelConfig = declare("ecm.model.admin.IdLabelConfig", [_ConfigurationObject], {ID:"id", LABEL:"label", constructor:function (id, name) {
        }, getLabel:function () {
            return this.getValue(this.LABEL);
        }, setLabel:function (name) {
            this.setValue(this.LABEL, name);
        }});
        IdLabelConfig.createIdLabelConfig = function (id) {
            return new IdLabelConfig(id, "IdLabelConfig");
        };
        return IdLabelConfig;
    });
}, "ecm/model/ChildComponentSearchCriteria":function () {
    define("ecm/model/ChildComponentSearchCriteria", ["dojo/_base/declare", "dojo/_base/array", "./_ModelObject"], function (declare, array, _ModelObject) {
        return declare("ecm.model.ChildComponentSearchCriteria", [_ModelObject], {searchCriteria:null, constructor:function () {
            if (!this.searchCriteria) {
                this.searchCriteria = [];
            }
        }, clone:function () {
            var childComponent = new ecm.model.ChildComponentSearchCriteria(this.id, this.name);
            var searchCriteria = [];
            for (var i in this.searchCriteria) {
                searchCriteria.push(this.searchCriteria[i].clone());
            }
            childComponent.searchCriteria = searchCriteria;
            return childComponent;
        }, equals:function (childComponentCriteria) {
            if (this.id != childComponentCriteria.id) {
                return false;
            }
            if ((this.searchCriteria instanceof Array) != (childComponentCriteria.searchCriteria instanceof Array)) {
                return false;
            }
            if (this.searchCriteria instanceof Array) {
                if (this.searchCriteria.length != childComponentCriteria.searchCriteria.length) {
                    return false;
                }
                if (!array.every(this.searchCriteria, function (criterion, i) {
                    return criterion.equals(childComponentCriteria.searchCriteria[i]);
                })) {
                    return false;
                }
            }
            return true;
        }});
    });
}, "ecm/model/SearchCriterion":function () {
    define("ecm/model/SearchCriterion", ["dojo/_base/declare", "dojo/_base/array", "dojo/_base/lang", "dojo/date", "dojo/string", "./_ModelObject", "./_AttributeMixin"], function (declare, array, lang, date, string, _ModelObject, _AttributeMixin) {
        return declare("ecm.model.SearchCriterion", [_ModelObject, _AttributeMixin], {EDIT_PROPERTY:{EDITABLE:"editable", HIDDEN:"hidden", READONLY:"readonly", REQUIRED:"required"}, searchTemplate:null, availableOperators:null, defaultOperator:"", selectedOperator:"", dataType:"", format:"", cardinality:"SINGLE", choiceList:null, markingList:null, defaultValue:"", value:"", values:null, valueRequired:false, readOnly:false, hidden:false, allowedValues:null, maxLength:"", minValue:"", maxValue:"", itemId:"", hasDependentAttributes:false, valueFixed:false, constructor:function () {
            if (!this.availableOperators) {
                this.availableOperators = [];
            }
            if (!this.allowedValues) {
                this.allowedValues = [];
            }
            if (!this.defaultOperator) {
                this.defaultOperator = (this.availableOperators && this.availableOperators.length) ? this.availableOperators[0] : "";
            }
            this.selectedOperator = this.defaultOperator;
            if (!this.format) {
                this.format = ecm.model.desktop.valueFormatter.getDefaultFormat(this.dataType == "xs:timestamp" ? "xs:date" : this.dataType);
            }
            if (lang.isArray(this.defaultValue)) {
                var values = this._normalizeValues(this.defaultValue);
                this.value = values[0];
                this.values = values;
            } else {
                if (typeof this.defaultValue != "undefined" && this.defaultValue !== null) {
                    this.value = this.defaultValue;
                    this.values = [this.defaultValue];
                } else {
                    this.value = "";
                    this.values = [""];
                }
            }
        }, clone:function () {
            var searchCriterion = new ecm.model.SearchCriterion({id:this.id, name:this.name, availableOperators:lang.clone(this.availableOperators), defaultOperator:this.defaultOperator, selectedOperator:this.selectedOperator, dataType:this.dataType, format:lang.clone(this.format), cardinality:this.cardinality, choiceList:lang.clone(this.choiceList), defaultValue:lang.clone(this.defaultValue), value:lang.clone(this.value), values:lang.clone(this.values), valueRequired:this.valueRequired, readOnly:this.readOnly, hidden:this.hidden, allowedValues:lang.clone(this.allowedValues), maxLength:this.maxLength, minValue:this.minValue, maxValue:this.maxValue, itemId:this.itemId, hasDependentAttributes:this.hasDependentAttributes, valueFixed:this.valueFixed});
            return searchCriterion;
        }, getAvailableOperatorsSelectOptions:function () {
            var selectOptions = [];
            var selectedIndex = 0;
            for (var i in this.availableOperators) {
                var availableOperator = this.availableOperators[i];
                var selectOption = {value:availableOperator, label:ecm.messages["operator_" + availableOperator]};
                if (availableOperator == this.defaultOperator) {
                    selectedIndex = selectOptions.length;
                }
                selectOptions.push(selectOption);
            }
            if (selectOptions.length > 0) {
                selectOptions[selectedIndex].selected = true;
            }
            return selectOptions;
        }, setValues:function (values) {
            this.values = values;
            if (values) {
                this.value = values[0];
            } else {
                this.value = null;
            }
            this.onChange(this);
        }, resetValue:function () {
            var defaultValue = this.defaultValue;
            if (defaultValue) {
                if (lang.isArray(defaultValue)) {
                    var values = this._normalizeValues(defaultValue);
                    this.value = values[0];
                    this.values = values;
                } else {
                    this.value = defaultValue;
                    this.values = [defaultValue];
                }
            } else {
                this.value = "";
                this.values = [""];
            }
        }, reset:function () {
            this.resetValue();
            this.selectedOperator = this.defaultOperator;
            this.onChange(this);
        }, _normalizeValues:function (values) {
            var normalizedValues = new Array();
            array.forEach(values, function (value) {
                normalizedValues.push(value && typeof value == "string" ? string.trim(value) : value || "");
            });
            return normalizedValues;
        }, equals:function (searchCriterion) {
            if (this.id != searchCriterion.id) {
                return false;
            }
            if (this.selectedOperator != searchCriterion.selectedOperator) {
                return false;
            }
            if ((this.values instanceof Array) != (searchCriterion.values instanceof Array)) {
                return false;
            }
            if (this.values instanceof Array) {
                var callback = function (value) {
                    return value != "";
                };
                var values = array.filter(this.values, callback);
                var otherValues = array.filter(searchCriterion.values, callback);
                if (values.length != otherValues.length) {
                    return false;
                }
                if (!array.every(values, function (value, i) {
                    return (searchCriterion.dataType == "xs:date" || searchCriterion.dataType == "xs:time" || searchCriterion.dataType == "xs:timestamp") ? !date.compare(new Date(value), new Date(otherValues[i]), searchCriterion.dataType == "xs:time" ? "time" : "date") : value == otherValues[i];
                })) {
                    return false;
                }
            }
            return true;
        }});
    });
}, "ecm/model/EntryTemplate":function () {
    define("ecm/model/EntryTemplate", ["dojo/_base/declare", "dojo/_base/json", "./_ModelObject", "./Request", "./ContentItem", "./WorkItem", "./Permission", "./SecurityPolicy", "./EntryTemplateOption", "./EntryTemplatePropertyOptions"], function (declare, dojojson, _ModelObject, Request, ContentItem, WorkItem, Permission, SecurityPolicy, EntryTemplateOption, EntryTemplatePropertyOptions) {
        var EntryTemplate = declare("ecm.model.EntryTemplate", [_ModelObject], {description:"", repository:null, type:"DOCUMENT", objectStore:null, useForCheckin:false, allowUserSelectFile:true, allowDuplicateFileNames:true, folder:null, allowUserSelectFolder:true, restrictToSelectedFolderOrDescendant:true, asMinorVersion:null, autoClassify:null, addClassName:"", addClassLabel:"", addClassDescription:"", allowUserSetPropertyValues:true, propertiesOptions:null, securityPolicy:null, permissions:null, allowUserSetSecurity:true, editable:true, declareRecord:"NEVER_DECLARE", workflow:null, teamspaceDefault:"", isRetrieved:false, constructor:function () {
            if (!this.asMinorVersion) {
                this.asMinorVersion = new EntryTemplateOption({id:"asMinorVersion", name:"asMinorVersion", on:false, readOnly:false, hidden:false});
            }
            if (!this.autoClassify) {
                this.autoClassify = new EntryTemplateOption({id:"autoClassify", name:"autoClassify", on:false, readOnly:true, hidden:true});
            }
            if (!this.propertiesOptions) {
                this.propertiesOptions = [];
            }
        }, _onChange:function () {
            if (!this._disableOnChange) {
                this.onChange(this);
            }
        }, retrieveEntryTemplate:function (callback, editMode, allowFailure) {
            if (this.isRetrieved) {
                if (callback) {
                    callback(this);
                }
                this.onEntryTemplateRetrieved(this);
            } else {
                var self = this;
                var request = Request.invokeService("openEntryTemplate", this.repository.type, {repositoryId:this.repository.id, template_name:this.id, form_type:editMode ? "edit" : "apply", allow_failure:allowFailure ? true : false}, function (response) {
                    self._retrieveEntryTemplateCompleted(response, callback);
                });
            }
        }, _retrieveEntryTemplateCompleted:function (response, callback) {
            if (response.id) {
                this.id = response.id;
                this.name = response.displayName;
                this._disableOnChange = true;
                try {
                    this.description = response.description;
                    this.type = response.entrytemplate_type;
                    this.useForCheckin = response.useForCheckin;
                    this.objectStore = response.objectStore;
                    this.allowUserSelectFile = response.file.allowUserSelect;
                    this.allowDuplicateFileNames = response.file.allowDuplicateFileNames;
                    if (response.folder.selected) {
                        this.folder = ContentItem.createFromJSON(response.folder.selected, this.repository, null, null);
                    }
                    this.allowUserSelectFolder = response.folder.allowUserSelect;
                    this.restrictToSelectedFolderOrDescendant = response.folder.restrictToSelectedFolderOrDescendant;
                    response.asMinorVersion.id = "asMinorVersion";
                    response.asMinorVersion.name = "asMinorVersion";
                    this.asMinorVersion = new EntryTemplateOption(response.asMinorVersion);
                    response.autoClassify.id = "autoClassify";
                    response.autoClassify.name = "autoClassify";
                    this.autoClassify = new EntryTemplateOption(response.autoClassify);
                    this.addClassName = response.template.template_name;
                    this.addClassLabel = response.template.template_label;
                    this.addClassDescription = response.template.template_desc;
                    this.allowUserSetPropertyValues = response.template.allowUserSetPropertyValues;
                    if (response.template.propertiesOptions) {
                        this.propertiesOptions = [];
                        for (var i in response.template.propertiesOptions) {
                            var propOptionsJSON = response.template.propertiesOptions[i];
                            this.propertiesOptions.push(new EntryTemplatePropertyOptions(propOptionsJSON));
                        }
                    }
                    if (response.security.policy) {
                        this.securityPolicy = new SecurityPolicy(response.security.policy);
                    }
                    this.permissions = Permission.createFromJSON(response.security.acl);
                    this.allowUserSetSecurity = response.security.allowUserSelect;
                    this.declareRecord = response.record.declare;
                    if (response.workflow) {
                        var workflow = response.workflow;
                        workflow.repository = this.repository;
                        workflow.connectionPoint = this.repository.connectionPoint;
                        this.workflow = new WorkItem(workflow);
                    }
                }
                catch (e) {
                }
                this.isRetrieved = true;
                delete this._disableOnChange;
                this._onChange();
            }
            if (callback) {
                callback(this);
            }
            this.onEntryTemplateRetrieved(this);
        }, onEntryTemplateRetrieved:function (template) {
        }});
        EntryTemplate.TYPE = {DOCUMENT:"DOCUMENT", FOLDER:"FOLDER", CUSTOMOBJECT:"CUSTOMOBJECT"};
        EntryTemplate.DECLARE = {ALWAYS_DECLARE:"ALWAYS_DECLARE", OPTIONALY_DECLARE:"OPTIONALY_DECLARE", CLASSIFY_DECLARE:"CLASSIFY_DECLARE", CLASSIFY_OPTIONALLY:"CLASSIFY_OPTIONALLY", NEVER_DECLARE:"NEVER_DECLARE"};
        return EntryTemplate;
    });
}, "ecm/model/ConfiguredLabels":function () {
    define("ecm/model/ConfiguredLabels", ["dojo/_base/declare", "../LoggerMixin", "../MessagesMixin", "idx/html"], function (declare, LoggerMixin, MessagesMixin, html) {
        return declare("ecm.model.ConfiguredLabels", [LoggerMixin, MessagesMixin], {constructor:function (modelObjects) {
            this._configuredLabelsDict = new Object();
            for (var i in modelObjects) {
                var modelItem = modelObjects[i];
                var key = modelItem.getLabelKey();
                if (key != null && key != "") {
                    this._configuredLabelsDict[key] = modelItem;
                }
            }
        }, getLabelValue:function (key, dojoLocale, htmlEscape) {
            var value = "";
            var cfgLocale = dojoLocale;
            cfgLocale = cfgLocale.replace(/-/, "_");
            if (cfgLocale == "zh_cn") {
                cfgLocale = "zh_CN";
            } else {
                if (cfgLocale == "zh_tw") {
                    cfgLocale = "zh_TW";
                } else {
                    if (cfgLocale == "pt_br") {
                        cfgLocale = "pt_BR";
                    }
                }
            }
            if (cfgLocale.indexOf("_") > 0 || cfgLocale.indexOf("-") > 0) {
                if (cfgLocale != "zh_CN" && cfgLocale != "zh_TW" && cfgLocale != "pt_BR") {
                    cfgLocale = cfgLocale.substring(0, 2);
                }
            }
            if (this._configuredLabelsDict[key] != null) {
                var configuredLabel = this._configuredLabelsDict[key];
                var localeData = configuredLabel.getLocaleData();
                value = localeData.getValue(cfgLocale);
            }
            if (value == null || value == "") {
                var messages = dojo.i18n.getLocalization("ecm", "messages", dojoLocale);
                if (messages && messages[key]) {
                    value = messages[key];
                }
            }
            if (value == null || value == "") {
                var messages = dojo.i18n.getLocalization("ecm", "messages", "en");
                if (messages && messages[key]) {
                    value = messages[key];
                }
            }
            if (value == null || value == "") {
                value = key;
            }
            if (htmlEscape == undefined || htmlEscape == true) {
                return html.escapeHTML(value);
            } else {
                return value;
            }
        }});
    });
}, "ecm/model/admin/InterfaceTextConfig":function () {
    define("ecm/model/admin/InterfaceTextConfig", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/json", "./_ConfigurationObject", "./InterfaceTextLocaleConfig", "./InterfaceTextLabelConfig"], function (declare, lang, dojojson, _ConfigurationObject, InterfaceTextLocaleConfig, InterfaceTextLabelConfig) {
        var InterfaceTextConfig = declare("ecm.model.admin.InterfaceTextConfig", [_ConfigurationObject], {LABEL_KEY:"labelKey", TOOLTIP_KEY:"tooltipKey", TYPE:"type", REPOSITORY_TYPE:"repositoryType", REPOSITORY_ID:"repositoryId", DESKTOP_ID:"desktopId", USER_DATA:"userData", DISPLAYED_IN:"displayedIn", CLASSIC_LABEL_KEY:"classicLabelKey", localeData:null, labelData:null, constructor:function (id, name) {
        }, getType:function () {
            return this.getValue(this.TYPE);
        }, setType:function (type) {
            this.setValue(this.TYPE, type);
        }, isTypeSystem:function () {
            return this.getType() == "system";
        }, isTypeApplication:function () {
            return this.getType() == "application";
        }, isTypeAction:function () {
            return this.getType() == "action";
        }, isTypeDesktop:function () {
            return this.getType() == "desktop";
        }, getUserData:function () {
            return this.getValue(this.USER_DATA);
        }, setUserData:function (data) {
            this.setValue(this.USER_DATA, data);
        }, getRepositoryType:function () {
            return this.getValue(this.REPOSITORY_TYPE);
        }, setRepositoryType:function (type) {
            this.setValue(this.REPOSITORY_TYPE, type);
        }, getRepositoryId:function () {
            return this.getValue(this.REPOSITORY_ID);
        }, setRepositoryId:function (id) {
            this.setValue(this.REPOSITORY_ID, id);
        }, getDesktopId:function () {
            return this.getValue(this.DESKTOP_ID);
        }, setDesktopId:function (id) {
            this.setValue(this.DESKTOP_ID, id);
        }, isP8:function () {
            return this.getRepositoryType() == "p8";
        }, isCM:function () {
            return this.getRepositoryType() == "cm";
        }, isOD:function () {
            return this.getRepositoryType() == "od";
        }, getLabelKey:function () {
            return this.getValue(this.LABEL_KEY);
        }, setLabelKey:function (key) {
            this.setValue(this.LABEL_KEY, key);
        }, getTooltipKey:function () {
            return this.getValue(this.TOOLTIP_KEY);
        }, getDisplayedIn:function () {
            return this.getValue(this.DISPLAYED_IN);
        }, setDisplayedIn:function (value) {
            this.setValue(this.DISPLAYED_IN, value);
        }, getClassicLabelKey:function () {
            return this.getValue(this.CLASSIC_LABEL_KEY);
        }, setLocaleData:function (localeData) {
            this.localeData = localeData;
        }, getLocaleData:function () {
            if (!this.localeData) {
                this.localeData = ecm.model.admin.InterfaceTextLocaleConfig.createInterfaceTextLocaleConfig(this.id);
            }
            return this.localeData;
        }, setLabelData:function (labelData) {
            this.labelData = labelData;
        }, getLabelData:function () {
            if (!this.labelData) {
                this.labelData = InterfaceTextLabelConfig.createInterfaceTextLabelConfig(this.id);
            }
            return this.labelData;
        }, hasLabelData:function () {
            if (this.labelData) {
                return this.labelData.hasLabelData();
            } else {
                return false;
            }
        }, updateConfigs:function (configs, callback) {
            var data = [];
            for (var i in configs) {
                var localeData = configs[i].getLocaleData();
                var obj = {id:localeData._attributes.id};
                var hasData = false;
                for (var key in localeData._attributes) {
                    if (key != "id") {
                        var value = localeData._attributes[key];
                        if (value && value != "") {
                            hasData = true;
                            obj[key] = value;
                        }
                    }
                }
                if (hasData) {
                    data.push(obj);
                }
            }
            var params = lang.mixin({action:"updateUILabels", id:this.id, configuration:this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(data), function (response) {
                if (callback) {
                    callback();
                }
            });
            return this;
        }, getInterfaceTextConfig:function (callback) {
            this.getConfig(callback);
            return this;
        }, updateInterfaceTextConfig:function (callback) {
            this.updateConfig(callback);
        }});
        InterfaceTextConfig.createInterfaceTextConfig = function (id) {
            return new InterfaceTextConfig(id, "InterfaceTextConfig");
        };
        InterfaceTextConfig.getUniqueId = function (sequenceNumber) {
            var d = new Date();
            return "" + (d.getTime() + sequenceNumber);
        };
        InterfaceTextConfig.updateConfiguration = function (configs, desktopId, callback) {
            var params = {application:"navigator", action:"updateInterfaceText", configuration:"InterfaceTextConfig", desktop:desktopId, id:desktopId ? desktopId : "interfaceText"};
            ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(configs), function (response) {
                if (callback) {
                    callback(response);
                }
            });
        };
        InterfaceTextConfig.updateConfigurationOnly = function (configs, callback) {
            var params = {application:"navigator", action:"updateInterfaceTextOnly", configuration:"InterfaceTextConfig", id:"interfaceText"};
            ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(configs), function (response) {
                if (callback) {
                    callback(response);
                }
            });
        };
        return InterfaceTextConfig;
    });
}, "idx/html":function () {
    define(["idx/main", "dojo/_base/lang", "dojo/_base/window", "dojo/dom-construct", "dojo/dom-geometry"], function (iMain, dLang, dWindow, dDomConstruct, dDomGeo) {
        var iHTML = dLang.getObject("html", true, iMain);
        iMain.getOffsetPosition = iHTML.getOffsetPosition = function (node, root) {
            root = root || dWindow.body();
            var n = node;
            var l = 0;
            var t = 0;
            while (n != root) {
                l += n.offsetLeft;
                t += n.offsetTop;
                n = n.offsetParent;
            }
            return {l:l, t:t};
        };
        iMain.containsNode = iHTML.containsNode = function (parent, node) {
            var n = node;
            while (n && n != dWindow.body()) {
                if (n == parent) {
                    return true;
                }
                if (n.parentNode) {
                    n = n.parentNode;
                } else {
                    break;
                }
            }
            return false;
        };
        iMain.containsCursor = iHTML.containsCursor = function (node, evt) {
            var pos = dDomGeo.position(node);
            var l = pos.x;
            var t = pos.y;
            var r = l + pos.w;
            var b = t + pos.h;
            var cx = evt.clientX;
            var cy = evt.clientY;
            var contained = cx > l && cx < r && cy > t && cy < b;
            return contained;
        };
        iMain.setTextNode = iHTML.setTextNode = function (node, text) {
            if (!node) {
                return;
            }
            dDomConstruct.place(dWindow.doc.createTextNode(text), node, "only");
        };
        iMain.escapeHTML = iHTML.escapeHTML = function (s) {
            if (!dLang.isString(s)) {
                return s;
            }
            return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        };
        iMain.unescapeHTML = iHTML.unescapeHTML = function (s) {
            if (!dLang.isString(s)) {
                return s;
            }
            return s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/&amp;/g, "&");
        };
        return iHTML;
    });
}, "ecm/model/SearchContentClasses":function () {
    define("ecm/model/SearchContentClasses", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "./_HasAttributesMixin"], function (declare, lang, array, _HasAttributesMixin) {
        return declare("ecm.model.SearchContentClasses", [_HasAttributesMixin], {contentClasses:null, attributeDefinitions:null, constructor:function (contentClasses) {
            this.setContentClasses(contentClasses);
        }, setContentClasses:function (contentClasses) {
            this.contentClasses = contentClasses;
            this.attributeDefinitions = null;
            this.repository = null;
            this.objectStore = null;
            this.id = "";
            this.name = "";
            if (contentClasses instanceof Array && contentClasses.length > 0) {
                this.repository = contentClasses[0].repository;
                this.objectStore = contentClasses[0].objectStore;
                array.forEach(contentClasses, function (contentClass) {
                    if (this.id) {
                        this.id += ",";
                        this.name += ", ";
                    }
                    this.id += contentClass.id;
                    this.name += contentClass.name;
                }, this);
            }
        }, _getContentClass:function (id) {
            var foundClass = null;
            if (this.contentClasses instanceof Array) {
                array.some(this.contentClasses, function (contentClass) {
                    var found = id == contentClass.id;
                    if (found) {
                        foundClass = contentClass;
                    }
                    return found;
                });
            }
            return foundClass;
        }, isTextSearchable:function () {
            var searchable = false;
            if (this.contentClasses instanceof Array) {
                searchable = array.every(this.contentClasses, function (contentClass) {
                    return contentClass.textSearchable;
                });
            }
            return searchable;
        }, _retrieveAttributeDefinitionsCompleted:function (response, callback) {
            if (response.classes instanceof Array) {
                array.forEach(response.classes, function (classInfo) {
                    var contentClass = this._getContentClass(classInfo.template_label);
                    if (contentClass) {
                        if (classInfo.template_label) {
                            contentClass.name = classInfo.template_label;
                        }
                        if (response.parm_name_attribute) {
                            contentClass.nameAttribute = classInfo.parm_name_attribute;
                        }
                        lang.mixin(contentClass, classInfo);
                    }
                }, this);
            }
            this.inherited(arguments);
        }, _retrieveAttributeDefinitionsForSearchesCompleted:function (response, callback) {
            if (response.classes instanceof Array) {
                array.forEach(response.classes, function (classInfo) {
                    var contentClass = this._getContentClass(classInfo.template_label);
                    if (contentClass) {
                        if (classInfo.template_label) {
                            contentClass.name = classInfo.template_label;
                        }
                    }
                }, this);
            }
            this.inherited(arguments);
        }});
    });
}, "ecm/model/EntryTemplatePropertyOptions":function () {
    define("ecm/model/EntryTemplatePropertyOptions", ["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        var EntryTemplatePropertyOptions = declare("ecm.model.EntryTemplatePropertyOptions", [_ModelObject], {dataType:null, defaultValue:null, required:false, readOnly:false, hidden:false, cardinality:"SINGLE", requiredClass:"", constructor:function () {
            if (!this.id) {
                this.id = this.name;
            }
            if (this.required_template && this.required_template.template_id) {
                this.requiredClass = this.required_template.template_id;
                delete this.required_template;
            }
        }});
        EntryTemplatePropertyOptions.CARDINALITY = {SINGLE:"SINGLE", LIST:"LIST"};
        return EntryTemplatePropertyOptions;
    });
}, "dojo/date/locale":function () {
    define("dojo/date/locale", ["../_base/lang", "../_base/array", "../date", "../cldr/supplemental", "../i18n", "../regexp", "../string", "../i18n!../cldr/nls/gregorian", "module"], function (lang, array, date, supplemental, i18n, regexp, string, gregorian, module) {
        var exports = {};
        lang.setObject(module.id.replace(/\//g, "."), exports);
        function formatPattern(dateObject, bundle, options, pattern) {
            return pattern.replace(/([a-z])\1*/ig, function (match) {
                var s, pad, c = match.charAt(0), l = match.length, widthList = ["abbr", "wide", "narrow"];
                switch (c) {
                  case "G":
                    s = bundle[(l < 4) ? "eraAbbr" : "eraNames"][dateObject.getFullYear() < 0 ? 0 : 1];
                    break;
                  case "y":
                    s = dateObject.getFullYear();
                    switch (l) {
                      case 1:
                        break;
                      case 2:
                        if (!options.fullYear) {
                            s = String(s);
                            s = s.substr(s.length - 2);
                            break;
                        }
                      default:
                        pad = true;
                    }
                    break;
                  case "Q":
                  case "q":
                    s = Math.ceil((dateObject.getMonth() + 1) / 3);
                    pad = true;
                    break;
                  case "M":
                  case "L":
                    var m = dateObject.getMonth();
                    if (l < 3) {
                        s = m + 1;
                        pad = true;
                    } else {
                        var propM = ["months", c == "L" ? "standAlone" : "format", widthList[l - 3]].join("-");
                        s = bundle[propM][m];
                    }
                    break;
                  case "w":
                    var firstDay = 0;
                    s = exports._getWeekOfYear(dateObject, firstDay);
                    pad = true;
                    break;
                  case "d":
                    s = dateObject.getDate();
                    pad = true;
                    break;
                  case "D":
                    s = exports._getDayOfYear(dateObject);
                    pad = true;
                    break;
                  case "e":
                  case "c":
                    var d = dateObject.getDay();
                    if (l < 2) {
                        s = (d - supplemental.getFirstDayOfWeek(options.locale) + 8) % 7;
                        break;
                    }
                  case "E":
                    d = dateObject.getDay();
                    if (l < 3) {
                        s = d + 1;
                        pad = true;
                    } else {
                        var propD = ["days", c == "c" ? "standAlone" : "format", widthList[l - 3]].join("-");
                        s = bundle[propD][d];
                    }
                    break;
                  case "a":
                    var timePeriod = dateObject.getHours() < 12 ? "am" : "pm";
                    s = options[timePeriod] || bundle["dayPeriods-format-wide-" + timePeriod];
                    break;
                  case "h":
                  case "H":
                  case "K":
                  case "k":
                    var h = dateObject.getHours();
                    switch (c) {
                      case "h":
                        s = (h % 12) || 12;
                        break;
                      case "H":
                        s = h;
                        break;
                      case "K":
                        s = (h % 12);
                        break;
                      case "k":
                        s = h || 24;
                        break;
                    }
                    pad = true;
                    break;
                  case "m":
                    s = dateObject.getMinutes();
                    pad = true;
                    break;
                  case "s":
                    s = dateObject.getSeconds();
                    pad = true;
                    break;
                  case "S":
                    s = Math.round(dateObject.getMilliseconds() * Math.pow(10, l - 3));
                    pad = true;
                    break;
                  case "v":
                  case "z":
                    s = exports._getZone(dateObject, true, options);
                    if (s) {
                        break;
                    }
                    l = 4;
                  case "Z":
                    var offset = exports._getZone(dateObject, false, options);
                    var tz = [(offset <= 0 ? "+" : "-"), string.pad(Math.floor(Math.abs(offset) / 60), 2), string.pad(Math.abs(offset) % 60, 2)];
                    if (l == 4) {
                        tz.splice(0, 0, "GMT");
                        tz.splice(3, 0, ":");
                    }
                    s = tz.join("");
                    break;
                  default:
                    throw new Error("dojo.date.locale.format: invalid pattern char: " + pattern);
                }
                if (pad) {
                    s = string.pad(s, l);
                }
                return s;
            });
        }
        exports._getZone = function (dateObject, getName, options) {
            if (getName) {
                return date.getTimezoneName(dateObject);
            } else {
                return dateObject.getTimezoneOffset();
            }
        };
        exports.format = function (dateObject, options) {
            options = options || {};
            var locale = i18n.normalizeLocale(options.locale), formatLength = options.formatLength || "short", bundle = exports._getGregorianBundle(locale), str = [], sauce = lang.hitch(this, formatPattern, dateObject, bundle, options);
            if (options.selector == "year") {
                return _processPattern(bundle["dateFormatItem-yyyy"] || "yyyy", sauce);
            }
            var pattern;
            if (options.selector != "date") {
                pattern = options.timePattern || bundle["timeFormat-" + formatLength];
                if (pattern) {
                    str.push(_processPattern(pattern, sauce));
                }
            }
            if (options.selector != "time") {
                pattern = options.datePattern || bundle["dateFormat-" + formatLength];
                if (pattern) {
                    str.push(_processPattern(pattern, sauce));
                }
            }
            return str.length == 1 ? str[0] : bundle["dateTimeFormat-" + formatLength].replace(/\'/g, "").replace(/\{(\d+)\}/g, function (match, key) {
                return str[key];
            });
        };
        exports.regexp = function (options) {
            return exports._parseInfo(options).regexp;
        };
        exports._parseInfo = function (options) {
            options = options || {};
            var locale = i18n.normalizeLocale(options.locale), bundle = exports._getGregorianBundle(locale), formatLength = options.formatLength || "short", datePattern = options.datePattern || bundle["dateFormat-" + formatLength], timePattern = options.timePattern || bundle["timeFormat-" + formatLength], pattern;
            if (options.selector == "date") {
                pattern = datePattern;
            } else {
                if (options.selector == "time") {
                    pattern = timePattern;
                } else {
                    pattern = bundle["dateTimeFormat-" + formatLength].replace(/\{(\d+)\}/g, function (match, key) {
                        return [timePattern, datePattern][key];
                    });
                }
            }
            var tokens = [], re = _processPattern(pattern, lang.hitch(this, _buildDateTimeRE, tokens, bundle, options));
            return {regexp:re, tokens:tokens, bundle:bundle};
        };
        exports.parse = function (value, options) {
            var controlChars = /[\u200E\u200F\u202A\u202E]/g, info = exports._parseInfo(options), tokens = info.tokens, bundle = info.bundle, re = new RegExp("^" + info.regexp.replace(controlChars, "") + "$", info.strict ? "" : "i"), match = re.exec(value && value.replace(controlChars, ""));
            if (!match) {
                return null;
            }
            var widthList = ["abbr", "wide", "narrow"], result = [1970, 0, 1, 0, 0, 0, 0], amPm = "", valid = array.every(match, function (v, i) {
                if (!i) {
                    return true;
                }
                var token = tokens[i - 1], l = token.length, c = token.charAt(0);
                switch (c) {
                  case "y":
                    if (l != 2 && options.strict) {
                        result[0] = v;
                    } else {
                        if (v < 100) {
                            v = Number(v);
                            var year = "" + new Date().getFullYear(), century = year.substring(0, 2) * 100, cutoff = Math.min(Number(year.substring(2, 4)) + 20, 99);
                            result[0] = (v < cutoff) ? century + v : century - 100 + v;
                        } else {
                            if (options.strict) {
                                return false;
                            }
                            result[0] = v;
                        }
                    }
                    break;
                  case "M":
                  case "L":
                    if (l > 2) {
                        var months = bundle["months-" + (c == "L" ? "standAlone" : "format") + "-" + widthList[l - 3]].concat();
                        if (!options.strict) {
                            v = v.replace(".", "").toLowerCase();
                            months = array.map(months, function (s) {
                                return s.replace(".", "").toLowerCase();
                            });
                        }
                        v = array.indexOf(months, v);
                        if (v == -1) {
                            return false;
                        }
                    } else {
                        v--;
                    }
                    result[1] = v;
                    break;
                  case "E":
                  case "e":
                  case "c":
                    var days = bundle["days-" + (c == "c" ? "standAlone" : "format") + "-" + widthList[l - 3]].concat();
                    if (!options.strict) {
                        v = v.toLowerCase();
                        days = array.map(days, function (d) {
                            return d.toLowerCase();
                        });
                    }
                    v = array.indexOf(days, v);
                    if (v == -1) {
                        return false;
                    }
                    break;
                  case "D":
                    result[1] = 0;
                  case "d":
                    result[2] = v;
                    break;
                  case "a":
                    var am = options.am || bundle["dayPeriods-format-wide-am"], pm = options.pm || bundle["dayPeriods-format-wide-pm"];
                    if (!options.strict) {
                        var period = /\./g;
                        v = v.replace(period, "").toLowerCase();
                        am = am.replace(period, "").toLowerCase();
                        pm = pm.replace(period, "").toLowerCase();
                    }
                    if (options.strict && v != am && v != pm) {
                        return false;
                    }
                    amPm = (v == pm) ? "p" : (v == am) ? "a" : "";
                    break;
                  case "K":
                    if (v == 24) {
                        v = 0;
                    }
                  case "h":
                  case "H":
                  case "k":
                    if (v > 23) {
                        return false;
                    }
                    result[3] = v;
                    break;
                  case "m":
                    result[4] = v;
                    break;
                  case "s":
                    result[5] = v;
                    break;
                  case "S":
                    result[6] = v;
                }
                return true;
            });
            var hours = +result[3];
            if (amPm === "p" && hours < 12) {
                result[3] = hours + 12;
            } else {
                if (amPm === "a" && hours == 12) {
                    result[3] = 0;
                }
            }
            var dateObject = new Date(result[0], result[1], result[2], result[3], result[4], result[5], result[6]);
            if (options.strict) {
                dateObject.setFullYear(result[0]);
            }
            var allTokens = tokens.join(""), dateToken = allTokens.indexOf("d") != -1, monthToken = allTokens.indexOf("M") != -1;
            if (!valid || (monthToken && dateObject.getMonth() > result[1]) || (dateToken && dateObject.getDate() > result[2])) {
                return null;
            }
            if ((monthToken && dateObject.getMonth() < result[1]) || (dateToken && dateObject.getDate() < result[2])) {
                dateObject = date.add(dateObject, "hour", 1);
            }
            return dateObject;
        };
        function _processPattern(pattern, applyPattern, applyLiteral, applyAll) {
            var identity = function (x) {
                return x;
            };
            applyPattern = applyPattern || identity;
            applyLiteral = applyLiteral || identity;
            applyAll = applyAll || identity;
            var chunks = pattern.match(/(''|[^'])+/g), literal = pattern.charAt(0) == "'";
            array.forEach(chunks, function (chunk, i) {
                if (!chunk) {
                    chunks[i] = "";
                } else {
                    chunks[i] = (literal ? applyLiteral : applyPattern)(chunk.replace(/''/g, "'"));
                    literal = !literal;
                }
            });
            return applyAll(chunks.join(""));
        }
        function _buildDateTimeRE(tokens, bundle, options, pattern) {
            pattern = regexp.escapeString(pattern);
            if (!options.strict) {
                pattern = pattern.replace(" a", " ?a");
            }
            return pattern.replace(/([a-z])\1*/ig, function (match) {
                var s, c = match.charAt(0), l = match.length, p2 = "", p3 = "";
                if (options.strict) {
                    if (l > 1) {
                        p2 = "0" + "{" + (l - 1) + "}";
                    }
                    if (l > 2) {
                        p3 = "0" + "{" + (l - 2) + "}";
                    }
                } else {
                    p2 = "0?";
                    p3 = "0{0,2}";
                }
                switch (c) {
                  case "y":
                    s = "\\d{2,4}";
                    break;
                  case "M":
                  case "L":
                    s = (l > 2) ? "\\S+?" : "1[0-2]|" + p2 + "[1-9]";
                    break;
                  case "D":
                    s = "[12][0-9][0-9]|3[0-5][0-9]|36[0-6]|" + p2 + "[1-9][0-9]|" + p3 + "[1-9]";
                    break;
                  case "d":
                    s = "3[01]|[12]\\d|" + p2 + "[1-9]";
                    break;
                  case "w":
                    s = "[1-4][0-9]|5[0-3]|" + p2 + "[1-9]";
                    break;
                  case "E":
                  case "e":
                  case "c":
                    s = "\\S+";
                    break;
                  case "h":
                    s = "1[0-2]|" + p2 + "[1-9]";
                    break;
                  case "k":
                    s = "1[01]|" + p2 + "\\d";
                    break;
                  case "H":
                    s = "1\\d|2[0-3]|" + p2 + "\\d";
                    break;
                  case "K":
                    s = "1\\d|2[0-4]|" + p2 + "[1-9]";
                    break;
                  case "m":
                  case "s":
                    s = "[0-5]\\d";
                    break;
                  case "S":
                    s = "\\d{" + l + "}";
                    break;
                  case "a":
                    var am = options.am || bundle["dayPeriods-format-wide-am"], pm = options.pm || bundle["dayPeriods-format-wide-pm"];
                    s = am + "|" + pm;
                    if (!options.strict) {
                        if (am != am.toLowerCase()) {
                            s += "|" + am.toLowerCase();
                        }
                        if (pm != pm.toLowerCase()) {
                            s += "|" + pm.toLowerCase();
                        }
                        if (s.indexOf(".") != -1) {
                            s += "|" + s.replace(/\./g, "");
                        }
                    }
                    s = s.replace(/\./g, "\\.");
                    break;
                  default:
                    s = ".*";
                }
                if (tokens) {
                    tokens.push(match);
                }
                return "(" + s + ")";
            }).replace(/[\xa0 ]/g, "[\\s\\xa0]");
        }
        var _customFormats = [];
        exports.addCustomFormats = function (packageName, bundleName) {
            _customFormats.push({pkg:packageName, name:bundleName});
        };
        exports._getGregorianBundle = function (locale) {
            var gregorian = {};
            array.forEach(_customFormats, function (desc) {
                var bundle = i18n.getLocalization(desc.pkg, desc.name, locale);
                gregorian = lang.mixin(gregorian, bundle);
            }, this);
            return gregorian;
        };
        exports.addCustomFormats(module.id.replace(/\/date\/locale$/, ".cldr"), "gregorian");
        exports.getNames = function (item, type, context, locale) {
            var label, lookup = exports._getGregorianBundle(locale), props = [item, context, type];
            if (context == "standAlone") {
                var key = props.join("-");
                label = lookup[key];
                if (label[0] == 1) {
                    label = undefined;
                }
            }
            props[1] = "format";
            return (label || lookup[props.join("-")]).concat();
        };
        exports.isWeekend = function (dateObject, locale) {
            var weekend = supplemental.getWeekend(locale), day = (dateObject || new Date()).getDay();
            if (weekend.end < weekend.start) {
                weekend.end += 7;
                if (day < weekend.start) {
                    day += 7;
                }
            }
            return day >= weekend.start && day <= weekend.end;
        };
        exports._getDayOfYear = function (dateObject) {
            return date.difference(new Date(dateObject.getFullYear(), 0, 1, dateObject.getHours()), dateObject) + 1;
        };
        exports._getWeekOfYear = function (dateObject, firstDayOfWeek) {
            if (arguments.length == 1) {
                firstDayOfWeek = 0;
            }
            var firstDayOfYear = new Date(dateObject.getFullYear(), 0, 1).getDay(), adj = (firstDayOfYear - firstDayOfWeek + 7) % 7, week = Math.floor((exports._getDayOfYear(dateObject) + adj - 1) / 7);
            if (firstDayOfYear == firstDayOfWeek) {
                week++;
            }
            return week;
        };
        return exports;
    });
}, "ecm/model/Action":function () {
    define("ecm/model/Action", ["dojo/_base/declare", "dojo/_base/lang", "ecm/model/ContentItem", "ecm/model/WorkItem", "ecm/model/Teamspace", "ecm/model/Favorite", "ecm/model/_SearchTemplateBase", "ecm/model/FavoritesResultSet", "./_ModelObject"], function (declare, lang, ContentItem, WorkItem, Teamspace, Favorite, SearchTemplateBase, FavoritesResultSet, _ModelObject) {
        return declare("ecm.model.Action", [_ModelObject], {subActions:null, repositoryTypes:"", multiDoc:false, global:false, privileges:null, action:null, pluginId:null, constructor:function () {
            if (!this.subActions) {
                this.subActions = [];
            }
            if (this.label) {
                this.name = this.label;
                delete this.label;
            }
            if (this.serverTypes) {
                this.repositoryTypes = this.serverTypes;
                delete this.serverTypes;
            }
            if (this.privilegeName) {
                this.privileges = this.privilegeName.split(",");
                delete this.privilegeName;
            }
        }, isVisible:function (repository, items) {
            if (this.repositoryTypes == null || this.repositoryTypes == "") {
                return this._isVisibleForItems(repository, items);
            } else {
                if (repository) {
                    var serverTypes = this.repositoryTypes.split(",");
                    for (i in serverTypes) {
                        if (serverTypes[i] == repository.type) {
                            return this._isVisibleForItems(repository, items);
                        }
                    }
                    return false;
                } else {
                    return false;
                }
            }
        }, _isVisibleForItems:function (repository, items) {
            var isVisible = true;
            if (this.id == "EditTeamspaceClasses") {
                if (items[0].item) {
                    isVisible = items[0].item.usesClasses;
                } else {
                    isVisible = items[0].usesClasses;
                }
            } else {
                if (this.id == "EditTeamspaceEntryTemplates") {
                    if (items[0].item) {
                        isVisible = !items[0].item.usesClasses;
                    } else {
                        isVisible = !items[0].usesClasses;
                    }
                } else {
                    if (this.id == "CreateTemplate") {
                        isVisible = repository.getPrivilege("addTeamspaceTemplate");
                    } else {
                        if (this.id == "CreateTeamSpace") {
                            isVisible = repository.getPrivilege("addTeamspace");
                        } else {
                            if (this.id == "ManageTeamspaces") {
                                isVisible = repository.getPrivilege("manageTeamspace");
                            } else {
                                if (this.id == "TransferWorkflow") {
                                    var item = items[0].item ? items[0].item : items[0];
                                    if ((item.mimetype == "") || (item.getMimeClass() != "ftWorkflow")) {
                                        isVisible = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return isVisible;
        }, isEnabled:function (repository, listType, items, teamspace, resultSet) {
            return this.canPerformAction(repository, items, listType, teamspace, resultSet);
        }, canPerformAction:function (repository, itemList, listType, teamspace, resultSet) {
            var canPerform = true;
            var items = [];
            if ((resultSet && resultSet.isInstanceOf && resultSet.isInstanceOf(ecm.model.FavoritesResultSet)) || listType == "Favorites") {
                if (!itemList || itemList.length == 0) {
                    return false;
                }
                if ((this.id != "DeleteFavorite" && this.id != "Edit" && this.id != "SearchProperties") && itemList.length > 1) {
                    return false;
                }
                items = [];
                for (var i in itemList) {
                    items.push(itemList[i].item ? itemList[i].item : itemList[i]);
                }
            } else {
                items = itemList;
            }
            if (this.global) {
                switch (this.id) {
                  case "Undo":
                    canPerform = ecm.model.desktop.canUndo();
                    break;
                  case "Redo":
                    canPerform = ecm.model.desktop.canRedo();
                    break;
                  case "CreateHold":
                    if (!repository || !repository.privileges || !repository.getPrivilege("createHold")) {
                        canPerform = false;
                    }
                    break;
                  case "Import":
                  case "CreateFolder":
                    if (items && (items.length > 0)) {
                        if (items.length > 1) {
                            canPerform = false;
                        } else {
                            if (this.id == "Import") {
                                if (!items[0].hasPrivilege("privAddItem") || !items[0].hasPrivilege("privAddToFolder")) {
                                    canPerform = false;
                                }
                            } else {
                                if (!items[0].hasPrivilege("privAddLink")) {
                                    canPerform = false;
                                }
                            }
                        }
                    } else {
                        if (this.privileges && repository.connected) {
                            if (repository.rootItem != null && repository.rootItem.hasPrivilege("privAddLink") == false) {
                                canPerform = false;
                            } else {
                                for (var i = 0; i < this.privileges.length && canPerform; i++) {
                                    if (!repository.getPrivilege(this.privileges[i])) {
                                        canPerform = false;
                                    }
                                }
                                if (canPerform) {
                                    canPerform = !ecm.model.desktop.fileIntoFolder || repository.getPrivilege("foldering");
                                }
                            }
                        }
                    }
                    break;
                  case "ImportUsingTemplate":
                  case "CreateFolderUsingTemplate":
                    if (items != null && items[0].hasPrivilege("privNone")) {
                        canPerform = false;
                    } else {
                        if (this.privileges && repository.connected) {
                            for (var i = 0; i < this.privileges.length && canPerform; i++) {
                                if (!repository.getPrivilege(this.privileges[i])) {
                                    canPerform = false;
                                }
                            }
                        }
                        if (canPerform && teamspace) {
                            canPerform = false;
                        }
                    }
                    break;
                  case "OpenFolder":
                    if (items[0].isInstanceOf && items[0].isInstanceOf(ecm.model.ContentItem) && items[0].parent != null && items[0].parent.isInstanceOf && items[0].parent.isInstanceOf(ecm.model.WorkItem)) {
                        canPerform = false;
                    }
                    break;
                  case "OpenSearchNewTab":
                    if (listType == "ProcessAttachments") {
                        canPerform = false;
                    } else {
                        canPerform = !items[0].isNew();
                    }
                    break;
                  case "EditSearch":
                    canPerform = !items[0].isNew() && items[0].isNavigatorSavedSearch() && (items[0].hasPrivilege("privMajorVersion") || (items[0].hasPrivilege("privCheckInOutDoc") && items[0].hasPrivilege("privEditProperties")));
                    break;
                  case "SearchProperties":
                    canPerform = false;
                    if (items.length == 1) {
                        if (!items[0].isNew()) {
                            canPerform = true;
                        }
                    } else {
                        for (var index in items) {
                            var item = items[index];
                            if ((item.repository.type == "p8" || item.repository.type == "cm" || item.repository.type == "cmis") && item.hasPrivilege("privEditProperties") && !item.isNew()) {
                                canPerform = true;
                                break;
                            }
                        }
                    }
                    break;
                  case "AddToFavorites":
                    if (items[0].hasPrivilege("privNone")) {
                        canPerform = false;
                    } else {
                        if (item.repository.type == "cmis") {
                            if (item.getValue("cmis:versionSeriesCheckedOutId") && item.getValue("cmis:objectId") && item.getValue("cmis:versionSeriesCheckedOutId") == item.getValue("cmis:objectId")) {
                                canPerform = false;
                            }
                        }
                    }
                    break;
                  case "PrintDoc":
                    var item = items[0];
                    if (!item.hasPrivilege("privPrintDoc") || !item.hasPrivilege("privViewDoc") || item.mimetype == "" || item.isFolder() || item.deleted || !item.hasContent() || (item.getMimeClass() == "ftExternalFile")) {
                        canPerform = false;
                    }
                    break;
                  case "EditTeamspaceTeam":
                    if (items[0].isInstanceOf && items[0].isInstanceOf(ecm.model.Teamspace)) {
                        if (items[0].state == "deleted") {
                            canPerform = false;
                        } else {
                            if (!items[0].hasPrivilege("addRemoveRoleParticipants")) {
                                canPerform = false;
                            }
                        }
                    }
                    break;
                  case "AddDocFromRepo":
                    if (items[0] && (items[0].length > 0)) {
                        if (items.length > 1) {
                            canPerform = false;
                        } else {
                            canPerform = item.isFolder();
                            if (canPerform && !items[0].hasPrivilege("privAddItem") || !items[0].hasPrivilege("privAddToFolder")) {
                                canPerform = false;
                            }
                            if (canPerform && teamspace && !teamspace.hasPrivilege("createNewSearches")) {
                                canPerform = false;
                            }
                        }
                    }
                    break;
                  case "EditTeamspaceRoles":
                    if (items[0].isInstanceOf && items[0].isInstanceOf(ecm.model.Teamspace)) {
                        if (items[0].state == "deleted") {
                            canPerform = false;
                        } else {
                            if (!items[0].hasPrivilege("modifyRoles")) {
                                canPerform = false;
                            }
                        }
                    }
                    break;
                  case "EditTeamspaceSearches":
                    if (items[0].isInstanceOf && items[0].isInstanceOf(ecm.model.Teamspace)) {
                        if (items[0].state == "deleted") {
                            canPerform = false;
                        } else {
                            if (!items[0].hasPrivilege("addNewSearches")) {
                                canPerform = false;
                            }
                        }
                    }
                    break;
                  case "EditTeamspaceClasses":
                    if (items[0].isInstanceOf && items[0].isInstanceOf(ecm.model.Teamspace)) {
                        if (items[0].state == "deleted") {
                            canPerform = false;
                        } else {
                            if (!items[0].hasPrivilege("addRemoveClassesOrEntryTemplates")) {
                                canPerform = false;
                            }
                        }
                    }
                    break;
                  case "EditTeamspaceEntryTemplates":
                    if (items[0].isInstanceOf && items[0].isInstanceOf(ecm.model.Teamspace)) {
                        if (items[0].state == "deleted") {
                            canPerform = false;
                        } else {
                            if (!items[0].hasPrivilege("addRemoveClassesOrEntryTemplates")) {
                                canPerform = false;
                            }
                        }
                    }
                    break;
                  case "CreateTeamSpace":
                    break;
                  case "CreateTemplate":
                    break;
                  case "WorkspaceProperties":
                    if (teamspace && teamspace.type == "instance") {
                        if (teamspace.state == "deleted") {
                            canPerform = false;
                        } else {
                            if (teamspace.repository._isCM()) {
                                canPerform = teamspace.hasPrivilege("privOwner");
                            } else {
                                canPerform = teamspace.hasPrivilege("modifyFolderProperties");
                            }
                        }
                    } else {
                        if (canPerform && !items[0].hasPrivilege("privEdit")) {
                            canPerform = false;
                        }
                    }
                    break;
                  default:
                    canPerform = true;
                }
                return canPerform;
            }
            if (!items || items.length < 1 || (items.length > 1 && !this.multiDoc)) {
                return false;
            }
            if (this.id == "SendAttachments" && navigator.appVersion.indexOf("Mac") != -1) {
                return false;
            }
            if (this.id == "DownloadAsPdf" || this.id == "StartWF" || this.id == "ApplyHold") {
                canPerform = true;
                for (var i = 0; i < items.length && canPerform; i++) {
                    var item = items[i];
                    if (this.id == "ApplyHold") {
                        canPerform = item.hasPrivilege("privHold");
                    } else {
                        if (repository && repository._isOnDemand() && item.mimetype == "application/afp") {
                            canPerform = false;
                        } else {
                            if (item.isInstanceOf && item.isInstanceOf(ecm.model._SearchTemplateBase)) {
                                canPerform = false;
                            } else {
                                if (this.id == "DownloadAsPdf" && !items[i].hasContent()) {
                                    canPerform = false;
                                }
                            }
                        }
                    }
                }
                if (!canPerform) {
                    return false;
                }
            }
            canPerform = this.id == "PrintDoc" ? true : false;
            var parentFolderId = null;
            var userId = repository ? repository.userId : "";
            var multiSelectValid = false;
            var isDoneChecking = false;
            for (var i = 0; i < items.length && !isDoneChecking; i++) {
                var item = items[i];
                var lockedUser = "";
                if (!item.isInstanceOf(ecm.model.Teamspace)) {
                    lockedUser = item && item.lockedUser ? item.lockedUser : "";
                }
                if (!this.repositoryTypes || this.repositoryTypes == "" || (item.repository && this.repositoryTypes.indexOf(item.repository.type) || !item.repository) >= 0) {
                    if (this.privileges && !item.isInstanceOf(ecm.model.Teamspace)) {
                        for (var j = 0; j < this.privileges.length && !canPerform; j++) {
                            var privilege = this.privileges[j];
                            if (item) {
                                if (item.hasPrivilege(privilege)) {
                                    if (privilege == "privPrintDoc") {
                                        canPerform &= true;
                                    } else {
                                        canPerform = true;
                                    }
                                } else {
                                    if (privilege == "privPrintDoc") {
                                        canPerform &= false;
                                    } else {
                                        canPerform = false;
                                    }
                                }
                            } else {
                                canPerform = false;
                            }
                        }
                    } else {
                        canPerform = true;
                    }
                    if (item && item.hasPrivilege("privNone")) {
                        canPerform = false;
                    }
                    if (canPerform) {
                        switch (this.id) {
                          case "DeleteWorkspace":
                            if (items[0].isInstanceOf && items[0].isInstanceOf(ecm.model.Teamspace)) {
                                if (items[0].state == "deleted") {
                                    canPerform = false;
                                } else {
                                    if (items[0].repository._isCM()) {
                                        if (items[0].type == ecm.model.Teamspace.TEMPLATE) {
                                            if (!items[0].hasPrivilege("privDelete")) {
                                                canPerform = false;
                                            }
                                        } else {
                                            if (!items[0].hasPrivilege("privOwner")) {
                                                canPerform = false;
                                            }
                                        }
                                    } else {
                                        if (!items[0].hasPrivilege("privDelete") && !items[0].hasPrivilege("deleteItems")) {
                                            canPerform = false;
                                        }
                                    }
                                }
                            }
                            break;
                          case "EditWorkspace":
                            if (items[0].state == "deleted") {
                                canPerform = false;
                            } else {
                                if (!items[0].hasPrivilege("privEdit")) {
                                    canPerform = false;
                                }
                            }
                            break;
                          case "MakeWorkspaceTemplateDefault":
                            canPerform = items[0].state != "offline" && items[0].state != "default" && items[0].state != "validate";
                            if (canPerform && !items[0].hasPrivilege("privEdit")) {
                                canPerform = false;
                            }
                            break;
                          case "DisableWorkspace":
                            canPerform = (items[0].state == "published" || items[0].state == "default");
                            if (canPerform && !items[0].hasPrivilege("privEdit")) {
                                canPerform = false;
                            }
                            break;
                          case "EnableWorkspace":
                            canPerform = items[0].state == "offline";
                            if (canPerform && !items[0].hasPrivilege("privEdit")) {
                                canPerform = false;
                            }
                            break;
                          case "ValidateWorkspace":
                            canPerform = items[0].state == "validate";
                            if (canPerform && !items[0].hasPrivilege("privEdit")) {
                                canPerform = false;
                            }
                            break;
                          case "PrintDoc":
                            if (!item.hasPrivilege("privPrintDoc") || !item.hasPrivilege("privViewDoc") || (item.mimetype == "") || item.isFolder() || item.deleted || !item.hasContent() || (item.getMimeClass() == "ftExternalFile") || item.getMimeClass() == "ftPolicyDocument" || item.getMimeClass() == "ftFormData" || item.getMimeClass() == "ftFormTemplate") {
                                canPerform &= false;
                            }
                            break;
                          case "Lock":
                            canPerform = !item.locked;
                            break;
                          case "Unlock":
                            if (!repository || (!repository._isP8() && !repository._isCmis())) {
                                canPerform = item.locked;
                            }
                            if (canPerform && repository && repository._isCM() && ((resultSet && resultSet.context && resultSet.context == "PropertiesVersions") || (resultSet && resultSet._moreOptions && resultSet._moreOptions.versionOption == "allversions"))) {
                                canPerform = false;
                            }
                            break;
                          case "CheckOut":
                          case "CheckOutDownload":
                          case "CheckOutLabelWithDownload":
                          case "CheckOutNoDownload":
                            if (item.isFolder() == true) {
                                canPerform = false;
                            } else {
                                if (lockedUser && lockedUser.length > 0) {
                                    canPerform = false;
                                } else {
                                    if (item.hasPrivilege("privCheckOutDoc") == false) {
                                        canPerform = false;
                                    } else {
                                        if ((this.id == "CheckOutDownload") && ((item.hasPrivilege("privExport") == false) || (item.hasContent() == false))) {
                                            canPerform = false;
                                        } else {
                                            if (repository && repository._isP8()) {
                                                if ((resultSet && resultSet.context && resultSet.context == "PropertiesVersions") || (resultSet && resultSet._moreOptions && resultSet._moreOptions.versionOption == "allversions")) {
                                                    if (items.length == 1) {
                                                        canPerform = item.currentVersion;
                                                    } else {
                                                        canPerform = false;
                                                    }
                                                }
                                                if (canPerform && (item.getMimeClass() == "ftPolicyDocument" || item.getMimeClass() == "ftFormData")) {
                                                    canPerform = false;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (items.length > 1) {
                                if (canPerform == true) {
                                    multiSelectValid = canPerform;
                                }
                                if (i + 1 >= items.length) {
                                    canPerform = multiSelectValid;
                                }
                            }
                            break;
                          case "CheckIn":
                            if (item.isFolder()) {
                                canPerform = false;
                            } else {
                                if (!repository || (!repository._isP8() && !repository._isCmis())) {
                                    if (userId != null && userId.length > 0) {
                                        canPerform = (userId && lockedUser && userId.toUpperCase() == lockedUser.toUpperCase());
                                    }
                                    if (canPerform && repository && repository._isCM()) {
                                        if (resultSet && resultSet.context && resultSet.context == "PropertiesVersions") {
                                            if (items.length == 1) {
                                                canPerform = item.currentVersion;
                                            } else {
                                                canPerform = false;
                                            }
                                        } else {
                                            if (resultSet && resultSet._moreOptions && resultSet._moreOptions.versionOption == "allversions") {
                                                canPerform = false;
                                            }
                                        }
                                    }
                                } else {
                                    if (repository && repository._isP8()) {
                                        if (item.getMimeClass() == "ftPolicyDocument" || item.getMimeClass() == "ftFormData") {
                                            canPerform = false;
                                        }
                                    }
                                }
                            }
                            break;
                          case "EditDoc":
                            if (repository && repository._isCM() && resultSet && resultSet._moreOptions && resultSet._moreOptions.versionOption == "allversions") {
                                canPerform = false;
                            }
                            break;
                          case "DeleteItem":
                            if (repository && repository._isCM() && userId != null && userId.length > 0) {
                                canPerform = (!lockedUser || lockedUser.length == 0 || (userId && userId.toUpperCase() == lockedUser.toUpperCase()));
                            }
                            if (canPerform && repository && repository._isP8() && (resultSet && resultSet.context && resultSet.context == "PropertiesVersions")) {
                                canPerform = (item.versionStatusInt != ecm.model.ContentItem.P8_VERSION_STATUS.RESERVED);
                            }
                            if (items.length > 1) {
                                if (canPerform == true) {
                                    multiSelectValid = canPerform;
                                }
                                if (i + 1 >= items.length) {
                                    canPerform = multiSelectValid;
                                }
                            }
                            break;
                          case "RemoveHold":
                            canPerform = item.hasHold;
                            break;
                          case "Download":
                            canPerform = !item.isFolder();
                            canPerform = (item.hasContent && !item.hasContent()) ? false : canPerform;
                            if (canPerform && repository && repository._isP8() && (resultSet && resultSet.context && resultSet.context == "PropertiesVersions")) {
                                canPerform = item.hasContent() && (item.versionStatusInt != ecm.model.ContentItem.P8_VERSION_STATUS.RESERVED);
                            }
                            break;
                          case "DownloadAsOriginal":
                            canPerform = item.hasContent();
                            break;
                          case "DownloadAsPdf":
                            if (canPerform && repository && repository._isP8()) {
                                if (item.getMimeClass() == "ftPolicyDocument" || item.getMimeClass() == "ftFormData" || item.getMimeClass() == "ftFormTemplate") {
                                    canPerform = false;
                                }
                            }
                            break;
                          case "DownloadAll":
                            canPerform = !item.isFolder();
                            canPerform = (item.hasContent && !item.hasContent()) ? false : canPerform;
                            if (canPerform && repository && repository._isP8() && (resultSet && resultSet.context && resultSet.context == "PropertiesVersions")) {
                                canPerform = item.hasContent() && (item.versionStatusInt != ecm.model.ContentItem.P8_VERSION_STATUS.RESERVED);
                            }
                            break;
                          case "RemoveFromFolder":
                            canPerform = this._canPerformDefaultFolderActions(item, repository);
                            if ((canPerform == true) && (items.length > 1)) {
                                if (resultSet && resultSet._moreOptions && resultSet._moreOptions.versionOption == "allversions") {
                                    canPerform = false;
                                } else {
                                    var parent = item.parent;
                                    if (parent == null) {
                                        canPerform = false;
                                    } else {
                                        if (parent.isFolder() == false) {
                                            canPerform = false;
                                        } else {
                                            if (parent.hasPrivilege("privRemoveFromFolder") == false) {
                                                canPerform = false;
                                            } else {
                                                if (parentFolderId == null) {
                                                    parentFolderId = parent.id;
                                                } else {
                                                    if (parentFolderId != parent.id) {
                                                        canPerform = false;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            break;
                          case "MoveDocumentToFolder":
                            canPerform = this._canPerformDefaultFolderActions(item, repository);
                            if ((canPerform == true) && (items.length > 1) && resultSet && resultSet._moreOptions && (resultSet._moreOptions.versionOption == "allversions")) {
                                canPerform = false;
                            }
                            break;
                          case "MoveFolderToFolder":
                            if ((items.length > 1) && resultSet && resultSet._moreOptions && (resultSet._moreOptions.versionOption == "allversions")) {
                                canPerform = false;
                            } else {
                                if ((item.isInstanceOf && item.isInstanceOf(ecm.model.ContentItem) && item.rootFolder == true) || (item.attributes.PathName != null && item.attributes.PathName == "/")) {
                                    canPerform = false;
                                }
                            }
                            break;
                          case "AddToFolder":
                            canPerform = this._canPerformDefaultFolderActions(item, repository);
                            if ((canPerform == true) && (items.length > 1) && resultSet && resultSet._moreOptions && (resultSet._moreOptions.versionOption == "allversions")) {
                                canPerform = false;
                            } else {
                                if (item.repository && (item.repository.id != repository.id)) {
                                    canPerform = false;
                                }
                            }
                            break;
                          case "DemoteVersion":
                            canPerform = false;
                            if ((item.hasPrivilege("privMajorVersion") && (item.versionStatusInt == ecm.model.ContentItem.P8_VERSION_STATUS.RELEASED) && (item.currentVersion) && (!item.locked))) {
                                canPerform = true;
                            }
                            break;
                          case "PromoteVersion":
                            canPerform = false;
                            if ((item.hasPrivilege("privMajorVersion") && (item.versionStatusInt == ecm.model.ContentItem.P8_VERSION_STATUS.IN_PROCESS) && (item.currentVersion) && (!item.locked))) {
                                canPerform = true;
                            }
                            break;
                          case "MoveToInbox":
                            if (item.parent.queueType != "processQueue") {
                                canPerform = false;
                            }
                            break;
                          case "Reassign":
                            canPerform = false;
                            if (item.hasPrivilege("privCanReassign")) {
                                canPerform = true;
                            }
                            break;
                          case "Launch":
                          case "StartWF":
                            if (resultSet) {
                            }
                            break;
                          case "ResumeWF":
                            if (item.isInstanceOf && item.isInstanceOf(ecm.model.WorkItem) && !item.isSuspended) {
                                canPerform = false;
                            }
                            break;
                          case "OpenStep":
                            if (item.repository.type == "cmis" || item.repository.type == "p8") {
                                canPerform = false;
                            }
                            break;
                          case "EditWF":
                          case "SuspendWF":
                          case "ContinueWF":
                            if (item.isInstanceOf && item.isInstanceOf(ecm.model.WorkItem) && item.isSuspended) {
                                canPerform = false;
                            }
                            break;
                          case "TransferWorkflow":
                            if ((item.mimetype == "") || item.isFolder() || (item.getMimeClass() != "ftWorkflow")) {
                                canPerform = false;
                            }
                            break;
                          case "Preview":
                            if (repository && repository._isOnDemand()) {
                                canPerform = false;
                            } else {
                                if (canPerform && repository && repository._isP8()) {
                                    if (resultSet && resultSet.context && resultSet.context == "PropertiesVersions") {
                                        canPerform = item.hasContent() && (item.versionStatusInt != ecm.model.ContentItem.P8_VERSION_STATUS.RESERVED);
                                    }
                                    if (canPerform) {
                                        var mimeClass = item.getMimeClass();
                                        if (mimeClass == "ftPolicyDocument" || mimeClass == "ftFormData" || mimeClass == "ftFormTemplate" || item.mimetype == "application/x-filenet-external") {
                                            canPerform = false;
                                        }
                                    }
                                } else {
                                    if (canPerform && repository && repository._isCmis()) {
                                        canPerform = item.hasContent();
                                    }
                                }
                            }
                            break;
                          case "SendLinksToDocs":
                          case "SendAttachments":
                          case "ShowHyperlink":
                            if (canPerform && repository && repository._isP8() && (resultSet && resultSet.context && resultSet.context == "PropertiesVersions")) {
                                canPerform = item.hasContent() && (item.versionStatusInt != ecm.model.ContentItem.P8_VERSION_STATUS.RESERVED);
                            }
                            break;
                          case "OpenSearch":
                          case "OpenSearchInTab":
                            if (listType == "ProcessAttachments") {
                                canPerform = false;
                            }
                            break;
                          case "View":
                            if (canPerform && repository && repository._isP8() && (resultSet && resultSet.context && resultSet.context == "PropertiesVersions")) {
                                canPerform = (item.hasContent() || (item.getMimeClass() == "ftExternalFile")) && (item.versionStatusInt != ecm.model.ContentItem.P8_VERSION_STATUS.RESERVED);
                            }
                            break;
                          case "AddToFavorites":
                            if (item.repository.type == "cmis") {
                                if (item.getValue("cmis:versionSeriesCheckedOutId") && item.getValue("cmis:objectId") && item.getValue("cmis:versionSeriesCheckedOutId") == item.getValue("cmis:objectId")) {
                                    canPerform = false;
                                }
                            }
                            break;
                          case "Edit":
                            if (items.length > 1) {
                                if ((item.repository.type == "p8" || item.repository.type == "cm" || item.repository.type == "cmis") && item.hasPrivilege("privEditProperties")) {
                                    multiSelectValid = true;
                                    isDoneChecking = true;
                                }
                                if (i + 1 >= items.length || isDoneChecking) {
                                    canPerform = multiSelectValid;
                                }
                            }
                        }
                    }
                } else {
                    canPerform = false;
                }
                if (!isDoneChecking) {
                    if (this.id != "PrintDoc" && this.id != "Edit") {
                        isDoneChecking = canPerform;
                    }
                }
            }
            return canPerform;
        }, _canPerformDefaultFolderActions:function (item, repository) {
            if (!repository.getPrivilege("foldering")) {
                return false;
            } else {
                if (item.isInstanceOf && item.isInstanceOf(ecm.model._SearchTemplateBase)) {
                    return !item.isNew();
                } else {
                    return !item.isFolder();
                }
            }
        }, isGlobalEnabled:function (resultSet, items) {
            var repo = resultSet.repository;
            if (this.id == "CreateHold" && (repo && !repo.getPrivilege("createHold"))) {
                return false;
            } else {
                if (this.id == "Import" || this.id == "CreateFolder") {
                    var parentFolder = resultSet.parentFolder;
                    if (parentFolder && parentFolder.isFolder && parentFolder.isFolder() && !parentFolder.rootFolder) {
                        return this.canPerformAction(repo, [parentFolder]);
                    } else {
                        if (parentFolder && parentFolder.isInstanceOf && parentFolder.isInstanceOf(ecm.model.Favorite)) {
                            if (parentFolder.item && parentFolder.item.rootFolder) {
                                if (parentFolder.item.rootFolder) {
                                    return repo ? repo.getPrivilege("addItem") : false;
                                } else {
                                    return this.canPerformAction(repo, [parentFolder]);
                                }
                            } else {
                                return false;
                            }
                        } else {
                            if (this.id == "CreateFolder" && parentFolder && parentFolder.isFolder && parentFolder.isFolder() && parentFolder.isRootFolder && parentFolder.rootFolder) {
                                return parentFolder.hasPrivilege("privAddLink");
                            } else {
                                return repo ? (repo.getPrivilege("addItem") && (!ecm.model.desktop.fileIntoFolder || repo.getPrivilege("foldering"))) : false;
                            }
                        }
                    }
                } else {
                    if (resultSet && resultSet.isInstanceOf && resultSet.isInstanceOf(ecm.model.FavoritesResultSet)) {
                        if (!items || items.length == 0) {
                            return false;
                        } else {
                            if (this.id == "DeleteFavorite") {
                                return true;
                            } else {
                                if (items.length == 1) {
                                    return true;
                                } else {
                                    return false;
                                }
                            }
                        }
                    } else {
                        return true;
                    }
                }
            }
        }, performAction:function (repository, itemList, callback, teamspace, resultSet, parameterMap) {
            ecm.model.desktop.getActionsHandler(lang.hitch(this, function (actionsHandler) {
                var action = this.action || "action" + this.id;
                var items = [];
                if (itemList && itemList[0] && itemList[0].isInstanceOf && itemList[0].isInstanceOf(ecm.model.Favorite) && this.id != "RenameFavorite" && this.id != "DeleteFavorite" && this.id != "OpenFolder") {
                    for (var i in itemList) {
                        items.push(itemList[i].item);
                    }
                } else {
                    items = itemList;
                }
                if (actionsHandler && actionsHandler[action]) {
                    actionsHandler[action](repository, items, callback, teamspace, resultSet, parameterMap, this);
                } else {
                    if (window && window[action]) {
                        window[action](repository, items, callback, teamspace, resultSet, parameterMap, this);
                    } else {
                        this.logError("performAction", "action " + action + " not implemented.");
                    }
                }
            }));
        }});
    });
}, "ecm/model/ProcessInbasket":function () {
    define("ecm/model/ProcessInbasket", ["dojo/_base/declare", "dojo/_base/lang", "dojo/json", "./Worklist", "./ContentClass", "./AttributeDefinition", "./ResultSet"], function (declare, lang, dojojson, Worklist, ContentClass, AttributeDefinition, ResultSet) {
        return declare("ecm.model.ProcessInbasket", [Worklist], {parent:null, attributes:null, queueType:null, queueName:null, fetchCount:0, filterClass:null, filterValues:null, pageSize:null, connectionPoint:null, mergeBoundUser:false, constructor:function (params) {
            if (!this.attributes) {
                this.attributes = {};
            }
            this._attributeTypes = {};
            this._attributeFormats = {};
            if (params) {
                var attributes = {};
                for (var i in params.attributes) {
                    var jsonAttribute = params.attributes[i];
                    attributes[i] = jsonAttribute[0];
                    if (jsonAttribute.length > 1) {
                        this._attributeTypes[i] = jsonAttribute[1];
                    }
                    if (jsonAttribute.length > 2) {
                        this._attributeFormats[i] = jsonAttribute[2];
                    }
                }
                this.attributes = attributes;
            }
        }, containsValue:function (attribute, value) {
            var v = this.attributes[attribute];
            if (value == v) {
                return true;
            } else {
                if (lang.isArray(v)) {
                    for (var i in v) {
                        if (value == v[i]) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }, getValue:function (attribute) {
            return this.attributes[attribute];
        }, getValues:function (attribute) {
            var v = this.attributes[attribute];
            if (lang.isArray(v)) {
                return v;
            } else {
                return [v];
            }
        }, hasAttribute:function (attribute) {
            return (typeof this.attributes[attribute] != "undefined");
        }, getAttributeType:function (attribute) {
            return this._attributeTypes[attribute];
        }, getAttributeFormat:function (attribute) {
            return this._attributeFormats[attribute];
        }, retrieveWorkItems:function (callback, orderBy, descending, refresh, filters, queryFilter, substitutionVars) {
            if (orderBy) {
                this._orderBy = this._prevOrderBy = orderBy;
                this._descending = this._prevDescending = descending;
            } else {
                if (refresh) {
                    orderBy = this._prevOrderBy;
                    descending = this._prevDescending;
                }
            }
            var request = ecm.model.Request.invokeService("getWorkItems", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, inbasket_name:encodeURIComponent(this.id), processrole_name:encodeURIComponent(this.parent.name), appspace_name:encodeURIComponent(this.parent.parent.id), order_by:this._orderBy ? orderBy : "", order_descending:this._descending ? "true" : "false", filter_criteria:filters ? encodeURIComponent(filters) : "", pageSize:this.pageSize, merge_bound_user:this.mergeBoundUser ? "true" : "false", query_filter:queryFilter ? encodeURIComponent(queryFilter) : "", query_substitution_vars:substitutionVars ? encodeURIComponent(dojojson.stringify(substitutionVars)) : ""}, lang.hitch(this, function (response) {
                this._retrieveWorkItemsCompleted(response, callback);
            }));
            return request;
        }, _retrieveWorkItemsCompleted:function (response, callback) {
            if (response.fetchCount) {
                this.fetchCount = response.fetchCount;
            }
            response.repository = this.repository;
            response.parentFolder = this;
            response.setType = "workItems";
            var resultSet = new ecm.model.ResultSet(response);
            if (this.pageSize && this.pageSize > 0) {
                resultSet.pageSize = this.pageSize;
            }
            callback(resultSet);
            this.message = response.messages[0];
        }, retrieveQueueItems:function (callback, refresh, filters) {
            var request = ecm.model.Request.invokeService("getInboxWorkItems", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, queue_name:encodeURIComponent(this.queueName)}, lang.hitch(this, function (response) {
                this._retrieveQueueItemsCompleted(response, callback);
            }));
            return request;
        }, _retrieveQueueItemsCompleted:function (response, callback) {
            if (response.fetchCount) {
                this.fetchCount = response.fetchCount;
            }
            response.repository = this.repository;
            response.parentFolder = this;
            response.setType = "workItems";
            var results = new ecm.model.ResultSet(response);
            callback(results);
            this.message = response.messages[0];
        }, retrieveFilterCriteria:function (callback) {
            var request = ecm.model.Request.invokeService("getFilterCriteria", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, processrole_name:encodeURIComponent(this.parent.name), appspace_name:encodeURIComponent(this.parent.parent.id), inbasket_name:encodeURIComponent(this.id), merge_bound_user:this.mergeBoundUser ? "true" : "false"}, lang.hitch(this, function (response) {
                this._retrieveFilterCriteriaCompleted(response, callback);
            }));
        }, _retrieveFilterCriteriaCompleted:function (response, callback) {
            if (response.criterias) {
                this.filterClass = new ContentClass({id:"FilterClass", name:"FilterClass", repository:this.repository, pseudoClass:true, allowsInstances:false});
                var filterCriterias = [];
                for (var i in response.criterias) {
                    var filter = response.criterias[i];
                    var filterId = filter.name;
                    filterCriterias.push(this._createFilterCriteria(filter));
                }
                this.filterClass.attributeDefinitions = filterCriterias;
            }
            if (callback) {
                callback(this.filterClass);
            }
        }, _createFilterCriteria:function (filter) {
            var attributeDefinition = new AttributeDefinition({id:filter.name, name:filter.label, repositoryType:this.repository.type, dataType:filter.dataType, defaultValue:filter.value, required:filter.required, readOnly:filter.readOnly, hidden:filter.hidden, system:filter.system, settability:"", maxLength:filter.maxEntry, minLength:filter.minEntry, minValue:filter.minValue, maxValue:filter.maxValue, cardinality:filter.cardinality, choiceList:filter.choiceList, contentClass:this.filterClass, searchable:false, promptText:filter.promptText, field:filter.field, operator:filter.operator});
            return attributeDefinition;
        }});
    });
}, "ecm/Logger":function () {
    define(["dojo/_base/declare", "dojo/_base/connect", "dojo/_base/lang"], function (declare, connect, lang) {
        var Logger = declare("ecm.Logger", null, {constructor:function () {
            this._logLevel = 0;
            this._appId = "CIWEB";
            this._logWindow = null;
            this._useConsole = true;
            this._initialized = false;
        }, getLogLevel:function () {
            return this._logLevel;
        }, getUseConsole:function () {
            return this._useConsole;
        }, initLogger:function (logLevel, useConsole) {
            if (!this._initialized) {
                if (typeof logLevel == "number") {
                    this._logLevel = logLevel;
                } else {
                    if (typeof logLevel == "string") {
                        this._logLevel = parseInt(logLevel);
                    }
                }
                if (!useConsole) {
                    this._useConsole = false;
                    this._setupLogWindow();
                }
                this._initialized = true;
            }
        }, _setupLogWindow:function () {
            if ((this._logLevel > 0) && (this._logWindow == null)) {
                this._logWindow = window.open("", "_blank", "width=500,height=500,location=0,menubar=0,resizable=1,scrollbars=1,status=0,titlebar=0,toolbar=0");
                if ((window.onunload == null) || (typeof window.onunload != "function")) {
                    window.onunload = lang.hitch(this, function () {
                        this._logWindow.close();
                        this._logWindow = null;
                    });
                } else {
                    var windowCloseLink = connect.connect(window, "onunload", this, function () {
                        this._logWindow.close();
                        this._logWindow = null;
                    });
                }
                var header = new Array("<style>", "*", "{", "font-family: fixed,monospace;", "font-size: x-small;", "white-space: nowrap;", "}", "</style>");
                for (var line = 0; line < header.length; line++) {
                    this._logWindow.document.writeln(header[line]);
                }
                this._logWindow.focus();
                window.focus();
            } else {
                if ((this._logLevel == 0) && (this._logWindow != null)) {
                    this._logWindow.close();
                    this._logWindow = null;
                }
            }
        }, isDebug:function () {
            return this._logLevel >= 4;
        }, logError:function (location, message, extra) {
            this._log(1, location, message, extra);
        }, logWarning:function (location, message, extra) {
            this._log(2, location, message, extra);
        }, logInfo:function (location, message, extra) {
            this._log(3, location, message, extra);
        }, logDebug:function (location, message, extra) {
            this._log(4, location, message, extra);
        }, logEntry:function (location, extra) {
            this._log(4, location, "ENTRY", extra);
        }, logExit:function (location, extra) {
            this._log(4, location, "EXIT", extra);
        }, _log:function (level, location, message, extra) {
            if (level <= this._logLevel) {
                var d = new Date();
                var logRecord = {level:level, timeStamp:d, loc:location, msg:message, extra:extra};
                var formattedLogRecord = this._formatLogRecord(logRecord);
                if (this._useConsole) {
                    console.log(formattedLogRecord);
                } else {
                    if (this._logWindow && (!this._logWindow.closed) && this._logWindow.document) {
                        try {
                            this._logWindow.document.writeln(formattedLogRecord);
                            this._logWindow.scrollBy(0, 100);
                        }
                        catch (err) {
                        }
                    }
                }
            }
        }, _formatLogRecord:function (logRecord) {
            var formattedLogRecord = this._useConsole ? "" : "<br>";
            var timestamp = logRecord.timeStamp;
            var hours = this._pad(timestamp.getHours(), 2);
            var minutes = this._pad(timestamp.getMinutes(), 2);
            var seconds = this._pad(timestamp.getSeconds(), 2);
            var milliseconds = this._pad(timestamp.getMilliseconds(), 3);
            formattedLogRecord += hours + ":" + minutes + ":" + seconds + "." + milliseconds + " ";
            formattedLogRecord += this._appId + " ";
            switch (logRecord.level) {
              case 1:
                formattedLogRecord += "ERROR:";
                break;
              case 2:
                formattedLogRecord += "WARN :";
                break;
              case 3:
                formattedLogRecord += "INFO :";
                break;
              case 4:
                if (logRecord.msg === "ENTRY") {
                    formattedLogRecord += "ENTRY:";
                    logRecord.msg = null;
                } else {
                    if (logRecord.msg === "EXIT") {
                        formattedLogRecord += "EXIT :";
                        logRecord.msg = null;
                    } else {
                        formattedLogRecord += "DEBUG:";
                    }
                }
                break;
            }
            formattedLogRecord += (" " + logRecord.loc);
            if (logRecord.msg != null) {
                formattedLogRecord += (" --- " + this._formatData(logRecord.msg));
            }
            if (logRecord.extra != null) {
                formattedLogRecord += (" --- " + this._formatData(logRecord.extra));
            }
            return formattedLogRecord;
        }, _formatData:function (data) {
            if (typeof (data) == "object") {
                var formatted = "{";
                for (var i in data) {
                    if (typeof (data[i]) != "function") {
                        if (formatted.length > 1) {
                            formatted += ",";
                        }
                        if (i == "password") {
                            formatted += i + ":" + this._blackoutPassword(data[i]);
                        } else {
                            formatted += i + ":" + data[i];
                        }
                    }
                }
                formatted += "}";
                return formatted;
            } else {
                return data;
            }
        }, _pad:function (number, length) {
            var str = "" + number;
            while (str.length < length) {
                str = "0" + str;
            }
            return str;
        }, _blackoutPassword:function (password) {
            var str = "";
            for (var i in password) {
                str += "*";
            }
            return str;
        }});
        ecm.logger = new Logger();
        return ecm.logger;
    });
}, "ecm/model/admin/FileTypeConfig":function () {
    define("ecm/model/admin/FileTypeConfig", ["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var FileTypeConfig = declare("ecm.model.admin.FileTypeConfig", [_ConfigurationObject], {NAME:"name", DESCRIPTION:"description", CONTENT_TYPES:"contentTypes", constructor:function (id, name) {
        }, getName:function () {
            return this.getValue(this.NAME);
        }, setName:function (name) {
            this.setValue(this.NAME, name);
        }, getDescription:function () {
            return this.getValue(this.DESCRIPTION);
        }, setDescription:function (description) {
            this.setValue(this.DESCRIPTION, description);
        }, getContentTypes:function () {
            return this.getValues(this.CONTENT_TYPES);
        }, setContentTypes:function (contentTypes) {
            this.setValue(this.CONTENT_TYPES, contentTypes);
        }});
        FileTypeConfig.createFileTypeConfig = function (id) {
            return new FileTypeConfig(id, "FileTypeConfig");
        };
        return FileTypeConfig;
    });
}, "ecm/model/UnifiedSearchTemplate":function () {
    define(["dojo/_base/array", "dojo/_base/declare", "dojo/_base/json", "dojo/_base/lang", "ecm/model/_SearchTemplateBase", "ecm/model/_ModelStore", "ecm/model/ChildComponentSearchCriteria", "ecm/model/ContentItem", "ecm/model/ResultSet", "ecm/model/SearchConfiguration", "ecm/model/SearchCriterion", "ecm/model/User"], function (array, declare, dojojson, lang, _SearchTemplateBase, _ModelStore, ChildComponentSearchCriteria, ContentItem, ResultSet, SearchConfiguration, SearchCriterion, User) {
        var UnifiedSearchTemplate = declare("ecm.model.UnifiedSearchTemplate", _SearchTemplateBase, {searchRepositories:null, attributeMappings:null, _init:function () {
            this.inherited(arguments);
            var repositories1 = this._getAttributeValue("IcnSearchingRepositories");
            var repositories2 = this._getAttributeValue("clbSearchingRepositories");
            this._repositories = (repositories1 || repositories2 || "").split(",");
        }, getContentType:function () {
            var contentType = this.inherited(arguments);
            return contentType.indexOf("application/x") == 0 ? contentType : "application/x-unifiedsearchtemplate";
        }, update:function (item, skipOnChange) {
            this.inherited(arguments);
            this._repositories = (this.attributes.IcnSearchingRepositories || this.attributes.clbSearchingRepositories || "").split(",");
        }, search:function (callback, sortProperty, descending, errorCallback) {
            var request = ecm.model.Request.postService("unifiedSearch", null, {desktop:ecm.model.desktop.id, template_name:this.id, vsId:this.vsId || "", order_by:sortProperty, order_descending:descending}, "text/json", this.searchCriteria ? this.toJson(true) : "{}", lang.hitch(this, function (response) {
                var results = new ecm.model.ResultSet(response);
                results.searchTemplate = this;
                results.setAttributeMappings(this.attributeMappings);
                results._moreOptions = this.moreOptions;
                if (callback) {
                    callback(results);
                }
                this.onSearchCompleted(results);
            }), false, false, false, function (response) {
                if (response.errors && errorCallback) {
                    errorCallback(response);
                }
            });
            return request;
        }, toJson:function () {
            var methodName = "toJson";
            var json = this.inherited(arguments);
            var toJson = function (item) {
                return item.toJson();
            };
            json.repositories = array.map(this.searchRepositories, toJson);
            json.mappings = array.map(this.attributeMappings, toJson);
            if (this.resultsDisplay && (!this.resultsDisplay.columns || this.resultsDisplay.columns.length < 1) && (!this.resultsDisplay.magazineColumns || this.resultsDisplay.magazineColumns.length < 1)) {
                json.resultsDisplay = null;
            }
            json = dojojson.toJson(json);
            return json;
        }, containsEqualCriteria:function (searchTemplate) {
            if (!this.inherited(arguments)) {
                return false;
            }
            if (this.searchRepositories instanceof Array != searchTemplate.searchRepositories instanceof Array) {
                return false;
            }
            if (this.searchRepositories instanceof Array) {
                if (this.searchRepositories.length != searchTemplate.searchRepositories.length) {
                    return false;
                }
                if (!array.every(this.searchRepositories, function (repository, i) {
                    return repository.equals(searchTemplate.searchRepositories[i]);
                })) {
                    return false;
                }
            }
            if (this.attributeMappings instanceof Array != searchTemplate.attributeMappings instanceof Array) {
                return false;
            }
            if (this.attributeMappings instanceof Array) {
                if (this.attributeMappings.length != searchTemplate.attributeMappings.length) {
                    return false;
                }
                if (!array.every(this.attributeMappings, function (mapping, i) {
                    return mapping.equals(searchTemplate.attributeMappings[i]);
                })) {
                    return false;
                }
            }
            return true;
        }, clone:function () {
            var clone = this.inherited(arguments);
            var cloneIt = function (item) {
                return item.clone();
            };
            clone.searchRepositories = this.searchRepositories ? array.map(this.searchRepositories, cloneIt) : null;
            clone.attributeMappings = this.attributeMappings ? array.map(this.attributeMappings, cloneIt) : null;
            return clone;
        }});
        UnifiedSearchTemplate.instanceOf = function (itemJSON) {
            if (itemJSON.template == "IcnSearch") {
                return true;
            }
            if (itemJSON.template == "ICMSearch") {
                return itemJSON.attributes.clbSearchType[0] === 1;
            }
            return false;
        };
        UnifiedSearchTemplate.createFromJSON = function (itemJSON, repository, resultSet, parent) {
            var template = null;
            if (UnifiedSearchTemplate.instanceOf(itemJSON)) {
                template = new UnifiedSearchTemplate(itemJSON);
            }
            return template;
        };
        ContentItem.registerFactory(UnifiedSearchTemplate);
        return UnifiedSearchTemplate;
    });
}, "ecm/model/AttachmentItem":function () {
    define("ecm/model/AttachmentItem", ["dojo/_base/declare", "dojo/_base/lang", "./Item"], function (declare, lang, Item) {
        var AttachmentItem = declare("ecm.model.AttachmentItem", [Item], {connectionPoint:null, objectStore:null, authoredName:"", modified:false, getObjectStore:function () {
            if (!this.objectStore) {
                this.objectStore = this.objectStoreId ? {id:this.objectStoreId, symbolicName:this.objectStoreName, displayName:this.objectStoreDisplayName} : null;
            }
            return this.objectStore;
        }, getFolderContents:function () {
            return this._folderContents;
        }, unloadFolderContents:function () {
        }, addAttachment:function (attachmentItems, item, repository, version, vsId, type) {
            var id = item.id.split(",")[2];
            this.logInfo("addAttachment", "Adding attachment: name = " + item.name, ", id = " + id + ", objectStore = " + repository.objectStoreName);
            attachmentItems.push({"attachment_id":id, "attachment_name":item.name, "attachment_library_type":3, "attachment_repository_id":repository.id, "attachment_library_name":repository.objectStoreName, "attachment_version":version, "attachment_vsid":vsId, "attachment_type":type});
            this.modified = true;
            if (item.attributes["{NAME}"] == undefined) {
                item.attributes["{NAME}"] = item.name;
                item.attributeTypes["{NAME}"] = "xs:string";
            }
            var items = this.resultSet;
            if (items) {
                var contentItems = items.getItems();
                contentItems.push(item);
            }
            if (item.isFolder()) {
                var folders = this.getFolderContents();
                if (folders) {
                    var folderItems = folders.getItems();
                    folderItems.push(item);
                }
            }
        }, removeAttachment:function (attachmentItems, items) {
            var resultSetItems = this.resultSet.getItems();
            for (i = 0; i < items.length; i++) {
                this.logInfo("removeAttachment", "Removing attachment: name = " + items[i].name);
                for (j = 0; j < resultSetItems.length; j++) {
                    if (items[i].id == resultSetItems[j].id) {
                        resultSetItems.splice(j, 1);
                        attachmentItems.splice(j, 1);
                        break;
                    }
                }
            }
            this.modified = true;
            var folderContents = this.getFolderContents();
            if (folderContents) {
                var contentItems = folderContents.getItems();
                for (i = 0; i < items.length; i++) {
                    for (j = 0; j < contentItems.length; j++) {
                        if (items[i].id == contentItems[j].id) {
                            contentItems.splice(j, 1);
                            break;
                        }
                    }
                }
            }
        }, retrieveAttachmentContents:function (foldersOnly, refresh, callback) {
            this.logInfo("retrieveAttachmentContents", "step_attachment_name = " + this.name + ", step_parameter = " + this.authoredName);
            if (!refresh && !foldersOnly && this.resultSet) {
                this.logInfo("retrieveAttachmentContents", "Returning cached result set of attachment items");
                callback(this.resultSet);
            } else {
                if (!refresh && foldersOnly && this._folderContents) {
                    for (var i = this._folderContents.items.length - 1; i >= 0; i--) {
                        var item = this._folderContents.getItem(i);
                        if (!item.isFolder()) {
                            this._folderContents.deleteItem(item);
                        }
                    }
                    this.logInfo("retrieveAttachmentContents", "Returning cached result set of attachment folders only");
                    callback(this._folderContents);
                } else {
                    var filterType = "";
                    if (foldersOnly) {
                        filterType = "folderSearch";
                    }
                    var self = this;
                    this.logInfo("retrieveAttachmentContents", "Calling getStepAttachmentItems action");
                    var request = null;
                    if (this.repository.type == "cm") {
                        request = ecm.model.Request.invokeService("getStepAttachmentItems", this.repository.type, {repositoryId:this.repository.id, workItemId:this.parent.id, docId:this.docid, }, function (response) {
                            self._retrieveAttachmentContentsCompleted(response, foldersOnly, callback);
                        });
                    } else {
                        request = ecm.model.Request.invokeService("getStepAttachmentItems", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:this.objectStore ? this.objectStore.id : "", wob_num:this.parent.id, queue_name:this.parent.queueName ? encodeURIComponent(this.parent.queueName) : "", launch_version:this.parent.workflowVersion ? encodeURIComponent(this.parent.workflowVersion) : "", attachmentId:this.parent.F_AttachmentId ? this.parent.F_AttachmentId : "", step_parameter:encodeURIComponent(this.authoredName), step_attachment_name:encodeURIComponent(this.name), filter_type:filterType}, function (response) {
                            self._retrieveAttachmentContentsCompleted(response, foldersOnly, callback);
                        });
                    }
                }
            }
        }, _retrieveAttachmentContentsCompleted:function (response, foldersOnly, callback) {
            response.repository = this.repository;
            response.parentFolder = this;
            var results = new ecm.model.ResultSet(response);
            if (foldersOnly) {
                this.logInfo("_retrieveAttachmentContentsCompleted", "Returning new result set of attachment folders only");
                this._folderContents = results;
            } else {
                this.logInfo("_retrieveAttachmentContentsCompleted", "Returning new result set of attachment items");
                this.resultSet = results;
                this._folderContents = new ecm.model.ResultSet(response);
            }
            var attachmentItems = this.parent.getValue(this.authoredName);
            if (this.resultSet) {
                this._updateRepositoryOnItems(this.resultSet, attachmentItems);
            }
            if (this._folderContents) {
                this._updateRepositoryOnItems(this._folderContents, attachmentItems);
            }
            if (response.docid) {
                this.parent.id = response.docid;
            }
            if (callback) {
                callback(results);
            }
        }, _updateRepositoryOnItems:function (resultSet, attachmentItems) {
            for (var i = 0; i < resultSet.items.length; i++) {
                var item = resultSet.getItem(i);
                var itemId = item.getValue("Id");
                var itemVsId = "";
                if (!item.isFolder()) {
                    itemVsId = item.vsId;
                }
                for (var j in attachmentItems) {
                    var currentId = itemId;
                    var id = attachmentItems[j].attachment_id;
                    if (!item.isFolder()) {
                        var vsId = attachmentItems[j].attachment_vsid;
                        if (!vsId) {
                            id = attachmentItems[j].attachment_version;
                        } else {
                            currentId = itemVsId;
                        }
                    }
                    if (currentId == id) {
                        var repository = ecm.model.desktop.getRepository(attachmentItems[j].attachment_repository_id);
                        item.repository = repository;
                        this.logInfo("_updateRepositoryOnItems", "Updating item: name = " + item.name + " repositoryId = " + repository.id);
                        break;
                    }
                }
            }
        }});
        AttachmentItem.createFromJSON = function (itemJSON, repository, resultSet, parent) {
            itemJSON.repository = repository;
            itemJSON.resultSet = resultSet;
            itemJSON.parent = parent;
            itemJSON.connectionPoint = parent ? parent.connectionPoint : "";
            var item = new AttachmentItem(itemJSON);
            return item;
        };
        return AttachmentItem;
    });
}, "ecm/model/Request":function () {
    define("ecm/model/Request", ["dojo/_base/declare", "dojo/_base/array", "dojo/_base/json", "dojo/_base/lang", "dojo/_base/sniff", "dojo/_base/xhr", "dojo/cookie", "dojo/dom-construct", "dojo/io-query", "dojo/io/iframe", "dojox/uuid/generateRandomUuid", "../Messages", "../Logger", "./_ModelObject", "./Message"], function (declare, array, dojojson, lang, has, xhr, cookie, domConstruct, ioQuery, iframe, generateRandomUuid, Messages, Logger, _ModelObject, Message) {
        var Request = declare("ecm.model.Request", [_ModelObject], {requestUrl:null, requestHeaders:null, requestBody:null, requestMethod:"POST", requestCompleteCallback:null, requestFailedCallback:null, progressMessage:null, repository:null, cancellable:false, cancelMessage:null, xmlHttpRequest:null, backgroundRequest:false, uuid:null, cancelled:false, isSameRequestAs:function (request) {
            return (request && request.isInstanceOf && request.isInstanceOf(Request)) ? this.uuid == request.uuid : false;
        }, send:function (params) {
            if (params) {
                lang.mixin(this, params);
            }
            this.logInfo("send", "URL=" + this.requestUrl + " METHOD=" + this.requestMethod + " SYNCHRONOUS=" + this.synchronous + " HEADER=" + this.requestHeaders + " BODY=" + this.requestBody);
            this.xmlHttpRequest = xhr._xhrObj ? xhr._xhrObj() : new XMLHttpRequest();
            if (ecm.model.desktop.requestTimeout) {
                this.xmlHttpRequest.timeout = ecm.model.desktop.requestTimeout;
            }
            if (ecm.model.desktop.onRequestTimeout && this.xmlHttpRequest.timeout) {
                this.xmlHttpRequest.ontimeout = setTimeout(lang.hitch(this, function () {
                    ecm.model.desktop.onRequestTimeout(this.xmlHttpRequest);
                }), this.xmlHttpRequest.timeout);
            }
            this.xmlHttpRequest.open(this.requestMethod, this.requestUrl, !this.synchronous);
            if (this.requestHeaders) {
                for (var key in this.requestHeaders) {
                    var value = this.requestHeaders[key];
                    this.xmlHttpRequest.setRequestHeader(key, value);
                }
            }
            if (this.requestHeaders && !this.requestHeaders["userid"] && this.requestHeaders["repositoryId"] && ecm.model.desktop) {
                this.xmlHttpRequest.setRequestHeader("userid", ecm.model.desktop.getRepository(this.properties["repositoryId"]).userId);
            }
            var cookieLocaleLanguage = cookie(ecm.model.Desktop.cookieLocaleLanguage);
            if (cookieLocaleLanguage) {
                this.xmlHttpRequest.setRequestHeader("Accept-Language", cookieLocaleLanguage);
            }
            if (!this.synchronous) {
                this.xmlHttpRequest.onreadystatechange = lang.hitch(this, function () {
                    if (this.xmlHttpRequest.readyState == 4) {
                        if (this.xmlHttpRequest.ontimeout) {
                            clearTimeout(this.xmlHttpRequest.ontimeout);
                        }
                        this._onFinished();
                    }
                });
            }
            this.onRequestStarted(this);
            try {
                this.xmlHttpRequest.send(this.requestBody);
            }
            catch (e) {
                this.onRequestCompleted(this);
                this.logError("send", "Error on XMLHttpRequest.send: " + e);
                if (ecm.model.desktop) {
                    var errorMessage = Message.createErrorMessage("http_send_error", [ecm.model.desktop.servicesUrl, e], this.backgroundRequest);
                    this.addMessage(errorMessage);
                    if (lang.isFunction(this.requestFailedCallback)) {
                        this.requestFailedCallback(this.xmlHttpRequest.status + " " + this.xmlHttpRequest.responseText, errorMessage);
                    }
                } else {
                    if (lang.isFunction(this.requestFailedCallback)) {
                        this.requestFailedCallback(this.xmlHttpRequest.status + " " + this.xmlHttpRequest.responseText);
                    }
                }
            }
            if (this.synchronous && this.xmlHttpRequest.readyState == 4) {
                this._onFinished();
            }
        }, _onFinished:function () {
            var errorMessage;
            this.onRequestCompleted(this);
            if (this.cancelled) {
                this.logInfo("_onFinished", "Request was cancelled", "URL=" + this.requestUrl);
                if (ecm.model.desktop) {
                    this.addMessage(new Message({number:0, level:0, text:this.cancelMessage}));
                }
                return;
            }
            if (!this.xmlHttpRequest.status || this.xmlHttpRequest.status >= 300) {
                this.logError("_onFinished", "Http error response: " + this.xmlHttpRequest.status, "URL=" + this.requestUrl + " HEADERS=" + this.xmlHttpRequest.getAllResponseHeaders());
                if (ecm.model.desktop) {
                    if (ecm.model.desktop._tamKerberosTokenPresent && this.xmlHttpRequest.status == 403) {
                        errorMessage = Message.createErrorMessage("http_ltpa_expired", [ecm.model.desktop.servicesUrl, this.xmlHttpRequest.status + " " + this.xmlHttpRequest.responseText], this.backgroundRequest);
                    } else {
                        errorMessage = Message.createErrorMessage("http_error", [ecm.model.desktop.servicesUrl, this.xmlHttpRequest.status + " " + this.xmlHttpRequest.responseText], this.backgroundRequest);
                    }
                    this.addMessage(errorMessage);
                    if (lang.isFunction(this.requestFailedCallback)) {
                        this.requestFailedCallback(this.xmlHttpRequest.status + " " + this.xmlHttpRequest.responseText, errorMessage);
                    }
                } else {
                    if (lang.isFunction(this.requestFailedCallback)) {
                        this.requestFailedCallback(this.xmlHttpRequest.status + " " + this.xmlHttpRequest.responseText);
                    }
                }
            } else {
                var response = this.getResponse();
                if (!response) {
                    this.logError("_onFinished", "Bad response (not JSON?): " + this.getResponseText(), "URL=" + this.requestUrl + " HEADERS=" + this.xmlHttpRequest.getAllResponseHeaders());
                    if (ecm.model.desktop) {
                        errorMessage = Message.createErrorMessage("http_response_bad", [ecm.model.desktop.servicesUrl, this.responseText || ""], this.backgroundRequest);
                        this.addMessage(errorMessage);
                        if (lang.isFunction(this.requestFailedCallback)) {
                            this.requestFailedCallback(this.xmlHttpRequest.status + " " + this.xmlHttpRequest.responseText, errorMessage);
                        }
                    } else {
                        if (lang.isFunction(this.requestFailedCallback)) {
                            this.requestFailedCallback(this.xmlHttpRequest.status + " " + this.xmlHttpRequest.responseText);
                        }
                    }
                } else {
                    Request.getSecurityToken(response);
                    if (response.errors) {
                        for (var i in response.errors) {
                            var error = response.errors[i];
                            if (lang.isString(error)) {
                                this.logError("_onFinished", "Error: " + error, "URL=" + this.requestUrl + " HEADERS=" + this.xmlHttpRequest.getAllResponseHeaders());
                                if (ecm.model.desktop) {
                                    errorMessage = new Message({number:0, level:3, text:error, backgroundRequest:this.backgroundRequest});
                                    this.addMessage(errorMessage);
                                    if (lang.isFunction(this.requestFailedCallback)) {
                                        this.requestFailedCallback(response, errorMessage);
                                    }
                                } else {
                                    if (lang.isFunction(this.requestFailedCallback)) {
                                        this.requestFailedCallback(response);
                                    }
                                }
                            } else {
                                this.logError("_onFinished", "Error: " + error.text, "URL=" + this.requestUrl + " HEADERS=" + this.xmlHttpRequest.getAllResponseHeaders());
                                if (ecm.model.desktop) {
                                    if (error.number == 1003 || error.number == 1007) {
                                        ecm.model.desktop.onSessionExpired(this, error);
                                    } else {
                                        errorMessage = new Message({number:error.number, level:3, text:error.text, explanation:error.explanation, userResponse:error.userResponse, adminResponse:error.adminReponse, messageProductId:error.messageProductId, backgroundRequest:this.backgroundRequest});
                                        this.addMessage(errorMessage);
                                        if (lang.isFunction(this.requestFailedCallback)) {
                                            this.requestFailedCallback(response, errorMessage);
                                        }
                                    }
                                } else {
                                    if (lang.isFunction(this.requestFailedCallback)) {
                                        this.requestFailedCallback(response);
                                    }
                                }
                            }
                        }
                    }
                    if (response.warnings) {
                        for (var i in response.warnings) {
                            var warning = response.warnings[i];
                            if (lang.isString(warning)) {
                                this.logWarning("_onFinished", "Warning: " + warning, "URL=" + this.requestUrl + " HEADERS=" + this.xmlHttpRequest.getAllResponseHeaders());
                                if (ecm.model.desktop) {
                                    this.addMessage(new Message({number:0, level:2, text:warning}));
                                }
                            } else {
                                this.logWarning("_onFinished", "Warning: " + warning.text, "URL=" + this.requestUrl + " HEADERS=" + this.xmlHttpRequest.getAllResponseHeaders());
                                if (ecm.model.desktop) {
                                    this.addMessage(new Message({number:warning.number, level:2, text:warning.text, explanation:warning.explanation, userResponse:warning.userResponse, adminResponse:warning.adminReponse, moreInformation:warning.moreInformation, messageProductId:warning.messageProductId}));
                                }
                            }
                        }
                    }
                    if (response.messages) {
                        for (var i in response.messages) {
                            var information = response.messages[i];
                            if (information) {
                                if (lang.isString(information)) {
                                    this.logInfo("_onFinished", "Information: " + information, "URL=" + this.requestUrl + " HEADERS=" + this.xmlHttpRequest.getAllResponseHeaders());
                                    if (ecm.model.desktop) {
                                        this.addMessage(new Message({number:0, level:0, text:information}));
                                    }
                                } else {
                                    this.logInfo("_onFinished", "Information: " + information.text, "URL=" + this.requestUrl + " HEADERS=" + this.xmlHttpRequest.getAllResponseHeaders());
                                    if (ecm.model.desktop) {
                                        this.addMessage(new Message({number:information.number, level:0, text:information.text, explanation:information.explanation, userResponse:information.userResponse, adminResponse:information.adminReponse, messageProductId:information.messageProductId}));
                                    }
                                }
                            }
                        }
                    }
                    if (lang.isFunction(this.requestCompleteCallback) && !response.errors) {
                        this.requestCompleteCallback(response);
                    }
                }
            }
        }, onRequestStarted:function (request) {
            if (ecm.model.desktop) {
                ecm.model.desktop.onRequestStarted(request);
            }
        }, onRequestCompleted:function (request) {
            if (ecm.model.desktop) {
                ecm.model.desktop.onRequestCompleted(request);
            }
        }, addMessage:function (message) {
            if (ecm.model.desktop) {
                ecm.model.desktop.addMessage(message);
            }
        }, getReadyState:function () {
            return this.xmlHttpRequest.readyState;
        }, getResponseStatus:function () {
            if (this.xmlHttpRequest.readyState == 4) {
                return this.xmlHttpRequest.status;
            } else {
                return undefined;
            }
        }, getResponseText:function () {
            if (this.xmlHttpRequest.readyState == 4) {
                return this.xmlHttpRequest.responseText;
            } else {
                return undefined;
            }
        }, getResponseProperties:function () {
            if (this.xmlHttpRequest.readyState == 4) {
                return this.xmlHttpRequest.getAllResponseHeaders();
            } else {
                return undefined;
            }
        }, getResponse:function () {
            var responseText = this.getResponseText();
            var response;
            if (responseText && responseText.length > 0 && (responseText.substring(0, 1) == "{" || responseText.substring(0, 1) == "[")) {
                try {
                    if (has("ff") || has("ie")) {
                        if (responseText.length > 4 && responseText.substring(0, 4) == "{}&&") {
                            responseText = responseText.substring(4);
                        }
                        var useJSONParse = false;
                        try {
                            if (JSON && JSON.parse) {
                                useJSONParse = true;
                            }
                        }
                        catch (e) {
                        }
                        if (useJSONParse) {
                            response = JSON.parse(responseText);
                        } else {
                            response = dojojson.fromJson(responseText);
                        }
                    } else {
                        response = dojojson.fromJson(responseText);
                        if (response["object_with_error"]) {
                            response = null;
                        }
                    }
                }
                catch (e) {
                    response = null;
                    this.logError("getResponse", "Error parsing JSON: " + e);
                    if (e.description) {
                        this.logError("getResponse", "Error description parsing JSON: " + e.description);
                    }
                }
            }
            return response;
        }, cancel:function () {
            this.cancelled = true;
            this.xmlHttpRequest.abort();
        }, retry:function () {
            if (this.fileInputForm) {
                var inputs = [];
                if (Request.enableSecureService) {
                    var token = Request._security_token;
                    if (token) {
                        inputs.push(domConstruct.create("input", {type:"hidden", name:"security_token", value:token}, this.fileInputForm));
                    }
                }
                if (this._origParams) {
                    if (Request.enableSecureService) {
                        for (var name in this._origParams) {
                            var value = this._origParams[name];
                            if (value || value === 0 || value === false) {
                                inputs.push(domConstruct.create("input", {type:"hidden", name:name, value:value}, this._fileInputForm));
                            }
                        }
                    }
                }
                try {
                    this.dojoIOIFrameSend();
                }
                finally {
                    array.forEach(inputs, domConstruct.destroy);
                }
            } else {
                if (this.requestBody) {
                    if (lang.isString(this.requestBody)) {
                        var index = this.requestBody.indexOf("security_token=");
                        if (index >= 0) {
                            var prefix = this.requestBody.substr(0, index);
                            var postfix = "";
                            var indexEnd = this.requestBody.indexOf("&", index);
                            if (indexEnd > 0) {
                                postfix = this.requestBody.substr(indexEnd);
                            }
                            this.requestBody = prefix + "security_token=" + Request._security_token + postfix;
                        }
                    } else {
                        if (this.requestBody instanceof FormData) {
                            if (this._origFormParams) {
                                this.requestBody = new FormData();
                                for (var prop in this._origFormParams) {
                                    if (this._origFormParams.hasOwnProperty(prop)) {
                                        this.requestBody.append(prop, this._origFormParams[prop]);
                                    }
                                }
                                if (this._origParams) {
                                    if (Request.enableSecureService) {
                                        var token = Request._security_token;
                                        if (token) {
                                            this.requestBody.append("security_token", token);
                                        }
                                        for (var name in this._origParams) {
                                            var value = this._origParams[name];
                                            if (value && value.length > 0 && value != "undefined") {
                                                this.requestBody.append(name, value);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                this.send();
            }
        }, dojoIOIFrameSend:function (fileInputForm) {
            var errorMessage;
            this.fileInputForm = fileInputForm;
            this.onRequestStarted(this);
            if (ecm.model.desktop) {
                ecm.model.desktop.getActionsHandler(lang.hitch(this, function (actionsHandler) {
                    if (actionsHandler && lang.isFunction(actionsHandler._clearDownloadDeferred)) {
                        actionsHandler._clearDownloadDeferred();
                    }
                    iframe.send({url:this.requestUrl, handleAs:"json", form:this.fileInputForm, method:"post", load:lang.hitch(this, function (data, ioArgs) {
                        this.onRequestCompleted(this);
                        if (!data) {
                            this.logError("dojoIOIFrameSend", "Bad response (not JSON?)", "URL=" + this.requestUrl + " ARGS=" + ioArgs);
                            if (ecm.model.desktop) {
                                errorMessage = Message.createErrorMessage("http_response_bad", null, this.backgroundRequest);
                                this.addMessage(errorMessage);
                                if (lang.isFunction(this.requestFailedCallback)) {
                                    this.requestFailedCallback("", errorMessage);
                                }
                            } else {
                                if (lang.isFunction(this.requestFailedCallback)) {
                                    this.requestFailedCallback("");
                                }
                            }
                        } else {
                            if (data.errors) {
                                for (var i in data.errors) {
                                    var error = data.errors[i];
                                    if (lang.isString(error)) {
                                        this.logError("dojoIOIFrameSend", "Error: " + error, "URL=" + this.requestUrl + " ARGS=" + ioArgs);
                                        if (ecm.model.desktop) {
                                            errorMessage = new Message({number:0, level:3, text:error});
                                            this.addMessage(errorMessage);
                                            if (lang.isFunction(this.requestFailedCallback)) {
                                                this.requestFailedCallback(data, errorMessage);
                                            }
                                        } else {
                                            if (lang.isFunction(this.requestFailedCallback)) {
                                                this.requestFailedCallback(data);
                                            }
                                        }
                                    } else {
                                        this.logError("dojoIOIFrameSend", "Error: " + error.text, "URL=" + this.requestUrl + " ARGS=" + ioArgs);
                                        if (ecm.model.desktop) {
                                            if (error.number == 1003) {
                                                ecm.model.desktop.onSessionExpired(this, error);
                                            } else {
                                                errorMessage = new Message({number:error.number, level:3, text:error.text, explanation:error.explanation, userResponse:error.userResponse, adminResponse:error.adminReponse, messageProductId:error.messageProductId});
                                                this.addMessage(errorMessage);
                                                if (lang.isFunction(this.requestFailedCallback)) {
                                                    this.requestFailedCallback(data, errorMessage);
                                                }
                                            }
                                        } else {
                                            if (lang.isFunction(this.requestFailedCallback)) {
                                                this.requestFailedCallback(data);
                                            }
                                        }
                                    }
                                }
                            }
                            if (data.warnings) {
                                for (var i in data.warnings) {
                                    var warning = data.warnings[i];
                                    if (lang.isString(warning)) {
                                        this.logWarning("dojoIOIFrameSend", "Warning: " + warning, "URL=" + this.requestUrl + " ARGS=" + ioArgs);
                                        if (ecm.model.desktop) {
                                            this.addMessage(new Message({number:0, level:2, text:warning}));
                                        }
                                    } else {
                                        this.logWarning("dojoIOIFrameSend", "Warning: " + warning.text, "URL=" + this.requestUrl + " ARGS=" + ioArgs);
                                        if (ecm.model.desktop) {
                                            this.addMessage(new Message({number:warning.number, level:2, text:warning.text, explanation:warning.explanation, userResponse:warning.userResponse, adminResponse:warning.adminReponse, messageProductId:warning.messageProductId}));
                                        }
                                    }
                                }
                            }
                            if (data.messages) {
                                for (var i in data.messages) {
                                    var information = data.messages[i];
                                    if (information) {
                                        if (lang.isString(information)) {
                                            this.logInfo("dojoIOIFrameSend", "Information: " + information, "URL=" + this.requestUrl + " ARGS=" + ioArgs);
                                            if (ecm.model.desktop) {
                                                this.addMessage(new Message({number:0, level:0, text:information}));
                                            }
                                        } else {
                                            this.logInfo("dojoIOIFrameSend", "Information: " + information.text, "URL=" + this.requestUrl + " ARGS=" + ioArgs);
                                            if (ecm.model.desktop) {
                                                this.addMessage(new Message({number:information.number, level:0, text:information.text, explanation:information.explanation, userResponse:information.userResponse, adminResponse:information.adminReponse, messageProductId:information.messageProductId}));
                                            }
                                        }
                                    }
                                }
                            }
                            if (this.requestCompleteCallback && !data.errors) {
                                this.requestCompleteCallback(data);
                            }
                        }
                    }), error:lang.hitch(this, function (data, ioArgs) {
                        this.onRequestCompleted(this);
                        this.logError("dojoIOIFrameSend", "Http error" + " DATA=" + data + " ARGS=" + ioArgs);
                        if (ecm.model.desktop) {
                            errorMessage = Message.createErrorMessage("http_error", null, this.backgroundRequest);
                            this.addMessage(errorMessage);
                            if (errorback) {
                                errorback(data, errorMessage);
                            }
                        } else {
                            if (errorback) {
                                errorback(data);
                            }
                        }
                    })});
                }));
            }
        }});
        Request.getSecurityToken = function (response) {
            var token = (response && response.security_token);
            if (token && token != Request._security_token) {
                Request._security_token = token;
                if (Request.onSecurityTokenChange) {
                    Request.onSecurityTokenChange(response);
                }
            }
            return token;
        };
        Request.setSecurityToken = function (params) {
            if (params) {
                var token = Request._security_token;
                if (token) {
                    if (lang.isString(params)) {
                        params = params + "&security_token=" + token;
                    } else {
                        params.security_token = token;
                    }
                }
            }
            return params;
        };
        Request.appendSecurityToken = function (url) {
            if (url && lang.isString(url)) {
                var token = Request._security_token;
                if (token) {
                    var connector = (url.indexOf("?") < 0 ? "?" : "&");
                    url = url + connector + "security_token=" + token;
                }
            }
            return url;
        };
        Request.getServiceRequestUrl = function (serviceName, serverType, params) {
            ecm.logger.logEntry("ecm.model.Request.getServiceRequestUrl", "serviceName=" + serviceName + " serverType=" + serverType + " params=" + params);
            if (ecm.model.desktop) {
                var servicesUrl = ecm.model.desktop.servicesUrl;
            } else {
                var servicesUrl = "/navigator";
            }
            var requestUrl;
            if (servicesUrl.indexOf("json") >= 0) {
                requestUrl = servicesUrl;
                if (requestUrl.substring(requestUrl.length - 1) != "/") {
                    requestUrl += "/";
                }
                requestUrl += serviceName;
                if (params) {
                    if (0) {
                        var paramsFlipped = [];
                        for (var paramName in params) {
                            paramsFlipped.unshift(params[paramName]);
                        }
                        params = paramsFlipped;
                    }
                    for (var paramName in params) {
                        if (paramName != "criterias") {
                            if (lang.isArray(params[paramName])) {
                                var paramValues = params[paramName];
                                for (var i = 0; i < paramValues.length; i++) {
                                    requestUrl += "_" + paramValues[i].replace(/[^a-z0-9A-Z_]/g, "");
                                }
                            } else {
                                if (params[paramName]) {
                                    requestUrl += "_" + params[paramName].replace(/[^a-z0-9A-Z_]/g, "");
                                }
                            }
                        }
                    }
                }
                requestUrl += ".json";
            } else {
                requestUrl = servicesUrl;
                if (serverType) {
                    requestUrl += "/" + serverType;
                }
                requestUrl += "/" + serviceName + ".do";
                if (ecm.model.desktop) {
                    if (params) {
                        var desktopId = params["desktop"];
                        if (!desktopId) {
                            params["desktop"] = ecm.model.desktop.id;
                        }
                        requestUrl = requestUrl + "?" + ioQuery.objectToQuery(params);
                    } else {
                        params = {desktop:ecm.model.desktop.id};
                    }
                }
            }
            ecm.logger.logExit("ecm.model.Request.getServiceRequestUrl", "Request URL=" + requestUrl);
            return requestUrl;
        };
        Request.createRequest = function (params) {
            ecm.logger.logEntry("ecm.model.Request.createRequest", "params=" + params);
            var request = new Request(params);
            if (params && params.requestParams.repositoryId && ecm.model.desktop) {
                request.repository = ecm.model.desktop.getRepository(params.requestParams.repositoryId);
            }
            ecm.logger.logExit("ecm.model.Request.createRequest", request);
            return request;
        }, Request.enableSecureService = true, Request.invokeService = function (serviceName, serverType, params, onFinished, cancellable, synchronous, onError, backgroundRequest) {
            return Request.invokeServiceAPI(serviceName, serverType, {requestParams:params, cancellable:cancellable, backgroundRequest:backgroundRequest, synchronous:synchronous, requestCompleteCallback:onFinished, requestFailedCallback:onError});
        };
        Request.invokeServiceAPI = function (serviceName, serverType, params) {
            ecm.logger.logEntry("ecm.model.Request.invokeServiceAPI", "serviceName=" + serviceName + ", serverType: " + serverType);
            if (serverType == "dummy") {
                return new Request("");
            }
            params.progressMessage = Messages["progress_message_" + serverType + "_" + serviceName] || Messages["progress_message_" + serviceName] || Messages.progress_message_general;
            params.cancelMessage = Messages["cancel_message_" + serverType + "_" + serviceName] || Messages["cancel_message_" + serviceName] || Messages.cancel_message_general;
            if (ecm.model.desktop) {
                var servicesUrl = ecm.model.desktop.servicesUrl;
            } else {
                var servicesUrl = "/navigator";
            }
            var request;
            params.requestHeaders = {"Cache-Control":"no-cache"};
            if (!Request.enableSecureService || servicesUrl == null || servicesUrl.indexOf("json") >= 0) {
                var requestUrl = Request.getServiceRequestUrl(serviceName, serverType, params.requestParams);
                params.requestUrl = requestUrl;
                params.requestMethod = "GET";
                var request = Request.createRequest(params);
                request.send();
            } else {
                var requestUrl = Request.getServiceRequestUrl(serviceName, serverType);
                params.requestUrl = requestUrl;
                if (ecm.model.desktop && !params.requestParams["desktop"]) {
                    params.requestParams["desktop"] = ecm.model.desktop.id;
                }
                Request.setSecurityToken(params.requestParams);
                params.requestMethod = "POST";
                params.requestBody = ioQuery.objectToQuery(params.requestParams);
                params.requestHeaders["Cache-Control"] = "no-cache";
                params.requestHeaders["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8";
                if (has("webkit")) {
                    var request = Request.createRequest(params);
                    request.send();
                } else {
                    params.requestHeaders["Content-Length"] = params.requestBody.length;
                    var request = Request.createRequest(params);
                    request.send();
                }
            }
            ecm.logger.logExit("ecm.model.Request.invokeServiceAPI");
            return request;
        };
        Request.postServiceAPI = function (serviceName, serverType, contentType, params) {
            ecm.logger.logEntry("ecm.model.Request.postService", "serviceName=" + serviceName);
            var repositoryId = null;
            if (lang.isObject(params.requestBody)) {
                params.requestBody = JSON.stringify(params.requestBody);
            } else {
                if (params.requestParams && params.requestParams.repositoryId) {
                    repositoryId = params.requestParams.repositoryId;
                }
            }
            if (params.requestParams) {
                if (Request.enableSecureService) {
                    Request.setSecurityToken(params.requestParams);
                    if (params.requestBody) {
                        params.requestParams.json_post = params.requestBody;
                    }
                    if (ecm.model.desktop && !params.requestParams["desktop"]) {
                        params.requestParams["desktop"] = ecm.model.desktop.id;
                    }
                    params.requestBody = ioQuery.objectToQuery(params.requestParams);
                    params.requestParams = undefined;
                    contentType = "application/x-www-form-urlencoded";
                }
            }
            var requestUrl = Request.getServiceRequestUrl(serviceName, serverType, params.requestParams);
            params.progressMessage = Messages["progress_message_" + serverType + "_" + serviceName] || Messages["progress_message_" + serviceName] || Messages.progress_message_general;
            params.cancelMessage = Messages["cancel_message_" + serverType + "_" + serviceName] || Messages["cancel_message_" + serviceName] || Messages.cancel_message_general;
            params.requestUrl = requestUrl;
            var request = new Request(params);
            if (repositoryId && ecm.model.desktop) {
                request.repository = ecm.model.desktop.getRepository(repositoryId);
            }
            if (has("webkit")) {
                request.send({requestHeaders:{"Cache-Control":"no-cache", "Content-Type":contentType}});
            } else {
                request.send({requestHeaders:{"Cache-Control":"no-cache", "Content-Type":contentType, "Content-Length":params.requestBody.length}});
            }
            ecm.logger.logExit("ecm.model.Request.postService");
            return request;
        };
        Request.postService = function (serviceName, serverType, params, contentType, content, onFinished, cancellable, backgroundRequest, synchronous, onError) {
            return Request.postServiceAPI(serviceName, serverType, contentType, {requestParams:params, requestBody:content, cancellable:cancellable, backgroundRequest:backgroundRequest, synchronous:synchronous, requestCompleteCallback:onFinished, requestFailedCallback:onError});
        };
        Request.postFormToServiceAPI = function (serviceName, serverType, params, form) {
            ecm.logger.logEntry("ecm.model.Request.postFormToService", "serviceName=" + serviceName);
            var repositoryId;
            var origFormParams;
            if (!(form instanceof FormData) && (form instanceof Object)) {
                origFormParams = form;
                form = new FormData();
                for (var propname in origFormParams) {
                    if (origFormParams.hasOwnProperty(propname)) {
                        form.append(propname, origFormParams[propname]);
                    }
                }
            }
            if (Request.enableSecureService) {
                var token = Request._security_token;
                if (token) {
                    form.append("security_token", token);
                }
            }
            var origParams;
            if (params.requestParams) {
                origParams = params.requestParams;
                repositoryId = params.requestParams.repositoryId;
                if (Request.enableSecureService) {
                    for (var name in params.requestParams) {
                        var value = params.requestParams[name];
                        if (value && value.length > 0 && value != "undefined") {
                            form.append(name, value);
                        }
                    }
                    params.requestParams = {};
                }
            }
            params.requestUrl = Request.getServiceRequestUrl(serviceName, serverType, params.requestParams);
            params.progressMessage = Messages["progress_message_" + serverType + "_" + serviceName] || Messages["progress_message_" + serviceName] || Messages.progress_message_general;
            params.cancelMessage = Messages["cancel_message_" + serverType + "_" + serviceName] || Messages["cancel_message_" + serviceName] || Messages.cancel_message_general;
            params.requestHeaders = {"Cache-Control":"no-cache"};
            params.requestMethod = "POST";
            params.requestBody = form;
            var request = new Request(params);
            if (origFormParams) {
                request._origFormParams = origFormParams;
                if (origParams) {
                    request._origParams = origParams;
                }
            }
            if (repositoryId && ecm.model.desktop) {
                request.repository = ecm.model.desktop.getRepository(repositoryId);
            }
            request.send();
            ecm.logger.logExit("ecm.model.Request.postFormToService");
            return request;
        };
        Request.postFormToService = function (serviceName, serverType, params, form, onFinished, cancellable, backgroundRequest, onError) {
            return Request.postFormToServiceAPI(serviceName, serverType, {requestParams:params, cancellable:cancellable, backgroundRequest:backgroundRequest, synchronous:false, requestCompleteCallback:onFinished, requestFailedCallback:onError}, form);
        };
        Request.ieFileUploadServiceAPI = function (serviceName, serverType, params, fileInputForm) {
            ecm.logger.logEntry("ecm.model.Request.ieFileUploadService", "serviceName=" + serviceName);
            var inputs = [];
            var repositoryId;
            if (Request.enableSecureService) {
                var token = Request._security_token;
                if (token) {
                    inputs.push(domConstruct.create("input", {type:"hidden", name:"security_token", value:token}, fileInputForm));
                }
            }
            var origParams;
            if (params.requestParams) {
                origParams = params.requestParams;
                repositoryId = params.requestParams.repositoryId;
                if (Request.enableSecureService) {
                    for (var name in params.requestParams) {
                        var value = params.requestParams[name];
                        if (value || value === 0 || value === false) {
                            inputs.push(domConstruct.create("input", {type:"hidden", name:name, value:value}, fileInputForm));
                        }
                    }
                    params.requestParams = {};
                }
            }
            try {
                params.requestUrl = Request.getServiceRequestUrl(serviceName, serverType, params.requestParams);
                params.progressMessage = Messages["progress_message_" + serverType + "_" + serviceName] || Messages["progress_message_" + serviceName] || Messages.progress_message_general;
                params.cancelMessage = Messages["cancel_message_" + serverType + "_" + serviceName] || Messages["cancel_message_" + serviceName] || Messages.cancel_message_general;
                var request = new Request(params);
                if (repositoryId && ecm.model.desktop) {
                    request.repository = ecm.model.desktop.getRepository(repositoryId);
                }
                if (origParams) {
                    request._origParams = origParams;
                }
                request.dojoIOIFrameSend(fileInputForm);
            }
            finally {
                array.forEach(inputs, domConstruct.destroy);
            }
            ecm.logger.logExit("ecm.model.Request.ieFileUploadService");
            return request;
        };
        Request.ieFileUploadService = function (serviceName, serverType, params, fileInputForm, onFinished, cancellable, backgroundRequest, onError) {
            return Request.ieFileUploadServiceAPI(serviceName, serverType, {requestParams:params, cancellable:cancellable, backgroundRequest:backgroundRequest, synchronous:false, requestCompleteCallback:onFinished, requestFailedCallback:onError}, fileInputForm);
        };
        Request.invokePluginService = function (pluginName, pluginServiceName, pluginParams) {
            ecm.logger.logEntry("ecm.model.Request.invokePluginService", "pluginName=" + pluginName + ", pluginServiceName=" + pluginServiceName);
            if (!lang.isObject(pluginParams)) {
                pluginParams = {};
            }
            var params = {};
            if (lang.isObject(pluginParams.requestParams)) {
                for (var i in pluginParams.requestParams) {
                    params[i] = pluginParams.requestParams[i];
                }
            }
            params["plugin"] = pluginName;
            params["action"] = pluginServiceName;
            Request.setSecurityToken(params);
            pluginParams.requestUrl = Request.getServiceRequestUrl("plugin", "", params);
            pluginParams.progressMessage = Messages["progress_message_" + pluginName + "_" + pluginServiceName] || Messages["progress_message_" + pluginServiceName] || Messages.progress_message_general;
            pluginParams.cancelMessage = Messages["cancel_message_" + pluginName + "_" + pluginServiceName] || Messages["cancel_message_" + pluginServiceName] || Messages.cancel_message_general;
            pluginParams.requestMethod = "GET";
            pluginParams.requestHeaders = {"Cache-Control":"no-cache"};
            var request = new Request(pluginParams);
            request.send();
            ecm.logger.logExit("ecm.model.Request.invokePluginService");
            return request;
        };
        Request.invokeSynchronousPluginService = function (pluginName, pluginServiceName, pluginParams) {
            ecm.logger.logEntry("ecm.model.Request.invokeSynchronousPluginService", "pluginName=" + pluginName + ", pluginServiceName=" + pluginServiceName);
            var params = {};
            if (lang.isObject(pluginParams)) {
                for (var i in pluginParams) {
                    params[i] = pluginParams[i];
                }
            }
            params["plugin"] = pluginName;
            params["action"] = pluginServiceName;
            Request.setSecurityToken(params);
            var requestUrl = Request.getServiceRequestUrl("plugin", "", params);
            var response;
            var onFinished = function (r) {
                response = r;
            };
            var request = new Request({requestMethod:"GET", requestUrl:requestUrl, requestHeaders:{"Cache-Control":"no-cache"}, synchronous:true, requestCompleteCallback:onFinished});
            request.send();
            ecm.logger.logExit("ecm.model.Request.invokeSynchronousPluginService");
            return response;
        };
        Request.postPluginService = function (pluginName, pluginServiceName, contentType, pluginParams) {
            ecm.logger.logEntry("ecm.model.Request.postPluginService", "pluginName=" + pluginName + ", pluginServiceName=" + pluginServiceName);
            if (!lang.isObject(pluginParams)) {
                pluginParams = {};
            }
            if (!pluginParams.requestBody) {
                pluginParams.requestBody = {};
            }
            if (lang.isObject(pluginParams.requestBody)) {
                pluginParams.requestBody = JSON.stringify(pluginParams.requestBody);
            }
            var params = {};
            if (lang.isObject(pluginParams.requestParams)) {
                for (var i in pluginParams.requestParams) {
                    params[i] = pluginParams.requestParams[i];
                }
            }
            params["plugin"] = pluginName;
            params["action"] = pluginServiceName;
            if (ecm.model.desktop && pluginParams.requestParams && !pluginParams.requestParams["desktop"]) {
                params["desktop"] = ecm.model.desktop.id;
            }
            pluginParams.requestUrl = Request.getServiceRequestUrl("plugin", "", params);
            pluginParams.progressMessage = Messages["progress_message_" + pluginName + "_" + pluginServiceName] || Messages["progress_message_" + pluginServiceName] || Messages.progress_message_general;
            pluginParams.cancelMessage = Messages["cancel_message_" + pluginName + "_" + pluginServiceName] || Messages["cancel_message_" + pluginServiceName] || Messages.cancel_message_general;
            pluginParams.synchronous = false;
            pluginParams.requestMethod = "POST";
            var request = new Request(pluginParams);
            var requestHeaders = {"Cache-Control":"no-cache", "Content-Type":contentType};
            if (Request.enableSecureService) {
                var token = Request._security_token;
                if (token) {
                    requestHeaders["security_token"] = token;
                }
            }
            if (has("webkit")) {
                request.send({"requestHeaders":requestHeaders});
            } else {
                requestHeaders["Content-Length"] = pluginParams.requestBody.length;
                request.send({"requestHeaders":requestHeaders});
            }
            ecm.logger.logExit("ecm.model.Request.postPluginService");
            return request;
        };
        Request.postSynchronousPluginService = function (pluginName, pluginServiceName, contentType, pluginParams) {
            ecm.logger.logEntry("ecm.model.Request.postSynchronousPluginService", "pluginName=" + pluginName + ", pluginServiceName=" + pluginServiceName);
            if (!lang.isObject(pluginParams)) {
                pluginParams = {};
            }
            if (!pluginParams.requestBody) {
                pluginParams.requestBody = {};
            }
            if (lang.isObject(pluginParams.requestBody)) {
                pluginParams.requestBody = JSON.stringify(pluginParams.requestBody);
            }
            var params = {};
            if (lang.isObject(pluginParams.requestParams)) {
                for (var i in pluginParams.requestParams) {
                    params[i] = pluginParams.requestParams[i];
                }
            }
            params["plugin"] = pluginName;
            params["action"] = pluginServiceName;
            if (ecm.model.desktop && pluginParams.requestParams && !pluginParams.requestParams["desktop"]) {
                params["desktop"] = ecm.model.desktop.id;
            }
            pluginParams.requestUrl = Request.getServiceRequestUrl("plugin", "", params);
            pluginParams.progressMessage = Messages["progress_message_" + pluginName + "_" + pluginServiceName] || Messages["progress_message_" + pluginServiceName] || Messages.progress_message_general;
            pluginParams.cancelMessage = Messages["cancel_message_" + pluginName + "_" + pluginServiceName] || Messages["cancel_message_" + pluginServiceName] || Messages.cancel_message_general;
            pluginParams.synchronous = true;
            pluginParams.requestMethod = "POST";
            var response;
            var onFinished = function (r) {
                response = r;
            };
            pluginParams.requestCompleteCallback = onFinished;
            var request = new Request(pluginParams);
            var requestHeaders = {"Cache-Control":"no-cache", "Content-Type":contentType};
            if (Request.enableSecureService) {
                var token = Request._security_token;
                if (token) {
                    requestHeaders["security_token"] = token;
                }
            }
            if (has("webkit")) {
                request.send({"requestHeaders":requestHeaders});
            } else {
                requestHeaders["Content-Length"] = pluginParams.requestBody.length;
                request.send({"requestHeaders":requestHeaders});
            }
            ecm.logger.logExit("ecm.model.Request.postSynchronousPluginService");
            return response;
        };
        Request.postFormToPluginService = function (pluginName, pluginServiceName, form, pluginParams) {
            ecm.logger.logEntry("ecm.model.Request.postFormToService", "pluginName=" + pluginName + ", pluginServiceName=" + pluginServiceName);
            var origFormParams;
            if (!(form instanceof FormData) && (form instanceof Object)) {
                origFormParams = form;
                form = new FormData();
                for (var propname in origFormParams) {
                    if (origFormParams.hasOwnProperty(propname)) {
                        form.append(propname, origFormParams[propname]);
                    }
                }
            }
            if (Request.enableSecureService) {
                var token = Request._security_token;
                if (token) {
                    form.append("security_token", token);
                }
            }
            form.append("plugin", pluginName);
            form.append("action", pluginServiceName);
            var origParams;
            if (pluginParams.requestParams) {
                origParams = pluginParams.requestParams;
                if (Request.enableSecureService) {
                    for (var name in pluginParams.requestParams) {
                        var value = pluginParams.requestParams[name];
                        if (value && value.length > 0 && value != "undefined") {
                            form.append(name, value);
                        }
                    }
                    pluginParams.requestParams = undefined;
                }
            }
            pluginParams.requestUrl = Request.getServiceRequestUrl("plugin", "", pluginParams.requestParams);
            pluginParams.progressMessage = Messages["progress_message_" + pluginName + "_" + pluginServiceName] || Messages["progress_message_" + pluginServiceName] || Messages.progress_message_general;
            pluginParams.cancelMessage = Messages["cancel_message_" + pluginName + "_" + pluginServiceName] || Messages["cancel_message_" + pluginServiceName] || Messages.cancel_message_general;
            pluginParams.requestHeaders = {"Cache-Control":"no-cache"};
            pluginParams.requestMethod = "POST";
            pluginParams.requestBody = form;
            var request = new Request(pluginParams);
            if (origFormParams) {
                request._origFormParams = origFormParams;
                if (origParams) {
                    request._origParams = origParams;
                }
            }
            request.send();
            ecm.logger.logExit("ecm.model.Request.postFormToService");
            return request;
        };
        Request.getPluginResourceUrl = function (pluginName, resourceName) {
            ecm.logger.logEntry("ecm.model.Request.getPluginResourceUrl", "pluginName=" + pluginName + " resourceName=" + resourceName);
            if (ecm.model.desktop) {
                var servicesUrl = ecm.model.desktop.servicesUrl;
            } else {
                var servicesUrl = "/navigator";
            }
            var requestUrl = servicesUrl + "/plugin/" + pluginName + "/getResource/" + resourceName;
            ecm.logger.logExit("ecm.model.Request.getPluginResourceUrl", "Request URL=" + requestUrl);
            return requestUrl;
        };
        return Request;
    });
}, "ecm/model/admin/MenuTypeConfig":function () {
    define(["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var MenuTypeConfig = declare("ecm.model.admin.MenuTypeConfig", [_ConfigurationObject], {LABEL:"label", TOOLTIP:"tooltip", CATEGORY:"category", constructor:function (id, name) {
            this._attributes.id = id;
        }, isToolbar:function () {
            return this.id.indexOf("Toolbar") > -1 ? true : false;
        }, isContextMenu:function () {
            return this.id.indexOf("ContextMenu") > -1 ? true : false;
        }, getLabel:function () {
            return this.getValue(this.LABEL);
        }, setLabel:function (label) {
            this.setValue(this.LABEL, label);
        }, getTooltip:function () {
            return this.getValue(this.TOOLTIP);
        }, setTooltip:function (tooltip) {
            this.setValue(this.TOOLTIP, tooltip);
        }, getCategory:function () {
            return this.getValue(this.CATEGORY);
        }, setCategory:function (category) {
            this.setValue(this.CATEGORY, category);
        }});
        MenuTypeConfig.createMenuTypeConfig = function (id) {
            return new MenuTypeConfig(id, "MenuTypeConfig");
        };
        return MenuTypeConfig;
    });
}, "ecm/model/User":function () {
    define("ecm/model/User", ["dojo/_base/declare", "dojo/_base/array", "./_ModelObject", "./Role"], function (declare, array, _ModelObject, Role) {
        return declare("ecm.model.User", [_ModelObject], {shortName:null, displayName:null, emailAddress:null, maxPrivs:null, roles:null, constructor:function (params) {
            if (!this.roles) {
                this.roles = [];
            }
            if (params && params.roles) {
                this._setRoles(params.roles);
            }
        }, _setRoles:function (roles) {
            this.roles = [];
            if (roles) {
                array.forEach(roles, function (obj) {
                    if (obj) {
                        var role = new Role({id:obj.id, name:obj.name, description:obj.desc, privileges:obj.privs});
                        this.roles.push(role);
                    }
                }, this);
            }
        }, hasPrivilege:function (privilege) {
            var hasPriv = false;
            if (this.maxPrivs != null) {
                array.forEach(this.maxPrivs, function (priv) {
                    if (priv == privilege) {
                        hasPriv = true;
                    }
                }, this);
            }
            return hasPriv;
        }, toJSON:function () {
            var jsonUser = {};
            jsonUser.id = this.id;
            jsonUser.name = this.name;
            jsonUser.shortName = this.shortName;
            jsonUser.displayName = this.displayName;
            return jsonUser;
        }});
    });
}, "ecm/model/admin/InterfaceTextLocaleConfig":function () {
    define("ecm/model/admin/InterfaceTextLocaleConfig", ["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var InterfaceTextLocaleConfig = declare("ecm.model.admin.InterfaceTextLocaleConfig", [_ConfigurationObject], {ID:"id", constructor:function (id, name) {
        }, getId:function () {
            return this.getValue(this.ID);
        }, clearOverrideValues:function () {
            for (var key in this._attributes) {
                if (key != "id") {
                    this._attributes[key] = "";
                }
            }
        }});
        InterfaceTextLocaleConfig.createInterfaceTextLocaleConfig = function (id) {
            return new InterfaceTextLocaleConfig(id, "InterfaceTextLocaleConfig");
        };
        return InterfaceTextLocaleConfig;
    });
}, "ecm/version":function () {
    define("ecm/version", ["dojo/_base/lang", "dojo/_base/xhr", "./Logger"], function (lang, xhr, Logger) {
        var version = lang.getObject("ecm.version", true);
        version.getVersion = function (full) {
            var msg;
            var params = {url:require.toUrl("ecm/version.txt"), showProgress:false, handleAs:"json", sync:true, load:function (response, ioArgs) {
                msg = response.version;
                if (full) {
                    msg += "-";
                    msg += response.revision;
                }
                ecm.logger.logDebug("ecm.version.load", msg);
            }, error:function (response, ioArgs) {
                ecm.logger.logDebug("ecm.version.error", response);
                return;
            }};
            xhr.get(params);
            return msg;
        };
        return version;
    });
}, "ecm/model/Role":function () {
    define(["dojo/_base/declare", "dojo/_base/array", "./_ModelObject"], function (declare, array, _ModelObject) {
        var Role = declare("ecm.model.Role", [_ModelObject], {description:"", privileges:null, owner:false, preDefined:false, currentUserPrivileges:null, messageId:"", constructor:function () {
            if (!this.privileges) {
                this.privileges = [];
            }
            if (!this.currentUserPrivileges) {
                this.currentUserPrivileges = [];
            }
        }, toJSON:function () {
            var json = {};
            json.id = this.id;
            json.name = this.name;
            json.description = this.description;
            json.owner = this.owner;
            json.preDefined = this.preDefined;
            json.privileges = this.privileges;
            json.messageId = (this.messageId ? this.messageId : "");
            return json;
        }, hasPrivilege:function (privilege) {
            if (this.currentUserPrivileges) {
                var position = array.indexOf(this.currentUserPrivileges, privilege);
                var hasPriv = position != -1;
                return hasPriv;
            }
            return false;
        }});
        Role.lookupPrivilegeLabel = function (privName) {
            return ecm.messages["workspacebuilder_roles_priv_" + privName];
        };
        Role.lookupPrivilegeDescription = function (privName) {
            return ecm.messages["workspacebuilder_roles_plbl_" + privName];
        };
        Role.PRIVILEGE_CATEGORIES = {folder:["modifyFolderPermissions", "deleteFolders", "modifyFolderProperties", "createSubfolders", "fileInFolders", "viewFolderProperties"], document:["modifyDocumentPermissions", "deleteDocuments", "promoteVersions", "modifyContent", "modifyDocumentProperties", "viewContent", "viewDocumentProperties"], p8Teamspace:["addNewSearches", "createNewSearches", "addRemoveClassesOrEntryTemplates", "addRemoveRoleParticipants"], cmTeamspace:["addNewSearches", "createNewSearches", "addRemoveClasses", "addRemoveRoleParticipants"], ownerTeamspace:["modifyRoles"], p8Item:["modifyItemPermissions", "deleteItems", "promoteVersions", "modifyContent", "modifyItemProperties", "createSubfolders", "fileInFolders", "viewContent", "viewItemProperties"], cmItem:["createItems", "deleteItems", "modifyItemProperties", "modifyItemPermissions", "viewContent", "viewItemProperties"]};
        (function () {
            var privCategories = Role.PRIVILEGE_CATEGORIES;
            var privileges = [];
            for (var privCategory in privCategories) {
                if (typeof privCategories[privCategory] !== "function") {
                    privileges = privileges.concat(privCategories[privCategory]);
                }
            }
            Role.AVAILABLE_PRIVILEGES = privileges;
        })();
        return Role;
    });
}, "ecm/model/Desktop":function () {
    define("ecm/model/Desktop", ["dojo/_base/declare", "dojo/_base/array", "dojo/_base/config", "dojo/_base/json", "dojo/_base/kernel", "dojo/_base/lang", "dojo/_base/sniff", "dojo/_base/xhr", "dojo/_base/connect", "./_ModelObject", "./Request", "./Feature", "./Repository", "./Action", "./Viewer", "./ViewerMapping", "./_ModelStore", "./ValueFormatter", "./Container", "./ConfiguredLabels", "./Item", "./admin/ApplicationConfig", "./Favorite", "./Message", "./TaskManager", "./admin/InterfaceTextLocaleConfig", "./admin/InterfaceTextConfig", "./admin/IconStatusConfig", "./admin/IconConfig", "./admin/FileTypeConfig", "./admin/UserActionMacroConfig"], function (declare, array, config, dojojson, kernel, lang, has, xhr, connect, _ModelObject, Request, Feature, Repository, Action, Viewer, ViewerMapping, _ModelStore, ValueFormatter, Container, ConfiguredLabels, Item, ApplicationConfig, Favorite, Message, TaskManager, InterfaceTextLocaleConfig, InterfaceTextConfig, IconStatusConfig, IconConfig, FileTypeConfig, UserActionMacroConfig) {
        var Desktop = declare("ecm.model.Desktop", [_ModelObject], {navigatorRelease:null, navigatorBuild:null, servicesUrl:null, disableCookies:false, disableAutocomplete:false, culturalCollation:false, theme:null, authenticationType:2, repositories:null, defaultRepositoryId:null, dataSources:null, defaultDataSourceId:null, container:null, helpUrl:null, messageSearchUrl:"http://www.ibm.com/search/csass/search?q=", applicationName:null, loginLogoUrl:null, bannerLogoUrl:null, loginInformationUrl:null, passwordRulesUrl:null, bannerBackgroundColor:null, bannerApplicationNameColor:null, bannerMenuColor:null, actionLists:null, openActions:null, viewers:null, viewerMappings:null, viewersCache:null, messages:null, actionsHandler:null, _undoQueue:null, _redoQueue:null, _selectedItems:null, repositoryId:null, templateName:null, documentId:null, emailLink:null, layout:"ecm.widget.layout.NavigatorMainLayout", layoutDijit:null, dirtyMessage:null, enableThumbnails:true, showViewFilmstrip:true, showGlobalToolbar:false, preventCreateNewSearch:false, preventCreateNewUnifiedSearch:false, showSecurity:false, fileIntoFolder:false, configuredLabels:null, defaultLayoutRepositories:null, features:null, defaultFeature:null, adminFeature:null, _tamKerberosTokenPresent:false, desktopLoaded:false, favorites:null, fileTypes:null, userActionMacros:null, appServerOs:null, maxNumberDocToAdd:null, maxNumberDocToModify:null, _loadedViewerClasses:new Object(), valueFormatter:null, mobileAppAccess:null, addPhotoFromMobile:null, addDocFoldersToRepo:null, openDocFromOtherApp:null, mobileFeatures:null, requestTimeout:undefined, onRequestTimeout:undefined, taskManager:null, constructor:function () {
            if (!this.valueFormatter) {
                this.valueFormatter = new ValueFormatter();
            }
            if (!this.repositories) {
                this.repositories = [];
            }
            if (!this.dataSources) {
                this.dataSources = [];
            }
            if (!this.actionLists) {
                this.actionLists = [];
            }
            if (!this.viewers) {
                this.viewers = [];
            }
            if (!this.viewerMappings) {
                this.viewerMappings = [];
            }
            if (!this.viewersCache) {
                this.viewersCache = {};
            }
            if (!this.messages) {
                this.messages = [];
            }
            if (!this._undoQueue) {
                this._undoQueue = [];
            }
            if (!this._redoQueue) {
                this._redoQueue = [];
            }
            if (!this._selectedItems) {
                this._selectedItems = [];
            }
            if (!this.fileTypes) {
                this.fileTypes = [];
            }
            if (!this.userActionMacros) {
                this.userActionMacros = [];
            }
            if (!this.appServerOs) {
                this.appServerOs = {};
            }
            if (!this.mobileFeatures) {
                this.mobileFeatures = [];
            }
            if (!this.taskManager) {
                this.taskManager = new TaskManager();
            }
            if (kernel.global.location && kernel.global.location.href.substring(0, 5) == "file:") {
                this.servicesUrl = null;
                this._cServicesUrl = null;
            } else {
                var contextRoot = config.baseUrl.substring(0, config.baseUrl.length - 1);
                var end = contextRoot.lastIndexOf("/");
                contextRoot = contextRoot.substring(0, end);
                if (contextRoot == "") {
                    this.servicesUrl = ".";
                    contextRoot = window.location.pathname;
                    end = contextRoot.lastIndexOf("/");
                    this._cServicesUrl = contextRoot.substring(0, end);
                } else {
                    this.servicesUrl = contextRoot;
                    this._cServicesUrl = contextRoot;
                }
            }
        }, copyDesktop:function (desktop) {
            this.authenticationType = desktop.authenticationType;
            this.repositories = desktop.repositories;
            this.defaultRepositoryId = desktop.defaultRepositoryId;
            this.dataSources = desktop.dataSources;
            this.defaultDataSourceId = desktop.defaultDataSourceId;
            this.disableCookies = desktop.disableCookies;
            this.disableAutocomplete = desktop.disableAutocomplete;
            this.culturalCollation = desktop.culturalCollation;
            this.theme = desktop.theme;
            this.helpUrl = desktop.helpUrl;
            this.messageSearchUrl = desktop.messageSearchUrl;
            this.applicationName = desktop.applicationName;
            this.loginLogoUrl = desktop.loginLogoUrl;
            this.bannerLogoUrl = desktop.bannerLogoUrl;
            this.loginInformationUrl = desktop.loginInformationUrl;
            this.passwordRulesUrl = desktop.passwordRulesUrl;
            this.bannerBackgroundColor = desktop.bannerBackgroundColor;
            this.bannerApplicationNameColor = desktop.bannerApplicationNameColor;
            this.bannerMenuColor = desktop.bannerMenuColor;
            this._role = desktop._role;
            this.viewers = desktop.viewers;
            this.viewerMappings = desktop.viewerMappings;
            this.layout = desktop.layout;
            this.layoutDijit = desktop.layoutDijit;
            this.enableThumbnails = desktop.enableThumbnails;
            this.showViewFilmstrip = desktop.showViewFilmstrip;
            this.showGlobalToolbar = desktop.showGlobalToolbar;
            this.preventCreateNewSearcn = desktop.preventCreateNewSearch;
            this.preventCreateNewUnifiedSearcn = desktop.preventCreateNewUnifiedSearch;
            this.showSecurity = desktop.showSecurity;
            this.fileIntoFolder = desktop.fileIntoFolder;
            this.features = desktop.features;
            this.defaultFeature = desktop.defaultFeature;
            this.defaultLayoutRepositories = desktop.defaultLayoutRepositories;
            this.documentId = desktop.documentId;
            this.emailLink = desktop.emailLink;
            this.messages = desktop.messages;
            this._redoQueue = desktop._redoQueue;
            this.repositoryId = desktop.repositoryId;
            this._selectedItems = desktop._selectedItems;
            this.servicesUrl = desktop.servicesUrl;
            this.templateName = desktop.templateName;
            this._undoQueue = desktop._undoQueue;
            this.desktopLoaded = desktop.desktopLoaded;
            this._initialRepository = desktop._initialRepository;
            this._authenticatingRepositoryId = desktop._authenticatingRepositoryId;
            this.container = desktop.container;
            this._plugins = desktop._plugins;
            this._applicationConfig = desktop._applicationConfig;
            this.adminFeature = desktop.adminFeature;
            this._tamKerberosTokenPresent = desktop._tamKerberosTokenPresent;
            this.favorites = desktop.favorites;
            this.fileTypes = desktop.fileTypes;
            this.userActionMacros = desktop.userActionMacros;
            this.appServerOs = desktop.appServerOs;
            this.maxNumberDocToAdd = desktop.maxNumberDocToAdd;
            this.maxNumberDocToModify = desktop.maxNumberDocToModify;
            this.navigatorRelease = desktop.navigatorRelease;
            this.navigatorBuild = desktop.navigatorBuild;
            this.mobileAppAccess = desktop.mobileAppAccess;
            this.addPhotoFromMobile = desktop.addPhotoFromMobile;
            this.addDocFoldersToRepo = desktop.addDocFoldersToRepo;
            this.openDocFromOtherApp = desktop.openDocFromOtherApp;
            this.taskManager = desktop.taskManager;
            this.mobileFeatures = [];
            array.forEach(desktop.mobileFeatures, function (desktopMobileFeature) {
                var mobileFeature = {};
                mobileFeature.id = desktopMobileFeature.id;
                mobileFeature.name = desktopMobileFeature.name;
                mobileFeature.display = desktopMobileFeature.display;
                mobileFeature.url = desktopMobileFeature.url;
                mobileFeature.iconFile = desktopMobileFeature.iconFile;
                this.mobileFeatures.push(mobileFeature);
            }, this);
        }, logon:function (password, callback, reqParams) {
            if (!reqParams) {
                reqParams = {};
            }
            lang.mixin(reqParams, {desktop:this.id, userid:this.userId, password:password});
            var enableSecureService = Request.enableSecureService;
            try {
                Request.enableSecureService = true;
                var request = Request.invokeService("logon", null, reqParams, lang.hitch(this, function (response) {
                    this._logonCompleted(response, callback);
                }));
            }
            finally {
                Request.enableSecureService = enableSecureService;
            }
            return request;
        }, _logonCompleted:function (response, callback) {
            this.connected = true;
            this.userId = response.userid;
            this.userDisplayName = response.user_displayname;
            this.taskManager.taskSecurityRoles = response.taskSecurityRoles;
            if (response.adminLayout) {
                if (!response.adminLayout.featureTooltip) {
                    response.adminLayout.featureTooltip = ecm.messages.launchbar_admin;
                }
                this.createAdminFeature(response.adminLayout);
            }
            this.onChange(this);
            if (response.desktopAttributes) {
                lang.mixin(this, response.desktopAttributes);
            }
            if (this.repositories.length > 0) {
                for (var i in response.servers) {
                    var repositoryJSON = response.servers[i];
                    if (repositoryJSON.connected) {
                        var repository = this.getRepository(repositoryJSON.repositoryId);
                        if (repository != null && repository != this) {
                            repository._loadRepository(repositoryJSON);
                            if (this.defaultRepositoryId == repository.id) {
                                repository.userDisplayName = this.userDisplayName;
                                this.onLogin(repository);
                            }
                        }
                    }
                }
            }
            if (this.dataSources && this.dataSources.length > 0) {
                for (var i in response.dataSources) {
                    var dataSourceJSON = response.dataSources[i];
                    if (dataSourceJSON.connected) {
                        var dataSource = this.getDataSource(dataSourceJSON.id);
                        if (dataSource != null) {
                            lang.mixin(dataSource, dataSourceJSON);
                            if (this.defaultDataSourceId == dataSource.id) {
                                dataSource.userDisplayName = this.userDisplayName;
                                this.onLogin(dataStore);
                            }
                        }
                    }
                }
            }
            if (this.authenticationType != 2) {
                this.onLogin(null);
            }
            if (callback) {
                callback(this);
            }
        }, logoff:function () {
            var request = Request.invokeService("logoff", null, {desktop:this.id}, lang.hitch(this, function (response) {
                this._logoffCompleted(response);
            }));
            return request;
        }, _logoffCompleted:function (response) {
            this.connected = false;
            this.desktop = null;
            if (this.repositories) {
                for (var i in this.repositories) {
                    var repository = this.repositories[i];
                    if (repository) {
                        repository._logoffCompleted(response);
                    }
                }
            }
            if (this.dataSources) {
                for (var i in this.dataSources) {
                    var dataSource = this.dataSources[i];
                    if (dataSource) {
                        dataSource.connected = false;
                        dataSource.onDisconnected();
                    }
                }
            }
            if (this.container) {
                this.container.connected = false;
                this.container.onDisconnected();
            }
            if (this.taskManager) {
                this.taskManager.logoff();
            }
            this.clearFavorites();
            this.onLogout(null);
        }, setServicesUrl:function (url) {
            this.servicesUrl = url;
            this.onChange(this);
        }, getServicesUrl:function () {
            return this.servicesUrl;
        }, setActionsHandler:function (actionsHandler) {
            this.actionsHandler = actionsHandler;
            this.onChange(this);
        }, getActionsHandler:function (callback) {
            var self = this;
            if (!this.actionsHandler && this._actionHandler) {
                var widgetReq = this._actionHandler.split(".").join("/");
                require([widgetReq], function (cls) {
                    self.actionsHandler = new cls();
                    if (callback) {
                        callback(self.actionsHandler);
                    }
                });
            } else {
                if (callback) {
                    callback(this.actionsHandler);
                }
            }
            return this.actionsHandler;
        }, getInitialRepository:function () {
            return this._initialRepository;
        }, setInitialRepository:function (repository) {
            this._initialRepository = repository;
        }, getAuthenticatingRepository:function () {
            if (this._authenticatingRepositoryId) {
                return this.getRepository(this._authenticatingRepositoryId);
            }
            return null;
        }, getAuthenticatingRepositoryId:function () {
            return this._authenticatingRepositoryId;
        }, getDefaultRepositoryId:function () {
            return this.defaultRepositoryId;
        }, setDefaultRepositoryId:function (repository) {
            this.defaultRepositoryId = repository;
        }, getDefaultRepository:function () {
            if (this.defaultRepositoryId) {
                return this.getRepository(this.defaultRepositoryId);
            }
            return null;
        }, getDefaultLayoutRepositories:function () {
            return this.defaultLayoutRepositories;
        }, isContainerLoggedIn:function () {
            if (this.container) {
                return true;
            }
            return false;
        }, getHelpUrl:function (forPage) {
            return forPage ? this.helpUrl + "index.jsp?content=/com.ibm.usingeuc.doc/" : this.helpUrl;
        }, getMessageSearchUrl:function () {
            return this.messageSearchUrl || "http://www.ibm.com/search/csass/search?q=";
        }, getLayout:function (callback) {
            var self = this;
            if (!this.layoutDijit) {
                var widgetReq = this.layout.split(".").join("/");
                require([widgetReq], function (cls) {
                    self.layoutDijit = new cls({});
                    if (callback) {
                        callback(self.layoutDijit);
                    }
                });
            } else {
                if (callback) {
                    callback(self.layoutDijit);
                }
            }
            return this.layoutDijit;
        }, createAdminFeature:function (repositoryJSON) {
            this.adminFeature = new Feature(repositoryJSON);
        }, addFeature:function (feature) {
            if (!feature) {
                return;
            }
            if (!this.features) {
                this.features = [];
            }
            this.features.push(feature);
            this.onChange(feature);
        }, removeFeature:function (feature) {
            if (!feature) {
                return;
            }
            if (this.features) {
                for (var index in this.features) {
                    if (feature.id == this.features[index].id) {
                        this.features.splice(index, 1);
                        if (this.adminFeature) {
                            if (feature.id == this.adminFeature.id) {
                                this.adminFeature = null;
                            }
                        }
                    }
                }
                this.onChange(feature);
            }
        }, getFeature:function (feature) {
            if (this.features && feature) {
                for (var i in this.features) {
                    var feat = this.features[i];
                    if (feat.id == feature.id) {
                        return feature;
                    }
                }
            }
            return null;
        }, isTamKerberosTokenPersent:function () {
            return this._tamKerberosTokenPresent;
        }, setTamKerberosTokenPersent:function (token) {
            this._tamKerberosTokenPresent = token;
        }, getRepositoriesStore:function () {
            return new _ModelStore(this, lang.hitch(this, function (callback) {
                callback(this.repositories);
            }));
        }, getRepository:function (repositoryId) {
            if (this.repositories) {
                for (var i in this.repositories) {
                    var repository = this.repositories[i];
                    if (repository.id == repositoryId) {
                        return repository;
                    }
                }
            }
            return null;
        }, getDataSource:function (id) {
            if (this.dataSources) {
                for (var i in this.dataSources) {
                    var datasource = this.dataSources[i];
                    if (datasource.id == id) {
                        return datasource;
                    }
                }
            }
            return null;
        }, getRepositoryByName:function (name) {
            if (this.repositories) {
                for (var i in this.repositories) {
                    var repository = this.repositories[i];
                    if (repository.type == "p8" && (repository.objectStoreName == name || repository.objectStoreDisplayName == name)) {
                        return repository;
                    } else {
                        if (repository.serverName == name) {
                            return repository;
                        }
                    }
                }
            }
            return null;
        }, getRepositoryOfObjectStore:function (objectStoreName) {
            if (this.repositories) {
                for (var i in this.repositories) {
                    var repository = this.repositories[i];
                    if (repository.objectStoreName == objectStoreName) {
                        return repository;
                    }
                }
            }
            return null;
        }, onDesktopLoaded:function (response) {
            this.desktopLoaded = true;
        }, isLoggedIn:function () {
            return this._initialRepository && this._initialRepository.connected;
        }, setSelectedItems:function (items) {
            this._selectedItems = items;
            this.onChange(this);
        }, getSelectedItems:function () {
            return this._selectedItems;
        }, addMessage:function (message) {
            this.logInfo("addMessage", message);
            this.messages.push(message);
            if (this.messages.length > 100) {
                this.messages.shift();
            }
            this.onMessagesChanged();
            this.onMessageAdded(message);
            this.onChange(this);
        }, clearMessages:function () {
            this.messages = [];
            this.onMessagesChanged();
            this.onChange(this);
        }, getViewer:function (viewerId) {
            for (var i in this.viewers) {
                var viewer = this.viewers[i];
                if (viewer.id == viewerId) {
                    return viewer;
                }
            }
            return null;
        }, getViewerForItem:function (item, explicitMatchRequired) {
            var returnViewer = null;
            for (var i in this.viewerMappings) {
                var viewerMapping = this.viewerMappings[i];
                var viewer = viewerMapping.useViewer(item, explicitMatchRequired);
                if (viewer) {
                    returnViewer = viewer;
                    break;
                }
            }
            return returnViewer;
        }, loadViewerClasses:function (loadedCallback, viewerClasses) {
            var methodName = "loadViewerClasses";
            if (!viewerClasses) {
                viewerClasses = this._getConfiguredViewerClasses();
            }
            var requestedClasses = [];
            var requestedParms = "";
            var requestedStores = "";
            for (var idx = 0; idx < viewerClasses.length; idx++) {
                var viewerClass = viewerClasses[idx];
                if (!this._loadedViewerClasses[viewerClass]) {
                    requestedClasses.push(viewerClass.split(".").join("/"));
                    if (requestedParms != "") {
                        requestedParms = requestedParms + ", ";
                    }
                    var clsVar = "cls" + idx;
                    requestedParms = requestedParms + clsVar;
                    requestedStores = requestedStores + "this._loadedViewerClasses['" + viewerClass + "'] = " + clsVar + ";\n ";
                }
            }
            if (requestedClasses.length > 0) {
                eval("var handler = function(" + requestedParms + ") {" + requestedStores + " loadedCallback(); }");
                require(requestedClasses, lang.hitch(this, handler));
            } else {
                loadedCallback();
            }
        }, _getConfiguredViewerClasses:function () {
            var viewerClasses = new Array();
            var requestedViewers = new Object();
            for (idx = 0; idx < this.viewers.length; idx++) {
                var viewerClass = this.viewers[idx].viewerClass;
                if (viewerClass != null && !requestedViewers[viewerClass]) {
                    requestedViewers[viewerClass] = true;
                    viewerClasses.push(viewerClass);
                }
            }
            delete requestedViewers;
            return viewerClasses;
        }, getViewersForItem:function (item, explicitMatchRequired) {
            var methodName = "getViewersForItem";
            var viewers = this._getCachedViewers(item, explicitMatchRequired);
            if (viewers == null) {
                viewers = new Array();
                for (var i in this.viewerMappings) {
                    var viewerMapping = this.viewerMappings[i];
                    var viewer = viewerMapping.useViewer(item, explicitMatchRequired);
                    if (viewer) {
                        if (this._canOpenItem(viewer, item)) {
                            viewers.push(viewer);
                        }
                    }
                }
                this._setCachedViewers(item, explicitMatchRequired, viewers);
            }
            return viewers;
        }, getLoadedViewerClass:function (viewer) {
            var cls = null;
            var viewerClass = viewer.viewerClass;
            if (this._loadedViewerClasses[viewerClass]) {
                cls = this._loadedViewerClasses[viewerClass];
            }
            return cls;
        }, _getCachedViewersKey:function (item, explicitMatchRequired) {
            var contentType = item.mimetype || "";
            contentType = contentType.toLowerCase();
            if (contentType == null || contentType == "") {
                contentType = item.getContentClass();
            }
            return item.repository.type + contentType + explicitMatchRequired;
        }, _getCachedViewers:function (item, explicitMatchRequired) {
            var key = this._getCachedViewersKey(item, explicitMatchRequired);
            return this.viewersCache[key];
        }, _setCachedViewers:function (item, explicitMatchRequired, viewers) {
            var key = this._getCachedViewersKey(item, explicitMatchRequired);
            this.viewersCache[key] = viewers;
        }, _canOpenItem:function (viewer, item) {
            var viewerClass = viewer.viewerClass;
            var docViewer = null;
            if (this._loadedViewerClasses[viewerClass]) {
                docViewer = new this._loadedViewerClasses[viewerClass]();
            } else {
                var widgetReq = viewerClass.split(".").join("/");
                require([widgetReq], dojo.hitch(this, function (cls) {
                    docViewer = new cls();
                    this._loadedViewerClasses[viewerClass] = cls;
                }));
            }
            var canOpenItem = docViewer.canOpenItem(item);
            delete docViewer;
            return canOpenItem;
        }, onRequestStarted:function (request) {
        }, onRequestCompleted:function (request) {
        }, onMessageAdded:function (message) {
        }, onMessagesChanged:function () {
        }, addUndoableTask:function (task) {
            if (this._undoQueue.length >= this._maxUndoQueueLength) {
                this._undoQueue.shift();
            }
            this._undoQueue.push(task);
            this._redoQueue = [];
            this.onChange(this);
        }, canUndo:function () {
            return this._undoQueue.length > 0;
        }, getUndoDescription:function () {
            return ecm.messages.format(this.messages.undo_description, this._undoQueue[this._undoQueue.length - 1].name);
        }, undo:function () {
            var task = this._undoQueue.pop();
            if (!task) {
                this.logError("undo", "No task on undo queue!");
            } else {
                task.undoit();
                this._redoQueue.push(task);
                this.onChange(this);
            }
        }, canRedo:function () {
            return this._redoQueue.length > 0;
        }, getRedoDescription:function () {
            return ecm.messages.format(this.messages.redo_description, this._undoQueue[this._undoQueue.length - 1].name);
        }, redo:function () {
            var task = this._redoQueue.pop();
            if (!task) {
                this.logError("undo", "No task on redo queue!");
            } else {
                task.doit();
                this._undoQueue.push(task);
                this.onChange(this);
            }
        }, refresh:function () {
            array.forEach(this.repositories, function (repository) {
                if (repository.connected) {
                    repository.refresh();
                }
            });
        }, refreshActionsList:function () {
            this.actionLists = [];
        }, loadDesktop:function (desktopId, callback, synchronous) {
            this.id = desktopId || "";
            var self = this;
            var request = Request.invokeService("getDesktop", null, {desktop:this.id}, function (response) {
                self._desktopLoaded(response, callback);
            }, false, synchronous);
            this.getConfiguredLabels(lang.hitch(this, function (callback) {
            }));
            return request;
        }, getRequestParam:function (name) {
            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var regexStr = "[\\?&]" + name + "=([^&#]*)";
            var regex = new RegExp(regexStr);
            var results = regex.exec(window.location.href);
            if (results == null) {
                return null;
            } else {
                return results[1];
            }
        }, createRepository:function (repositoryJSON) {
            var initialPrivileges = {};
            initialPrivileges.foldering = repositoryJSON.folderingEnabled || false;
            if (repositoryJSON.connected) {
                initialPrivileges.addDoc = repositoryJSON.priv_addDoc || false;
                initialPrivileges.addItem = repositoryJSON.priv_addItem || false;
                initialPrivileges.addSearch = repositoryJSON.priv_addSearch || false;
                initialPrivileges.addUnifiedSearch = repositoryJSON.priv_addUnifiedSearch || false;
                initialPrivileges.createHold = repositoryJSON.privCreateHold || false;
                initialPrivileges.addTeamspace = repositoryJSON.priv_addTeamspace || false;
                initialPrivileges.addTeamspaceTemplate = repositoryJSON.priv_addTeamspaceTemplate || false;
                initialPrivileges.manageTeamspace = true;
                initialPrivileges.search = true;
                initialPrivileges.workflow = repositoryJSON.type == "cm" || (repositoryJSON.type == "p8" && repositoryJSON.connectionPoint != null);
            } else {
                if (repositoryJSON.type == "p8") {
                    initialPrivileges.workflow = repositoryJSON.connectionPoint != null && repositoryJSON.connectionPoint != "";
                }
            }
            repositoryJSON.id = repositoryJSON.repositoryId;
            repositoryJSON.name = repositoryJSON.displayName;
            repositoryJSON.privileges = initialPrivileges;
            var repository = new Repository(repositoryJSON);
            if (repositoryJSON.userID) {
                repository.userId = repositoryJSON.userID;
            }
            repository.isAdminUser = (repositoryJSON.admin_user == true);
            if (repositoryJSON.adminLayout) {
                if (!repositoryJSON.adminLayout.featureTooltip) {
                    repositoryJSON.adminLayout.featureTooltip = ecm.messages.launchbar_admin;
                }
                ecm.model.desktop.createAdminFeature(repositoryJSON.adminLayout);
                if (ecm.model.desktop.adminFeature) {
                    this.features.push(ecm.model.desktop.adminFeature);
                }
            }
            if (repositoryJSON.type == "p8") {
                repository.objectStoreName = repositoryJSON.objectStore;
                repository.objectStoreDisplayName = repositoryJSON.objectStoreDisplayName;
            }
            repository.serverName = repositoryJSON.hostName;
            return repository;
        }, _desktopLoaded:function (response, callback) {
            this.id = response.id;
            this.name = response.name;
            this.authenticationType = response.authenticationType || 2;
            this.connected = response.connected;
            this.userId = response.userid;
            this.userDisplayName = response.user_displayname;
            this.navigatorRelease = response.navigatorRelease;
            this.navigatorBuild = response.navigatorBuild;
            this.disableCookies = response.disableCookies || false;
            this.disableAutocomplete = response.disableAutocomplete || false;
            this.culturalCollation = response.culturalCollation || false;
            this.theme = response.theme;
            this.helpUrl = response.helpURL || document.location.protocol + "//" + document.location.host + "/wcdocs/";
            this.messageSearchUrl = response.messageSearchURL || "http://www.ibm.com/search/csass/search?q=";
            this.applicationName = response.applicationName || ecm.messages.product_name;
            this.loginLogoUrl = response.loginLogoURL;
            this.bannerLogoUrl = response.bannerLogoURL;
            this.loginInformationUrl = response.loginInformationURL;
            this.passwordRulesUrl = response.passwordRulesURL;
            this.bannerBackgroundColor = response.bannerBackgroundColor;
            this.bannerApplicationNameColor = response.bannerApplicationNameColor;
            this.bannerMenuColor = response.bannerMenuColor;
            this._authenticatingRepositoryId = response.authenticatingRepositoryId;
            this.defaultLayoutRepositories = response.defaultLayoutRepositories;
            this._additionalScript = response.additionalScript;
            this._additionalCss = response.additionalCss;
            this.layout = response.layout || "ecm.widget.layout.NavigatorMainLayout";
            this.maxNumberDocToAdd = response.maxNumberDocToAdd || 50;
            this.maxNumberDocToModify = response.maxNumberDocToModify || 50;
            this._actionHandler = response.actionHandler || "ecm.widget.layout.CommonActionsHandler";
            this.taskManager.taskSecurityRoles = response.taskSecurityRoles;
            this.taskManager.serviceURL = response.taskManagerServiceURL;
            var defaultFeatureParamValue = this.getRequestParam("feature");
            var featureValueValid = false;
            if (response.features) {
                this.features = [];
                for (var i = 0; i < response.features.length; i++) {
                    var featureI = new Feature(response.features[i]);
                    this.features.push(featureI);
                    if (!featureValueValid && defaultFeatureParamValue) {
                        if (featureI.id == defaultFeatureParamValue) {
                            featureValueValid = true;
                        }
                    }
                }
            }
            if (featureValueValid) {
                this.defaultFeature = defaultFeatureParamValue;
            } else {
                if (defaultFeatureParamValue) {
                    if (defaultFeatureParamValue != "ecmClientAdmin") {
                        ecm.model.desktop.addMessage(Message.createErrorMessage("feature_invalid", [defaultFeatureParamValue]));
                        this.defaultFeature = response.defaultFeature;
                    } else {
                        this.defaultFeature = "ecmClientAdmin";
                    }
                } else {
                    this.defaultFeature = response.defaultFeature;
                }
            }
            this._role = response.role;
            this.showGlobalToolbar = response.showGlobalToolbar || false;
            this.preventCreateNewSearch = response.preventCreateNewSearch || false;
            this.preventCreateNewUnifiedSearch = response.preventCreateNewUnifiedSearch || false;
            this.showSecurity = response.showSecurity || false;
            this.fileIntoFolder = response.fileIntoFolder || false;
            this.enableThumbnails = true;
            if (response.enableThumbnails == false) {
                this.enableThumbnails = false;
            }
            this.showViewFilmstrip = true;
            if (response.showViewFilmstrip == undefined) {
                this.showViewFilmstrip = this.enableThumbnails;
            } else {
                if (response.showViewFilmstrip == false) {
                    this.showViewFilmstrip = false;
                }
            }
            if (this._additionalScript) {
                try {
                    var scriptText;
                    xhr.get({url:this._additionalScript, sync:true, load:function (text) {
                        scriptText = text;
                    }});
                    if (has("ie")) {
                        window.execScript(scriptText);
                    } else {
                        eval.call(window, scriptText);
                    }
                }
                catch (e) {
                    this.logError("_desktopLoaded", "Error evaluating additional JavaScript for desktop");
                    ecm.model.desktop.addMessage(Message.createErrorMessage("desktop_error", [this.getId]));
                }
            }
            if (this._additionalCss) {
                if (has("ie")) {
                    document.createStyleSheet(this._additionalCss);
                } else {
                    var head = document.getElementsByTagName("head")[0];
                    var link = document.createElement("link");
                    link.rel = "stylesheet";
                    link.type = "text/css";
                    link.href = this._additionalCss;
                    head.appendChild(link);
                }
            }
            this.defaultRepositoryId = response.defaultRepositoryId;
            this.repositories = [];
            for (var i in response.servers) {
                var repositoryJSON = response.servers[i];
                this.repositories.push(this.createRepository(repositoryJSON));
            }
            this.container = null;
            if (response.containers) {
                var containerJSON = response.containers;
                var container = new Container(containerJSON);
                container.userId = containerJSON.userID;
                container.userDisplayName = containerJSON.user_displayname;
                container.desktop = containerJSON.desktop;
                if (containerJSON.adminLayout) {
                    if (!containerJSON.adminLayout.featureTooltip) {
                        containerJSON.adminLayout.featureTooltip = ecm.messages.launchbar_admin;
                    }
                    this.createAdminFeature(containerJSON.adminLayout);
                    if (this.adminFeature) {
                        this.features.push(this.adminFeature);
                    }
                }
                if (this.authenticationType == 1 && container.connected) {
                    container.onConnected(container);
                    this.onLogin();
                }
            }
            this.container = container;
            if (response.tam_token) {
                this._tamKerberosTokenPresent = response.tam_token;
            }
            this._plugins = response.plugins;
            this._initializePlugins();
            if (response.openActions) {
                this.openActions = {};
                for (var i = 0; i < response.openActions.length; i++) {
                    var openAction = response.openActions[i];
                    for (var r = 0; r < openAction.serverTypes.length; r++) {
                        var serverType = openAction.serverTypes[r];
                        if (!this.openActions[serverType]) {
                            this.openActions[serverType] = {};
                        }
                        for (var m = 0; m < openAction.contentTypes.length; m++) {
                            var contentType = openAction.contentTypes[m];
                            if (!this.openActions[serverType][contentType]) {
                                this.openActions[serverType][contentType] = openAction;
                            } else {
                                if (openAction.id != this.openActions[serverType][contentType].id) {
                                }
                            }
                        }
                    }
                }
            }
            this.viewers = [];
            for (var i in response.viewerDefs) {
                var viewerJSON = response.viewerDefs[i];
                viewerJSON.id = viewerJSON.viewerName;
                viewerJSON.name = viewerJSON.viewerName;
                var viewer = new Viewer(viewerJSON);
                this.viewers.push(viewer);
            }
            this.viewerMappings = [];
            var ctr = 0;
            for (var i in response.viewerMappings) {
                var viewerMappingJSON = response.viewerMappings[i];
                if (viewerMappingJSON.contentTypes instanceof Array) {
                    for (var j = 0; j < viewerMappingJSON.contentTypes.length; j++) {
                        var contentType = viewerMappingJSON.contentTypes[j];
                        var viewerMapping = new ViewerMapping({id:ctr, name:ctr, contentType:contentType, serverType:viewerMappingJSON.serverType, viewer:this.getViewer(viewerMappingJSON.viewerName)});
                        this.viewerMappings.push(viewerMapping);
                        ctr++;
                    }
                } else {
                    var viewerMapping = new ViewerMapping({id:ctr, name:ctr, contentType:viewerMappingJSON.contentTypes, serverType:viewerMappingJSON.serverType, viewer:this.getViewer(viewerMappingJSON.viewerName)});
                    this.viewerMappings.push(viewerMapping);
                    ctr++;
                }
            }
            for (var menuId in response.menus) {
                var actions = [];
                this._loadActions(response.menus[menuId], actions);
                this.actionLists[menuId] = actions;
            }
            var iconMappings = [];
            for (var i in response.iconMappings) {
                var iconMappingJSON = response.iconMappings[i];
                var id = iconMappingJSON.id;
                var iconConfig = IconConfig.createIconConfig(id);
                iconConfig.setClassName(iconMappingJSON.className);
                iconConfig.setFileName(iconMappingJSON.fileName);
                iconConfig.setContentTypes(iconMappingJSON.contentTypes);
                iconMappings.push(iconConfig);
            }
            Item.loadIconMapping(iconMappings);
            var iconStates = [];
            for (var i in response.iconStatus) {
                var iconStatusJSON = response.iconStatus[i];
                var id = iconStatusJSON.id;
                var iconStatusConfig = IconStatusConfig.createIconStatusConfig(id);
                iconStatusConfig.setClassName(iconStatusJSON.className);
                iconStatusConfig.setFileName(iconStatusJSON.fileName);
                iconStatusConfig.setServers(iconStatusJSON.servers);
                iconStatusConfig.setLabel(iconStatusJSON.label);
                iconStates.push(iconStatusConfig);
            }
            Item.loadIconStateMapping(iconStates);
            var uiLabels = [];
            for (var i in response.uiLabels) {
                var uiLabelJSON = response.uiLabels[i];
                var id = uiLabelJSON.id;
                var uiLabel = InterfaceTextConfig.createInterfaceTextConfig(id);
                lang.mixin(uiLabel, {_attributes:uiLabelJSON});
                var localeId = uiLabelJSON.localeData && uiLabelJSON.localeData.id ? uiLabelJSON.localeData.id : "" + i;
                var uiLabelLocale = InterfaceTextLocaleConfig.createInterfaceTextLocaleConfig(localeId);
                uiLabel.setLocaleData(uiLabelLocale);
                if (uiLabelJSON.localeData) {
                    lang.mixin(uiLabelLocale, {_attributes:uiLabelJSON.localeData});
                }
                uiLabels.push(uiLabel);
            }
            this.configuredLabels = new ConfiguredLabels(uiLabels);
            var classDisplayLabel = this.configuredLabels.getLabelValue("class_label", kernel.locale);
            ecm.messages.document_type = classDisplayLabel;
            ecm.messages.search_class = classDisplayLabel + ":";
            ecm.messages.search_class_multiple = classDisplayLabel + "(${0}):";
            ecm.messages.document_type = classDisplayLabel;
            ecm.messages.print_property_class = classDisplayLabel + ":";
            ecm.messages.class_label = classDisplayLabel;
            ecm.messages.class_label_no_html_encode = this.configuredLabels.getLabelValue("class_label", kernel.locale, false);
            var processRoleDisplayLabel = this.configuredLabels.getLabelValue("process_role", kernel.locale, false);
            ecm.messages.process_role = processRoleDisplayLabel;
            var processInbasketDisplayLabel = this.configuredLabels.getLabelValue("process_inbasket", kernel.locale, false);
            ecm.messages.process_inbasket = processInbasketDisplayLabel;
            var repositoryDisplayLabel = this.configuredLabels.getLabelValue("repository", kernel.locale);
            ecm.messages.repository = repositoryDisplayLabel;
            ecm.messages.repository_label = repositoryDisplayLabel;
            ecm.messages.server = repositoryDisplayLabel;
            array.forEach(response.fileTypes, function (fileTypeJSON) {
                var fileTypeConfig = FileTypeConfig.createFileTypeConfig(fileTypeJSON.id);
                fileTypeConfig.setName(fileTypeJSON.name);
                fileTypeConfig.setDescription(fileTypeJSON.description);
                fileTypeConfig.setContentTypes(fileTypeJSON.contentTypes);
                this.fileTypes.push(fileTypeConfig);
            }, this);
            array.forEach(response.userActionMacros, function (userActionMacroJSON) {
                var userActionMacroConfig = UserActionMacroConfig.createUserActionMacroConfig(userActionMacroJSON.id);
                userActionMacroConfig.setName(userActionMacroJSON.name);
                userActionMacroConfig.setServerType(userActionMacroJSON.serverType);
                userActionMacroConfig.setUserProperty(userActionMacroJSON.userProperty);
                userActionMacroConfig.setDateProperty(userActionMacroJSON.dateProperty);
                userActionMacroConfig.setReserved(userActionMacroJSON.reserved);
                this.userActionMacros.push(userActionMacroConfig);
            }, this);
            this.appServerOs = {name:response.appServerOSName, arch:response.appServerOSArch, version:response.appServerOSVersion, distroName:response.appServerOSDistroName, distroRelease:response.appServerOSDistroRelease};
            this.mobileAppAccess = response.mobileAppAccess;
            this.addPhotoFromMobile = response.addPhotoFromMobile;
            this.addDocFoldersToRepo = response.addDocFoldersToRepo;
            this.openDocFromOtherApp = response.openDocFromOtherApp;
            this.mobileFeatures = [];
            array.forEach(response.mobileFeatures, function (mobileFeatureJSON) {
                var mobileFeature = {};
                mobileFeature.id = mobileFeatureJSON.id;
                mobileFeature.name = mobileFeatureJSON.name;
                mobileFeature.display = mobileFeatureJSON.display;
                mobileFeature.url = mobileFeatureJSON.url;
                mobileFeature.iconFile = mobileFeatureJSON.iconFile;
                this.mobileFeatures.push(mobileFeature);
            }, this);
            this.defaultDataSourceId = response.defaultDataSourceId;
            this.dataSources = [];
            for (var i in response.dataSources) {
                var datasourceJSON = response.dataSources[i];
                var dsModelClassName = datasourceJSON.modelClass.split(".").join("/");
                var dsModelClass = null;
                require([dsModelClassName], function (cls) {
                    dsModelClass = new cls(datasourceJSON);
                });
                this.dataSources.push(dsModelClass);
                if (this.authenticationType == 3 && dsModelClass.connected) {
                    dsModelClass.onConnected(dsModelClass);
                    this.onLogin();
                }
            }
            this.onDesktopLoaded(response);
            if (callback) {
                callback(this);
            }
            this._checkForConnectedRepositories();
            this.onChange(this);
        }, _initializePlugins:function () {
            if (this._plugins) {
                for (var i in this._plugins) {
                    var plugin = this._plugins[i];
                    if (plugin.cssFileName) {
                        var cssFileUrl = Request.getPluginResourceUrl(plugin.id, plugin.cssFileName);
                        if (has("ie")) {
                            document.createStyleSheet(cssFileUrl);
                        } else {
                            var head = document.getElementsByTagName("head")[0];
                            var link = document.createElement("link");
                            link.rel = "stylesheet";
                            link.type = "text/css";
                            link.href = cssFileUrl;
                            head.appendChild(link);
                        }
                    }
                    if (plugin.dojoModule) {
                        var moduleUrl = Request.getPluginResourceUrl(plugin.id, plugin.dojoModule);
                        if (moduleUrl.indexOf("./") == 0) {
                            moduleUrl = "." + moduleUrl;
                        }
                        require({packages:[{name:plugin.dojoModule, location:escape(moduleUrl)}]});
                    }
                    if (plugin.script) {
                        var scriptUrl = Request.getPluginResourceUrl(plugin.id, plugin.script);
                        try {
                            var scriptText;
                            xhr.get({url:scriptUrl, sync:true, load:function (text) {
                                scriptText = text;
                            }});
                            if (has("ie")) {
                                window.execScript(scriptText);
                            } else {
                                eval.call(window, scriptText);
                            }
                        }
                        catch (e) {
                            this.logError("_desktopLoaded", "Error evaluating JavaScript for plugin " + plugin.id, e.message);
                            ecm.model.desktop.addMessage(Message.createErrorMessage("plugin_error", [plugin.id]));
                        }
                    }
                }
            }
        }, isPluginLoaded:function (pluginId) {
            if (this._plugins) {
                for (var i in this._plugins) {
                    if (this._plugins[i].id == pluginId) {
                        return true;
                    }
                }
            }
            return false;
        }, loadMenuActions:function (actionListSuffix, callback) {
            if (this.actionLists[actionListSuffix]) {
                callback(this.actionLists[actionListSuffix]);
            } else {
                var self = this;
                var params = {desktop:this.id, action_list_suffix:actionListSuffix};
                var request = Request.invokeService("getActions", null, params, function (response) {
                    self._actionsLoaded(response, actionListSuffix, callback);
                });
            }
            return request;
        }, _actionsLoaded:function (response, actionListSuffix, callback) {
            var actions = [];
            this._loadActions(response.actions, actions);
            this.actionLists[actionListSuffix] = actions;
            callback(actions);
        }, _loadActions:function (actionsJSON, actions) {
            for (var i in actionsJSON) {
                var actionJSON = actionsJSON[i];
                var action;
                if (actionJSON.actionModelClass) {
                    var widgetReq = actionJSON.actionModelClass.split(".").join("/");
                    require([widgetReq], lang.hitch(this, function (actionJSON, actions, cls) {
                        action = new cls(actionJSON);
                        this._recLoadActions(actionJSON, action, actions);
                    }, actionJSON, actions));
                } else {
                    action = new Action(actionJSON);
                    this._recLoadActions(actionJSON, action, actions);
                }
            }
        }, _recLoadActions:function (actionJSON, action, actions) {
            if (actionJSON.actions && actionJSON.actions.length > 0) {
                this._loadActions(actionJSON.actions, action.subActions);
            }
            actions.push(action);
        }, _checkForConnectedRepositories:function () {
            for (var i in this.repositories) {
                var repository = this.repositories[i];
                if (repository.connected) {
                    repository.onConnected(repository);
                    if (this.authenticationType == 2 && repository.id == this.defaultRepositoryId) {
                        this._initialRepository = repository;
                        this.onLogin(repository);
                        break;
                    }
                }
            }
        }, getCustomLabel:function (name) {
            return ecm.messages[name];
        }, onTeamspacesValueChanged:function (id, teamspacesStringValue) {
            for (var i = 0; i < this.repositories.length; i++) {
                var repository = this.repositories[i];
                if (repository.id == id) {
                    var teamspacesEnabled = (teamspacesStringValue == true || teamspacesStringValue == "true");
                    if (repository.teamspacesEnabled != teamspacesEnabled) {
                        repository._teamspacesEnabled = teamspacesEnabled;
                        this.onTeamspacesListChanged();
                    }
                    break;
                }
            }
        }, onTeamspacesListChanged:function () {
        }, clearFavorites:function () {
            this.favorites = null;
        }, loadFavorites:function (callback) {
            if (this.favorites && this.favoritesStructure && this.favoritesMagazineStructure) {
                if (callback) {
                    callback(this.favorites, this.favoritesStructure, this.favoritesMagazineStructure);
                }
            } else {
                var params = {application:"navigator", userid:this.id + "." + this.getDefaultRepositoryId() + "." + this.getDefaultRepository().userId.toLowerCase()};
                Request.invokeService("listFavorites", null, params, lang.hitch(this, function (response) {
                    this.favoritesStructure = response.columns;
                    this.favoritesMagazineStructure = response.magazineColumns;
                    var itemsJSON = response.rows;
                    if (itemsJSON) {
                        if (!this.favorites) {
                            this.favorites = [];
                        }
                        for (var i in itemsJSON) {
                            var item = itemsJSON[i];
                            var favorite = new Favorite(item);
                            this.favorites.push(favorite);
                        }
                    } else {
                        this.favorites = null;
                    }
                    if (callback) {
                        callback(this.favorites, this.favoritesStructure, this.favoritesMagazineStructure);
                    }
                }));
            }
        }, addFavorite:function (favorite, callback) {
            var params = {application:"navigator", action:"add", configuration:"FavoriteConfig", id:favorite.id, update_list_configuration:"UserConfig", update_list_id:this.id + "." + this.getDefaultRepositoryId() + "." + this.getDefaultRepository().userId.toLowerCase(), update_list_type:"favorites"};
            Request.postService("user", null, params, "text/json", favorite.toJSON(), lang.hitch(this, function (response) {
                this._addFavoriteCompleted(response, favorite, callback);
            }));
        }, _addFavoriteCompleted:function (response, favorite, callback) {
            if (favorite) {
                favorite.repositoryLabel = response.configuration.repositoryLabel;
                if (!this.favorites) {
                    this.favorites = [];
                }
                this.favorites.push(favorite);
                if (callback) {
                    callback(favorite);
                }
                this.onFavoriteAdded(favorite);
            }
        }, onFavoriteAdded:function (favorite) {
        }, updateFavorite:function (favorite, callback) {
            var params = {application:"navigator", action:"update", configuration:"FavoriteConfig", id:favorite.favoriteId ? favorite.favoriteId : favorite.id};
            Request.postService("user", null, params, "text/json", favorite.toJSON(), lang.hitch(this, function (response) {
                this._updateFavoriteCompleted(response, favorite, callback);
            }));
        }, _updateFavoriteCompleted:function (response, favorite, callback) {
            if (favorite && this.favorites) {
                for (var i in this.favorites) {
                    if (this.favorites[i].id == favorite.id) {
                        this.favorites[i].name = favorite.name;
                    }
                }
                if (callback) {
                    callback(response, favorite);
                }
                this.onFavoriteUpdated([favorite]);
            }
        }, onFavoriteUpdated:function (favorite) {
        }, removeFavorites:function (favorites, callback) {
            var ids = [];
            if (!lang.isArray(favorites)) {
                ids.push(favorites.id);
            } else {
                for (var i in favorites) {
                    ids.push(favorites[i].favoriteId ? favorites[i].favoriteId : favorites[i].id);
                }
            }
            var params = {application:"navigator", action:"deleteList", configuration:"FavoriteConfig", id:"nexus", ids:dojojson.toJson(ids), update_list_configuration:"UserConfig", update_list_id:this.id + "." + this.getDefaultRepositoryId() + "." + this.getDefaultRepository().userId.toLowerCase(), update_list_type:"favorites"};
            Request.postService("user", null, params, null, null, lang.hitch(this, function (response) {
                this._removeFavoritesCompleted(response, favorites, ids, callback);
            }));
        }, _removeFavoritesCompleted:function (response, favoritesRemoved, ids, callback) {
            if (ids && this.favorites) {
                var tempArray = [];
                for (var i in this.favorites) {
                    var favorite = this.favorites[i];
                    var index = array.indexOf(ids, favorite.id);
                    if (index == -1) {
                        tempArray.push(favorite);
                    }
                }
                this.favorites = tempArray;
                if (callback) {
                    callback(ids);
                }
                this.onFavoritesRemoved(favoritesRemoved);
            }
        }, onFavoritesRemoved:function (favoritesRemoved) {
        }, onSessionExpired:function (request) {
        }, onLogin:function (repository) {
        }, onLogout:function (repository) {
        }, logOffRepositories:function (response) {
            var repos = this.repositories;
            if (repos) {
                for (var i in repos) {
                    var repository = repos[i];
                    if (repository && repository.connected) {
                        repository._logoffCompleted(response);
                    }
                }
            }
        }, getConfiguredLabelsvalue:function (key) {
            if (this.configuredLabels) {
                return this.configuredLabels.getLabelValue(key, kernel.locale);
            } else {
                return ecm.messages[key];
            }
        }, getConfiguredLabels:function (callback) {
            callback(this.configuredLabels);
        }, onDisplayStatusDialog:function (statusDialog) {
        }, onHideStatusDialog:function (statusDialog) {
        }, onDisplayBatchStatusDialog:function () {
        }, onHideBatchStatusDialog:function () {
        }, onBeforeClose:function (events) {
        }});
        Desktop.cookieLocaleLanguage = "icn_locale_language";
        Desktop.cookieLocaleValueFormat = "icn_locale_format";
        ecm.model.desktop = new Desktop({id:"default", name:"Default Desktop"});
        return ecm.model.desktop;
    });
}, "ecm/model/WorklistFolder":function () {
    define(["dojo/_base/declare", "./_ModelObject", "./Worklist"], function (declare, _ModelObject, Worklist) {
        return declare("ecm.model.WorklistFolder", [_ModelObject], {description:"", repository:null, worklists:null, retrieveWorklists:function (callback) {
            if (this.worklists) {
                callback(this.worklists);
            } else {
                if (this.id == "all") {
                    var request = this.repository.retrieveWorklists(callback);
                } else {
                    var self = this;
                    var request = ecm.model.Request.invokeService("openWorklistFolder", this.repository.type, {repositoryId:this.repository.id, folder_name:this.id}, function (response) {
                        self._retrieveWorklistsCompleted(response, callback);
                    });
                }
            }
            return request;
        }, _retrieveWorklistsCompleted:function (response, callback) {
            this.worklists = [];
            for (var i in response.datastore.items) {
                var templateJSON = response.datastore.items[i];
                var template = new Worklist({id:templateJSON.template_name, name:templateJSON.template_label, description:templateJSON.template_desc, repository:this.repository});
                this.worklists.push(template);
            }
            callback(this.worklists);
        }});
    });
}, "ecm/MessagesMixin":function () {
    define("ecm/MessagesMixin", ["dojo/_base/declare", "./Messages"], function (declare, Messages) {
        return declare("ecm.MessagesMixin", null, {messages:ecm.messages});
    });
}, "ecm/model/_ModelStore":function () {
    define("ecm/model/_ModelStore", ["dojo/_base/declare", "dojo/_base/kernel", "dojo/_base/lang", "dojo/_base/array", "dojo/data/util/sorter", "dojo/data/util/filter", "./_ModelStore", "../LoggerMixin"], function (declare, kernel, lang, array, sorter, filter, _ModelStore, LoggerMixin) {
        var _ModelStore = declare("ecm.model._ModelStore", [LoggerMixin], {constructor:function (parentModelObject, getListFunction, newItemFunction, deleteItemFunction, getMappedAttributeNameFunction) {
            this.parentModelObject = parentModelObject;
            this._getListFunction = getListFunction;
            this._newItemFunction = newItemFunction;
            this._deleteItemFunction = deleteItemFunction;
            this._getMappedAttributeNameFunction = getMappedAttributeNameFunction;
            this.comparatorMap = {};
        }, getFeatures:function () {
            return {"dojo.data.api.Notification":true, "dojo.data.api.Read":true, "dojo.data.api.Identity":true};
        }, getIdentity:function (item) {
            return this.getIdentityId(item.id);
        }, getIdentityId:function (id) {
            var newId = id.replace(/\"/g, "").replace(/\+/g, "").replace(/=/g, "").replace(/~/g, "").replace(/>/g, "").replace(/]/g, "").replace(/'/g, "");
            if (newId != id) {
                newId += new Date().getTime();
            }
            return newId;
        }, getIdentityAttributes:function (item) {
            return [];
        }, fetchItemByIdentity:function (keywordArgs) {
            if (!this.isItemLoaded(keywordArgs.item)) {
                throw new Error("Unimplemented API: dojo.data.api.Identity.fetchItemByIdentity");
            }
        }, save:function (obj) {
            if (obj && obj.onComplete) {
                var scope = obj.scope || kernel.global;
                obj.onComplete.call(scope);
            }
        }, setValue:function (item, attribute, value) {
            if (item && item[attribute] != undefined) {
                item[attribute] = value;
            }
        }, getValue:function (item, attribute, defaultValue) {
            if (attribute == "icon" || attribute == "mimeTypeIcon" || attribute == "stateIcon" || attribute == "multiStateIcon" || (attribute.indexOf && attribute.indexOf("InternalIconColumn") != -1)) {
                return item;
            }
            if (lang.isFunction(this._getMappedAttributeNameFunction)) {
                attribute = this._getMappedAttributeNameFunction(item, attribute);
            }
            if (attribute == "isFolder") {
                return item.isFolder() ? "1" : "2";
            } else {
                if (item.getDisplayValue) {
                    var type = (item.getAttributeType && item.getAttributeType(attribute));
                    if (type == "xs:integer" || type == "xs:decimal" || type == "xs:string:num" || type == "xs:short" || type == "xs:double") {
                        this.comparatorMap[attribute] = _ModelStore.numericComparator;
                    } else {
                        if (type == "xs:long") {
                            this.comparatorMap[attribute] = _ModelStore.longComparator;
                        } else {
                            if (type == "xs:date" || type == "xs:time" || type == "xs:timestamp") {
                                this.comparatorMap[attribute] = sorter.basicComparator;
                            } else {
                                if (!this.comparatorMap[attribute]) {
                                    if (this.parentModelObject && (item.repository ? item.repository._isCM() : this.parentModelObject.repository ? this.parentModelObject.repository._isCM() : false)) {
                                        this.comparatorMap[attribute] = _ModelStore.cmBasicComparator;
                                    } else {
                                        this.comparatorMap[attribute] = _ModelStore.caseInsensitiveComparator;
                                    }
                                }
                            }
                        }
                    }
                    var value;
                    try {
                        value = item.getDisplayValue(attribute) || "";
                        if (!value) {
                            if (attribute == "repositoryName" && item.repository) {
                                value = item.repository.name;
                            } else {
                                if (attribute == "name") {
                                    value = item.name;
                                } else {
                                    if (attribute == "{CLASS}" && item.getContentClass) {
                                        if (item.getContentItem) {
                                            value = item.getContentItem().getContentClass().name;
                                        } else {
                                            value = item.getContentClass().name;
                                        }
                                    }
                                }
                            }
                        } else {
                            if (lang.isArray(value)) {
                                if (!this._separator) {
                                    this._separator = ecm.model.desktop.valueFormatter.getSeparator();
                                }
                                value = value.join(this._separator + " ");
                            }
                        }
                    }
                    catch (e) {
                        this.logError("getValue", e.message);
                        throw e;
                    }
                    return value;
                } else {
                    if (item.getValue) {
                        return item.getValue(attribute) || "";
                    } else {
                        return null;
                    }
                }
            }
        }, getValues:function (item, attribute) {
            if (!item.getValues) {
                return [];
            }
            if (lang.isFunction(this._getMappedAttributeNameFunction)) {
                attribute = this._getMappedAttributeNameFunction(item, attribute);
            }
            return item.getValues(attribute);
        }, getAttributes:function (item) {
            var cols = this.parentModelObject && this.parentModelObject.getColumns ? this.parentModelObject.getColumns() : null;
            if (cols) {
                return cols;
            } else {
                if (item.attributes) {
                    var att = item.attributes;
                    if (att instanceof Array) {
                        var attArray = [];
                        for (var i in att) {
                            attArray.push(i);
                        }
                        return attArray;
                    } else {
                        return att;
                    }
                }
            }
            return [];
        }, hasAttribute:function (item, attribute) {
            if (!item.hasAttribute) {
                return false;
            }
            if (lang.isFunction(this._getMappedAttributeNameFunction)) {
                attribute = this._getMappedAttributeNameFunction(item, attribute);
            }
            return item.hasAttribute(attribute);
        }, containsValue:function (item, attribute, value) {
            var regexp = undefined;
            if (typeof value === "string") {
                regexp = filter.patternToRegExp(value, false);
            }
            return this._containsValue(item, attribute, value, regexp);
        }, _containsValue:function (item, attribute, value, regexp) {
            return array.some(this.getValues(item, attribute), function (possibleValue) {
                if (possibleValue && !lang.isObject(possibleValue) && regexp) {
                    if (possibleValue.toString().match(regexp)) {
                        return true;
                    }
                } else {
                    if (value === possibleValue) {
                        return true;
                    }
                }
            });
        }, isItem:function (something) {
            return true;
        }, isItemLoaded:function (something) {
            return true;
        }, loadItem:function (keywordArgs) {
        }, fetch:function (request) {
            request = request || {};
            if (!request.store) {
                request.store = this;
            }
            this._fetchItems(request, lang.hitch(this, this._fetchHandler), lang.hitch(this, this._errorHandler));
            return request;
        }, _errorHandler:function (errorData, requestObject) {
            if (requestObject.onError) {
                var scope = requestObject.scope || kernel.global;
                requestObject.onError.call(scope, errorData, requestObject);
            }
        }, _fetchHandler:function (items, requestObject) {
            var oldAbortFunction = requestObject.abort || null;
            var aborted = false;
            var startIndex = requestObject.start ? requestObject.start : 0;
            var endIndex = items.length;
            requestObject.abort = function () {
                aborted = true;
                if (oldAbortFunction) {
                    oldAbortFunction.call(requestObject);
                }
            };
            var scope = requestObject.scope || kernel.global;
            if (!requestObject.store) {
                requestObject.store = this;
            }
            if (requestObject.onBegin) {
                var endIndexForGrid = endIndex;
                if (this.parentModelObject.isInstanceOf(ecm.model.ResultSet)) {
                    var hasContinuation = this.parentModelObject.hasContinuation();
                    if (hasContinuation) {
                        endIndexForGrid += 20;
                    }
                    requestObject._maxResultsReached = this.parentModelObject.maxResultsReached;
                }
                requestObject.onBegin.call(scope, endIndexForGrid, requestObject);
            }
            if (requestObject.onItem) {
                for (var i = startIndex; (i < items.length) && (i < endIndex); ++i) {
                    var item = items[i];
                    if (!aborted) {
                        requestObject.onItem.call(scope, item, requestObject);
                    }
                }
            }
            if (requestObject.onComplete && !aborted) {
                var subset = null;
                if (!requestObject.onItem) {
                    subset = items.slice(startIndex, endIndex);
                }
                try {
                    requestObject.onComplete.call(scope, subset, requestObject);
                }
                catch (e) {
                }
            }
        }, newItem:function (item) {
            var added = false;
            if (this._newItemFunction) {
                added = this._newItemFunction.call(this.parentModelObject, item);
            }
            if (added) {
                this.onNew(item);
            }
            return added;
        }, deleteItem:function (item) {
            var deleted = false;
            if (this._deleteItemFunction) {
                deleted = this._deleteItemFunction.call(this.parentModelObject, item);
            }
            if (deleted) {
                this.onDelete(item);
            }
            return deleted;
        }, _fetchItems:function (requestArgs, fetchHandler, errorCallback) {
            var itemsNeeded = requestArgs.start + requestArgs.count;
            var afterItemsRetrievedFunction = lang.hitch(this, this._afterItemsRetrieved, requestArgs, fetchHandler);
            if (this._firstTime == undefined || this._firstTime == true) {
                this._getListFunction.call(this.parentModelObject, afterItemsRetrievedFunction, itemsNeeded);
                this._firstTime = false;
                return;
            }
            if (requestArgs.sort && requestArgs.sort[0].attribute == "mimeTypeIcon" && (requestArgs.store.parentModelObject.repository && requestArgs.store.parentModelObject.repository._isCM())) {
                var sortDescending = false;
                if (requestArgs.sort[0].descending == false) {
                    sortDescending = false;
                } else {
                    sortDescending = true;
                }
                this._getListFunction.call(this.parentModelObject, lang.hitch(this, function (items) {
                    var sortArrayAscending = function (a, b) {
                        if (a.mimetype > b.mimetype) {
                            return 1;
                        }
                        if (a.mimetype < b.mimetype) {
                            return -1;
                        }
                        return 0;
                    };
                    var sortArrayDescending = function (a, b) {
                        if (a.mimetype > b.mimetype) {
                            return -1;
                        }
                        if (a.mimetype < b.mimetype) {
                            return 1;
                        }
                        return 0;
                    };
                    if (items) {
                        var sortItems = items;
                        if (sortDescending) {
                            sortItems.sort(sortArrayDescending);
                        } else {
                            sortItems.sort(sortArrayAscending);
                        }
                        items = sortItems;
                    }
                    afterItemsRetrievedFunction(items);
                }), itemsNeeded);
                return;
            }
            if (requestArgs.sort && requestArgs.start == 0) {
                var sortableColumn = true;
                var structure = this.parentModelObject.structure;
                var sortColumnNdx = -1;
                if (structure) {
                    var columns = structure.cells[0];
                    var sortProp = requestArgs.sort[0].attribute;
                    for (var i in columns) {
                        var col = columns[i];
                        if (col.field == sortProp) {
                            sortColumnNdx = parseInt(i);
                            sortableColumn = col.sortable == undefined || col.sortable == true ? true : false;
                            break;
                        }
                    }
                }
                if (sortableColumn) {
                    if (this.parentModelObject.doSort) {
                        this.parentModelObject.doSort(requestArgs.sort, lang.hitch(this, function (newResultSet) {
                            if (typeof newResultSet.sortIndex !== "undefined") {
                                newResultSet.sortIndex = sortColumnNdx;
                            }
                            if (typeof newResultSet.sortDirection !== "undefined") {
                                newResultSet.sortDirection = requestArgs.sort[0].descending ? -1 : 1;
                            }
                            this.parentModelObject = newResultSet;
                            this._getListFunction.call(this.parentModelObject, afterItemsRetrievedFunction, itemsNeeded);
                        }), this);
                    } else {
                        if (typeof this.parentModelObject.sortIndex !== "undefined") {
                            this.parentModelObject.sortIndex = sortColumnNdx;
                        }
                        if (typeof this.parentModelObject.sortDirection !== "undefined") {
                            this.parentModelObject.sortDirection = requestArgs.sort[0].descending ? -1 : 1;
                        }
                        this._getListFunction.call(this.parentModelObject, lang.hitch(this, function (items) {
                            if (items) {
                                items.sort(sorter.createSortFunction(requestArgs.sort, this));
                            }
                            afterItemsRetrievedFunction(items);
                        }), itemsNeeded);
                    }
                    return;
                }
            }
            this._getListFunction.call(this.parentModelObject, afterItemsRetrievedFunction, itemsNeeded);
        }, _afterItemsRetrieved:function (requestArgs, fetchHandler, arrayOfItems) {
            if (requestArgs.query) {
                var items = [];
                var i, key, value = null;
                var ignoreCase = requestArgs.queryOptions ? requestArgs.queryOptions.ignoreCase : false;
                var regexpList = {};
                for (key in requestArgs.query) {
                    value = requestArgs.query[key];
                    if (typeof value === "string") {
                        regexpList[key] = filter.patternToRegExp(value, ignoreCase);
                    } else {
                        if (value instanceof RegExp) {
                            regexpList[key] = value;
                        }
                    }
                }
                for (i = 0; i < arrayOfItems.length; ++i) {
                    var match = true;
                    var candidateItem = arrayOfItems[i];
                    if (candidateItem === null) {
                        match = false;
                    } else {
                        for (key in requestArgs.query) {
                            value = requestArgs.query[key];
                            if (!this._containsValue(candidateItem, key, value, regexpList[key])) {
                                match = false;
                            }
                        }
                    }
                    if (match) {
                        items.push(candidateItem);
                    }
                }
                arrayOfItems = items;
            }
            fetchHandler(arrayOfItems, requestArgs);
        }, _getItemsArray:function (keywordArgs) {
            if (keywordArgs.queryOptions && keywordArgs.queryOptions.deep) {
                this.logError("_getItemArray", "queryOptions.deep is not supported.");
                return null;
            }
            var itemsNeeded = keywordArgs.start + keywordArgs.count;
            var result = this._getListFunction.call(this.parentModelObject, itemsNeeded);
            return result;
        }, close:function (request) {
        }, getLabel:function (item) {
            return item.name;
        }, getLabelAttributes:function (item) {
            return [];
        }, onSet:function (item, attribute, oldValue, newValue) {
        }, onNew:function (newItem, parentInfo) {
        }, onDelete:function (deletedItem) {
        }});
        _ModelStore.cmBasicComparator = function (a, b) {
            var r = -1;
            if (a === null) {
                a = undefined;
            }
            if (b === null) {
                b = undefined;
            }
            if (a == b) {
                r = 0;
            } else {
                if (a == null || a == "") {
                    r = 1;
                } else {
                    if (b == null || b == "") {
                        r = -1;
                    } else {
                        if (a > b) {
                            r = 1;
                        } else {
                            if (b > a) {
                                r = -1;
                            }
                        }
                    }
                }
            }
            return r;
        };
        _ModelStore.caseInsensitiveComparator = function (a, b) {
            var r = -1;
            if (a === null) {
                a = undefined;
            }
            if (b === null) {
                b = undefined;
            }
            var au = a && a.toUpperCase ? a.toUpperCase() : a;
            var bu = b && b.toUpperCase ? b.toUpperCase() : b;
            if (au == bu) {
                if (a == b) {
                    r = 0;
                } else {
                    if (a > b || a == null) {
                        r = 1;
                    }
                }
            } else {
                if (au > bu || au == null) {
                    r = 1;
                }
            }
            return r;
        };
        _ModelStore.numericComparator = function (a, b) {
            function parseNumeric(n) {
                if (n === 0) {
                    return 0;
                } else {
                    if (!n) {
                        return -1;
                    } else {
                        if (typeof n == "string") {
                            var b = 1;
                            if (n.indexOf("K") > 0) {
                                b = 1024;
                            } else {
                                if (n.indexOf("M") > 0) {
                                    b = 1024 * 1024;
                                } else {
                                    if (n.indexOf("G") > 0) {
                                        b = 1024 * 1024 * 1024;
                                    }
                                }
                            }
                            var f = parseFloat(n);
                            if (isNaN(f)) {
                                return -1;
                            }
                            return f * b;
                        } else {
                            return n;
                        }
                    }
                }
            }
            a = parseNumeric(a);
            b = parseNumeric(b);
            if (a == b) {
                return 0;
            } else {
                if (a > b) {
                    return 1;
                } else {
                    return -1;
                }
            }
        };
        _ModelStore.longComparator = function (a, b) {
            if (!a) {
                if (!b) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                if (!b) {
                    return -1;
                }
            }
            var padding = (new Array(((a.length > b.length) ? a.length : b.length) + 1)).join("0");
            function padLong(longVal) {
                return (padding.slice(0, padding.length - longVal.length) + longVal);
            }
            var aIsNegative = (a.slice(0, 1) == "-");
            var bIsNegative = (b.slice(0, 1) == "-");
            var invert;
            if (aIsNegative) {
                if (bIsNegative) {
                    a = padLong(a.slice(1));
                    b = padLong(b.slice(1));
                    invert = true;
                } else {
                    return -1;
                }
            } else {
                if (bIsNegative) {
                    return 1;
                } else {
                    a = padLong(a);
                    b = padLong(b);
                }
            }
            if (a == b) {
                return 0;
            } else {
                if (a > b) {
                    return (invert ? -1 : 1);
                } else {
                    return (invert ? 1 : -1);
                }
            }
        };
        return _ModelStore;
    });
}, "ecm/model/ODSavedSearchCriterion":function () {
    define(["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        return declare("ecm.model.ODSavedSearchCriterion", [_ModelObject], {operator:null, values:null, setValues:function (values) {
            this.values = values;
            this.onChange(this);
        }});
    });
}, "ecm/model/_HasAttributesMixin":function () {
    define("ecm/model/_HasAttributesMixin", ["dojo/_base/declare", "dojo/_base/json", "../LoggerMixin", "./AttributeDefinition", "./ChildComponentDefinition", "./ChildComponent"], function (declare, dojojson, LoggerMixin, AttributeDefinition, ChildComponentDefinition, ChildComponent) {
        return declare("ecm.model._HasAttributesMixin", [LoggerMixin], {setAttributeDefinitions:function (attributeDefinitions) {
            this.attributeDefinitions = attributeDefinitions;
        }, unloadAttributeDefinitions:function () {
            this.attributeDefinitions = null;
            this.allAttributeDefinitions = null;
        }, isPseudoClass:function () {
            return false;
        }, retrieveAttributeDefinitions:function (callback, isBackgroundRequest) {
            if (this.attributeDefinitions) {
                if (callback) {
                    callback(this.attributeDefinitions, this.childComponentDefinitions);
                }
            } else {
                var self = this;
                var request = ecm.model.Request.invokeService("openContentClass", this.repository.type, {repositoryId:this.repository.id, objectStoreId:this.objectStore ? this.objectStore.id : "", template_name:this.id, pseudo_class:this.pseudoClass}, function (response) {
                    self._retrieveAttributeDefinitionsCompleted(response, callback);
                }, null, null, null, isBackgroundRequest);
            }
            return request;
        }, _retrieveAttributeDefinitionsCompleted:function (response, callback) {
            this.attributeDefinitions = this._createAttributeDefinitions(response);
            this.childComponentDefinitions = this._createChildComponentDefinitions(response);
            if (callback) {
                callback(this.attributeDefinitions, this.childComponentDefinitions);
            }
        }, _createAttributeDefinitions:function (response) {
            var methodName = "_createAttributeDefinitions";
            var attributeDefinitions = [];
            for (var i in response.criterias) {
                var criterionJSON = response.criterias[i];
                criterionJSON.id = criterionJSON.name;
                criterionJSON.name = criterionJSON.label;
                criterionJSON.contentClass = this;
                criterionJSON.repositoryType = this.repository.type;
                criterionJSON.maxLength = criterionJSON.maxEntry;
                criterionJSON.minLength = criterionJSON.minEntry;
                criterionJSON.openChoice = criterionJSON.open_choice;
                criterionJSON.allowedValues = criterionJSON.validValues;
                criterionJSON.defaultValue = criterionJSON.value;
                var criterion = new AttributeDefinition(criterionJSON);
                attributeDefinitions.push(criterion);
            }
            return attributeDefinitions;
        }, _createChildComponentDefinitions:function (response) {
            var childDefinitions = null;
            if (response.parm_childcomponents) {
                for (var j in response.parm_childcomponents) {
                    var childcomponent = response.parm_childcomponents[j];
                    if (childcomponent.criterias) {
                        var childDefinition = new ChildComponentDefinition({id:childcomponent.template_name, name:childcomponent.template_label, repository:this.repository, minCardinality:childcomponent.parm_minCardinality, maxCardinality:childcomponent.parm_maxCardinality});
                        childDefinition.attributeDefinitions = this._createAttributeDefinitions(childcomponent);
                        if (childDefinitions == null) {
                            childDefinitions = [];
                        }
                        childDefinitions.push(childDefinition);
                    }
                }
            }
            return childDefinitions;
        }, _createChildComponents:function (response) {
            var childComponents = null;
            if (response.parm_childcomponents) {
                for (var j in response.parm_childcomponents) {
                    var childcomponentJson = response.parm_childcomponents[j];
                    if (childcomponentJson.values) {
                        var childcomponentParams = {template_name:childcomponentJson.name, template_label:childcomponentJson.name, criterias:[]};
                        for (var k in childcomponentJson.values) {
                            var childcomponentInstanceJson = childcomponentJson.values[k];
                            for (var a in childcomponentInstanceJson.values) {
                                if (k == 0) {
                                    childcomponentParams.criterias[a] = {};
                                    var name = childcomponentInstanceJson.values[a].name;
                                    name = name.substr(name.lastIndexOf("/") + 1);
                                    childcomponentParams.criterias[a].name = name;
                                    childcomponentParams.criterias[a].validValues = [];
                                }
                                childcomponentParams.criterias[a].validValues.push(childcomponentInstanceJson.values[a].value);
                            }
                        }
                    }
                    var childComponent = new ChildComponent(childcomponentParams);
                    if (childComponents == null) {
                        childComponents = [];
                    }
                    childComponents.push(childComponent);
                }
            }
            return childComponents;
        }, retrieveAttributeDefinitionsForSearches:function (callback, includeSubclassDefinitions) {
            if (!this.repository._isP8Like() || !includeSubclassDefinitions) {
                this.retrieveAttributeDefinitions(callback);
            } else {
                if (this.allAttributeDefinitions) {
                    if (callback) {
                        callback(this.allAttributeDefinitions, this.childComponentDefinitions);
                    }
                } else {
                    var self = this;
                    var request = ecm.model.Request.invokeService("openContentClass", this.repository.type, {repositoryId:this.repository.id, objectStoreId:this.objectStore ? this.objectStore.id : "", template_name:this.id, pseudo_class:this.pseudoClass, filter_type:"searches", include_subclass_definitions:"true"}, function (response) {
                        self._retrieveAttributeDefinitionsForSearchesCompleted(response, callback, null, includeSubclassDefinitions);
                    });
                }
            }
            return request;
        }, _retrieveAttributeDefinitionsForSearchesCompleted:function (response, callback) {
            this.allAttributeDefinitions = this._createAttributeDefinitions(response);
            this.childComponentDefinitions = this._createChildComponentDefinitions(response);
            if (callback) {
                callback(this.allAttributeDefinitions, this.childComponentDefinitions);
            }
        }, retrieveDependentAttributeDefinitions:function (attributes, childComponentValues, callback, isBackgroundRequest, onError) {
            if (childComponentValues && childComponentValues.length > 0) {
                var params = {criterias:attributes, childComponentValues:childComponentValues};
            } else {
                var params = attributes;
            }
            if (this.hasDependentAttributes() && (this.repository.type == "p8" || this.repository.type == "cm" || this.repository.type == "cmis")) {
                var self = this;
                var request = ecm.model.Request.postService("getDependentAttributeInfo", this.repository.type, {repositoryId:this.repository.id, objectStoreId:this.objectStore ? this.objectStore.id : "", template_name:this.id, pseudo_class:this.pseudoClass}, "text/json", dojojson.toJson(params), function (response) {
                    self._retrieveDependentAttributeDefinitionsCompleted(response, callback);
                }, false, isBackgroundRequest ? isBackgroundRequest : false, false, onError);
            } else {
                var dependentAttributeDefinitions = [];
                for (var i in this.attributeDefinitions) {
                    var dependentAttributeDefinition = this.attributeDefinitions[i].clone();
                    var value = attributes[dependentAttributeDefinition.id];
                    if (typeof value !== "undefined") {
                        dependentAttributeDefinition.defaultValue = value;
                        dependentAttributeDefinition.updatedDefaultValue = true;
                        dependentAttributeDefinition.updated = true;
                    }
                    dependentAttributeDefinitions.push(dependentAttributeDefinition);
                }
                var childComponents = null;
                if (callback) {
                    callback(dependentAttributeDefinitions, this.childComponentDefinitions, childComponents);
                }
            }
            return request;
        }, _retrieveDependentAttributeDefinitionsCompleted:function (response, callback) {
            var attributeDefinitions = this._createAttributeDefinitions(response);
            var childComponentDefinitions = this._createChildComponentDefinitions(response) || this.childComponentDefinitions;
            var childComponents = this._createChildComponents(response);
            if (callback) {
                callback(attributeDefinitions, childComponentDefinitions, childComponents);
            }
        }, hasDependentAttributes:function () {
            if (!this.attributeDefinitions) {
                return true;
            }
            var hasDependentAttributes = false;
            for (var i in this.attributeDefinitions) {
                if (this.attributeDefinitions[i].hasDependentAttributes) {
                    hasDependentAttributes = true;
                }
            }
            if (this.childComponentDefinitions) {
                for (var i in this.childComponentDefinitions) {
                    if (this.childComponentDefinitions[i].hasDependentAttributes) {
                        hasDependentAttributes = true;
                    }
                }
            }
            return hasDependentAttributes;
        }});
    });
}, "ecm/model/Viewer":function () {
    define(["dojo/_base/declare", "ecm/model/Request", "./_ModelObject"], function (declare, Request, _ModelObject) {
        return declare("ecm.model.Viewer", [_ModelObject], {launchUrl:null, launchInSeparateWindow:false, viewerClass:"ecm.widget.viewer.IframeDocViewer", viewerMappings:null, supportedContentTypes:null, constructor:function () {
            if (!this.viewerMappings) {
                this.viewerMappings = {};
            }
            if (!this.supportedContentTypes) {
                this.supportedContentTypes = {};
            }
        }, addViewerMapping:function (viewerMapping) {
            this.viewerMappings[viewerMapping.getKey()] = viewerMapping;
            var contentType = viewerMapping.contentType || "";
            this.supportedContentTypes[contentType] = contentType;
        }, getDocUrl:function (item) {
            var methodName = "getDocUrl";
            var servicesUrl = ecm.model.desktop._cServicesUrl;
            var docId = item.id;
            var template = "";
            var contentClass = item.getContentClass();
            if (contentClass) {
                template = contentClass.id;
            }
            var repositoryId = item.repository.id;
            var serverType = item.repository.type;
            var vsId = item.vsId;
            var replicationGroup = item.replicationGroup;
            var objectStoreName = item.repository.objectStoreName;
            var docUrl = servicesUrl + "/" + serverType + "/getDocument.do?docid=" + encodeURIComponent(docId) + "&template_name=" + encodeURIComponent(template) + "&repositoryId=" + encodeURIComponent(repositoryId);
            if (vsId) {
                var resultSet = item.resultSet;
                if (resultSet && resultSet.parentFolder) {
                    docUrl = docUrl + "&vsId=" + encodeURIComponent(vsId);
                }
            }
            if (item.version) {
                docUrl = docUrl + "&version=" + item.version;
            }
            if (replicationGroup) {
                docUrl = docUrl + "&replicationGroup=" + encodeURIComponent(replicationGroup);
            }
            if (objectStoreName) {
                docUrl = docUrl + "&objectStoreName=" + encodeURIComponent(objectStoreName);
            }
            return ecm.model.Request.setSecurityToken(docUrl);
        }, getLaunchUrl:function (item) {
            var methodName = "getLaunchUrl";
            var servicesUrl = ecm.model.desktop._cServicesUrl;
            var docId = item.id;
            var docName = item.name;
            var repositoryId = item.repository.id;
            var mimeType = item.mimetype || "";
            var serverType = item.repository.type;
            var vsId = item.vsId;
            var replicationGroup = item.replicationGroup;
            var objectStoreName = item.repository.objectStoreName;
            var docUrl = this.getDocUrl(item);
            if (servicesUrl == ".") {
                if (this.launchUrl.indexOf("servicesUrl+'/viewers/") == 0 && docUrl.indexOf("./") == 0) {
                    docUrl = "." + docUrl;
                    servicesUrl = "." + servicesUrl;
                }
            }
            var privs = "&printDoc=" + item.hasPrivilege("privPrintDoc") + "&exportDoc=" + item.hasPrivilege("privExport") + "&viewAnnotations=" + item.hasPrivilege("privViewAnnotations") + "&editAnnotations=" + item.hasPrivilege("privEditAnnotations") + "&editDoc=" + item.hasPrivilege("privEditDoc") + "&editProperties=" + item.hasPrivilege("privEditProperties");
            var launchUrl = Request.appendSecurityToken(eval(this.launchUrl));
            if (launchUrl.indexOf("../viewers") == 0) {
                launchUrl = launchUrl.substring(1);
            }
            return launchUrl;
        }});
    });
}, "ecm/model/ODSavedSearch":function () {
    define("ecm/model/ODSavedSearch", ["dojo/_base/declare", "dojo/_base/json", "./_ModelObject", "./ODSavedSearchCriterion"], function (declare, dojojson, _ModelObject, ODSavedSearchCriterion) {
        return declare("ecm.model.ODSavedSearch", [_ModelObject], {repository:null, templateName:null, isPublic:false, andSearch:true, searchCriteria:null, constructor:function () {
            if (this.saved_criterias) {
                this._populateCriteria(this.saved_criterias);
                delete this.saved_criterias;
            }
        }, _populateCriteria:function (criteriaJSON) {
            this.searchCriteria = new Object();
            for (var i in criteriaJSON) {
                criteriaJSON[i].id = criteriaJSON[i].name;
                var criterion = new ODSavedSearchCriterion(criteriaJSON[i]);
                this.searchCriteria[criteriaJSON[i].name] = criterion;
            }
        }, toJson:function () {
            var jsonTemplate = {};
            jsonTemplate.id = this.id;
            jsonTemplate.name = this.name;
            jsonTemplate.andSearch = this.andSearch;
            jsonTemplate.query_name = this.name;
            jsonTemplate.query_public = this.isPublic;
            jsonTemplate.template_name = this.templateName;
            jsonTemplate.saved_criterias = [];
            for (var i in this.searchCriteria) {
                var jsonCriterion = new Object();
                jsonCriterion.name = criterion.name;
                jsonCriterion.operator = criterion.selectedOperator;
                jsonCriterion.values = criterion.values;
                jsonTemplate.saved_criterias.push(jsonCriterion);
            }
            var json = dojojson.toJson(jsonTemplate);
            return json;
        }});
    });
}, "ecm/model/Favorite":function () {
    define(["dojo/_base/declare", "dojo/_base/lang", "./_ModelObject", "./Item", "./Teamspace"], function (declare, lang, _ModelObject, Item, Teamspace) {
        var Favorite = declare("ecm.model.Favorite", [_ModelObject], {repository:null, type:null, objectId:null, mimetype:null, template:null, vsId:null, repositoryLabel:null, favoriteId:null, item:null, constructor:function (params) {
            if (params && params.attributes) {
                this.id = params.favoriteId;
                delete this.favoriteId;
                if (params.repositoryId) {
                    this.repository = ecm.model.desktop.getRepository(params.repositoryId);
                    if (this.repository) {
                        delete this.repositoryId;
                    }
                }
                this.type = params.attributes.type[0];
                this.objectId = params.id;
                this.template = params.attributes.template[0];
                delete this.attributes;
            }
        }, hasPrivilege:function (priv) {
            return this.item && this.item.hasPrivilege(priv) ? this.item.hasPrivilege(priv) : false;
        }, getAttributes:function () {
            if (!this.attributes) {
                this.attributes = [];
            }
            this.attributes["label"] = this.name;
            this.attributes["repositoryName"] = this.repository ? this.repository.name : "";
            this.attributes["mimetype"] = this.mimetype;
            this.attributes["template"] = this.template;
            this.attributes["vsId"] = this.vsId;
            this.attributes["type"] = this.type;
            this.attributes["itemid"] = this.objectId;
            this.attributes["repositoryLabel"] = this.repositoryLabel;
            return this.attributes;
        }, getValue:function (attrName) {
            var attributes = this.getAttributes();
            if (attributes) {
                return attributes[attrName];
            } else {
                return "";
            }
        }, getValues:function (attribute) {
            var attributes = this.getAttributes();
            if (!attributes) {
                return [];
            }
            var v = attributes[attribute];
            if (lang.isArray(v)) {
                return v;
            } else {
                return [v];
            }
        }, getPath:function () {
            var array = [];
            var item = this;
            while (item) {
                array.push(item);
                item = item.parentFolder ? item.parentFolder : item.parent;
            }
            return array.reverse();
        }, hasAttribute:function (attribute) {
            var attributes = this.getAttributes();
            return ((attributes && (typeof attributes[attribute] != "undefined")) ? true : false);
        }, isFolder:function () {
            if (this.type == "folder") {
                return true;
            } else {
                return false;
            }
        }, retrieveFavorite:function (callback) {
            if (this.repository) {
                var self = this;
                if (this.repository.connected) {
                    if (this.type == "search") {
                        this.repository.retrieveSearchTemplate(this.objectId, this.vsId, "released", function (item) {
                            item.parent = self.parentFolder;
                            self.item = item;
                            callback(self.item);
                        });
                    } else {
                        if (this.type == "teamspace") {
                            this.item = new Teamspace({id:this.objectId, name:"", repository:this.repository, type:"instance", className:this.template});
                            this.item.retrieveUserPrivileges(function () {
                                callback(self.item);
                            });
                        } else {
                            this.repository.retrieveItem(this.objectId, function (item) {
                                item.parent = self.parentFolder;
                                self.item = item;
                                callback(self.item);
                            }, this.template, "released", this.vsId, null, "favorite");
                        }
                    }
                } else {
                    var loginDialog = ecm.widget.dialog.LoginDialog.getLoginDialog();
                    loginDialog.connectToRepository(this.repository, lang.hitch(this, function (repos) {
                        if (this.repository.connected) {
                            if (this.type == "search") {
                                this.repository.retrieveSearchTemplate(this.objectId, this.vsId, "released", function (item) {
                                    item.parent = self.parentFolder;
                                    self.item = item;
                                    callback(self.item);
                                });
                            } else {
                                if (this.type == "teamspace") {
                                    this.item = new Teamspace({id:this.objectId, name:"", repository:this.repository, type:"instance", className:this.template});
                                    this.item.retrieveUserPrivileges(function () {
                                        callback(self.item);
                                    });
                                } else {
                                    this.repository.retrieveItem(this.objectId, function (item) {
                                        item.parent = self.parentFolder;
                                        self.item = item;
                                        callback(self.item);
                                    }, this.template, "released", this.vsId, null, "favorite");
                                }
                            }
                        }
                    }));
                }
            }
        }, getMimeClass:function () {
            var iconClass;
            if (this.type == "folder") {
                iconClass = "dijitIconFolderClosed";
            } else {
                iconClass = Item.MimeTypeToFileType[this.mimetype];
                if (!iconClass) {
                    if (this.mimetype) {
                        if (this.mimetype.substr(0, "audio/".length) == "audio/") {
                            iconClass = Item.MimeTypeToFileType["audio/*"] || "ftAudio";
                        } else {
                            if (this.mimetype.substr(0, "image/".length) == "image/") {
                                iconClass = Item.MimeTypeToFileType["image/*"] || "ftGraphic";
                            } else {
                                if (this.mimetype.substr(0, "video/".length) == "video/") {
                                    iconClass = Item.MimeTypeToFileType["video/*"] || "ftVideo";
                                } else {
                                    if (this.mimetype == "teamspace" || this.mimetype == "Teamspace") {
                                        iconClass = "ecmTeamspaceIcon";
                                    } else {
                                        if (this.type == "search") {
                                            iconClass = "ftSearchTemplate";
                                        } else {
                                            iconClass = "ftDefault";
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        iconClass = "ftDefault";
                    }
                }
            }
            return iconClass;
        }, toJSON:function () {
            var json = {};
            json.alias = this.name;
            json.itemId = this.objectId;
            json.mimetype = this.mimetype;
            json.repositoryId = this.repository ? this.repository.id : this.repositoryId;
            json.template = this.template;
            json.type = this.type;
            json.vsId = this.vsId;
            return json;
        }});
        Favorite.createFromItem = function (item, alias) {
            var id = Favorite.generateFavoriteId(item);
            var type = "document";
            if (item.isInstanceOf && item.isInstanceOf(ecm.model.Teamspace)) {
                type = "teamspace";
            } else {
                if (item.isFolder()) {
                    type = "folder";
                } else {
                    if (item.isInstanceOf && item.isInstanceOf(ecm.model._SearchTemplateBase)) {
                        type = "search";
                    }
                }
            }
            var template = "";
            if (type == "teamspace") {
                template = item.className;
            } else {
                template = item ? item.template : "";
            }
            var favName = alias || item.name;
            var mimeType = item.mimetype ? item.mimetype : type;
            var vsId = item.vsId ? item.vsId : null;
            var repositoryLabel = item.getValue && item.getValue("repositoryLabel") ? item.getValue("repositoryLabel") : "";
            var favorite = new Favorite({id:id, name:favName, repository:item.repository, type:type, objectId:item.id, mimetype:mimeType, template:template, vsId:vsId, repositoryLabel:repositoryLabel});
            favorite.item = item;
            return favorite;
        };
        Favorite.generateFavoriteId = function (item) {
            var id = ecm.model.desktop.id + "." + ecm.model.desktop.getDefaultRepository().userId.toLowerCase() + "." + item.repository.id + ".";
            var itemid = item.id;
            var i = itemid.indexOf(";");
            if (i > 0) {
                itemid = encodeURIComponent(itemid);
            }
            id += itemid;
            return id;
        };
        return Favorite;
    });
}, "ecm/model/Feature":function () {
    define(["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        return declare("ecm.model.Feature", [_ModelObject], {separator:false, iconUrl:null, featureClass:null, popupWindowClass:null, featureTooltip:null, popupWindowTooltip:null, preLoad:false});
    });
}, "ecm/model/Repository":function () {
    define("ecm/model/Repository", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/json", "./admin/RepositoryReadConfig", "./_ModelObject", "./_OpenedSearchesMixin", "./_RecentSearchesMixin", "./ContentClass", "./ContentItem", "./Directory", "./EntryTemplate", "./Item", "./ProcessApplicationSpace", "./ProcessRole", "./Request", "./ResultSet", "./Role", "./SearchTemplateFolder", "./SearchTemplate", "./Task", "./Teamspace", "./User", "./UserGroup", "./Worklist", "./WorklistFolder"], function (declare, lang, array, dojojson, RepositoryReadConfig, _ModelObject, _OpenedSearchesMixin, _RecentSearchesMixin, ContentClass, ContentItem, Directory, EntryTemplate, Item, ProcessApplicationSpace, ProcessRole, Request, ResultSet, Role, SearchTemplateFolder, SearchTemplate, Task, Teamspace, User, UserGroup, Worklist, WorklistFolder) {
        return declare("ecm.model.Repository", [_ModelObject, _OpenedSearchesMixin, _RecentSearchesMixin], {CAPABILITY_COMMENT:{NONE:"none", DOCUMENT_ONLY:"documentonly", DOCUMENT_AND_FOLDER:"documentandfolder"}, type:null, connected:false, objectStoreName:null, objectStoreDisplayName:null, serverName:null, userId:null, userDisplayName:null, privileges:null, useSSO:false, rootItem:null, teamspacesEnabled:false, addAsMajorVersion:true, checkinAsMajorVersion:true, allPseudoClassSupported:false, templates:null, templatesFilter:null, templateFolders:null, contentClassCache:null, connectionPoint:null, worklistFolders:null, worklistContainers:null, worklists:null, teamspaces:null, roles:null, teamspaceTemplates:null, entryTemplateCache:null, textSearchType:false, capabilityQuery:null, capabilityComment:null, capabilityAllVersionsSearchable:false, attributes:null, repositoryConfig:null, openedSearches:null, recordDatamodelType:null, recordRepositoryType:null, isAdminUser:false, serverPrinters:null, serverPrinterDefaults:null, constructor:function () {
            if (!this.privileges) {
                this.privileges = [];
            }
            if (!this.attributes) {
                this.attributes = [];
            }
            this.allPseudoClassSupported = this._isCM();
        }, getAttribute:function (attributeName) {
            if (this.attributes) {
                return this.attributes[attributeName];
            } else {
                return null;
            }
        }, hasAttribute:function (attributeName) {
            return ((this.attributes && (typeof this.attributes[attributeName] != "undefined")) ? true : false);
        }, logon:function (password, callback, desktopId, synchronous, errorback) {
            var self = this;
            var enableSecureService = ecm.model.Request.enableSecureService;
            ecm.model.Request.enableSecureService = true;
            var request = ecm.model.Request.invokeService("logon", this.type, {desktop:desktopId ? desktopId : ecm.model.desktop.id, repositoryId:this.id, userid:this.userId, password:password}, function (response) {
                ecm.model.Request.enableSecureService = enableSecureService;
                self._logonCompleted(response, callback);
            }, false, synchronous, function (response) {
                if (lang.isFunction(errorback)) {
                    errorback(response);
                }
            });
            return request;
        }, _logonCompleted:function (response, callback) {
            if (!this.connected) {
                this.userDisplayName = response.user_displayname;
                this.serverPrinters = null;
                this.serverPrinterDefaults = null;
                var workflow = this.privileges.workflow;
                this.privileges = {};
                this.privileges.addDoc = response.priv_addDoc;
                this.privileges.addItem = response.priv_addItem;
                this.privileges.addSearch = response.priv_addSearch;
                this.privileges.addUnifiedSearch = response.priv_addUnifiedSearch;
                this.privileges.search = true;
                this.privileges.shareSearch = false;
                this.privileges.addTeamspace = response.priv_addTeamspace;
                this.privileges.addTeamspaceTemplate = response.priv_addTeamspaceTemplate;
                this.privileges.manageTeamspace = true;
                this.privileges.createHold = response.privCreateHold;
                if (workflow != null) {
                    this.privileges.workflow = workflow;
                } else {
                    if (this.type == "cm") {
                        this.privileges.workflow = this.type == "cm";
                    } else {
                        if (this.type == "p8") {
                            this.privileges.workflow = response.priv_workflow;
                        }
                    }
                }
                if (this.type == "cm") {
                    this.privileges.foldering = response.priv_foldering;
                } else {
                    this.privileges.foldering = this.type == "p8" || this.type == "cmis";
                }
                this.textSearchType = response.textSearchType;
                this.capabilityQuery = response.capabilityQuery;
                this.capabilityComment = response.capabilityComment;
                this.capabilityAllVersionsSearchable = response.capabilityAllVersionsSearchable;
                this._searchTemplateSupported = response.searchTemplateSupported;
                this.connected = true;
                if (response.useSSO) {
                    this.useSSO = response.useSSO;
                } else {
                    this.useSSO = false;
                }
                this.setRecordType(response.recordType);
                this.setRecordDatamodelType(response.recordDatamodelType);
                for (var i in response.servers) {
                    var repositoryJSON = response.servers[i];
                    if (repositoryJSON.connected && repositoryJSON.repositoryId == this.id) {
                        this.textSearchType = repositoryJSON.textSearchType;
                        this.capabilityQuery = repositoryJSON.capabilityQuery;
                        this.capabilityComment = repositoryJSON.capabilityComment;
                        this.capabilityAllVersionsSearchable = repositoryJSON.capabilityAllVersionsSearchable;
                        if (repositoryJSON.attributes) {
                            lang.mixin(this.attributes, repositoryJSON.attributes);
                        }
                        if (repositoryJSON.adminLayout) {
                            if (!repositoryJSON.adminLayout.featureTooltip) {
                                repositoryJSON.adminLayout.featureTooltip = ecm.messages.launchbar_admin;
                            }
                            ecm.model.desktop.createAdminFeature(repositoryJSON.adminLayout);
                        }
                        this.isAdminUser = repositoryJSON.admin_user;
                    }
                }
                this.onChange(this);
                this.onConnected(this);
                if (ecm.model.desktop.getInitialRepository() == this) {
                    ecm.model.desktop.onLogin(this);
                }
            }
            for (var i in response.servers) {
                var repositoryJSON = response.servers[i];
                if (repositoryJSON.connected) {
                    var repository = ecm.model.desktop.getRepository(repositoryJSON.repositoryId);
                    if (repository != null && repository != this) {
                        repository._loadRepository(repositoryJSON);
                    }
                }
            }
            if (callback) {
                callback(this);
            }
        }, _loadRepository:function (repositoryJSON) {
            this.connected = true;
            this.userId = repositoryJSON.userID;
            this.userDisplayName = repositoryJSON.user_displayname;
            var workflow = this.privileges.workflow;
            this.privileges = {};
            this.privileges.addDoc = repositoryJSON.priv_addDoc;
            this.privileges.addItem = repositoryJSON.priv_addItem;
            this.privileges.addSearch = repositoryJSON.priv_addSearch;
            this.privileges.addUnifiedSearch = repositoryJSON.priv_addUnifiedSearch;
            this.privileges.addTeamspace = repositoryJSON.priv_addTeamspace;
            this.privileges.addTeamspaceTemplate = repositoryJSON.priv_addTeamspaceTemplate;
            this.privileges.manageTeamspace = true;
            this.privileges.createHold = repositoryJSON.privCreateHold;
            this.privileges.search = true;
            if (this.type == "cm") {
                this.privileges.foldering = repositoryJSON.priv_foldering;
            } else {
                this.privileges.foldering = this.type == "p8" || this.type == "cmis";
            }
            if (workflow != null) {
                this.privileges.workflow = workflow;
            } else {
                if (this.type == "cm") {
                    this.privileges.workflow = this.type == "cm";
                } else {
                    if (this.type == "p8") {
                        this.privileges.workflow = repositoryJSON.priv_workflow;
                    }
                }
            }
            this.textSearchType = repositoryJSON.textSearchType;
            this.capabilityQuery = repositoryJSON.capabilityQuery;
            this.capabilityComment = repositoryJSON.capabilityComment;
            this.capabilityAllVersionsSearchable = repositoryJSON.capabilityAllVersionsSearchable;
            this._searchTemplateSupported = repositoryJSON.searchTemplateSupported;
            this.allPseudoClassSupported = this._isCM();
            this.useSSO = repositoryJSON.useSSO;
            this.setRecordType(repositoryJSON.recordType);
            this.setRecordDatamodelType(repositoryJSON.recordDatamodelType);
            if (repositoryJSON.adminLayout) {
                if (!repositoryJSON.adminLayout.featureTooltip) {
                    repositoryJSON.adminLayout.featureTooltip = ecm.messages.launchbar_admin;
                }
                ecm.model.desktop.createAdminFeature(repositoryJSON.adminLayout);
            }
            this.isAdminUser = repositoryJSON.admin_user;
            if (repositoryJSON.attributes) {
                lang.mixin(this.attributes, repositoryJSON.attributes);
            }
            this.onChange(this);
        }, onConnected:function (repository) {
        }, logoff:function () {
            var self = this;
            var request = ecm.model.Request.invokeService("logoff", this.type, {repositoryId:this.id}, function (response) {
                self._logoffCompleted(response);
                ecm.model.desktop.logOffRepositories(response);
            });
            return request;
        }, _clearCache:function () {
            this.templates = null;
            this.templatesFilter = null;
            this.templateFolders = null;
            this.contentClassCache = null;
            this.worklistFolders = null;
            this.worklistContainers = null;
            this.worklists = null;
            this.teamspaces = null;
            this.roles = null;
            this.teamspaceTemplates = null;
            this.entryTemplateCache = null;
            this.repositoryConfig = null;
            this.serverPrinters = null;
            delete this._retrieveContentClassesCallbacks;
            delete this._retrieveItemCallbacks;
            delete this._retrieveTeamspaceFoldersCallbacks;
            delete this._retrieveTeamspaceFoldersResultSetCallbacks;
            delete this._retrieveTeamspaceTemplateFolderCallbacks;
            delete this._retrieveTeamspaceTemplateFolderResultSetCallbacks;
        }, _logoffCompleted:function (response) {
            this.connected = false;
            this._clearCache();
            this._recentSearches = null;
            this.openedSearches = null;
            this.attributes = [];
            this.recordRepositoryType = null;
            this.recordDatamodelType = null;
            this._clearPrivileges();
            this._searchTemplateSupported = null;
            this.isAdminUser = null;
            this.onDisconnected(this);
            if (ecm.model.desktop.getInitialRepository() == this) {
                ecm.model.desktop.onLogout(this);
            }
            this.onChange(this);
        }, _clearPrivileges:function () {
            this.privileges.addDoc = null;
            this.privileges.addItem = null;
            this.privileges.addSearch = null;
            this._searchTemplateSupported = null;
            this.privileges.addTeamspace = null;
            this.privileges.addTeamspaceTemplate = null;
            this.privileges.manageTeamspace = true;
        }, onDisconnected:function (repository) {
        }, canChangePassword:function () {
            if ((this.type == "od" || this.type == "cm") && this.connected && !this.useSSO) {
                return true;
            }
            return false;
        }, canChangeExpiredPassword:function () {
            if ((this.type == "od" || this.type == "cm")) {
                return true;
            }
            return false;
        }, changePassword:function (password, newPassword, callback) {
            var self = this;
            var request = ecm.model.Request.invokeService("changePassword", this.type, {repositoryId:this.id, userid:this.userId, password:password, new_password:newPassword}, function (response) {
                self._changePasswordCompleted(response, callback);
            });
            return request;
        }, _changePasswordCompleted:function (response, callback) {
            var oldConnected = this.connected;
            callback(this);
        }, getDirectories:function (callback) {
            var request = ecm.model.Request.invokeService("getDirectories", this.type, {repositoryId:this.id}, function (response) {
                var directories = [];
                for (var i in response.directories) {
                    var directoryJSON = response.directories[i];
                    var directory = new Directory(directoryJSON.id, directoryJSON.name);
                    directories.push(directory);
                }
                if (callback) {
                    callback(directories);
                }
            });
            return request;
        }, findUsers:function (callback, directoryName, searchString, searchType, sortType, maxResult, searchAttribute, queryAcrossDomains) {
            var request = ecm.model.Request.invokeService("findUsers", this.type, {repositoryId:this.id, queryAcrossDomains:queryAcrossDomains, directoryName:directoryName, searchString:searchString, searchType:searchType ? searchType : "2", sortType:sortType ? sortType : "1", maxResult:maxResult ? maxResult : "500", searchAttribute:searchAttribute}, function (response) {
                var users = [];
                for (var i in response.items) {
                    var userJSON = response.items[i];
                    if (!userJSON.emailAddress) {
                        userJSON.emailAddress = userJSON.name;
                    }
                    var user = new User(userJSON);
                    users.push(user);
                }
                if (callback) {
                    callback(users);
                }
            });
            return request;
        }, findGroups:function (callback, directoryName, searchString, searchType, sortType, maxResult, searchAttribute, queryAcrossDomains) {
            var request = ecm.model.Request.invokeService("findGroups", this.type, {repositoryId:this.id, queryAcrossDomains:queryAcrossDomains, directoryName:directoryName, searchString:searchString, searchType:searchType ? searchType : "2", sortType:sortType ? sortType : "1", maxResult:maxResult ? maxResult : "500", searchAttribute:searchAttribute}, function (response) {
                var groups = [];
                for (var i in response.items) {
                    var groupJSON = response.items[i];
                    var group = new UserGroup(groupJSON);
                    groups.push(group);
                }
                if (callback) {
                    callback(groups);
                }
            });
            return request;
        }, getContentClass:function (classId, objectStore) {
            var contentClassCache;
            var contentClass;
            if (contentClassCache = this.contentClassCache) {
                if (objectStore && (objectStore.symbolicName != this.objectStoreName)) {
                    if (contentClassCache = contentClassCache.byObjectStore) {
                        if (contentClassCache = contentClassCache[objectStore.symbolicName]) {
                            if (contentClassCache = contentClassCache.byId) {
                                contentClass = contentClassCache[classId];
                            }
                        }
                    }
                } else {
                    if (contentClassCache = contentClassCache.byId) {
                        contentClass = contentClassCache[classId];
                    }
                }
            }
            if (!contentClass) {
                contentClass = this._cacheContentClassById(new ContentClass({id:classId, name:classId, repository:this, pseudoClass:false, allowsInstances:true, objectStore:objectStore}));
            }
            return contentClass;
        }, isSearchTemplateSupported:function () {
            var priv = this._searchTemplateSupported;
            if (this.type == "od") {
                return true;
            }
            if (priv == null) {
                this.retrievePrivileges(lang.hitch(this, function () {
                    priv = this._searchTemplateSupported;
                }));
            }
            return priv;
        }, getPrivilege:function (privilege) {
            var priv = this.privileges[privilege];
            if (priv == null && this.type != "od") {
                this.retrievePrivileges(lang.hitch(this, function (privileges) {
                    if (privileges) {
                        priv = privileges[privilege];
                    }
                }));
            }
            return priv;
        }, retrievePrivileges:function (callback) {
            var self = this;
            var request = ecm.model.Request.invokeService("getPrivileges", this.type, {repositoryId:this.id}, function (response) {
                for (var i in response.servers) {
                    var repositoryJSON = response.servers[i];
                    self._retrievePrivilegesCompleted(repositoryJSON, callback);
                }
            }, false, true);
            return request;
        }, _retrievePrivilegesCompleted:function (repositoryJSON, callback) {
            this.privileges.addDoc = repositoryJSON.priv_addDoc;
            this.privileges.addItem = repositoryJSON.priv_addItem;
            this.privileges.addSearch = repositoryJSON.priv_addSearch;
            this.privileges.addUnifiedSearch = repositoryJSON.priv_addUnifiedSearch;
            this._searchTemplateSupported = repositoryJSON.searchTemplateSupported;
            this.privileges.addTeamspace = repositoryJSON.priv_addTeamspace;
            this.privileges.addTeamspaceTemplate = repositoryJSON.priv_addTeamspaceTemplate;
            this.privileges.workflow = repositoryJSON.priv_workflow;
            this.privileges.manageTeamspace = true;
            if (repositoryJSON.priv_foldering != null) {
                this.privileges.foldering = repositoryJSON.priv_foldering;
            }
            if (callback) {
                callback(this.privileges);
            }
        }, getDefaultTemplate:function () {
            var template = null;
            this.retrieveSearchTemplates(function (templates) {
                if (templates && templates.length > 0) {
                    template = templates[0];
                }
            });
            return template;
        }, retrieveSearchTemplates:function (callback, filter) {
            if (!filter) {
                filter = "navigation";
            }
            if (this.templates && this.templatesFilter == filter) {
                if (callback) {
                    callback(this.templates);
                }
            } else {
                var self = this;
                var request = ecm.model.Request.invokeService("getSearchTemplates", this.type, {repositoryId:this.id, filter_type:filter}, function (response) {
                    self._retrieveSearchTemplatesCompleted(response, callback);
                });
                this.templatesFilter = filter;
            }
            return request;
        }, _retrieveSearchTemplatesCompleted:function (response, callback) {
            var items = response.rows;
            this.templates = [];
            for (var i in items) {
                var template = ContentItem.createFromJSON(items[i], this);
                this.templates.push(template);
            }
            if (callback) {
                callback(this.templates);
            }
        }, retrieveSearchTemplate:function (docId, vsId, version, callback, errorback) {
            var request = null;
            if (this.type != "od") {
                var requestParams = {repositoryId:this.id, docid:docId};
                if (vsId) {
                    requestParams.vsId = vsId;
                }
                if (version) {
                    requestParams.version = version;
                }
                request = ecm.model.Request.invokeService("getContentItems", this.type, requestParams, lang.hitch(this, function (response) {
                    this._retrieveSearchTemplateCompleted(response, callback);
                }), false, false, errorback);
            } else {
                var json = {rows:[{id:docId, name:docId, attributes:[]}]};
                this._retrieveSearchTemplateCompleted(json, callback);
            }
            return request;
        }, _retrieveSearchTemplateCompleted:function (response, callback) {
            var item = response.rows[0];
            var template = ContentItem.createFromJSON(item, this);
            if (callback) {
                callback(template);
            }
        }, getEntryTemplateById:function (entryTemplateId, entryTemplateName, objectStore) {
            var entryTemplateCache;
            var entryTemplate;
            if (entryTemplateCache = this.entryTemplateCache) {
                if (objectStore && (objectStore.symbolicName != this.objectStoreName)) {
                    if (entryTemplateCache = entryTemplateCache.byObjectStore) {
                        if (entryTemplateCache = entryTemplateCache[objectStore.symbolicName]) {
                            if (entryTemplateCache = entryTemplateCache.byId) {
                                entryTemplate = entryTemplateCache[entryTemplateId];
                            }
                        }
                    }
                } else {
                    if (entryTemplateCache = entryTemplateCache.byId) {
                        entryTemplate = entryTemplateCache[entryTemplateId];
                    }
                }
            }
            if (!entryTemplate) {
                if (!entryTemplateName) {
                    entryTemplateName = entryTemplateId;
                }
                entryTemplate = new EntryTemplate({id:entryTemplateId, name:entryTemplateName, repository:this});
                entryTemplate = this._cacheEntryTemplateById(entryTemplate, objectStore);
            }
            return entryTemplate;
        }, _cacheEntryTemplateById:function (entryTemplate, objectStore) {
            var entryTemplateCache = this.entryTemplateCache || (this.entryTemplateCache = {});
            if (objectStore && (objectStore.symbolicName != this.objectStoreName)) {
                entryTemplateCache = entryTemplateCache.byObjectStore || (entryTemplateCache.byObjectStore = {});
                entryTemplateCache = entryTemplateCache[objectStore.symbolicName] || (entryTemplateCache[objectStore.symbolicName] = {});
            }
            if (!entryTemplateCache.byId) {
                entryTemplateCache.byId = {};
            } else {
                if (!entryTemplate.isRetrieved) {
                    var cachedEntryTemplate = entryTemplateCache.byId[entryTemplate.id];
                    if (cachedEntryTemplate && cachedEntryTemplate.isRetrieved) {
                        return cachedEntryTemplate;
                    }
                }
            }
            entryTemplateCache.byId[entryTemplate.id] = entryTemplate;
            return entryTemplate;
        }, retrieveEntryTemplates:function (callback, filter, folderId, rootFolderId, objectStore) {
            if (!filter) {
                filter = "all";
            }
            var entryTemplates = null;
            var entryTemplateCache;
            if (entryTemplateCache = this.entryTemplateCache) {
                if (objectStore && (objectStore.symbolicName != this.objectStoreName)) {
                    entryTemplateCache = entryTemplateCache.byObjectStore && entryTemplateCache.byObjectStore[objectStore.symbolicName];
                }
                if (entryTemplateCache) {
                    if (folderId) {
                        if (entryTemplateCache.byFolderId) {
                            entryTemplates = entryTemplateCache.byFolderId[folderId];
                        }
                    } else {
                        if (entryTemplateCache.byFilter) {
                            entryTemplates = entryTemplateCache.byFilter[filter];
                        }
                    }
                }
            }
            if (entryTemplates) {
                if (callback) {
                    callback(entryTemplates);
                }
            } else {
                var request = ecm.model.Request.invokeService("getEntryTemplates", this.type, {repositoryId:this.id, filter_type:filter, folderDocid:folderId || "", rootFolderId:rootFolderId || "", objectStoreId:objectStore ? objectStore.id : ""}, lang.hitch(this, function (response) {
                    this._retrieveEntryTemplatesCompleted(response, callback, filter, folderId, objectStore);
                }));
            }
            return request;
        }, _retrieveEntryTemplatesCompleted:function (response, callback, filter, folderId, objectStore) {
            var entryTemplates = [];
            for (var i in response.datastore.items) {
                var entryTemplateJSON = response.datastore.items[i];
                entryTemplateJSON.id = entryTemplateJSON.template_name;
                entryTemplateJSON.name = entryTemplateJSON.template_label;
                entryTemplateJSON.description = entryTemplateJSON.template_desc;
                entryTemplateJSON.repository = this;
                var entryTemplate = new EntryTemplate(entryTemplateJSON);
                entryTemplate = this._cacheEntryTemplateById(entryTemplate, objectStore);
                entryTemplates.push(entryTemplate);
            }
            if (!this.entryTemplateCache) {
                this.entryTemplateCache = {};
            }
            var entryTemplateCache = this.entryTemplateCache;
            if (objectStore && (objectStore.symbolicName != this.objectStoreName)) {
                entryTemplateCache = entryTemplateCache.byObjectStore || (entryTemplateCache.byObjectStore = {});
                entryTemplateCache = entryTemplateCache[objectStore.symbolicName] || (entryTemplateCache[objectStore.symbolicName] = {});
            }
            if (folderId) {
                if (!entryTemplateCache.byFolderId) {
                    entryTemplateCache.byFolderId = {};
                }
                entryTemplateCache.byFolderId[folderId] = entryTemplates;
            } else {
                if (!entryTemplateCache.byFilter) {
                    entryTemplateCache.byFilter = {};
                }
                entryTemplateCache.byFilter[filter] = entryTemplates;
            }
            if (callback) {
                callback(entryTemplates);
            }
        }, clearEntryTemplateCache:function (filter, allFolders, folderId, objectStore) {
            var entryTemplateCache;
            if (filter == null && folderId == null && allFolders == null) {
                delete this.entryTemplateCache;
                return;
            }
            if (entryTemplateCache = this.entryTemplateCache) {
                if (objectStore && (objectStore.symbolicName != this.objectStoreName)) {
                    entryTemplateCache = entryTemplateCache.byObjectStore && entryTemplateCache.byObjectStore[objectStore.symbolicName];
                }
                if (entryTemplateCache) {
                    if (allFolders) {
                        if (entryTemplateCache.byFolderId) {
                            delete entryTemplateCache.byFolderId;
                        }
                    } else {
                        if (folderId) {
                            if (entryTemplateCache.byFolderId) {
                                delete entryTemplateCache.byFolderId[folderId];
                            }
                        } else {
                            if (entryTemplateCache.byFilter) {
                                delete entryTemplateCache.byFilter[filter];
                            }
                        }
                    }
                }
            }
        }, addSearchTemplate:function (searchTemplate, callback, teamspace) {
            console.debug(searchTemplate);
            var self = this;
            var request = ecm.model.Request.postService("addSearchTemplate", this.type, {repositoryId:this.id}, "text/json", searchTemplate.toJson(), function (response) {
                self._searchTemplateAdded(response, searchTemplate, callback);
            });
            return request;
        }, _searchTemplateAdded:function (response, searchTemplate, callback) {
            var properties = response.rows[0];
            lang.mixin(searchTemplate, properties);
            searchTemplate.permissions = null;
            if (this.templates) {
                this.templates.push(searchTemplate);
            }
            if (callback) {
                callback(searchTemplate);
            }
            this.onSearchTemplateAdded(searchTemplate);
            this.onChange(this);
        }, onSearchTemplateAdded:function (searchTemplate) {
        }, clearSearchTemplates:function () {
            this.templates = null;
            this.onChange(this);
        }, searchTemplatesDeleted:function (searchTemplates) {
            this.removeRecentSearches(searchTemplates);
            array.forEach(searchTemplates, function (searchTemplate) {
                this._searchTemplateDeleted(searchTemplate.id);
            }, this);
        }, _searchTemplateDeleted:function (searchTemplateId) {
            if (this.templates) {
                for (var i = 0; i < this.templates.length; i++) {
                    if (this.templates[i].id == searchTemplateId) {
                        this.templates.splice(i, 1);
                        break;
                    }
                }
            }
            if (this.openedSearches) {
                for (var i in this.openedSearches) {
                    var searchTemplate = this.openedSearches[i];
                    if (searchTemplate.id == searchTemplateId) {
                        delete this.openedSearches[i];
                    }
                }
            }
            this.onSearchTemplateDeleted(searchTemplateId);
        }, onSearchTemplateDeleted:function (searchTemplateId) {
        }, retrieveSearchTemplateFolders:function (callback) {
            if (this.templateFolders) {
                if (callback) {
                    callback(this.templateFolders);
                }
            } else {
                if (this.type == "od") {
                    var self = this;
                    var request = ecm.model.Request.invokeService("getCabinets", this.type, {repositoryId:this.id}, function (response) {
                        self._retrieveSearchTemplateFoldersCompleted(response, callback);
                    });
                } else {
                    this._retrieveSearchTemplateFoldersCompleted({datastore:{items:[]}}, callback);
                }
            }
            return request;
        }, _retrieveSearchTemplateFoldersCompleted:function (response, callback) {
            this.templateFolders = [];
            if (!this._allSearchTemplatesFolder) {
                this._allSearchTemplatesFolder = new SearchTemplateFolder({id:"all", name:ecm.messages.all_search_templates, description:"", repository:this});
            }
            this.templateFolders.push(this._allSearchTemplatesFolder);
            for (var i in response.datastore.items) {
                var templateFolderJSON = response.datastore.items[i];
                templateFolderJSON.repository = this;
                templateFolderJSON.id = templateFolderJSON.cabinet_name;
                templateFolderJSON.name = templateFolderJSON.cabinet_name;
                templateFolderJSON.description = templateFolderJSON.cabinet_desc;
                var templateFolder = new SearchTemplateFolder(templateFolderJSON);
                this.templateFolders.push(templateFolder);
            }
            if (callback) {
                callback(this.templateFolders);
            }
            this.onSearchTemplateFoldersRetrieved(this);
        }, onSearchTemplateFoldersRetrieved:function (repository) {
        }, retrieveContentClassList:function (callback, itemList) {
            var self = this;
            var request = ecm.model.Request.invokeService("getContentClasses", this.type, {repositoryId:this.id, itemList:dojojson.toJson(itemList)}, function (response) {
                var classList = [];
                for (var i in response.datastore.items) {
                    var templateJSON = response.datastore.items[i];
                    if (templateJSON[0]) {
                        var template = new ContentClass({id:templateJSON[0], name:templateJSON[1] || templateJSON[0], repository:self});
                    } else {
                        var template = new ContentClass({id:templateJSON.template_name, name:templateJSON.template_label, repository:self});
                    }
                    classList.push(template);
                }
                callback(classList);
            });
            return request;
        }, _cacheContentClassById:function (contentClass) {
            var contentClassCache = this.contentClassCache || (this.contentClassCache = {});
            var objectStore = contentClass.objectStore;
            if (objectStore && (objectStore.symbolicName != this.objectStoreName)) {
                contentClassCache = contentClassCache.byObjectStore || (contentClassCache.byObjectStore = {});
                contentClassCache = contentClassCache[objectStore.symbolicName] || (contentClassCache[objectStore.symbolicName] = {});
            }
            if (contentClassCache.byId) {
                var cachedContentClass = contentClassCache.byId[contentClass.id];
                if (cachedContentClass) {
                    for (var prop in contentClass) {
                        if ((typeof contentClass[prop] !== "function") && contentClass[prop]) {
                            cachedContentClass[prop] = contentClass[prop];
                        }
                    }
                    return cachedContentClass;
                }
            } else {
                contentClassCache.byId = {};
            }
            contentClassCache.byId[contentClass.id] = contentClass;
            return contentClass;
        }, retrieveContentClasses:function (callback, filterType) {
            var contentClasses = null;
            if (filterType == "editItem") {
                filterType = null;
            } else {
                if (this._isP8()) {
                    if (filterType != "search") {
                        filterType = null;
                    }
                }
            }
            if (this.contentClassCache) {
                if (filterType && (filterType.length > 0)) {
                    if (this.contentClassCache.byFilterType) {
                        contentClasses = this.contentClassCache.byFilterType[filterType];
                    }
                } else {
                    contentClasses = this.contentClassCache.all;
                }
            }
            if (contentClasses) {
                if (callback) {
                    callback(contentClasses);
                }
            } else {
                if (this._retrieveContentClassesCallbacks) {
                    this._retrieveContentClassesCallbacks.push(callback || null);
                } else {
                    this._retrieveContentClassesCallbacks = [(callback || null)];
                    var self = this;
                    var request = ecm.model.Request.invokeService("getContentClasses", this.type, {repositoryId:this.id, filter_type:filterType}, function (response) {
                        self._retrieveContentClassesCompleted(response, filterType);
                    }, false, false, lang.hitch(this, function () {
                        delete this._retrieveContentClassesCallbacks;
                    }));
                }
            }
            return request;
        }, _retrieveContentClassesCompleted:function (response, filterType) {
            var contentClassJSON;
            var contentClass;
            var contentClasses = [];
            if (this._isOnDemand()) {
                for (var i in response.rows) {
                    contentClassJSON = response.rows[i];
                    contentClass = this._cacheContentClassById(new ContentClass({id:contentClassJSON.id, name:contentClassJSON.name, repository:this}));
                    contentClasses.push(contentClass);
                }
            } else {
                for (var i in response.datastore.items) {
                    contentClassJSON = response.datastore.items[i];
                    if (contentClassJSON[0]) {
                    } else {
                        contentClassJSON.id = contentClassJSON.template_name;
                        contentClassJSON.name = contentClassJSON.template_label;
                        contentClassJSON.repository = this;
                        if (this._isCM()) {
                            contentClassJSON.allowsInstances = true;
                            contentClass = new ContentClass(contentClassJSON);
                        } else {
                            contentClass = new ContentClass(contentClassJSON);
                        }
                    }
                    contentClass = this._cacheContentClassById(contentClass);
                    contentClasses.push(contentClass);
                }
            }
            if (!this.contentClassCache) {
                this.contentClassCache = {};
            }
            if (filterType && (filterType.length > 0)) {
                if (!this.contentClassCache.byFilterType) {
                    this.contentClassCache.byFilterType = {};
                }
                if (!this.contentClassCache.byFilterType[filterType]) {
                    this.contentClassCache.byFilterType[filterType] = {};
                }
                this.contentClassCache.byFilterType[filterType] = contentClasses;
            } else {
                this.contentClassCache.all = contentClasses;
            }
            if (this._retrieveContentClassesCallbacks) {
                var retrieveContentClassesCallbacks = this._retrieveContentClassesCallbacks;
                delete this._retrieveContentClassesCallbacks;
                var callback;
                for (var i in retrieveContentClassesCallbacks) {
                    callback = retrieveContentClassesCallbacks[i];
                    if (callback) {
                        callback(contentClasses);
                    }
                }
            }
        }, _retrieveItem:function (requestParams, itemRetrievedCallback) {
            var itemRetrievedCallbackKey = requestParams.docid + ":" + requestParams.version + ":" + (requestParams.vsId ? requestParams.vsId : "");
            if (this._retrieveItemCallbacks && this._retrieveItemCallbacks[itemRetrievedCallbackKey]) {
                this._retrieveItemCallbacks[itemRetrievedCallbackKey].push(itemRetrievedCallback);
            } else {
                if (!this._retrieveItemCallbacks) {
                    this._retrieveItemCallbacks = {};
                }
                this._retrieveItemCallbacks[itemRetrievedCallbackKey] = [itemRetrievedCallback];
                var request = ecm.model.Request.invokeService("getContentItems", this.type, requestParams, lang.hitch(this, function (response) {
                    response.requestDocid = requestParams.docid;
                    this._retrieveItemCompleted(response, itemRetrievedCallbackKey);
                }), false, false, lang.hitch(this, function () {
                    delete this._retrieveItemCallbacks[itemRetrievedCallbackKey];
                }));
            }
            return request;
        }, retrieveItem:function (itemIdOrPath, itemRetrievedCallback, templateID, version, vsId, objectStoreId, action) {
            var requestParams = {repositoryId:this.id, objectStoreId:objectStoreId || "", docid:itemIdOrPath, template_name:templateID ? templateID : "", version:version ? version : ""};
            if (action) {
                requestParams.action = action;
            }
            if (vsId) {
                requestParams.vsId = vsId;
            }
            return this._retrieveItem(requestParams, itemRetrievedCallback);
        }, retrieveAdminRoot:function (itemIdOrPath, itemRetrievedCallback, templateID, version, vsId, objectStoreId) {
            var requestParams = {repositoryId:this.id, objectStoreId:objectStoreId || "", docid:itemIdOrPath, template_name:templateID ? templateID : "", version:version ? version : "", adminRoot:"true"};
            if (vsId) {
                requestParams.vsId = vsId;
            }
            return this._retrieveItem(requestParams, itemRetrievedCallback);
        }, _retrieveItemCompleted:function (response, itemRetrievedCallbackKey) {
            var retrieveItemCallbacks = this._retrieveItemCallbacks[itemRetrievedCallbackKey];
            delete this._retrieveItemCallbacks[itemRetrievedCallbackKey];
            var itemJSON = response.rows[0];
            var item = null;
            if (itemJSON) {
                item = ContentItem.createFromJSON(itemJSON, this, null);
            }
            if (response.requestDocid == "/") {
                this.rootItem = item;
            }
            for (var i in retrieveItemCallbacks) {
                retrieveItemCallbacks[i](item);
            }
        }, _teamspaceItemsCache:null, retrieveMultiItem:function (itemIdArray, itemRetrievedCallback, templateID, version, vsId) {
            var requestParams = {repositoryId:this.id, docid:itemIdArray, multiitem:"true", template_name:templateID ? templateID : "", version:version ? version : ""};
            if (vsId) {
                requestParams.vsId = vsId;
            }
            if (this._teamspaceItemsCache) {
                itemRetrievedCallback(this._teamspaceItemsCache);
            } else {
                var request = ecm.model.Request.invokeService("getContentItems", this.type, requestParams, lang.hitch(this, function (response) {
                    this._retrieveMultiItemCompleted(response, itemRetrievedCallback);
                }));
            }
            return request;
        }, _retrieveMultiItemCompleted:function (response, itemRetrievedCallback) {
            this._teamspaceItemsCache = [];
            var items = response.rows;
            if (items) {
                for (var i = 0; i < items.length; i++) {
                    var itemJSON = items[i];
                    var item = ContentItem.createFromJSON(itemJSON, this, null);
                    this._teamspaceItemsCache.push(item);
                }
            }
            if (itemRetrievedCallback) {
                itemRetrievedCallback(this._teamspaceItemsCache);
            }
        }, addDocumentItem:function (parentFolder, objectStore, templateName, criterias, contentSourceType, mimeType, filename, content, childComponentValues, permissions, securityPolicyId, addAsMinorVersion, autoClassify, allowDuplicateFileNames, setSecurityParent, teamspaceId, callback, isBackgroundRequest, onError) {
            var formParams = {criterias:JSON.stringify(criterias), childComponentValues:JSON.stringify(childComponentValues), acl:JSON.stringify(permissions)};
            if (content) {
                if (content.type == "Base64") {
                    formParams.fileBase64 = content.content;
                } else {
                    formParams.file = content;
                }
            }
            var args = {desktop:ecm.model.desktop.id, repositoryId:this.id, workspaceId:teamspaceId, parm_content_source_type:contentSourceType, docid:(parentFolder && parentFolder.id) || "", template_name:templateName, mimetype:mimeType, parm_part_filename:filename};
            if (this._isCM()) {
                args.parm_part_type = "ICMBASE";
            } else {
                if (this._isP8()) {
                    args.securityPolicyId = securityPolicyId;
                    args.asMinorVersion = addAsMinorVersion ? "true" : "false";
                    args.autoClassify = autoClassify ? "true" : "false";
                    args.allowDuplicateFileNames = allowDuplicateFileNames ? "true" : "false";
                    args.set_security_parent = setSecurityParent ? "true" : "false";
                    args.objectStoreId = objectStore ? objectStore.id : "";
                } else {
                    if (this._isCmis()) {
                        args.asMinorVersion = addAsMinorVersion ? "true" : "false";
                    }
                }
            }
            var request = ecm.model.Request.postFormToServiceAPI("addItem", this.type, {requestParams:args, requestCompleteCallback:lang.hitch(this, function (response) {
                this._addDocumentItemCompleted(response, parentFolder, callback);
            }), backgroundRequest:isBackgroundRequest, requestFailedCallback:onError}, formParams);
            return request;
        }, addDocumentItemUsingForm:function (parentFolder, objectStore, templateName, contentSourceType, filename, form, securityPolicyId, addAsMinorVersion, autoClassify, allowDuplicateFileNames, setSecurityParent, teamspaceId, callback, isBackgroundRequest, onError) {
            var args = {desktop:ecm.model.desktop.id, repositoryId:this.id, workspaceId:teamspaceId, parm_content_source_type:contentSourceType, docid:(parentFolder && parentFolder.id) || "", template_name:templateName, parm_part_filename:filename};
            if (this._isCM()) {
                args.parm_part_type = "ICMBASE";
            } else {
                if (this._isP8()) {
                    args.securityPolicyId = securityPolicyId;
                    args.asMinorVersion = addAsMinorVersion ? "true" : "false";
                    args.autoClassify = autoClassify ? "true" : "false";
                    args.allowDuplicateFileNames = allowDuplicateFileNames ? "true" : "false";
                    args.set_security_parent = setSecurityParent ? "true" : "false";
                    args.objectStoreId = objectStore ? objectStore.id : "";
                } else {
                    if (this._isCmis()) {
                        args.asMinorVersion = addAsMinorVersion ? "true" : "false";
                    }
                }
            }
            var request = ecm.model.Request.ieFileUploadServiceAPI("addItem", this.type, {requestParams:args, requestCompleteCallback:lang.hitch(this, function (response) {
                this._addDocumentItemCompleted(response, parentFolder, callback);
            }), backgroundRequest:isBackgroundRequest, requestFailedCallback:onError}, form);
            return request;
        }, _addDocumentItemCompleted:function (response, parentFolder, callback) {
            if (response.fieldErrors) {
                if (callback) {
                    callback(undefined, response.fieldErrors);
                }
            } else {
                var itemJSON = response.rows[0];
                var newItem = ContentItem.createFromJSON(itemJSON, this, null, parentFolder);
                if (callback) {
                    callback(newItem);
                }
            }
        }, addFolderItem:function (parentFolder, objectStore, templateName, criterias, childComponentValues, permissions, securityPolicyId, teamspaceId, callback) {
            var args = {desktop:ecm.model.desktop.id, repositoryId:this.id, workspaceId:teamspaceId, parm_content_source_type:"Folder", docid:(parentFolder && parentFolder.id) || "", template_name:templateName};
            var data = criterias;
            if (this._isCM()) {
                data = [{criterias:criterias, childComponentValues:childComponentValues}];
            } else {
                if (this._isP8()) {
                    args.securityPolicyId = securityPolicyId;
                    args.objectStoreId = objectStore ? objectStore.id : "";
                    data = [{criterias:criterias.criterias, acl:permissions}];
                } else {
                    if (this._isCmis()) {
                        data = [{criterias:criterias, acl:permissions}];
                    }
                }
            }
            var request = ecm.model.Request.postService("addItem", this.type, args, "text/json", JSON.stringify(data), lang.hitch(this, function (response) {
                this._addFolderItemCompleted(response, parentFolder, callback);
            }));
            return request;
        }, _addFolderItemCompleted:function (response, parentFolder, callback) {
            if (response.fieldErrors) {
                if (callback) {
                    callback(undefined, response.fieldErrors);
                }
            } else {
                if (callback) {
                    var itemJSON = response.rows[0];
                    var newItem = ContentItem.createFromJSON(itemJSON, this, null, parentFolder);
                    callback(newItem);
                }
            }
        }, retrieveWorklists:function (callback) {
            if (this.worklists) {
                if (callback) {
                    callback(this.worklists);
                }
            } else {
                var self = this;
                if (this.type == "cm") {
                    var request = ecm.model.Request.invokeService("getWorklists", this.type, {repositoryId:this.id}, function (response) {
                        self._retrieveWorklistsCompleted(response, callback);
                    });
                }
            }
            return request;
        }, _retrieveWorklistsCompleted:function (response, callback) {
            this.worklists = [];
            for (var i in response.datastore.items) {
                var worklistJSON = response.datastore.items[i];
                worklistJSON.id = worklistJSON.worklist_name;
                worklistJSON.name = worklistJSON.worklist_name;
                worklistJSON.description = worklistJSON.worklist_desc;
                worklistJSON.repository = this;
                var worklist = new Worklist(worklistJSON);
                this.worklists.push(worklist);
            }
            if (callback) {
                callback(this.worklists);
            }
        }, retrieveWorklistContainers:function (callback, rootContainersOnly) {
            if (this.worklistContainers) {
                if (callback) {
                    callback(this.worklistContainers);
                }
            } else {
                var self = this;
                if (this.type == "cm") {
                    this._retrieveWorklistFoldersCompleted({datastore:{items:[]}}, callback);
                } else {
                    var request = ecm.model.Request.invokeService("getProcessApplicationSpaces", this.type, {repositoryId:this.id, connection_point:this.connectionPoint}, function (response) {
                        self._retrieveWorklistContainersCompleted(response, callback, rootContainersOnly);
                    });
                }
            }
            return request;
        }, _retrieveWorklistContainersCompleted:function (response, callback, rootContainersOnly) {
            this.worklistContainers = [];
            if (rootContainersOnly || response.num_appspaces > 1) {
                for (var i in response.datastore.items) {
                    var templateJSON = response.datastore.items[i];
                    templateJSON.id = templateJSON.appspace_auth_name;
                    templateJSON.name = templateJSON.appspace_name;
                    templateJSON.description = templateJSON.appspace_desc;
                    templateJSON.canManageRoles = templateJSON.appspace_manage_roles;
                    templateJSON.repository = this;
                    templateJSON.connectionPoint = this.connectionPoint;
                    var processApplicationSpace = new ProcessApplicationSpace(templateJSON);
                    this.worklistContainers.push(processApplicationSpace);
                }
                callback(this.worklistContainers);
                this.onWorklistContainersRetrieved(this.worklistContainers);
            } else {
                var templateJSON = response.datastore.items[0];
                templateJSON.id = templateJSON.appspace_auth_name;
                templateJSON.name = templateJSON.appspace_name;
                templateJSON.description = templateJSON.appspace_desc;
                templateJSON.canManageRoles = templateJSON.appspace_manage_roles;
                templateJSON.repository = this;
                templateJSON.connectionPoint = this.connectionPoint;
                var processApplicationSpace = new ProcessApplicationSpace(templateJSON);
                var self = this;
                var request = ecm.model.Request.invokeService("getProcessRoles", this.type, {repositoryId:this.id, connection_point:this.connectionPoint, appspace_name:encodeURIComponent(response.datastore.items[0].appspace_auth_name)}, function (response) {
                    self._retrieveWorklistContainerRolesCompleted(response, processApplicationSpace, callback);
                });
            }
            return request;
        }, _retrieveWorklistContainerRolesCompleted:function (response, processApplicationSpace, callback) {
            this.worklistContainers = [];
            for (var i in response.datastore.items) {
                var templateJSON = response.datastore.items[i];
                templateJSON.id = templateJSON.processrole_auth_name;
                templateJSON.name = templateJSON.processrole_name;
                templateJSON.description = templateJSON.processrole_desc;
                templateJSON.repository = this;
                templateJSON.connectionPoint = this.connectionPoint;
                templateJSON.parent = processApplicationSpace;
                var processRole = new ProcessRole(templateJSON);
                this.worklistContainers.push(processRole);
            }
            callback(this.worklistContainers);
            this.onWorklistContainersRetrieved(this.worklistContainers);
        }, onWorklistContainersRetrieved:function (worklistContainers) {
        }, retrieveWorklistFolders:function (callback) {
            if (this.worklistFolders) {
                if (callback) {
                    callback(this.worklistFolders);
                }
            } else {
                this._retrieveWorklistFoldersCompleted({datastore:{items:[]}}, callback);
            }
            if (!request) {
                var request = null;
            }
            return request;
        }, _retrieveWorklistFoldersCompleted:function (response, callback) {
            this.worklistFolders = [];
            if (!this._allWorklistsFolder) {
                this._allWorklistsFolder = new WorklistFolder({id:"all", name:ecm.messages.all_worklists, description:ecm.messages.all_worklists_description, repository:this});
            }
            this.worklistFolders.push(this._allWorklistsFolder);
            for (var i in response.datastore.items) {
                var worklistFolderJSON = response.datastore.items[i];
                worklistFolderJSON.id = worklistFolderJSON.folder_name;
                worklistFolderJSON.name = worklistFolderJSON.folder_name;
                worklistFolderJSON.description = worklistFolderJSON.folder_desc;
                worklistFolderJSON.repository = this;
                var worklistFolder = new WorklistFolder(worklistFolderJSON);
                this.worklistFolders.push(worklistFolder);
            }
            if (callback) {
                callback(this.worklistFolders);
            }
        }, deleteTeamspace:function (teamspaceId, type, callback) {
            var self = this;
            var request = ecm.model.Request.invokeService("deleteWorkspace", this.type, {repositoryId:this.id, workspaceType:type, workspaceId:teamspaceId}, function (response) {
                self._teamspaceDeleted(response, callback, type, teamspaceId);
            });
            return request;
        }, _teamspaceDeleted:function (response, callback, type, id) {
            if (type == Teamspace.TEMPLATE) {
                this.teamspaceTemplates = null;
                this.onTeamspaceTemplateDeleted(id);
            } else {
                this.teamspaces = null;
                this.onTeamspaceDeleted(id);
            }
            callback(id);
        }, onTeamspaceDeleted:function (id) {
        }, onTeamspaceTemplateDeleted:function (id) {
        }, editTeamspaceTemplate:function (teamspace, callback, updateUsers, updateRoles) {
            var self = this;
            var request = ecm.model.Request.postService("addWorkspace", this.type, {repositoryId:this.id, workspaceId:teamspace.id, modifyWorkspace:"true", modifyUsers:updateUsers ? "true" : "false", modifyRoles:updateRoles ? "true" : "false", workspaceType:teamspace.type}, "text/json", teamspace.toJson(), function (response) {
                self._editTeamspaceTemplateCompleted(response, teamspace, callback);
            });
            return request;
        }, _editTeamspaceTemplateCompleted:function (response, teamspace, callback) {
            callback(response);
            if (teamspace.type == Teamspace.TEMPLATE) {
                this.teamspaceTemplates = null;
                if (teamspace.state == "default") {
                    this.teamspaceTemplates = null;
                }
                this.onUpdateTeamspaceTemplate(teamspace, this);
            } else {
                this.teamspaces = null;
                this.onUpdateTeamspace(teamspace, this);
            }
        }, addTeamspaceTemplate:function (teamspace, callback) {
            var self = this;
            var request = ecm.model.Request.postService("addWorkspace", this.type, {repositoryId:this.id, workspaceType:teamspace.type}, "text/json", teamspace.toJson(), function (response) {
                self._addTeamspaceTemplateCompleted(response, teamspace, callback);
            });
            return request;
        }, _addTeamspaceTemplateCompleted:function (response, teamspace, callback) {
            if (response.workspaces.length > 0) {
                var json = response.workspaces[0];
                json.repository = this;
                var teamspace = new Teamspace(json);
                if (this.teamspaceTemplates && this.teamspaceTemplates.length > 0) {
                    this.teamspaceTemplates.push(teamspace);
                }
                if (callback) {
                    callback(teamspace);
                }
                this.onAddTeamspaceTemplate(teamspace);
            }
        }, onAddTeamspaceTemplate:function (teamspace) {
        }, onUpdateTeamspaceTemplate:function (teamspace, repo) {
        }, addTeamspace:function (teamspace, callback) {
            var self = this;
            var request = ecm.model.Request.postService("addWorkspace", this.type, {repositoryId:this.id, workspaceType:teamspace.type}, "text/json", teamspace.toJson(), function (response) {
                self._addTeamspaceCompleted(response, teamspace, callback);
            });
            return request;
        }, _addTeamspaceCompleted:function (response, teamspace, callback) {
            if (!this.teamspaces) {
                this.teamspaces = [];
            }
            if (response.workspaces.length > 0) {
                var json = response.workspaces[0];
                json.repository = this;
                var teamspace = new Teamspace(json);
                this.teamspaces.push(teamspace);
                if (callback) {
                    callback(teamspace);
                }
                this.onAddTeamspace(teamspace);
            }
        }, onAddTeamspace:function (teamspace) {
        }, onUpdateTeamspace:function (teamspace) {
        }, validateTeamspace:function (Id, type, callback) {
            var found = false;
            var self = this;
            if (!type) {
                type = "instance";
            }
            var request = ecm.model.Request.invokeService("getWorkspaces", this.type, {workspaceId:Id, validate:true, workspaceType:type, repositoryId:this.id}, function (response) {
                self._validateTeamspaceCompleted(response, callback);
            });
            return request;
        }, _validateTeamspaceCompleted:function (response, callback) {
            if (response.workspaces.length > 0) {
                var json = response.workspaces[0];
                json.repository = this;
                var teamspace = new Teamspace(json);
                callback(teamspace);
            }
        }, retrieveTeamspaceById:function (Id, type, callback) {
            var found = false;
            var self = this;
            if (!type) {
                type = "instance";
            }
            var request = ecm.model.Request.invokeService("getWorkspaces", this.type, {workspaceId:Id, workspaceType:type, repositoryId:this.id}, function (response) {
                self._retrieveTeamspaceByIdCompleted(response, callback);
            });
            return request;
        }, _retrieveTeamspaceByIdCompleted:function (response, callback) {
            if (response.workspaces.length > 0) {
                var json = response.workspaces[0];
                json.repository = this;
                var teamspace = new Teamspace(json);
                callback(teamspace);
            }
        }, retrieveTeamspaceFolders:function (callback) {
            if (this.teamspaces) {
                if (callback) {
                    callback(this.teamspaces);
                }
            } else {
                if (this._retrieveTeamspaceFoldersCallbacks) {
                    this._retrieveTeamspaceFoldersCallbacks.push(callback);
                } else {
                    this._retrieveTeamspaceFoldersCallbacks = [callback];
                    var self = this;
                    var request = ecm.model.Request.invokeService("getWorkspaces", this.type, {repositoryId:this.id}, function (response) {
                        self._retrieveTeamspaceFolderCompleted(response, callback);
                    }, false, false, function (response) {
                        this.teamspaces = [];
                        var retrieveTeamspaceFoldersCallbacks = this._retrieveTeamspaceFoldersCallbacks;
                        this._retrieveTeamspaceFoldersCallbacks = null;
                        for (var i in retrieveTeamspaceFoldersCallbacks) {
                            retrieveTeamspaceFoldersCallbacks[i](this.teamspaces);
                        }
                    });
                }
            }
            return request;
        }, _retrieveTeamspaceFolderCompleted:function (response, callback) {
            this.teamspaces = [];
            for (var i in response.workspaces) {
                var teamspacesJSON = response.workspaces[i];
                teamspacesJSON.repository = this;
                teamspacesJSON.usesClasses = (teamspacesJSON.usesClasses == "true");
                var teamspace = new Teamspace(teamspacesJSON);
                this.teamspaces.push(teamspace);
            }
            var retrieveTeamspaceFoldersCallbacks = this._retrieveTeamspaceFoldersCallbacks;
            this._retrieveTeamspaceFoldersCallbacks = null;
            for (var i in retrieveTeamspaceFoldersCallbacks) {
                retrieveTeamspaceFoldersCallbacks[i](this.teamspaces);
            }
        }, retrieveTeamspaceTemplateFolder:function (callback) {
            if (this.teamspaceTemplates && this.teamspaceTemplates.length > 0) {
                if (callback) {
                    callback(this.teamspaceTemplates);
                }
            } else {
                if (this._retrieveTeamspaceTemplateFolderCallbacks) {
                    this._retrieveTeamspaceTemplateFolderCallbacks.push(callback);
                } else {
                    this._retrieveTeamspaceTemplateFolderCallbacks = [callback];
                    var self = this;
                    var request = ecm.model.Request.invokeService("getWorkspaces", this.type, {repositoryId:this.id, workspaceType:"template"}, function (response) {
                        self._retrieveTeamspaceTemplateFolderCompleted(response, callback);
                    }, false, false, function (response) {
                        this.teamspaceTemplates = [];
                        var retrieveTeamspaceTemplateFolderCallbacks = this._retrieveTeamspaceTemplateFolderCallbacks;
                        this._retrieveTeamspaceTemplateFolderCallbacks = null;
                        for (var i in retrieveTeamspaceTemplateFolderCallbacks) {
                            retrieveTeamspaceTemplateFolderCallbacks[i](this.teamspaceTemplates);
                        }
                    });
                }
            }
            return request;
        }, _retrieveTeamspaceTemplateFolderCompleted:function (response, callback) {
            this.teamspaceTemplates = [];
            for (var i in response.workspaces) {
                var teamspacesJSON = response.workspaces[i];
                teamspacesJSON.repository = this;
                teamspacesJSON.templateJSON = dojojson.toJson(teamspacesJSON.props);
                var teamspace = new Teamspace(teamspacesJSON);
                this.teamspaceTemplates.push(teamspace);
            }
            var retrieveTeamspaceTemplateFolderCallbacks = this._retrieveTeamspaceTemplateFolderCallbacks;
            this._retrieveTeamspaceTemplateFolderCallbacks = null;
            for (var i in retrieveTeamspaceTemplateFolderCallbacks) {
                retrieveTeamspaceTemplateFolderCallbacks[i](this.teamspaceTemplates);
            }
        }, retrieveTeamspaceFoldersResultSet:function (callback, pageResults, orderBy, descending, criteria) {
            if (this._retrieveTeamspaceFoldersResultSetCallbacks) {
                this._retrieveTeamspaceFoldersResultSetCallbacks.push(callback);
            } else {
                this._retrieveTeamspaceFoldersResultSetCallbacks = [callback];
                var params = {repositoryId:this.id, paging:pageResults};
                if (orderBy) {
                    params.order_by = orderBy;
                    if (descending) {
                        params.order_descending = "true";
                    }
                }
                if (criteria) {
                    params.criterias = JSON.stringify(criteria);
                }
                var self = this;
                var request = ecm.model.Request.invokeService("getWorkspaces", this.type, params, function (response) {
                    self._retrieveTeamspaceFolderResultSetCompleted(response, callback);
                }, false, false, function (response) {
                    this.teamspaceResultSet = new ResultSet();
                    var retrieveTeamspaceFoldersCallbacks = this._retrieveTeamspaceFoldersResultSetCallbacks;
                    this._retrieveTeamspaceFoldersResultSetCallbacks = null;
                    for (var i in retrieveTeamspaceFoldersCallbacks) {
                        retrieveTeamspaceFoldersCallbacks[i](this.teamspaceResultSet);
                    }
                });
            }
            return request;
        }, _retrieveTeamspaceFolderResultSetCompleted:function (response, callback) {
            response.repository = this;
            response.rows = [];
            for (var i in response.workspaces) {
                var teamspaceJSON = response.workspaces[i];
                teamspaceJSON.usesClasses = (teamspaceJSON.usesClasses == "true");
                var teamspace = new Teamspace(teamspaceJSON);
                response.rows.push(teamspaceJSON);
            }
            response.setType = "teamspace";
            this.teamspaceResultSet = new ResultSet(response);
            var retrieveTeamspaceFoldersCallbacks = this._retrieveTeamspaceFoldersResultSetCallbacks;
            this._retrieveTeamspaceFoldersResultSetCallbacks = null;
            for (var i in retrieveTeamspaceFoldersCallbacks) {
                retrieveTeamspaceFoldersCallbacks[i](this.teamspaceResultSet);
            }
        }, retrieveTeamspaceTemplateFolderResultSet:function (callback, orderBy, descending, criteria) {
            if (this._retrieveTeamspaceTemplateFolderResultSetCallbacks) {
                this._retrieveTeamspaceTemplateFolderResultSetCallbacks.push(callback);
            } else {
                this._retrieveTeamspaceTemplateFolderResultSetCallbacks = [callback];
                var params = {repositoryId:this.id, workspaceType:"template", paging:true};
                if (orderBy) {
                    params.order_by = orderBy;
                    if (descending) {
                        params.order_descending = "true";
                    }
                }
                if (criteria) {
                    params.criterias = JSON.stringify(criteria);
                }
                var self = this;
                var request = ecm.model.Request.invokeService("getWorkspaces", this.type, params, function (response) {
                    self._retrieveTeamspaceTemplateFolderResultSetCompleted(response, callback);
                }, false, false, function (response) {
                    this.teamspaceTemplateResultSet = new ResultSet();
                    var retrieveTeamspaceTemplateFolderCallbacks = this._retrieveTeamspaceTemplateFolderResultSetCallbacks;
                    this._retrieveTeamspaceTemplateFolderResultSetCallbacks = null;
                    for (var i in retrieveTeamspaceTemplateFolderCallbacks) {
                        retrieveTeamspaceTemplateFolderCallbacks[i](this.teamspaceTemplateResultSet);
                    }
                });
            }
            return request;
        }, _retrieveTeamspaceTemplateFolderResultSetCompleted:function (response, callback) {
            response.repository = this;
            response.rows = [];
            for (var i in response.workspaces) {
                var teamspaceJSON = response.workspaces[i];
                teamspaceJSON.usesClasses = (teamspaceJSON.usesClasses == "true");
                teamspaceJSON.repository = this;
                teamspaceJSON.templateJSON = dojojson.toJson(teamspaceJSON.props);
                var teamspace = new Teamspace(teamspaceJSON);
                response.rows.push(teamspaceJSON);
            }
            response.setType = "template";
            this.teamspaceTemplateResultSet = new ResultSet(response);
            var retrieveTeamspaceTemplateFolderCallbacks = this._retrieveTeamspaceTemplateFolderResultSetCallbacks;
            this._retrieveTeamspaceTemplateFolderResultSetCallbacks = null;
            for (var i in retrieveTeamspaceTemplateFolderCallbacks) {
                retrieveTeamspaceTemplateFolderCallbacks[i](this.teamspaceTemplateResultSet);
            }
        }, retrieveRoles:function (callback) {
            if (this.roles) {
                callback(this.roles);
            } else {
                var request = ecm.model.Request.invokeService("getRoles", this.type, {repositoryId:this.id}, lang.hitch(this, function (response) {
                    this.roles = [];
                    for (var i in response.roles) {
                        var rolesJSON = response.roles[i];
                        if (rolesJSON.desc) {
                            rolesJSON.description = rolesJSON.desc;
                        }
                        if (rolesJSON.privs) {
                            rolesJSON.privileges = rolesJSON.privs;
                        }
                        var role = new Role(rolesJSON);
                        this.roles.push(role);
                    }
                    callback(this.roles);
                }));
            }
            return request;
        }, addSystemRole:function (name, description, privileges, callback) {
            var params = {repositoryId:this.id, name:name, description:description, privs:privileges};
            var request = ecm.model.Request.invokeService("addRole", this.type, params, lang.hitch(this, function (response) {
                this.roles = null;
                var rolesJSON = response.roles[0];
                if (rolesJSON.desc) {
                    rolesJSON.description = rolesJSON.desc;
                }
                if (rolesJSON.privs) {
                    rolesJSON.privileges = rolesJSON.privs;
                }
                var role = new Role(rolesJSON);
                callback(role);
            }));
            return request;
        }, deleteSystemRole:function (id, callback) {
            var params = {repositoryId:this.id, name:name, id:id};
            var request = ecm.model.Request.invokeService("deleteRole", this.type, params, lang.hitch(this, function (response) {
                this.roles = null;
                callback();
            }));
            return request;
        }, retrieveHolds:function (items, isApply, callback) {
            var self = this;
            var docIDs = [];
            for (var i in items) {
                docIDs.push(items[i].id);
            }
            var request = ecm.model.Request.invokeService("getHolds", this.type, {repositoryId:this.id, list_all_hold_names:isApply, template_name:items.length > 0 ? items[0].template : "", docid:docIDs}, function (response) {
                self._retrieveHoldsCompleted(response, callback);
            });
            return request;
        }, _retrieveHoldsCompleted:function (response, callback) {
            if (callback) {
                var canCreateHold = false;
                var holds = [];
                if (response.hold_names) {
                    response.hold_names.sort(function (a, b) {
                        return a.hold_name.toUpperCase().localeCompare(b.hold_name.toUpperCase());
                    });
                    var name, label;
                    for (var i in response.hold_names) {
                        name = response.hold_names[i].hold_name;
                        label = response.hold_names[i].hold_desc;
                        holds.push({name:name, label:label});
                    }
                }
                canCreateHold = response.privCreateHold;
                callback(holds, canCreateHold);
            }
        }, applyHold:function (items, holdNames, callback) {
            var self = this;
            var docIDs = [];
            for (var i in items) {
                docIDs.push(items[i].id);
            }
            var request = ecm.model.Request.invokeService("applyHold", this.type, {repositoryId:this.id, template_name:items[0].template, desktop:ecm.model.desktop.id, hold_names:holdNames, docid:docIDs}, function (response) {
                self._applyHoldCompleted(items, response, callback);
            });
            return request;
        }, _applyHoldCompleted:function (items, response, callback) {
            var itemsJSON = response.rows;
            for (var i in itemsJSON) {
                var itemJSON = itemsJSON[i];
                for (var j in items) {
                    if (itemJSON.origdocid == items[j].id) {
                        items[j].originalId = items[j].id;
                        items[j].id = itemJSON.id;
                        items[j].hasHold = itemJSON.hasHold;
                    }
                }
            }
            this.onChange(items);
            if (callback) {
                callback(response);
            }
            this.onHoldApplied(this);
        }, onHoldApplied:function (repository) {
        }, removeHold:function (items, holdNames, callback) {
            var self = this;
            var docIDs = [];
            for (var i in items) {
                docIDs.push(items[i].id);
            }
            var request = ecm.model.Request.invokeService("removeHold", this.type, {repositoryId:this.id, template_name:items[0].template, desktop:ecm.model.desktop.id, hold_names:holdNames, docid:docIDs}, function (response) {
                self._removeHoldCompleted(items, response, callback);
            });
            return request;
        }, _removeHoldCompleted:function (items, response, callback) {
            var itemsJSON = response.rows;
            for (var i in itemsJSON) {
                var itemJSON = itemsJSON[i];
                for (var j in items) {
                    if (itemJSON.origdocid == items[j].id) {
                        items[j].originalId = items[j].id;
                        items[j].id = itemJSON.id;
                        items[j].hasHold = itemJSON.hasHold;
                    }
                }
            }
            this.onChange(items);
            if (callback) {
                callback(response);
            }
            this.onHoldRemoved(this);
        }, onHoldRemoved:function (repository) {
        }, createHold:function (name, description, folderName, callback) {
            var self = this;
            var request = ecm.model.Request.invokeService("createHold", this.type, {repositoryId:this.id, desktop:ecm.model.desktop.id, hold_name:name, hold_desc:description, template_name:folderName ? folderName : ""}, function (response) {
                self._createHoldCompleted(response, callback);
            });
            return request;
        }, _createHoldCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
            this.onHoldCreated(this);
        }, onHoldCreated:function (repository) {
        }, deleteItems:function (items, callback, allVersions) {
            var docIDs = [];
            for (var i in items) {
                docIDs.push(items[i].id);
            }
            var request = ecm.model.Request.invokeService("deleteItem", this.type, {repositoryId:this.id, docid:docIDs, include_all_versions:allVersions ? "true" : "false"}, lang.hitch(this, function (response) {
                this._deleteItemsCompleted(response, items, callback);
            }));
            return request;
        }, _deleteItemsCompleted:function (response, items, callback) {
            if (this._isP8() || this._isCM()) {
                var deletedItemIds = response.deletedItemIds;
                array.forEach(deletedItemIds, function (deletedItemId) {
                    for (var i in items) {
                        if (items[i].id == deletedItemId) {
                            items[i].deleted = true;
                            break;
                        }
                    }
                });
            } else {
                array.forEach(items, function (item) {
                    item.deleted = true;
                });
            }
            if (callback) {
                callback(items);
            }
            if (items && items[0] && items[0].resultSet && items[0].resultSet.context == "PropertiesVersions") {
                items[0].resultSet.onChange(items);
            } else {
                this.onChange(items);
            }
        }, lockItems:function (items, callback, returnVersion) {
            if (this.type != "od") {
                var task = new Task({id:ecm.messages.lock_items, name:ecm.messages.lock_items});
                task.doit = lang.hitch(this, "_lockItemsDoIt", task);
                task.undoit = lang.hitch(this, "_lockItemsUndoIt", task);
                task.lockCallback = callback;
                task.items = items;
                task.returnVersion = returnVersion;
                task.doit();
                ecm.model.desktop.addUndoableTask(task);
            }
        }, _lockItemsDoIt:function (task) {
            var docIDs = [];
            for (var i in task.items) {
                docIDs.push(task.items[i].id);
            }
            var request = ecm.model.Request.invokeService("lock", this.type, {repositoryId:this.id, docid:docIDs, template_name:task.items[0].template, returnVersion:task.returnVersion}, lang.hitch(this, function (response) {
                this._lockItemsCompleted(response, task.items, task.lockCallback);
            }));
            return request;
        }, _lockItemsUndoIt:function (task) {
            this._unlockItemsDoIt(task);
        }, _lockItemsCompleted:function (response, items, lockCallback) {
            var itemsJSON = response.rows;
            this._updateItemsById(items, itemsJSON);
            if (lockCallback) {
                lockCallback(itemsJSON);
            }
            if (this._isCmis()) {
                this._CMIS_refreshParentFolder(items);
            }
        }, _updateItemsById:function (items, jsonItems) {
            var returnedItem = null;
            for (var i in jsonItems) {
                returnedItem = ContentItem.createFromJSON(jsonItems[i], this, null, null);
                for (var j in items) {
                    if ((items[j].id == returnedItem.id) || (items[j].id == returnedItem.origdocid)) {
                        items[j].update(returnedItem);
                    }
                }
            }
        }, _CMIS_refreshParentFolder:function (items) {
            if (items != null && items.length > 0 && items[0] != null && items[0].parent != null) {
                items[0].parent.refresh();
            }
        }, unlockItems:function (items, callback) {
            if (this.type != "od") {
                var task = new Task({id:ecm.messages.unlock_items, name:ecm.messages.unlock_items});
                task.doit = lang.hitch(this, "_unlockItemsDoIt", task);
                task.undoit = lang.hitch(this, "_unlockItemsUndoIt", task);
                task.items = items;
                task.unlockCallback = callback;
                task.doit();
                ecm.model.desktop.addUndoableTask(task);
            }
        }, _unlockItemsDoIt:function (task) {
            var docIDs = [];
            for (var i in task.items) {
                docIDs.push(task.items[i].id);
            }
            var request = ecm.model.Request.invokeService("unlock", this.type, {repositoryId:this.id, docid:docIDs, template_name:task.items[0].template}, lang.hitch(this, function (response) {
                this._unlockItemsCompleted(response, task.items, task.unlockCallback);
            }));
            return request;
        }, canListFolders:function () {
            return this.type == "od" ? false : true;
        }, _unlockItemUndoIt:function (task) {
            this._lockItemsDoIt(task);
        }, _unlockItemsCompleted:function (response, items, unlockCallback) {
            var itemsJSON = response.rows;
            this._updateItemsById(items, itemsJSON);
            if (unlockCallback) {
                unlockCallback();
            }
            if (this._isCmis()) {
                this._CMIS_refreshParentFolder(items);
            }
        }, getDomainObjectStoreNames:function (callback) {
            if (this.type != "p8") {
                return null;
            } else {
                var self = this;
                var request = ecm.model.Request.invokeService("getDomainObjectStoreNames", this.type, {repositoryId:this.id}, function (response) {
                    self._getDomainObjectStoreNamesCompleted(response, callback);
                });
            }
            return request;
        }, _getDomainObjectStoreNamesCompleted:function (response, callback) {
            var objestStoreNames;
            if (response["objectstores"]) {
                objestStoreNames = response.objectstores;
            }
            if (callback) {
                callback(objestStoreNames);
            }
        }, refresh:function () {
            this._clearCache();
            this.onChange(this);
        }, onChange:function (modelObject) {
            ecm.model.desktop.onChange(modelObject);
        }, _isOnDemand:function () {
            return this.type == "od";
        }, _isCM:function () {
            return this.type == "cm";
        }, _isP8:function () {
            return this.type == "p8";
        }, _isP8Like:function () {
            return this.type == "p8" || this.type == "cmis";
        }, _isCmis:function () {
            return this.type == "cmis";
        }, getRepositoryConfig:function (callback) {
            var usingCallback = (callback != null);
            if (this.repositoryConfig) {
                if (usingCallback) {
                    callback(this.repositoryConfig);
                } else {
                    return this.repositoryConfig;
                }
            } else {
                var repositoryConfig = RepositoryReadConfig.createRepositoryReadConfig(this.id);
                repositoryConfig.getConfig(lang.hitch(this, function (response) {
                    this.repositoryConfig = repositoryConfig;
                    if (usingCallback) {
                        callback(this.repositoryConfig);
                    }
                }), !usingCallback);
                if (!usingCallback) {
                    return this.repositoryConfig;
                }
            }
        }, retrieveVersions:function (items, version, callback) {
            var itemids = [];
            if (items instanceof Array) {
                for (var i in items) {
                    itemids.push(items[i].id);
                }
            } else {
                itemids.push(items.id);
            }
            ecm.model.Request.invokeService("getDocumentVersions", this.type, {repositoryId:this.id, requestedVersion:version, docid:itemids}, lang.hitch(this, function (response) {
                response.repository = this;
                var results = new ResultSet(response);
                results.context = "PropertiesVersions";
                var structure = results.structure.cells[0];
                for (var i in structure) {
                    if (structure[i].field == "VersionStatus") {
                        structure[i].styles = "";
                    }
                    structure[i].sortable = false;
                }
                if (callback) {
                    callback(results);
                }
            }), true);
        }, isRecordFilePlanRepository:function () {
            return this.getRecordType() == "FilePlan";
        }, isRecordContentRepository:function () {
            return this.getRecordType() == "Content";
        }, getRecordType:function () {
            return this.recordRepositoryType;
        }, setRecordType:function (recordType) {
            if (recordType) {
                this.recordRepositoryType = recordType;
            }
        }, setRecordDatamodelType:function (datamodel) {
            if (datamodel) {
                this.recordDatamodelType = datamodel;
            }
        }, getRecordDatamodelType:function () {
            return this.recordDatamodelType;
        }, retrieveServerPrinters:function (callback, force) {
            if (this.type == "od") {
                var self = this;
                if (this.serverPrinters && !force) {
                    callback(this.serverPrinters, this.serverPrinterDefaults);
                } else {
                    ecm.model.Request.invokeService("getServerPrinters", "od", {repositoryId:this.id}, function (response) {
                        self._retrieveServerPrintersCompleted(response, callback);
                    });
                }
            } else {
                if (callback) {
                    callback(null);
                }
            }
        }, _retrieveServerPrintersCompleted:function (response, callback) {
            this.serverPrinters = [];
            this.serverPrinterDefaults = {};
            if (response) {
                this.serverPrinterDefaults.faxCoverPage = response.faxCoverPage;
                this.serverPrinterDefaults.faxSenderCompany = response.faxSenderCompany;
                this.serverPrinterDefaults.faxSenderName = response.faxSenderName;
                this.serverPrinterDefaults.faxSenderNumber = response.faxSenderNumber;
                this.serverPrinterDefaults.faxSenderTelNumber = response.faxSenderTelNumber;
                this.serverPrinterDefaults.user_printclass = response.user_printclass;
                this.serverPrinterDefaults.user_printer = response.user_printer;
                this.serverPrinterDefaults.user_printerid = response.user_printerid;
                this.serverPrinterDefaults.user_printformdef = response.user_printformdef;
                this.serverPrinterDefaults.user_printforms = response.user_printforms;
                this.serverPrinterDefaults.user_printnode = response.user_printnode;
                this.serverPrinterDefaults.user_printpagedef = response.user_printpagedef;
                this.serverPrinterDefaults.user_printrouting = response.user_printrouting;
                this.serverPrinterDefaults.user_printwriter = response.user_printwriter;
                this.serverPrinterDefaults.user_printbanner = response.user_printbanner;
                for (var k in response) {
                    var prop = response[k];
                    if (k === "printers") {
                        for (var i in prop) {
                            this.serverPrinters[i] = prop[i];
                        }
                    }
                }
            }
            if (callback) {
                callback(this.serverPrinters);
            }
        }, serverPrint:function (params, items, callback) {
            if (this.type == "od") {
                var docid = [];
                for (var i in items) {
                    if (i == 0) {
                        params.template_name = items[i].template;
                    }
                    docid.push(items[i].id);
                }
                params.docid = docid;
                params.repositoryId = this.id;
                ecm.model.Request.invokeService("serverPrint", "od", params, function (response) {
                    if (callback) {
                        callback(response);
                    }
                }, true);
            }
        }});
    });
}, "ecm/model/Dnd":function () {
    define("ecm/model/Dnd", ["dojo/_base/declare", "dojo/_base/lang", "./Message", "./Desktop", "./Item"], function (declare, lang, Message, Desktop, Item) {
        return declare("ecm.model.Dnd", null, {canDrop:function (sourceItems, targetItem, isCopy, rootItem) {
            if (!targetItem) {
                return false;
            }
            if (targetItem.isInstanceOf(ecm.model.Favorite) && targetItem.type != "folder") {
                return false;
            }
            var targetItemParent = targetItem.parentFolder ? targetItem.parentFolder : targetItem.parent;
            var isP8 = targetItem.repository ? targetItem.repository._isP8Like() : false;
            var isCopingDocuments = false;
            for (var i = 0; i < sourceItems.length; i++) {
                var sourceItem = sourceItems[i];
                if (!sourceItem) {
                    return false;
                }
                if (sourceItem.continuationData) {
                    return false;
                }
                if (sourceItem.id == targetItem.id) {
                    return false;
                }
                if (targetItem.objectId && sourceItem.id == targetItem.objectId) {
                    return false;
                }
                var sourceItemParent = sourceItem.parentFolder ? sourceItem.parentFolder : sourceItem.parent;
                if (sourceItemParent && (sourceItemParent.id == targetItem.id)) {
                    return false;
                }
                if (!isCopy && sourceItemParent && this._isSearchTemplate(sourceItemParent)) {
                    return false;
                }
                if (!targetItem.isFolder()) {
                    if (targetItemParent && sourceItemParent && (targetItemParent.id == sourceItemParent.id)) {
                        return false;
                    }
                }
                if (isCopy && isP8 && sourceItem.isFolder()) {
                    return false;
                }
                if (!targetItem.repository || targetItem.repository.id != sourceItem.repository.id) {
                    return false;
                }
                if (!isCopy && !this.hasPrivilegeToRemoveFrom(sourceItemParent)) {
                    return false;
                }
                if (!sourceItem.isFolder()) {
                    isCopingDocuments = true;
                }
            }
            if (isP8 && isCopingDocuments && rootItem && rootItem.id == targetItem.id) {
                return false;
            }
            if (this.hasPrivilegeToAddTo(targetItem)) {
                return true;
            } else {
                if (targetItem.isInstanceOf(ecm.model.Favorite) && !targetItem.item && targetItem.type == "folder") {
                    return true;
                } else {
                    return false;
                }
            }
        }, hasPrivilegeToRemoveFrom:function (currentParentItem) {
            return currentParentItem && currentParentItem.hasPrivilege && currentParentItem.hasPrivilege("privRemoveFromFolder");
        }, hasPrivilegeToAddTo:function (targetItem) {
            return targetItem && targetItem.hasPrivilege && targetItem.hasPrivilege("privAddItem") && targetItem.hasPrivilege("privAddToFolder");
        }, addCannotDropErrorMessage:function (name) {
            if (ecm.model.desktop) {
                ecm.model.desktop.addMessage(Message.createErrorMessage("dnd_no_privilege_error", [name]));
            }
        }, dropCopy:function (sourceItems, targetItem) {
            for (var i in sourceItems) {
                var sourceItem = sourceItems[i];
                var parent = sourceItem.parentFolder ? sourceItem.parentFolder : sourceItem.parent;
                if (sourceItem.item) {
                    sourceItems[i] = sourceItem.item;
                }
            }
            this._getItem(targetItem, lang.hitch(this, function (targetItemData) {
                targetItem = targetItemData;
                if (this.hasPrivilegeToAddTo(targetItem)) {
                    targetItem.addToFolder(sourceItems, function () {
                    });
                } else {
                    this.addCannotDropErrorMessage(targetItem.name);
                }
            }));
        }, dropMove:function (sourceItems, targetItem, currentParentItem) {
            for (var i in sourceItems) {
                var sourceItem = sourceItems[i];
                if (!currentParentItem) {
                    var parent = sourceItem.parentFolder ? sourceItem.parentFolder : sourceItem.parent;
                    if (parent) {
                        currentParentItem = parent;
                    }
                }
                if (sourceItem.item) {
                    sourceItems[i] = sourceItem.item;
                }
            }
            this._getItem(targetItem, lang.hitch(this, function (targetItemData) {
                targetItem = targetItemData;
                this._getItem(currentParentItem, lang.hitch(this, function (currentParentItemData) {
                    currentParentItem = currentParentItemData;
                    if (this.hasPrivilegeToRemoveFrom(currentParentItem) && this.hasPrivilegeToAddTo(targetItem)) {
                        targetItem.moveToFolder(sourceItems, currentParentItem, function () {
                        });
                    } else {
                        this.addCannotDropErrorMessage(targetItem.name);
                    }
                }));
            }));
        }, _isSearchTemplate:function (item) {
            if (item && item.item) {
                item = item.item;
            }
            if (item && item.isInstanceOf(ecm.model._SearchTemplateBase)) {
                return true;
            }
            return false;
        }, _getItem:function (item, callback) {
            var t = this;
            if (item.isInstanceOf(ecm.model.Favorite)) {
                if (item.item) {
                    callback(item.item);
                } else {
                    item.retrieveFavorite(lang.hitch(this, function () {
                        callback(item.item);
                    }));
                }
            } else {
                callback(item);
            }
        }});
    });
}, "ecm/model/ResultSet":function () {
    define("ecm/model/ResultSet", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/sniff", "dojo/_base/array", "dojo/data/util/sorter", "./_ModelObject", "./_ModelStore", "./ContentItem", "./WorkItem", "./AttachmentItem", "./SearchTemplate", "./Comment"], function (declare, lang, has, array, sorter, _ModelObject, _ModelStore, ContentItem, WorkItem, AttachmentItem, SearchTemplate, Comment) {
        var ResultSet = declare("ecm.model.ResultSet", [_ModelObject], {repository:null, searchTemplate:null, parentFolder:null, teamspaceId:"", maxResultsReached:false, structure:null, magazineStructure:null, columnNames:null, hasToolbar:true, setType:null, items:null, continuationData:null, sortIndex:0, sortDirection:0, pageSize:200, totalCountType:null, totalCount:0, constructor:function () {
            if (this.columns) {
                this.structure = this.columns;
                delete this.columns;
            }
            if (this.magazineColumns) {
                this.magazineStructure = this.magazineColumns;
                delete this.magazineColumns;
            }
            if (this.repository && this.repository.getRecordType() == null && this.repositoryRecordType) {
                this.repository.setRecordType(this.repositoryRecordType);
                delete this.repositoryRecordType;
            }
            if (this.rows) {
                this.items = this.buildItems(this.rows, this.templates);
                delete this.rows;
            }
            if (this.structure && this.structure.cells) {
                for (var i in this.structure.cells[0]) {
                    var cell = this.structure.cells[0][i];
                    if (cell.field == "{CLASS}" && cell.name == "{CLASS}") {
                        cell.name = ecm.messages.class_label_no_html_encode;
                    }
                    if (has("webkit")) {
                        if (cell.field == "icon" || cell.field == "mimeTypeIcon") {
                            cell.width = "25px";
                        } else {
                            if (cell.field == "multiStateIcon") {
                                cell.width = cell.widthWebKit;
                            }
                        }
                    }
                }
            }
        }, buildItems:function (jsonItemsArray, templates) {
            var result = [];
            for (var i in jsonItemsArray) {
                var itemJSON = jsonItemsArray[i];
                var repo = this.repository || ecm.model.desktop.getRepository(itemJSON.repositoryId);
                var item;
                if (this.setType == "workItems") {
                    item = ecm.model.WorkItem.createFromJSON(itemJSON, repo, this, this.parentFolder);
                } else {
                    if (this.setType == "attachmentItems") {
                        item = ecm.model.AttachmentItem.createFromJSON(itemJSON, repo, null, this.parentFolder);
                    } else {
                        if (this.setType == "teamspace") {
                            itemJSON.repository = repo;
                            item = new ecm.model.Teamspace(itemJSON);
                        } else {
                            if (this.setType == "template") {
                                itemJSON.repository = repo;
                                item = new ecm.model.Teamspace(itemJSON);
                            } else {
                                if (this.setType == "comment") {
                                    item = new ecm.model.Comment.createFromJSON(itemJSON, this.contentItem, this);
                                } else {
                                    item = ecm.model.ContentItem.createFromJSON(itemJSON, repo, this, this.parentFolder);
                                    item._teamspaceId = this.teamspaceId;
                                    if (this.teamspaceId) {
                                        this.setType = "teamspaceRuntime";
                                    }
                                    if (templates && !item.template_label && item.template) {
                                        for (var i = 0; i < templates.length; i++) {
                                            var template = templates[i];
                                            if (template.template_name == item.template && template.template_label) {
                                                item.template_label = template.template_label;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                result.push(item);
            }
            return result;
        }, retrieveNextPage:function (retrievedCallback, itemsNeeded) {
            var serviceName;
            if (this.setType == "workItems") {
                serviceName = "getNextWorkItems";
            } else {
                if (this.setType == "teamspace" || this.setType == "template") {
                    serviceName = "getNextTeamspacePage";
                } else {
                    serviceName = "continueQuery";
                }
            }
            var request = ecm.model.Request.invokeService(serviceName, this.repository.type, {repositoryId:this.repository.id, itemsNeeded:itemsNeeded ? itemsNeeded : "", continuationData:this.continuationData, skip:this.items.length, pageSize:this.pageSize}, lang.hitch(this, function (response) {
                var moreItems;
                if (this.setType == "teamspace" || this.setType == "template") {
                    moreItems = this.buildItems(response.workspaces);
                } else {
                    moreItems = this.buildItems(response.rows, response.templates);
                }
                this.items = this.items.concat(moreItems);
                this.maxResultsReached = response.maxResultsReached;
                this.continuationData = response.continuationData;
                retrievedCallback(this.items);
            }));
            return request;
        }, setAttributeMappings:function (attributeMappings) {
            if (attributeMappings instanceof Array) {
                var mappings = {};
                array.forEach(attributeMappings, function (mapping) {
                    mappings[mapping.id] = mapping;
                });
                this._attributeMappings = mappings;
            }
        }, _getMappedAttributeName:function (item, mappingId) {
            if (!this._attributeMappings) {
                return mappingId;
            }
            var repoId = item.repository ? item.repository.id : item.repositoryId;
            var mapping = this._attributeMappings[mappingId];
            if (!repoId || !mapping) {
                return mappingId;
            }
            var attrib = mapping.getRepositoryAttribute(repoId);
            return attrib ? attrib.id : mappingId;
        }, _isMappedAttributeNumeric:function (mappingId) {
            if (!this._attributeMappings) {
                return false;
            }
            var mapping = this._attributeMappings[mappingId];
            if (!mapping) {
                return false;
            }
            var attrib = mapping.toAttributeDefinition();
            return attrib ? attrib.isNumeric() : false;
        }, doSort:function (p, afterSort, store) {
            if (!this.parentFolder && !this.searchTemplate) {
                if (!this.setType || (this.setType != "teamspace" && this.setType != "template")) {
                    afterSort(this);
                    return;
                }
            }
            var col = p[0];
            var sortProperty = col.attribute;
            var clientAttribute = col.clientAttribute;
            if (clientAttribute) {
                delete col.clientAttribute;
            }
            function isNumericAttribute(store, attribute) {
                return (attribute && (store.comparatorMap[attribute] == _ModelStore.numericComparator || store.comparatorMap[attribute] == _ModelStore.longComparator));
            }
            if (store && this.items && !this.continuationData && (isNumericAttribute(store, sortProperty) || this._isMappedAttributeNumeric(sortProperty) || !ecm.model.desktop.culturalCollation)) {
                if (clientAttribute) {
                    col.attribute = clientAttribute;
                }
                var sortComparatorMap;
                if (store.comparatorMap["{NAME}"] && store.parentModelObject && (store.parentModelObject.repository && store.parentModelObject.repository._isCM())) {
                    sortComparatorMap = lang.mixin({}, store.comparatorMap);
                    sortComparatorMap["{NAME}"] = _ModelStore.caseInsensitiveComparator;
                } else {
                    sortComparatorMap = store.comparatorMap;
                }
                var sortStore = {comparatorMap:sortComparatorMap, getValue:lang.hitch(this, function (item, attribute) {
                    if (attribute == "isFolder") {
                        return (item && item.isFolder && item.isFolder() ? 1 : 2);
                    }
                    var value = null;
                    if (item && item.getValue) {
                        attribute = this._getMappedAttributeName(item, attribute);
                        value = item.getValue(attribute);
                    }
                    return value;
                })};
                if (this.parentFolder) {
                    p = [{attribute:"isFolder", descending:p[0].descending}].concat(p);
                }
                this.items.sort(sorter.createSortFunction(p, sortStore));
                if (afterSort) {
                    afterSort(this);
                }
                return;
            }
            if (this.searchTemplate) {
                this.searchTemplate.search(lang.hitch(this, function (resultSet) {
                    if (afterSort) {
                        afterSort(resultSet);
                    }
                }), sortProperty, col.descending, this.teamspaceId);
            } else {
                var item = this.parentFolder;
                if (item == null && (this.setType == "teamspace" || this.setType == "template")) {
                    if (this.setType == "teamspace" && this._disableSort == null) {
                        this.repository.retrieveTeamspaceFoldersResultSet(lang.hitch(this, function (resultSet) {
                            if (afterSort) {
                                afterSort(resultSet);
                            }
                        }), true, sortProperty, col.descending);
                    } else {
                        if (this.setType == "template" && this._disableSort == null) {
                            this.repository.retrieveTeamspaceTemplateFolderResultSet(lang.hitch(this, function (resultSet) {
                                if (afterSort) {
                                    afterSort(resultSet);
                                }
                            }), sortProperty, col.descending);
                        }
                    }
                } else {
                    if (item.isInstanceOf && (item.isInstanceOf(ecm.model.ProcessInbasket))) {
                        var filterCriteria = null;
                        if (item && item.filterValues) {
                            filterCriteria = item.filterValues;
                        }
                        item.retrieveWorkItems(lang.hitch(this, function (resultSet) {
                            if (afterSort) {
                                afterSort(resultSet);
                            }
                        }), sortProperty, col.descending, false, filterCriteria);
                    } else {
                        if (item.isInstanceOf && (item.isInstanceOf(ecm.model.Worklist))) {
                            item.retrieveWorkItems(lang.hitch(this, function (resultSet) {
                                if (afterSort) {
                                    afterSort(resultSet);
                                }
                            }), sortProperty, col.descending);
                        } else {
                            if (item.isInstanceOf && item.isInstanceOf(ecm.model.Favorite)) {
                                var item = item.item;
                                item.unloadFolderContents();
                                item.retrieveFolderContents(false, lang.hitch(this, function (resultSet) {
                                    if (afterSort) {
                                        afterSort(resultSet);
                                    }
                                }), sortProperty, col.descending, false, this.teamspaceId);
                            } else {
                                item.unloadFolderContents();
                                item.retrieveFolderContents(false, lang.hitch(this, function (resultSet) {
                                    if (afterSort) {
                                        afterSort(resultSet);
                                    }
                                }), sortProperty, col.descending, false, this.teamspaceId);
                            }
                        }
                    }
                }
            }
        }, getStore:function () {
            return new _ModelStore(this, this.getItems, null, lang.hitch(this, this.deleteItem), lang.hitch(this, this._getMappedAttributeName));
        }, getColumns:function () {
            if (!this.columnNames) {
                if (this.structure && this.structure.cells) {
                    var array = [];
                    for (var i in this.structure.cells) {
                        for (var j in this.structure.cells[i]) {
                            if (this.structure.cells[i][j].field) {
                                array.push(this.structure.cells[i][j].field);
                            }
                        }
                    }
                    this.columnNames = array;
                } else {
                    this.columnNames = [];
                }
            }
            return this.columnNames;
        }, getItem:function (index) {
            return this.items[index];
        }, setItem:function (index, item) {
            this.items[index] = item;
        }, getIndexOfItem:function (item) {
            return array.indexOf(this.items, item);
        }, getItems:function (handler, itemsNeeded) {
            if (itemsNeeded && handler) {
                if (!this.continuationData || this.items.length >= itemsNeeded) {
                    handler(this.items);
                } else {
                    var self = this;
                    var retrievedCallback = function () {
                        handler(self.items);
                    };
                    this.retrieveNextPage(retrievedCallback, itemsNeeded);
                }
            } else {
                return this.items;
            }
        }, deleteItem:function (item) {
            for (var index in this.items) {
                if (item.id == this.items[index].id) {
                    this.items.splice(index, 1);
                    return true;
                }
            }
            return false;
        }, hasContinuation:function () {
            return this.continuationData ? true : false;
        }, refresh:function () {
            if (this.searchTemplate) {
                this.searchTemplate.search(lang.hitch(this, "_refreshCompleted"));
            } else {
                if (this.parentFolder) {
                    if (this.parentFolder && this.parentFolder.isInstanceOf) {
                        if (this.parentFolder.isInstanceOf(ecm.model.ProcessInbasket)) {
                            this.parentFolder.retrieveWorkItems(lang.hitch(this, "_refreshCompleted"), null, null, true, this.parentFolder.filterValues);
                            return;
                        } else {
                            if (this.parentFolder.isInstanceOf(ecm.model.Worklist)) {
                                this.parentFolder.retrieveWorkItems(lang.hitch(this, "_refreshCompleted"));
                                return;
                            } else {
                                if (this.parentFolder.isInstanceOf(ecm.model.WorkItem)) {
                                    this.parentFolder.openFolderContent(lang.hitch(this, "_refreshCompleted"));
                                    return;
                                } else {
                                    if (this.parentFolder.isInstanceOf(ecm.model.AttachmentItem)) {
                                        this.parentFolder.retrieveAttachmentContents(false, false, lang.hitch(this, "_refreshCompleted"));
                                        return;
                                    } else {
                                        if (this.parentFolder.isInstanceOf(ecm.model.Favorite)) {
                                            var item = this.parentFolder.item;
                                            item.unloadFolderContents();
                                            item.retrieveFolderContents(false, lang.hitch(this, "_refreshCompleted"), undefined, undefined, true, this.teamspaceId, "", this.parentFolder);
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (this.context == "PropertiesVersions") {
                        this.repository.retrieveVersions(this.parentFolder, null, lang.hitch(this, function (resultSet) {
                            resultSet.searchTemplate = this.searchTemplate;
                            this._refreshCompleted(resultSet);
                        }));
                    } else {
                        this.parentFolder.unloadFolderContents();
                        this.parentFolder.retrieveFolderContents(false, lang.hitch(this, "_refreshCompleted"), undefined, undefined, true, this.teamspaceId);
                    }
                } else {
                    if (this.setType == "teamspace") {
                        this.repository.retrieveTeamspaceFoldersResultSet(lang.hitch(this, function (resultSet) {
                            this._refreshCompleted(resultSet);
                        }), true);
                    } else {
                        if (this.setType == "template") {
                            this.repository.retrieveTeamspaceTemplateFolderResultSet(lang.hitch(this, function (resultSet) {
                                this._refreshCompleted(resultSet);
                            }));
                        }
                    }
                }
            }
        }, _refreshCompleted:function (resultSet) {
            this.repository = resultSet.repository;
            this.searchTemplate = resultSet.searchTemplate;
            if (!this.parentFolder || !(this.parentFolder.isInstanceOf && this.parentFolder.isInstanceOf(ecm.model.Favorite))) {
                this.parentFolder = resultSet.parentFolder;
            }
            this.maxResultsReached = resultSet.maxResultsReached;
            this.structure = resultSet.structure;
            this.columnNames = null;
            this.setType = resultSet.setType;
            this.items = resultSet.items;
            this.continuationData = resultSet.continuationData;
            this.sortIndex = resultSet.sortIndex;
            this.sortDirection = resultSet.sortDirection;
            this.onChange(this);
        }, append:function (resultSet) {
            if (resultSet && resultSet.items && this.items) {
                var map = {};
                array.forEach(this.items, function (item) {
                    if (item && item.id) {
                        map[item.id] = item;
                    }
                });
                var items = this.items;
                var appended = false;
                array.forEach(resultSet.items, function (item) {
                    if (item) {
                        var id = item.id;
                        if (id && map[id]) {
                            return;
                        }
                        items.push(item);
                        appended = true;
                    }
                });
                if (appended) {
                    this.onChange(this);
                }
            }
        }, isResultSetForItem:function (item) {
            if (this.parentFolder && this.parentFolder.id == item.id) {
                return true;
            } else {
                if (this.searchTemplate && this.searchTemplate.id == item.id) {
                    return true;
                } else {
                    return false;
                }
            }
        }, getActionsMenuItemsType:function (items) {
            var contextMenuType = null;
            if (items) {
                if (this.setType == "teamspace") {
                    return "TeamspaceContextMenu";
                } else {
                    if (this.setType == "template") {
                        return "TeamspaceTemplateContextMenu";
                    } else {
                        if (this.setType == "teamspaceRuntime") {
                            return "TeamspaceSubFolderContextMenu";
                        }
                    }
                }
                var parentFolders = this._getParentFolders();
                var contextMenuType = "FolderContextMenu";
                for (var i in items) {
                    if (items[i] && items[i].isInstanceOf && items[i].isInstanceOf(ecm.model.WorkItem)) {
                        var repository = this.repository || items[i].repository;
                        if (repository && repository.type == "cm") {
                            if (items[i].isFolder()) {
                                contextMenuType = "WorkItemFolderContextMenu";
                                break;
                            } else {
                                contextMenuType = "WorkItemDocumentContextMenu";
                            }
                        } else {
                            if (items[i].parent.queueName == "Tracker") {
                                contextMenuType = "TrackerQueueContextMenu";
                            } else {
                                if (items[i].parent.queueType == "userQueue") {
                                    contextMenuType = "UserQueueContextMenu";
                                } else {
                                    if (items[i].parent.queueType == "processQueue") {
                                        contextMenuType = "ProcessQueueContextMenu";
                                    }
                                }
                            }
                        }
                    } else {
                        if (items[i] && !items[i].isFolder()) {
                            var actionsHandler = ecm.model.desktop.getActionsHandler();
                            var isBookmark = actionsHandler && actionsHandler.declaredClass == "ecm.widget.layout.BookmarkActionsHandler";
                            var searchTemplateContextMenuType = isBookmark ? "SearchTemplateBookmarkContextMenu" : "SearchTemplateContextMenu";
                            if (this.itemContextMenuDef) {
                                contextMenuType = this.itemContextMenuDef;
                            } else {
                                if (this._hasInstanceOfClass(parentFolders, ecm.model.AttachmentItem)) {
                                    if (items[i].repository.type == "cm") {
                                        contextMenuType = "AttachmentItemContextMenuCM";
                                    } else {
                                        contextMenuType = "AttachmentItemContextMenu";
                                    }
                                    if (items[i].isInstanceOf && items[i].isInstanceOf(ecm.model._SearchTemplateBase)) {
                                        contextMenuType = searchTemplateContextMenuType;
                                    }
                                } else {
                                    if (this.context && this.context == "PropertiesVersions") {
                                        if (items[i].repository.type == "cm") {
                                            contextMenuType = "VersionsCMContextMenu";
                                        } else {
                                            contextMenuType = "VersionsContextMenu";
                                        }
                                    } else {
                                        if (items[i].isInstanceOf && items[i].isInstanceOf(ecm.model._SearchTemplateBase)) {
                                            if (contextMenuType == "ItemContextMenu") {
                                                break;
                                            } else {
                                                contextMenuType = searchTemplateContextMenuType;
                                            }
                                        } else {
                                            contextMenuType = "ItemContextMenu";
                                        }
                                    }
                                }
                            }
                        } else {
                            if (this.folderContextMenuDef) {
                                contextMenuType = this.folderContextMenuDef;
                            } else {
                                if (this._hasInstanceOfClass(parentFolders, ecm.model.AttachmentItem)) {
                                    if (items[i].repository.type == "cm") {
                                        contextMenuType = "AttachmentFolderContextMenuCM";
                                    } else {
                                        contextMenuType = "AttachmentFolderContextMenu";
                                    }
                                } else {
                                    contextMenuType = "FolderContextMenu";
                                }
                            }
                            break;
                        }
                    }
                }
                if (contextMenuType == "ItemContextMenu" || contextMenuType == "FolderContextMenu") {
                    if (items.length == 1 && items[0].isSystemItem()) {
                        contextMenuType = "SystemItemContextMenu";
                    }
                    if (items.length > 1) {
                        var allDocuments = true;
                        for (var i = 0; i < items.length && allDocuments; i++) {
                            if (items[i].isFolder() || items[i].isSystemItem()) {
                                allDocuments = false;
                            }
                        }
                        if (!allDocuments) {
                            var allFolders = true;
                            for (var i = 0; i < items.length && allFolders; i++) {
                                if (!items[i].isFolder()) {
                                    allFolders = false;
                                }
                            }
                            if (!allFolders) {
                                contextMenuType = "MixItemsContextMenu";
                            }
                        }
                    }
                }
            }
            return contextMenuType;
        }, loadContextMenu:function (items, callback) {
            if (callback) {
                var firstItem = items[0];
                if (firstItem && firstItem.retrieveUserPrivileges) {
                    firstItem.retrieveUserPrivileges(lang.hitch(this, function () {
                        ecm.model.desktop.loadMenuActions(this.getActionsMenuItemsType(items), callback);
                    }));
                } else {
                    ecm.model.desktop.loadMenuActions(this.getActionsMenuItemsType(items), callback);
                }
            }
        }, _getParentFolders:function () {
            var root = this.parentFolder;
            var array = [];
            while (root) {
                array.push(root);
                var parent = root.parentFolder ? root.parentFolder : root.parent;
                if (parent) {
                    root = parent;
                } else {
                    break;
                }
            }
            return array;
        }, _hasInstanceOfClass:function (objArray, classObj) {
            for (var i in objArray) {
                if (objArray[i].isInstanceOf && objArray[i].isInstanceOf(classObj)) {
                    return true;
                }
            }
            return false;
        }, getToolbarDef:function () {
            if (this.toolbarDef) {
                return this.toolbarDef;
            } else {
                var toolbarDef = "ContentListToolbar";
                if (this.parentFolder && this.parentFolder.isInstanceOf) {
                    if (this.parentFolder.isInstanceOf(ecm.model.ProcessInbasket)) {
                        toolbarDef = "InbasketToolbarP8";
                    } else {
                        if (this.parentFolder.isInstanceOf(ecm.model.Worklist)) {
                            toolbarDef = "InbasketToolbar";
                        } else {
                            if (this.parentFolder.isInstanceOf(ecm.model.AttachmentItem)) {
                                toolbarDef = "AttachmentToolbar";
                            } else {
                                if (this.setType == "teamspaceRuntime" || this.teamspaceId) {
                                    toolbarDef = "TeamspaceContentListToolbar";
                                }
                            }
                        }
                    }
                } else {
                    if (this.setType == "teamspace") {
                        toolbarDef = "ManageTeamspacesListToolbar";
                    } else {
                        if (this.setType == "template") {
                            toolbarDef = "ManageTemplatesListToolbar";
                        }
                    }
                }
                return toolbarDef;
            }
        }, loadToolbar:function (callback) {
            if (this.hasToolbar && callback) {
                ecm.model.desktop.loadMenuActions(this.getToolbarDef(), callback);
            }
        }});
        ContentItem.createResultSet = function (json) {
            return new ResultSet(json);
        };
        return ResultSet;
    });
}, "ecm/model/SearchTemplate":function () {
    define("ecm/model/SearchTemplate", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/json", "dojo/date/stamp", "./_ModelStore", "./ContentItem", "./Permission", "./_SearchTemplateBase", "./SearchConfiguration", "./SearchCriterion", "./ChildComponentSearchCriteria", "./SearchFolder", "./SearchClass", "./SearchContentClasses", "./ResultSet", "./User", "./ODSavedSearch", "./FolderTreeModel", "./AttributeDefinition"], function (declare, lang, array, dojojson, dateStamp, _ModelStore, ContentItem, Permission, _SearchTemplateBase, SearchConfiguration, SearchCriterion, ChildComponentSearchCriteria, SearchFolder, SearchClass, SearchContentClasses, ResultSet, User, ODSavedSearch, FolderTreeModel, AttributeDefinition) {
        var SearchTemplate = declare("ecm.model.SearchTemplate", _SearchTemplateBase, {P8_STORED_SEARCH:"application/x-filenet-search", productName:null, _searchContentClass:null, includeSubclasses:false, editable:true, folders:null, classes:null, objectStores:null, objectType:null, moreOptions:null, textSearchCriteria:null, textSearchType:null, odSavedSearches:null, odViewSavedSearch:false, odViewPrivateSearch:false, odViewPublicSearch:false, teamspaceMacroSearch:false, invalidRepository:false, invalidClass:false, invalidFolder:false, invalidFileType:false, invalidProperty:false, invalidTextSearch:false, _init:function () {
            this.inherited(arguments);
            var icnAutoRun = this._getAttributeValue("IcnAutoRun");
            this._navigatorSavedSearch = typeof icnAutoRun === "undefined" || icnAutoRun != null;
        }, isNavigatorSavedSearch:function () {
            return this._navigatorSavedSearch;
        }, isAutoRun:function () {
            return this.autoRun || this.mimetype == this.P8_STORED_SEARCH;
        }, isShowInTree:function () {
            return this.showInTree || this.mimetype == this.P8_STORED_SEARCH;
        }, getSearchContentClass:function () {
            if (!this._searchContentClass) {
                this._searchContentClass = this.repository.getContentClass(this.className);
            }
            return this._searchContentClass;
        }, setSearchContentClass:function (searchContentClass) {
            if (!searchContentClass) {
                return;
            }
            this._searchContentClass = searchContentClass;
            this.classes = [];
            var subclasses = this.includeSubclasses;
            if (searchContentClass.isInstanceOf && searchContentClass.isInstanceOf(SearchContentClasses)) {
                var contentClasses = searchContentClass.contentClasses;
                if (contentClasses.length > 1) {
                    subclasses = false;
                }
                array.forEach(contentClasses, function (contentClass) {
                    this.classes.push(new SearchClass({id:contentClass.id, name:contentClass.name, objectType:this.objectType, searchSubclasses:subclasses}));
                }, this);
            } else {
                this.classes.push(new SearchClass({id:searchContentClass.id, name:searchContentClass.name, objectType:this.objectType, searchSubclasses:this.includeSubclasses}));
            }
            this.className = this.classes[0].id;
            this.classDisplayName = this.classes[0].name;
            this.includeSubclasses = subclasses;
        }, setClasses:function (classes) {
            if (!(classes instanceof Array) || classes.length < 1) {
                return;
            }
            this.classes = classes;
            var contentClasses = [];
            array.forEach(classes, function (cls) {
                var contentClass = this.repository.getContentClass(cls.id);
                contentClass.name = cls.name;
                contentClasses.push(contentClass);
            }, this);
            if (contentClasses.length > 1) {
                this._searchContentClass = new SearchContentClasses(contentClasses);
                this.includeSubclasses = false;
            } else {
                this._searchContentClass = contentClasses[0];
            }
            this.className = classes[0].id;
            this.classDisplayName = classes[0].name;
        }, isVersionOptionNone:function () {
            return this.moreOptions && this.moreOptions.versionOption && this.moreOptions.versionOption == "none";
        }, isTextSearchCriteriaPresent:function () {
            return lang.isArray(this.textSearchCriteria) && this.textSearchCriteria.length > 0;
        }, isOrderByRank:function () {
            return this.resultsDisplay && this.resultsDisplay.sortBy == "Rank";
        }, retrieveSearchCriteria:function (callback, editMode, teamspaceId, refresh, autoResolve) {
            var methodName = "retrieveSearchCriteria";
            if (this.searchCriteria && !refresh) {
                if (callback) {
                    callback(this.searchCriteria);
                }
                this.onSearchCriteriaRetrieved(this);
            } else {
                var self = this;
                var request = ecm.model.Request.invokeService("openSearchTemplate", this.repository.type, {repositoryId:this.repository.id, template_name:this.id, vsId:this.vsId || "", form_type:editMode ? "edit" : "search", workspaceId:teamspaceId, autoResolve:autoResolve}, function (response) {
                    self._retrieveSearchCriteriaCompleted(response, callback);
                }, false, false, function (response) {
                    if (response.errors) {
                        var unsupportedErrors = [1019, 1020, 1601, 1603, 1605, 1606, 1607, 1608, 1609, 1610, 1612];
                        for (var i in response.errors) {
                            var error = response.errors[i];
                            if (!lang.isString(error) && array.indexOf(unsupportedErrors, error.number) > -1) {
                                self.onUnsupportedSearchCriteriaRetrieved(self);
                                return;
                            }
                        }
                    }
                });
            }
        }, _retrieveSearchCriteriaCompleted:function (response, callback) {
            var methodName = "_retrieveSearchCriteriaCompleted";
            this.productName = response.productName;
            this.objectType = response.objectType;
            this.odViewSavedSearch = response.query_view;
            var classes = [];
            if (response.search_classes) {
                for (var i in response.search_classes) {
                    var classJSON = response.search_classes[i];
                    classJSON.id = classJSON.name;
                    classJSON.name = classJSON.displayName;
                    classes.push(new SearchClass(classJSON));
                }
                this.includeSubclasses = typeof response.search_classes[0].searchSubclasses === "undefined" ? false : response.search_classes[0].searchSubclasses;
            } else {
                classes.push(new SearchClass({id:response.template_name, name:response.template_label, objectType:response.objectType}));
                this.includeSubclasses = typeof response.searchSubclasses === "undefined" ? false : response.searchSubclasses;
            }
            this.setClasses(classes);
            if (!this.classDisplayName || this.classDisplayName == "$common") {
                this.classDisplayName = this.className == "$common" ? ecm.messages.search_class_all_pseudo : this.className;
            }
            if (response.search_objectstores) {
                this.objectStores = [];
                for (var i in response.search_objectstores) {
                    var osJSON = response.search_objectstores[i];
                    var os = {id:osJSON.id, symbolicName:osJSON.name, displayName:osJSON.displayName};
                    this.objectStores.push(os);
                }
            }
            if (response.search_folders) {
                this.folders = [];
                for (var i in response.search_folders) {
                    var folderJSON = response.search_folders[i];
                    this.folders.push(new SearchFolder(folderJSON.id, folderJSON.pathName, folderJSON.objectStoreId, folderJSON.objectStoreName, folderJSON.searchSubfolders, folderJSON.view, folderJSON.itemId));
                    this.teamspaceMacroSearch = this.teamspaceMacroSearch || folderJSON.id == ecm.model.FolderTreeModel.THIS_TEAMSPACE_ID;
                }
            }
            this.searchCriteria = [];
            if (response.andSearch != undefined && response.andSearch != null) {
                this.andSearch = response.andSearch;
            }
            for (var i in response.criterias) {
                var criterionJSON = response.criterias[i];
                if (lang.isArray(criterionJSON)) {
                    this.searchCriteria.push(this._createNestedCriteria(criterionJSON));
                } else {
                    if (criterionJSON.template_name) {
                        var childComp = new ChildComponentSearchCriteria(criterionJSON.template_name, criterionJSON.template_label);
                        var childAttrs = [];
                        for (var j in criterionJSON.criterias) {
                            childAttrs.push(this._createCriterion(criterionJSON.criterias[j]));
                        }
                        childComp.searchCriteria = childAttrs;
                        this.searchCriteria.push(childComp);
                    } else {
                        this.searchCriteria.push(this._createCriterion(criterionJSON));
                    }
                }
            }
            if ((this.repository.type == "od") && response.displayCriterias) {
                var contentClass = this.repository.getContentClass(this.className);
                if (!contentClass.attributeDefinitions) {
                    if (response.template_label) {
                        contentClass.name = response.template_label;
                    }
                    contentClass.attributeDefinitions = [];
                    contentClass.attributeDefinitionsById = {};
                    for (var i in response.displayCriterias) {
                        var criterionJSON = response.displayCriterias[i];
                        criterionJSON.id = criterionJSON.name;
                        criterionJSON.name = criterionJSON.label;
                        criterionJSON.repositoryType = this.repository.type;
                        criterionJSON.maxLength = criterionJSON.maxEntry;
                        criterionJSON.openChoice = criterionJSON.open_choice;
                        criterionJSON.allowedValues = criterionJSON.validValues;
                        var criterion = new AttributeDefinition(criterionJSON);
                        contentClass.attributeDefinitions.push(criterion);
                        contentClass.attributeDefinitionsById[criterion.id] = criterion;
                    }
                }
            }
            if (response.moreOptions) {
                this.moreOptions = response.moreOptions;
                this.moreOptions.objectType = this.objectType;
            }
            this.textSearchCriteria = [];
            if (lang.isArray(response.search_text_criteria)) {
                this.textSearchCriteria = response.search_text_criteria;
            } else {
                if (response.textSearchCriteria) {
                    this.textSearchCriteria = [response.textSearchCriteria];
                }
            }
            this.textCriteriaLayout = response.textCriteriaLayout;
            this.textSearchType = response.textSearchType;
            if (response.resultsDisplay) {
                this.resultsDisplay = response.resultsDisplay;
            }
            this._navigatorSavedSearch = "autoRun" in response;
            if (this._navigatorSavedSearch) {
                this.autoRun = response.autoRun;
            }
            if ("showInTree" in response) {
                this.showInTree = response.showInTree;
            }
            this.operatorHidden = response.operatorHidden;
            this.criteriaRelationshipHidden = response.criteriaRelationshipHidden;
            this.logInfo(methodName, "autoResolved: " + response.autoResolved);
            this.autoResolved = response.autoResolved;
            this.logInfo(methodName, "invalidRepository: " + response.invalidRepository);
            this.invalidRepository = response.invalidRepository;
            this.logInfo(methodName, "invalidClass: " + response.invalidClass);
            this.invalidClass = response.invalidClass;
            this.logInfo(methodName, "invalidFolder: " + response.invalidFolder);
            this.invalidFolder = response.invalidFolder;
            this.logInfo(methodName, "invalidFileType: " + response.invalidFileType);
            this.invalidFileType = response.invalidFileType;
            this.logInfo(methodName, "invalidProperty: " + response.invalidProperty);
            this.invalidProperty = response.invalidProperty;
            this.logInfo(methodName, "invalidTextSearch: " + response.invalidTextSearch);
            this.invalidTextSearch = response.invalidTextSearch;
            if (callback) {
                callback(this.searchCriteria);
            }
            this.onSearchCriteriaRetrieved(this);
        }, _createCriterion:function (criterionJSON) {
            var methodName = "_createCriterion";
            if (this.searchConfig.isUserProperty(criterionJSON.name)) {
                criterionJSON.dataType = "xs:user";
                var users = new Array();
                var displayValues = criterionJSON.displayValues;
                var values = lang.isArray(criterionJSON.values) ? criterionJSON.values : [criterionJSON.values];
                for (var i in values) {
                    var shortName = values[i];
                    if (shortName) {
                        var displayName = displayValues ? displayValues[i] : shortName;
                        users.push(new User({id:shortName, name:shortName, shortName:shortName, displayName:displayName}));
                    }
                }
                criterionJSON.values = users;
            }
            var operators = [];
            if (criterionJSON.availableOperators) {
                for (var i in criterionJSON.availableOperators) {
                    operators.push(this._convertOperatorFromJSON(criterionJSON.availableOperators[i]));
                }
            } else {
                operators = this.searchConfig.getOperators(criterionJSON.dataType, criterionJSON.cardinality, criterionJSON.choiceList || criterionJSON.markingList, criterionJSON.textSearchable, criterionJSON.nullable, criterionJSON.usesLongColumn, criterionJSON.hasDependentAttributes);
            }
            criterionJSON.defaultOperator = this._convertOperatorFromJSON(criterionJSON.defaultOperator);
            criterionJSON.searchTemplate = this;
            criterionJSON.availableOperators = operators;
            criterionJSON.id = criterionJSON.name;
            criterionJSON.name = criterionJSON.label;
            criterionJSON.valueRequired = criterionJSON.required;
            criterionJSON.maxLength = criterionJSON.maxEntry;
            criterionJSON.allowedValues = criterionJSON.validValues;
            criterionJSON.defaultValue = criterionJSON.values;
            criterionJSON.valueFixed = (criterionJSON.fixedValue === "true" || criterionJSON.fixedValue === true) ? true : false;
            var criterion = new SearchCriterion(criterionJSON);
            return criterion;
        }, _createNestedCriteria:function (nestedCriteriaJSON) {
            var nestedCriteria = [];
            for (var i in nestedCriteriaJSON) {
                var criterionJSON = nestedCriteriaJSON[i];
                if (lang.isArray(criterionJSON)) {
                    var criterion = this._createNestedCriteria(criterionJSON);
                } else {
                    var criterion = this._createCriterion(criterionJSON);
                }
                nestedCriteria.push(criterion);
            }
            return nestedCriteria;
        }, _convertOperatorFromJSON:function (operator) {
            if (operator == "Equals") {
                operator = "EQUAL";
            } else {
                if (operator == "Not Equal") {
                    operator = "NOTEQUAL";
                } else {
                    if (operator == "Like") {
                        operator = "LIKE";
                    } else {
                        if (operator == "Not Like") {
                            operator = "NOTLIKE";
                        } else {
                            if (operator == "Less Than") {
                                operator = "LESS";
                            } else {
                                if (operator == "Less Than Or Equal") {
                                    operator = "LESSOREQUAL";
                                } else {
                                    if (operator == "Greater Than") {
                                        operator = "GREATER";
                                    } else {
                                        if (operator == "Greater Than Or Equal") {
                                            operator = "GREATEROREQUAL";
                                        } else {
                                            if (operator == "Between") {
                                                operator = "BETWEEN";
                                            } else {
                                                if (operator == "Not Between") {
                                                    operator = "NOTBETWEEN";
                                                } else {
                                                    if (operator == "In") {
                                                        operator = "IN";
                                                    } else {
                                                        if (operator == "Not In") {
                                                            operator = "NOTIN";
                                                        } else {
                                                            if (operator == "Is Null") {
                                                                operator = "NULL";
                                                            } else {
                                                                if (operator == "Is Not Null") {
                                                                    operator = "NOTNULL";
                                                                } else {
                                                                    if (operator == "Contains") {
                                                                        operator = "CONTAINS";
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return operator;
        }, _convertOperatorToJSON:function (operator) {
            if (operator == "EQUAL") {
                operator = "Equals";
            } else {
                if (operator == "NOTEQUAL") {
                    operator = "Not Equal";
                } else {
                    if (operator == "LIKE") {
                        operator = "Like";
                    } else {
                        if (operator == "NOTLIKE") {
                            operator = "Not Like";
                        } else {
                            if (operator == "LESS") {
                                operator = "Less Than";
                            } else {
                                if (operator == "LESSOREQUAL") {
                                    operator = "Less Than Or Equal";
                                } else {
                                    if (operator == "GREATER") {
                                        operator = "Greater Than";
                                    } else {
                                        if (operator == "GREATEROREQUAL") {
                                            operator = "Greater Than Or Equal";
                                        } else {
                                            if (operator == "BETWEEN") {
                                                operator = "Between";
                                            } else {
                                                if (operator == "NOTBETWEEN") {
                                                    operator = "Not Between";
                                                } else {
                                                    if (operator == "IN") {
                                                        operator = "In";
                                                    } else {
                                                        if (operator == "NOTIN") {
                                                            operator = "Not In";
                                                        } else {
                                                            if (operator == "NULL") {
                                                                operator = "Is Null";
                                                            } else {
                                                                if (operator == "NOTNULL") {
                                                                    operator = "Is Not Null";
                                                                } else {
                                                                    if (operator == "CONTAINS") {
                                                                        operator = "Contains";
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return operator;
        }, setCritieraToODSavedQuery:function (odSavedQuery) {
            if (odSavedQuery && odSavedQuery.searchCriteria) {
                var savedSearchCriteria = odSavedQuery.searchCriteria;
                for (var i in this.searchCriteria) {
                    var criterion = this.searchCriteria[i];
                    var savedSearchCriterion = savedSearchCriteria[criterion.id];
                    if (savedSearchCriterion) {
                        criterion.selectedOperator = savedSearchCriterion.operator;
                        criterion.setValues(savedSearchCriterion.values);
                    }
                }
            }
        }, getQueryString:function () {
            var query = [];
            for (var i in this.searchCriteria) {
                var criterion = this.searchCriteria[i];
                if (criterion.isInstanceOf && criterion.isInstanceOf(ChildComponentSearchCriteria)) {
                    var childComp = {template_name:criterion.name, criteria:[]};
                    var childCriteria = criterion.searchCriteria;
                    for (var j in criterion.searchCriteria) {
                        var childCriterion = childCriteria[j];
                        var queryTerm = {name:childCriterion.id, operator:this._convertOperatorToJSON(childCriterion.selectedOperator), values:childCriterion.values};
                        childComp.criteria.push(queryTerm);
                    }
                    query.push(childComp);
                } else {
                    var queryTerm = {name:criterion.id, operator:this._convertOperatorToJSON(criterion.selectedOperator), values:criterion.values};
                    query.push(queryTerm);
                }
            }
            return dojojson.toJson(query);
        }, search:function (callback, sortProperty, descending, teamspace, errorCallback) {
            if (teamspace) {
                this.teamspaceId = teamspace && lang.isString(teamspace) ? teamspace : teamspace.id;
            }
            var self = this;
            var request = ecm.model.Request.postService("search", this.repository.type, {desktop:ecm.model.desktop.id, repositoryId:this.repository.id, teamspaceId:this.teamspaceId ? this.teamspaceId : "", template_name:this.id, vsId:this.vsId || "", criterias:this.getQueryString(), order_by:sortProperty, order_descending:descending, searchViaCeApi:ecm.model.desktop._searchViaCeApi ? ecm.model.desktop._searchViaCeApi : false}, "text/json", this.searchCriteria ? this.toJson(true) : "{}", function (response) {
                self._searchCompleted(response, callback, teamspace);
            }, false, false, false, function (response) {
                if (response.errors && errorCallback) {
                    errorCallback(response);
                }
            });
            return request;
        }, _searchCompleted:function (response, callback, teamspace) {
            response.repository = this.repository;
            response.parentFolder = this;
            response.searchTemplate = this;
            response.teamspaceId = this.teamspaceId;
            var results = new ecm.model.ResultSet(response);
            results._moreOptions = this.moreOptions;
            if (callback) {
                callback(results);
            }
            this.onSearchCompleted(results);
        }, updateAllowedValues:function (name, names, values, callback) {
            var self = this;
            var request = ecm.model.Request.invokeService("getFKValues", this.repository.type, {repositoryId:this.repository.id, template_name:this.id, criteria_name:name, criteria_names:dojojson.toJson(names), criteria_values:dojojson.toJson(values)}, function (response) {
                self._getFKValuesComplete(response, callback);
            });
        }, _getFKValuesComplete:function (response, callback) {
            var methodName = "_getFKValuesComplete";
            for (var i in response.criterias) {
                var criterionJSON = response.criterias[i];
                for (var j in this.searchCriteria) {
                    var criterion = this.searchCriteria[j];
                    if (criterionJSON.name == criterion.id) {
                        criterion.allowedValues = criterionJSON.validValues;
                        break;
                    }
                }
            }
            if (callback) {
                callback();
            }
        }, searchDocument:function (documentId, callback) {
            var self = this;
            var request = ecm.model.Request.invokeService("getContentItems", this.repository.type, {repositoryId:this.repository.id, docid:documentId, template_name:this.name}, function (response) {
                self._searchDocumentCompleted(response, callback);
            });
        }, _searchDocumentCompleted:function (response, callback) {
            response.repository = this.repository;
            response.searchTemplate = this;
            var results = new ecm.model.ResultSet(response);
            results._moreOptions = this.moreOptions;
            if (callback) {
                callback(results);
            }
        }, retrieveODSavedQueries:function (callback) {
            var self = this;
            if (this.odSavedSearches) {
                callback(this.odSavedSearches);
            } else {
                if (this.repository.type == "od") {
                    var request = ecm.model.Request.invokeService("listSavedSearches", this.repository.type, {repositoryId:this.repository.id, template_name:this.id}, function (response) {
                        self.retrieveODSavedQueriesCompleted(response, callback);
                    });
                }
            }
        }, retrieveODSavedQueriesCompleted:function (response, callback) {
            if (response) {
                this.odViewSavedSearch = response.query_view;
                this.odViewPrivateSearch = response.query_private;
                this.odViewPublicSearch = response.query_public;
                if (response.query_names) {
                    this.odSavedSearches = response.query_names;
                } else {
                    this.odSavedSearches = [];
                }
            }
            callback(this.odSavedSearches);
        }, retrieveODSavedQuery:function (queryName, callback) {
            var self = this;
            if (this.repository.type == "od") {
                var request = ecm.model.Request.invokeService("retrieveSavedSearch", this.repository.type, {repositoryId:this.repository.id, template_name:this.id, query_name:queryName}, function (response) {
                    self.retrieveODSavedQueryCompleted(response, callback);
                });
            }
        }, retrieveODSavedQueryCompleted:function (response, callback) {
            if (response) {
                response.repository = this.repository;
                response.id = response.name;
                response.templateName = response.template_name;
                response.isPublic = response.query_public;
                var savedSearch = new ODSavedSearch(response);
                if (callback) {
                    callback(savedSearch);
                }
            }
        }, saveODQuery:function (queryName, isPublic, callback) {
            var self = this;
            if (this.repository.type == "od") {
                var odSavedCriteria = [];
                for (var i in this.searchCriteria) {
                    var criterion = this.searchCriteria[i];
                    var jsonCriterion = {name:criterion.name, operator:criterion.selectedOperator, values:criterion.values};
                    odSavedCriteria.push(jsonCriterion);
                }
                var request = ecm.model.Request.invokeService("saveSavedSearch", this.repository.type, {repositoryId:this.repository.id, template_name:this.id, query_name:queryName, query_public:isPublic, saved_criterias:dojojson.toJson(odSavedCriteria)}, function (response) {
                    self.saveODQueryCompleted(response, callback);
                });
            }
        }, saveODQueryCompleted:function (response, callback) {
            if (response) {
                if (!this.odSavedSearches) {
                    this.odSavedSearches = [];
                }
                var alreadyInList = false;
                for (var i in this.odSavedSearches) {
                    if (this.odSavedSearches[i] == response.query_name) {
                        alreadyInList = true;
                        break;
                    }
                }
                if (!alreadyInList) {
                    this.odSavedSearches.push(response.query_name);
                }
                if (callback) {
                    callback(response.query_name);
                }
            }
        }, deleteODQueries:function (queries, callback) {
            var self = this;
            var request = ecm.model.Request.invokeService("deleteSavedSearch", this.repository.type, {repositoryId:this.repository.id, template_name:this.id, query_name:queries}, function (response) {
                self._deleteODQueriesCompleted(response, callback, queries);
            });
        }, _deleteODQueriesCompleted:function (response, callback) {
            if (response.query_names) {
                this.odSavedSearches = response.query_names;
            } else {
                this.odSavedSearches = [];
            }
            if (callback) {
                callback();
            }
        }, toJson:function (searching) {
            var jsonTemplate = this.inherited(arguments);
            jsonTemplate.editable = this.editable;
            jsonTemplate.objectType = this.objectType ? this.objectType : "";
            jsonTemplate.template_name = this.className;
            jsonTemplate.template_label = this.classDisplayName;
            jsonTemplate.searchSubclasses = this.includeSubclasses || false;
            jsonTemplate.search_classes = [];
            if (this.classes instanceof Array && this.classes.length > 1) {
                for (var i = 0; i < this.classes.length; i++) {
                    var cls = this.classes[i];
                    if (!cls.selected) {
                        continue;
                    }
                    jsonTemplate.search_classes.push({name:cls.id, displayName:cls.name, searchSubclasses:cls.searchSubclasses, editProperty:cls.editProperty, objectType:cls.objectType, itemId:cls.itemId});
                }
            }
            jsonTemplate.search_folders = [];
            for (var i in this.folders) {
                var folder = this.folders[i];
                jsonTemplate.search_folders.push({id:folder.id, pathName:folder.name, searchSubfolders:folder.searchSubfolders, view:folder.view, objectStoreId:folder.objectStoreId ? folder.objectStoreId : null, itemId:folder.itemId});
            }
            if (this.moreOptions) {
                jsonTemplate.moreOptions = this.moreOptions;
            }
            var textSearchCriteria = this.textSearchCriteria;
            if (lang.isArray(textSearchCriteria)) {
                jsonTemplate.search_text_criteria = textSearchCriteria;
                var firstCriterion = null;
                if (textSearchCriteria.length > 0) {
                    firstCriterion = textSearchCriteria[0];
                }
                if (firstCriterion && (!searching || firstCriterion.text)) {
                    jsonTemplate.textSearchCriteria = firstCriterion;
                }
            }
            jsonTemplate.textSearchType = this.textSearchType || "";
            jsonTemplate.resultsDisplay = this.resultsDisplay ? this.resultsDisplay : null;
            var json = dojojson.toJson(jsonTemplate);
            return json;
        }, toRecentSearchJson:function (contextId, userId) {
            var jsonTemplate = {};
            jsonTemplate.templateId = this.id;
            jsonTemplate.name = this.name;
            jsonTemplate.description = this.description || "";
            jsonTemplate.vsId = this.vsId || "";
            var json = dojojson.toJson(jsonTemplate);
            return json;
        }, _searchCriterionToJson:function (criterion, searching) {
            var jsonCriterion = this.inherited(arguments);
            jsonCriterion.defaultOperator = criterion.defaultOperator;
            jsonCriterion.availableOperators = criterion.availableOperators;
            jsonCriterion.format = criterion.format;
            jsonCriterion.defaultValue = criterion.defaultValue;
            jsonCriterion.valueRequired = criterion.valueRequired;
            jsonCriterion.readOnly = criterion.readOnly;
            jsonCriterion.hidden = criterion.hidden;
            jsonCriterion.allowedValues = criterion.allowedValues;
            jsonCriterion.maxLength = criterion.maxLength;
            jsonCriterion.minValue = criterion.minValue;
            jsonCriterion.maxValue = criterion.maxValue;
            return jsonCriterion;
        }, _compareMoreOptions:function (thisOptions, thatOptions) {
            var options = lang.clone(thisOptions);
            var options2 = lang.clone(thatOptions);
            if (options.objectType != options2.objectType) {
                return false;
            }
            if (!options.versionOption) {
                options.versionOption = "none";
            }
            if (!options2.versionOption) {
                options2.versionOption = "none";
            }
            if (options.versionOption != options2.versionOption) {
                return false;
            }
            if (options.propertyTextAnded === undefined) {
                options.propertyTextAnded = true;
            }
            if (options2.propertyTextAnded === undefined) {
                options2.propertyTextAnded = true;
            }
            if (new Boolean(options.propertyTextAnded).valueOf() != new Boolean(options2.propertyTextAnded).valueOf()) {
                return false;
            }
            if (new Boolean(options.macros).valueOf() != new Boolean(options2.macros).valueOf()) {
                return false;
            }
            if (options.macros) {
                if ((options.macros.fileTypes instanceof Array) != (options2.macros.fileTypes instanceof Array)) {
                    return false;
                }
                if (options.macros.fileTypes instanceof Array) {
                    if (options.macros.fileTypes.length != options2.macros.fileTypes.length) {
                        return false;
                    }
                    if (!array.every(options.macros.fileTypes, function (fileType) {
                        return array.some(options2.macros.fileTypes, function (fileType2) {
                            return fileType == fileType2;
                        });
                    })) {
                        return false;
                    }
                }
                if ((options.macros.userActions instanceof Array) != (options2.macros.userActions instanceof Array)) {
                    return false;
                }
                if (options.macros.userActions instanceof Array) {
                    if (options.macros.userActions.length != options2.macros.userActions.length) {
                        return false;
                    }
                    if (!array.every(options.macros.userActions, function (action) {
                        return array.some(options2.macros.userActions, function (action2) {
                            if (action.action != action2.action || action.dateOperator != action2.dateOperator) {
                                return false;
                            }
                            if ((action.users instanceof Array) != (action2.users instanceof Array)) {
                                return false;
                            }
                            if (action.users instanceof Array) {
                                if (action.users.length != action2.users.length) {
                                    return false;
                                }
                                if (!array.every(action.users, function (user) {
                                    return array.some(action2.users, function (user2) {
                                        return user == user2;
                                    });
                                })) {
                                    return false;
                                }
                            }
                            if (!array.every(action.dates, function (date) {
                                return array.some(action2.dates, function (date2) {
                                    if (!(date instanceof Date)) {
                                        date = dateStamp.fromISOString(date);
                                        date.setHours(0);
                                    }
                                    if (!(date2 instanceof Date)) {
                                        date2 = dateStamp.fromISOString(date2);
                                        date2.setHours(0);
                                    }
                                    return date.valueOf() == date2.valueOf();
                                });
                            })) {
                                return false;
                            }
                            return true;
                        });
                    })) {
                        return false;
                    }
                }
            }
            return true;
        }, containsEqualCriteria:function (searchTemplate) {
            if (!this.inherited(arguments)) {
                return false;
            }
            if (this.objectType != searchTemplate.objectType) {
                return false;
            }
            if (new Boolean(this.andSearch).valueOf() != new Boolean(searchTemplate.andSearch).valueOf()) {
                return false;
            }
            if ((this.objectStores instanceof Array) != (searchTemplate.objectStores instanceof Array)) {
                return false;
            }
            if (this.objectStores instanceof Array) {
                if (this.objectStores.length != searchTemplate.objectStores.length) {
                    return false;
                }
                if (!array.every(this.objectStores, function (os) {
                    return array.some(searchTemplate.objectStores, function (os2) {
                        return os.id == os2.id || os.symbolicName == os2.symbolicName;
                    });
                })) {
                    return false;
                }
            }
            if ((this.folders instanceof Array) != (searchTemplate.folders instanceof Array)) {
                return false;
            }
            if (this.folders instanceof Array) {
                if (this.folders.length != searchTemplate.folders.length) {
                    return false;
                }
                if (!array.every(this.folders, function (folder) {
                    return array.some(searchTemplate.folders, function (folder2) {
                        return folder.equals(folder2);
                    });
                })) {
                    return false;
                }
            }
            if ((this.classes instanceof Array) != (searchTemplate.classes instanceof Array)) {
                return false;
            }
            if (this.classes instanceof Array) {
                if (this.classes.length != searchTemplate.classes.length) {
                    return false;
                }
                if (!array.every(this.classes, function (sc) {
                    return array.some(searchTemplate.classes, function (sc2) {
                        return sc.equals(sc2);
                    });
                })) {
                    return false;
                }
            }
            if (new Boolean(this.includeSubclasses).toString() != new Boolean(searchTemplate.includeSubclasses).toString()) {
                return false;
            }
            if ((this.textSearchCriteria instanceof Array) != (searchTemplate.textSearchCriteria instanceof Array)) {
                return false;
            }
            if (this.textSearchCriteria instanceof Array) {
                if (this.textSearchCriteria.length != searchTemplate.textSearchCriteria.length) {
                    return false;
                }
                if (!array.every(this.textSearchCriteria, function (criterion) {
                    return array.some(searchTemplate.textSearchCriteria, function (criterion2) {
                        var prox1 = criterion.operator == "near" ? new Number(criterion.proximityDistance).valueOf() : 0;
                        var prox2 = criterion2.operator == "near" ? new Number(criterion2.proximityDistance).valueOf() : 0;
                        return criterion.text == criterion2.text && criterion.operator == criterion2.operator && prox1 == prox2;
                    });
                })) {
                    return false;
                }
            }
            if (new Boolean(this.moreOptions).valueOf() != new Boolean(searchTemplate.moreOptions).valueOf()) {
                return false;
            }
            if (this.moreOptions) {
                if (!this._compareMoreOptions(this.moreOptions, searchTemplate.moreOptions)) {
                    return false;
                }
            }
            return true;
        }, getContentType:function () {
            var contentType = this.inherited(arguments);
            if (contentType.indexOf("application/x") != 0 || this.autoRun) {
                contentType = "application/x-searchtemplate";
                if (this.autoRun) {
                    contentType += ".automatic";
                }
            }
            return contentType;
        }, clone:function () {
            var clone = this.inherited(arguments);
            clone.classes = lang.clone(this.classes);
            clone.folders = lang.clone(this.folders);
            clone.objectStores = lang.clone(this.objectStores);
            clone.moreOptions = lang.clone(this.moreOptions);
            clone.textSearchCriteria = lang.clone(this.textSearchCriteria);
            clone.textCriteriaLayout = lang.clone(this.textCriteriaLayout);
            clone.objectStore = lang.clone(this.objectStore);
            clone.odSavedSearches = lang.clone(this.odSavedSearches);
            return clone;
        }});
        SearchTemplate.instanceOf = function (json) {
            if (json.template == "StoredSearch") {
                return true;
            }
            if (json.template == "ICMSearch") {
                return !json.attributes.clbSearchType || (json.attributes.clbSearchType instanceof Array ? json.attributes.clbSearchType[0] === 0 : json.attributes.clbSearchType === 0);
            }
            if (json.isSearch) {
                return true;
            }
            return false;
        };
        SearchTemplate.createFromJSON = function (json, repository, resultSet, parent) {
            var searchTemplate = null;
            if (SearchTemplate.instanceOf(json)) {
                lang.mixin(json, {repository:repository, resultSet:resultSet, parent:parent});
                if (json[0]) {
                    searchTemplate = new SearchTemplate({id:json[0], name:json[0], repository:repository, resultSet:resultSet, parent:parent, autoRun:json[1] || json[0]});
                } else {
                    if (json.id) {
                        lang.mixin(json, {properties:json});
                        searchTemplate = new SearchTemplate(json);
                    } else {
                        lang.mixin(json, {id:json.template_name, name:json.template_label, description:json.template_desc});
                        searchTemplate = new SearchTemplate(json);
                    }
                }
            }
            return searchTemplate;
        };
        ContentItem.registerFactory(SearchTemplate);
        return SearchTemplate;
    });
}, "ecm/model/ContentClass":function () {
    define(["dojo/_base/declare", "dojo/_base/array", "dojo/_base/lang", "./_ModelObject", "./_HasAttributesMixin"], function (declare, array, lang, _ModelObject, _HasAttributesMixin) {
        var ContentClass = declare("ecm.model.ContentClass", [_ModelObject, _HasAttributesMixin], {repository:null, attributeDefinitions:null, attributeDefinitionsById:null, pseudoClass:false, allowsInstances:true, objectStore:null, classification:null, storesContent:true, versionControl:"OPTIONAL", subClasses:null, allAttributeDefinitions:null, textSearchable:false, itemTypeSecurity:false, hierarchical:false, forFoldersOnly:false, notForFolders:false, teamspaceDefault:false, nameAttribute:null, _retrieveAttributeDefinitionsCompleted:function (response, callback) {
            if (response.template_label) {
                this.name = response.template_label;
            }
            lang.mixin(this, response);
            this.inherited(arguments);
            this.attributeDefinitionsById = {};
            array.forEach(this.attributeDefinitions, lang.hitch(this, function (attrDef) {
                this.attributeDefinitionsById[attrDef.id] = attrDef;
            }));
        }, _createAttributeDefinitions:function (response) {
            var attributeDefinitions = this.inherited(arguments);
            array.forEach(attributeDefinitions, function (criterion) {
                if (criterion.markingList) {
                    if (!this.markingProperties) {
                        this.markingProperties = {};
                    }
                    this.markingProperties[criterion.id] = criterion.markingList;
                }
            }, this);
            if (response.parm_securitypolicy) {
                this.securityPolicy = new ecm.model.SecurityPolicy(response.parm_securitypolicy);
            }
            if (response.parm_name_attribute) {
                this.nameAttribute = response.parm_name_attribute;
            }
            return attributeDefinitions;
        }, _retrieveAttributeDefinitionsForSearchesCompleted:function (response, callback) {
            if (response.template_label) {
                this.name = response.template_label;
            }
            this.inherited(arguments);
        }, retrieveSubClasses:function (callback, filterType) {
            if (this.repository.type != "p8" && this.repository.type != "cmis") {
                if (callback) {
                    callback([]);
                }
            } else {
                if (filterType == "editItem") {
                    filterType = null;
                } else {
                    if (this.repository.type == "p8") {
                        if (filterType != "search") {
                            filterType = null;
                        }
                    }
                }
                var subClasses;
                if (this.subClasses) {
                    if (filterType) {
                        if (this.subClasses.byFilterType) {
                            subClasses = this.subClasses.byFilterType[filterType];
                        }
                    } else {
                        subClasses = this.subClasses.all;
                    }
                }
                if (subClasses) {
                    if (callback) {
                        callback(subClasses);
                    }
                } else {
                    var self = this;
                    var request = ecm.model.Request.invokeService("getContentClasses", this.repository.type, {repositoryId:this.repository.id, objectStoreId:this.objectStore ? this.objectStore.id : "", class_name:this.id, filter_type:filterType}, function (response) {
                        self._retrieveSubClassesCompleted(response, callback, filterType);
                    });
                }
            }
            return request;
        }, _retrieveSubClassesCompleted:function (response, callback, filterType) {
            var subClasses = [];
            for (var i in response.datastore.items) {
                var templateJSON = response.datastore.items[i];
                var subClass = this.repository.getContentClass(templateJSON.template_name, this.objectStore);
                subClass.name = templateJSON.template_label;
                subClass.allowsInstances = templateJSON.allowsInstances;
                subClass.pseudoClass = false;
                subClasses.push(subClass);
            }
            if (!this.subClasses) {
                this.subClasses = {};
            }
            if (filterType) {
                if (!this.subClasses.byFilterType) {
                    this.subClasses.byFilterType = {};
                }
                this.subClasses.byFilterType[filterType] = subClasses;
            } else {
                this.subClasses.all = subClasses;
            }
            if (response.parentclass) {
                if (response.parentclass.name) {
                    this.name = response.parentclass.name;
                }
                if (response.parentclass.allowsInstances != undefined) {
                    this.allowsInstances = response.parentclass.allowsInstances;
                }
            }
            if (callback) {
                callback(subClasses);
            }
        }, retrieveDefaultInstancePermissions:function (callback) {
            if (this.defaultInstancePermissions) {
                if (callback) {
                    callback(this.defaultInstancePermissions);
                }
            } else {
                var request = ecm.model.Request.invokeService("getDefaultInstancePermissions", this.repository.type, {repositoryId:this.repository.id, objectStoreId:this.objectStore ? this.objectStore.id : "", class_name:this.id}, lang.hitch(this, function (response) {
                    this.defaultInstancePermissions = ecm.model.Permission.createFromJSON(response.acl);
                    if (callback) {
                        callback(this.defaultInstancePermissions);
                    }
                }));
            }
            return request;
        }});
        ContentClass.CLASSIFICATION = {ITEM:"ITEM", RESOURCE:"RESOURCE", DOCUMENT:"DOCUMENT"};
        ContentClass.VERSION_CONTROL = {NEVER:"NEVER", ALWAYS:"ALWAYS", OPTIONAL:"OPTIONAL"};
        return ContentClass;
    });
}, "ecm/model/_AttributeMixin":function () {
    define("ecm/model/_AttributeMixin", ["dojo/_base/declare", "dojo/_base/lang", "../LoggerMixin", "../MessagesMixin"], function (declare, lang, LoggerMixin, MessagesMixin) {
        return declare("ecm.model._AttributeMixin", [LoggerMixin, MessagesMixin], {getAllowedValuesSelectOptions:function () {
            var selectOptions = [];
            for (var i in this.allowedValues) {
                var allowedValue = this.allowedValues[i];
                var selectOption = {value:allowedValue, label:allowedValue};
                if (allowedValue == this.defaultValue) {
                    selectOption.selected = true;
                }
                selectOptions.push(selectOption);
            }
            if ((!this.allowedValues || this.allowedValues.length == 0) && this.dataType == "xs:boolean") {
                selectOptions.push({value:true, label:ecm.messages.true_label});
                selectOptions.push({value:false, label:ecm.messages.false_label});
            }
            return selectOptions;
        }, isChoiceListNested:function () {
            if (this.markingList) {
                return false;
            }
            var nested = false;
            if (this.choiceList) {
                for (var i in this.choiceList.choices) {
                    nested = this.choiceList.choices[i].choices ? true : false;
                    if (nested) {
                        break;
                    }
                }
            }
            return nested;
        }, getChoiceList:function (onlyValid) {
            var choiceList = null;
            if (this.markingList) {
                if (onlyValid) {
                    if (!this.validChoiceList) {
                        this.validChoiceList = this._buildValidChoiceListFromMarkingList(this.markingList, onlyValid);
                    }
                    choiceList = this.validChoiceList;
                } else {
                    choiceList = {displayName:this.markingList.displayName, choices:this.markingList.choices};
                }
            } else {
                if (onlyValid) {
                    if (!this.validChoiceList) {
                        this.validChoiceList = this._buildValidChoiceList(this.choiceList);
                    }
                    choiceList = this.validChoiceList;
                } else {
                    choiceList = this.choiceList;
                }
            }
            return choiceList;
        }, _buildValidChoiceListFromMarkingList:function (markingList) {
            if (!markingList) {
                return markingList;
            }
            var choiceList = {displayName:markingList.displayName, markings:markingList.markings, choices:[]};
            for (var i in markingList.choices) {
                var choice = markingList.choices[i];
                if (markingList.markings[choice.value].canAdd) {
                    choiceList.choices.push(choice);
                } else {
                    if (markingList.markings[choice.value].canRemove) {
                        if (!choiceList.canRemoves) {
                            choiceList.canRemoves = {};
                        }
                        choiceList.canRemoves[choice.value] = choice;
                    }
                }
            }
            return choiceList;
        }, _buildValidChoiceList:function (choiceList) {
            if (!choiceList) {
                return choiceList;
            }
            var validChoiceList = {displayName:choiceList.displayName, choices:[]};
            for (var i in choiceList.choices) {
                var choice = choiceList.choices[i];
                if (choice.valid != false) {
                    if (choice.choices) {
                        validChoiceList.choices.push(this._buildValidChoiceList(choice));
                    } else {
                        validChoiceList.choices.push(choice);
                    }
                }
            }
            return validChoiceList;
        }});
    });
}, "dojo/DeferredList":function () {
    define("dojo/DeferredList", ["./_base/kernel", "./_base/Deferred", "./_base/array"], function (dojo, Deferred, darray) {
        dojo.DeferredList = function (list, fireOnOneCallback, fireOnOneErrback, consumeErrors, canceller) {
            var resultList = [];
            Deferred.call(this);
            var self = this;
            if (list.length === 0 && !fireOnOneCallback) {
                this.resolve([0, []]);
            }
            var finished = 0;
            darray.forEach(list, function (item, i) {
                item.then(function (result) {
                    if (fireOnOneCallback) {
                        self.resolve([i, result]);
                    } else {
                        addResult(true, result);
                    }
                }, function (error) {
                    if (fireOnOneErrback) {
                        self.reject(error);
                    } else {
                        addResult(false, error);
                    }
                    if (consumeErrors) {
                        return null;
                    }
                    throw error;
                });
                function addResult(succeeded, result) {
                    resultList[i] = [succeeded, result];
                    finished++;
                    if (finished === list.length) {
                        self.resolve(resultList);
                    }
                }
            });
        };
        dojo.DeferredList.prototype = new Deferred();
        dojo.DeferredList.prototype.gatherResults = function (deferredList) {
            var d = new dojo.DeferredList(deferredList, false, true, false);
            d.addCallback(function (results) {
                var ret = [];
                darray.forEach(results, function (result) {
                    ret.push(result[1]);
                });
                return ret;
            });
            return d;
        };
        return dojo.DeferredList;
    });
}, "ecm/model/ContentItem":function () {
    define("ecm/model/ContentItem", ["dojo/_base/declare", "dojo/_base/connect", "dojo/_base/lang", "dojo/_base/array", "dojo/date/stamp", "./Item", "./ChildComponent"], function (declare, connect, lang, dojo_array, dojo_stamp, Item, ChildComponent) {
        var ContentItem = declare("ecm.model.ContentItem", [Item], {vsId:null, objectStore:null, permissions:null, rootFolder:false, currentVersion:false, declaredAsRecord:false, showCheckoutForReservation:false, originalId:null, hasHold:false, constructor:function () {
            this.rootFolder = this.rootfolder;
            delete this.rootfolder;
        }, getObjectStore:function () {
            if (!this.objectStore) {
                this.objectStore = this.objectStoreId ? {id:this.objectStoreId, symbolicName:this.objectStoreName, displayName:this.objectStoreDisplayName, capabilityComment:this.capabilityComment} : null;
            }
            return this.objectStore;
        }, getContentClass:function () {
            if (!this.template) {
                return null;
            }
            var cls = this.repository.getContentClass(this.template, this.objectStore);
            if (this.template_label) {
                cls.name = this.template_label;
            }
            return cls;
        }, hasContent:function () {
            return !this.isFolder() && !ecm.model.ContentItem.NoContentMimeTypes[this.mimetype];
        }, isViewable:function () {
            return !this.isFolder() && !ecm.model.ContentItem.NotViewableMimeClasses[this.getMimeClass()];
        }, isSystemItem:function () {
            var systemItem = ecm.model.ContentItem.SystemItemMimeTypes[this.mimetype];
            return systemItem ? systemItem : this.isInstanceOf && this.isInstanceOf(ecm.model._SearchTemplateBase);
        }, isAttributeHidden:function (attributeId) {
            return false;
        }, isChildComponentHidden:function (childComponentId) {
            return false;
        }, retrieveAttributes:function (callback, backgroundRequest) {
            var self = this;
            var templateName;
            if (!self.template && self.id) {
                self.template = self.id.split(",", 1)[0];
            }
            var params = {desktop:ecm.model.desktop.id, repositoryId:this.repository.id, docid:self.id, alt_output:"JSON", template_name:self.template};
            if (this.repository._isP8()) {
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
            }
            var request;
            if (this._retrieveAttributesCallbacks) {
                this._retrieveAttributesCallbacks.push(callback || null);
            } else {
                this._retrieveAttributesCallbacks = [(callback || null)];
                request = ecm.model.Request.invokeService("openItem", this.repository.type, params, function (response) {
                    self._retrieveAttributesCompleted(response);
                }, false, false, lang.hitch(this, function () {
                    delete this._retrieveAttributesCallbacks;
                }), (backgroundRequest || (backgroundRequest == null)));
            }
            return request;
        }, _retrieveAttributesCompleted:function (response) {
            var retrieveAttributesCallbacks = this._retrieveAttributesCallbacks;
            delete this._retrieveAttributesCallbacks;
            for (var prop in response) {
                if (response.hasOwnProperty(prop) && prop != "criterias" && prop != "systemProperties") {
                    this[prop] = response[prop];
                }
            }
            for (var i in response.criterias) {
                var attribute = response.criterias[i];
                var attributeId = attribute.name;
                this.attributes[attributeId] = attribute.values;
                if (attribute.label || attribute.label == "") {
                    this.attributeLabels[attributeId] = attribute.label;
                }
                if (attribute.dataType || attribute.dataType == "") {
                    this.attributeTypes[attributeId] = attribute.dataType;
                }
                if (attribute.format || attribute.format == "") {
                    this.attributeFormats[attributeId] = attribute.format;
                }
                if (attribute.displayValue || attribute.displayValue == "") {
                    this.attributeDisplayValues[attributeId] = attribute.displayValue;
                }
                this.attributeReadOnly[attributeId] = (attribute.readOnly === true) ? true : false;
                if (attribute.objectValues) {
                    this.attributeItems[attributeId] = ecm.model.ContentItem.createFromJSON(attribute.objectValues[0], this.repository, null);
                }
            }
            if (this.attributes && this.attributes.hasOwnProperty("{NAME}")) {
                this.name = this.attributes["{NAME}"];
            }
            for (var i in response.systemProperties) {
                var attribute = response.systemProperties[i];
                var attributeId = attribute.name;
                this.attributeLabels[attributeId] = attribute.label;
                this.attributes[attributeId] = attribute.values;
                if (attribute.label || attribute.label == "") {
                    this.attributeLabels[attributeId] = attribute.label;
                }
                if (attribute.dataType || attribute.dataType == "") {
                    this.attributeTypes[attributeId] = attribute.dataType;
                }
                if (attribute.format || attribute.format == "") {
                    this.attributeFormats[attributeId] = attribute.format;
                }
                if (attribute.displayValue || attribute.displayValue == "") {
                    this.attributeDisplayValues[attributeId] = attribute.displayValue;
                }
                this.attributeSystemProperty[attributeId] = "true";
                if (attribute.objectValues) {
                    this.attributeItems[attributeId] = ecm.model.ContentItem.createFromJSON(attribute.objectValues[0], this.repository, null);
                }
            }
            this._childComponents = [];
            for (var i in response.parm_childcomponents) {
                var childComponentItem = new ChildComponent(response.parm_childcomponents[i]);
                this._childComponents.push(childComponentItem);
            }
            if (response.parm_securitypolicy) {
                this._securityPolicy = new ecm.model.SecurityPolicy(response.parm_securitypolicy);
            }
            if (response.filename) {
                this.filename = response.filename;
            }
            this.template_label = response.template_label;
            try {
                this.onChange([this]);
            }
            catch (e) {
            }
            if (retrieveAttributesCallbacks) {
                var callback;
                for (var i in retrieveAttributesCallbacks) {
                    callback = retrieveAttributesCallbacks[i];
                    if (callback) {
                        callback(this);
                    }
                }
            }
        }, getChildComponent:function (id) {
            if (this._childComponents) {
                for (var i in this._childComponents) {
                    var childComponent = this._childComponents[i];
                    if (childComponent.id == id) {
                        return childComponent;
                    }
                }
            }
            return null;
        }, retrieveChildComponent:function (childName, callback) {
            var self = this;
            var params = {desktop:ecm.model.desktop.id, repositoryId:this.repository.id, docid:self.id, child_name:childName, template_name:self.template};
            if (this.repository._isP8()) {
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
            }
            ecm.model.Request.invokeService("getChildComp", this.repository.type, params, function (response) {
                self._retrieveChildComponentCompleted(response, callback);
            }, null, null, null, false);
        }, _retrieveChildComponentCompleted:function (response, callback) {
            var childComponentItem = null;
            if (response.parm_childcomponents && response.parm_childcomponents.length > 0) {
                childComponentItem = new ChildComponent(response.parm_childcomponents[0]);
            }
            if (callback) {
                callback(childComponentItem);
            }
        }, removeFromFolder:function (items, folderRemoveCallback) {
            var itemIds = [];
            if (items instanceof String) {
                itemIds.push(items);
            } else {
                if (lang.isArray(items)) {
                    for (var i in items) {
                        var item = items[i];
                        if (item instanceof String) {
                            itemIds.push(item);
                        } else {
                            itemIds.push(item.id);
                        }
                    }
                } else {
                    itemIds.push(items.id);
                }
            }
            var params = {repositoryId:this.repository.id, docid:itemIds, folderDocid:this.id, template_name:this.template};
            if (this.repository._isP8()) {
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
            }
            var request = ecm.model.Request.invokeService("removeFromFolder", this.repository.type, params, lang.hitch(this, function (response) {
                this._removeFromFolderCompleted(response, folderRemoveCallback);
            }));
            return request;
        }, _removeFromFolderCompleted:function (response, folderRemoveCallback) {
            if (folderRemoveCallback) {
                folderRemoveCallback();
            }
            this.refresh(this);
        }, addToFolder:function (items, folderAddCallback) {
            var itemIds = [];
            if (items instanceof String) {
                itemIds.push(items);
            } else {
                if (lang.isArray(items)) {
                    for (var i in items) {
                        var item = items[i];
                        if (item instanceof String) {
                            itemIds.push(item);
                        } else {
                            itemIds.push(item.id);
                        }
                    }
                } else {
                    itemIds.push(items.id);
                }
            }
            var params = {repositoryId:this.repository.id, docid:itemIds, folderDocid:this.id, template_name:this.template};
            if (this.repository._isP8()) {
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
            }
            var request = ecm.model.Request.invokeService("addToFolder", this.repository.type, params, lang.hitch(this, function (response) {
                this._addToFolderCompleted(response, folderAddCallback);
            }));
            return request;
        }, _addToFolderCompleted:function (response, folderAddCallback) {
            if (folderAddCallback) {
                folderAddCallback();
            }
            this.refresh(this);
        }, moveToFolder:function (items, oldFolder, moveCallback) {
            if (this.id != oldFolder.id) {
                var itemIds = [];
                if (items instanceof String) {
                    itemIds.push(items);
                } else {
                    if (lang.isArray(items)) {
                        for (var i in items) {
                            var item = items[i];
                            if (item instanceof String) {
                                itemIds.push(item);
                            } else {
                                itemIds.push(item.id);
                            }
                        }
                    } else {
                        itemIds.push(items.id);
                    }
                }
                var params = {repositoryId:this.repository.id, docid:itemIds, folderDocid:oldFolder.id, newFolderDocid:this.id, template_name:this.template};
                if (this.repository._isP8()) {
                    params.objectStoreId = this.objectStore ? this.objectStore.id : "";
                }
                var request = ecm.model.Request.invokeService("moveToFolder", this.repository.type, params, lang.hitch(this, function (response) {
                    this._moveToFolderCompleted(response, oldFolder, moveCallback);
                }));
            }
            return request;
        }, _moveToFolderCompleted:function (response, oldFolder, moveCallback) {
            if (moveCallback) {
                moveCallback();
            }
            this.refresh(this);
            oldFolder.refresh(oldFolder);
        }, isFolderContentsRetrieved:function (filterType) {
            return this._folderContents && this._folderContents[filterType || ""];
        }, deleteItemFromFolderContentCache:function (item, filterType) {
            if (this._folderContents) {
                var resultSet = this._folderContents[filterType || ""];
                if (resultSet) {
                    resultSet.deleteItem(item);
                }
            }
        }, refresh:function () {
            this._folderContents = null;
            this.onChange(this);
        }, unloadFolderContents:function () {
            this._folderContents = null;
        }, retrieveFolderContents:function (foldersOnly, callback, orderBy, descending, noCache, teamspaceId, filterType, parent) {
            if (!filterType) {
                filterType = foldersOnly ? "folderSearch" : "";
            }
            if (teamspaceId) {
                this._teamspaceId = teamspaceId;
            }
            if (!this._folderContents) {
                this._folderContents = new Object();
            }
            if (!noCache && this._folderContents[filterType]) {
                callback(this._folderContents[filterType]);
            } else {
                var params = {repositoryId:this.repository.id, docid:this.id, workspaceId:this._teamspaceId, filter_type:filterType, name:this.name};
                if (this.repository._isP8()) {
                    params.objectStoreId = this.objectStore ? this.objectStore.id : "";
                }
                if (orderBy) {
                    params.order_by = orderBy;
                    if (descending) {
                        params.order_descending = "true";
                    }
                }
                var handler = lang.hitch(this, function (response) {
                    this._retrieveFolderCompleted(response, filterType, noCache, teamspaceId, parent, callback);
                });
                var type = this.repository.type;
                var request = ecm.model.Request.invokeService("openFolder", type, params, handler);
            }
            return request;
        }, _retrieveFolderCompleted:function (response, filterType, noCache, teamspaceId, parent, callback) {
            var parentItem = parent ? parent : this;
            response.repository = this.repository;
            response.parentFolder = parentItem;
            response.teamspaceId = teamspaceId;
            var resultSet = ContentItem.createResultSet(response);
            if (!noCache && this._folderContents) {
                this._folderContents[filterType] = resultSet;
            }
            callback(resultSet);
        }, saveAttributes:function (attributes, newTemplateName, childComponentValues, permissions, checkIn, callback, isBackgroundRequest, onError) {
            if (this._savingAttributes) {
                return;
            }
            this._savingAttributes = true;
            var data = attributes;
            if (this.repository.type == "cm") {
                data = [{criterias:attributes, childComponentValues:childComponentValues, acl:permissions}];
            } else {
                if (this.repository.type == "p8" || this.repository._isCmis()) {
                    data = [{criterias:attributes, acl:permissions}];
                }
            }
            var params = {repositoryId:this.repository.id, docid:this.id, desktop:ecm.model.desktop.id, childComponentValues:JSON.stringify([]), criterias:"", new_template_name:newTemplateName ? newTemplateName : this.template, template_name:this.template};
            if (checkIn) {
                params.parm_checkIn = true;
            }
            if (this.repository._isP8()) {
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
            }
            var request;
            var onSaveAttributesRequestCompletedConnect = connect.connect(ecm.model.desktop, "onRequestCompleted", lang.hitch(this, function (completedRequest) {
                if (!request || !request.isSameRequestAs(completedRequest)) {
                    return;
                }
                delete this._savingAttributes;
                connect.disconnect(onSaveAttributesRequestCompletedConnect);
            }));
            request = ecm.model.Request.postService("editAttributes", this.repository.type, params, "text/json", JSON.stringify(data), lang.hitch(this, function (response) {
                if (response.messages) {
                    for (var i in response.messages) {
                        var message = response.messages[i];
                        if (message.number = 1156) {
                            this.deleted = true;
                            this.repository.onChange([this]);
                        }
                    }
                }
                this._saveAttributesCompleted(response, newTemplateName && newTemplateName != this.template ? true : false, callback);
            }), false, isBackgroundRequest ? isBackgroundRequest : false, false, onError ? onError : lang.hitch(this, function (response) {
                if (response.errors) {
                    for (var i in response.errors) {
                        var error = response.errors[i];
                        if (error.number == 1078) {
                            this.deleted = true;
                            this.repository.onChange([this]);
                        }
                    }
                }
                if (callback) {
                    callback(response);
                }
            }));
            if (!request) {
                connect.disconnect(onSaveAttributesRequestCompletedConnect);
                delete this._savingAttributes;
            }
            return request;
        }, _saveAttributesCompleted:function (response, isReindex, callback) {
            if (response.fieldErrors) {
                if (callback) {
                    callback(response);
                }
            } else {
                if (response.rows && response.rows.length > 0) {
                    var itemJSON = response.rows[0];
                    var attributes = {};
                    var attributeTypes = {};
                    var attributeFormats = {};
                    var attributeDisplayValues = {};
                    var attributeReadOnly = {};
                    var attributeItems = {};
                    for (var i in itemJSON.attributes) {
                        var jsonAttribute = itemJSON.attributes[i];
                        attributes[i] = jsonAttribute[0];
                        if (jsonAttribute.length > 1) {
                            attributeTypes[i] = jsonAttribute[1];
                        }
                        if (jsonAttribute.length > 2 && jsonAttribute[2] != null) {
                            attributeFormats[i] = jsonAttribute[2];
                        }
                        if (jsonAttribute.length > 3 && jsonAttribute[3] != null) {
                            attributeDisplayValues[i] = jsonAttribute[3];
                        }
                        attributeReadOnly[i] = (jsonAttribute.length > 4 && jsonAttribute[4] === true);
                        if (jsonAttribute.length > 5 && jsonAttribute[5] != null && jsonAttribute[5].rows) {
                            attributeItems[i] = ecm.model.ContentItem.createFromJSON(jsonAttribute[5].rows[0], this.repository, null);
                        }
                    }
                    this.originalId = this.id;
                    lang.mixin(this, itemJSON);
                    this.attributes = attributes;
                    if (isReindex || this._childComponents) {
                        this._childComponents = [];
                        this.retrieveAttributes();
                    }
                    if (response.acl) {
                        this.permissions = [];
                        this.permissions = ecm.model.Permission.createFromJSON(response.acl);
                    }
                    if (callback) {
                        callback(response);
                    }
                    this.repository.onChange([this]);
                    this.originalId = null;
                } else {
                    if (callback) {
                        callback(response);
                    }
                }
            }
        }, checkIn:function (templateName, criterias, contentSourceType, mimeType, filename, content, childComponentValues, permissions, securityPolicyId, newVersion, checkInAsMinorVersion, autoClassify, callback) {
            var formParams = {criterias:JSON.stringify(criterias), childComponentValues:JSON.stringify(childComponentValues), acl:JSON.stringify(permissions)};
            if (content) {
                if (content.type == "Base64") {
                    formParams.fileBase64 = content.content;
                } else {
                    formParams.file = content;
                }
            }
            var params = {desktop:ecm.model.desktop.id, repositoryId:this.repository.id, parm_content_source_type:contentSourceType, docid:this.id, template_name:templateName, mimetype:mimeType, parm_part_filename:filename};
            if (this.repository._isCM()) {
                params.parm_part_type = "ICMBASE";
                params.parm_create_new_version = newVersion ? "true" : "false";
            } else {
                if (this.repository._isP8()) {
                    params.securityPolicyId = securityPolicyId;
                    params.asMinorVersion = checkInAsMinorVersion ? "true" : "false";
                    params.autoClassify = autoClassify ? "true" : "false";
                    params.objectStoreId = this.objectStore ? this.objectStore.id : "";
                } else {
                    if (this.repository._isCmis()) {
                        params.asMinorVersion = checkInAsMinorVersion ? "true" : "false";
                    }
                }
            }
            var request = ecm.model.Request.postFormToServiceAPI("checkIn", this.repository.type, {requestParams:params, requestCompleteCallback:lang.hitch(this, function (response) {
                this._checkInCompleted(response, callback);
            })}, formParams);
            return request;
        }, checkInUsingForm:function (templateName, contentSourceType, filename, form, securityPolicyId, newVersion, checkInAsMinorVersion, autoClassify, callback) {
            var params = {desktop:ecm.model.desktop.id, repositoryId:this.repository.id, parm_content_source_type:contentSourceType, docid:this.id, template_name:templateName, parm_part_filename:filename};
            if (this.repository._isCM()) {
                params.parm_create_new_version = newVersion ? "true" : "false";
            } else {
                if (this.repository._isP8()) {
                    params.securityPolicyId = securityPolicyId;
                    params.asMinorVersion = checkInAsMinorVersion ? "true" : "false";
                    params.autoClassify = autoClassify ? "true" : "false";
                    params.objectStoreId = this.objectStore ? this.objectStore.id : "";
                } else {
                    if (this.repository._isCmis()) {
                        params.asMinorVersion = checkInAsMinorVersion ? "true" : "false";
                    }
                }
            }
            var request = ecm.model.Request.ieFileUploadServiceAPI("checkIn", this.repository.type, {requestParams:params, requestCompleteCallback:lang.hitch(this, function (response) {
                this._checkInCompleted(response, callback);
            })}, form);
            return request;
        }, _checkInCompleted:function (response, callback) {
            if (response.fieldErrors) {
                if (callback) {
                    callback(undefined, response.fieldErrors);
                }
            } else {
                var itemJSON = response.rows[0];
                var item = ecm.model.ContentItem.createFromJSON(itemJSON, this.repository, null);
                var originalId = this.id;
                this.update(item, true);
                var clonedItem = item.clone();
                clonedItem.originalId = originalId;
                this.onChange([clonedItem]);
                if (callback) {
                    callback(item);
                }
                if (this.repository._isCmis()) {
                    if (this.parent != null) {
                        this.parent.refresh();
                    }
                }
            }
        }, clone:function () {
            var thisClone = new ecm.model.ContentItem({id:this.id, name:this.name});
            lang.mixin(thisClone, this);
            thisClone.attributes = lang.clone(this.attributes);
            thisClone.attributeLabels = lang.clone(this.attributeLabels);
            thisClone.attributeTypes = lang.clone(this.attributeTypes);
            thisClone.attributeFormats = lang.clone(this.attributeFormats);
            thisClone.attributeDisplayValues = lang.clone(this.attributeDisplayValues);
            thisClone.attributeReadOnly = lang.clone(this.attributeReadOnly);
            thisClone.attributeItems = lang.clone(this.attributeItems);
            return thisClone;
        }, update:function (item, skipOnChange) {
            if (!this.repository || !item.repository || (this.repository.id != item.repository.id)) {
                return;
            }
            if (this.repository._isP8()) {
                if (!this || !item || (this.vsId != item.vsId)) {
                    return;
                }
            }
            var prop;
            for (prop in item) {
                if ((typeof item[prop] !== "function") && (prop != "declaredClass") && (prop != "resultSet") && (prop != "parent") && (prop != "repository")) {
                    this[prop] = item[prop];
                }
            }
            if (this.originalId == null && item.origdocid != null) {
                this.originalId = item.origdocid;
            }
            if (!skipOnChange) {
                this.onChange([this]);
            }
        }, onChange:function (item) {
            if (this.resultSet) {
                this.resultSet.onChange(item);
                if (this.resultSet.context == "PropertiesVersions") {
                    return;
                }
            }
            this.repository.onChange(item);
        }, hasPrivilege:function (privilege) {
            return this.inherited(arguments);
        }, retrievePermissions:function (callback) {
            if (this.permissions) {
                if (callback) {
                    callback(this.permissions);
                }
            } else {
                var params = {repositoryId:this.repository.id, docid:this.id};
                if (this.repository._isP8()) {
                    params.objectStoreId = this.objectStore ? this.objectStore.id : "";
                }
                var request = ecm.model.Request.invokeService("getPermissions", this.repository.type, params, lang.hitch(this, function (response) {
                    this.permissions = ecm.model.Permission.createFromJSON(response.acl);
                    if (response.modifyPermissions) {
                        this["modifyPermissions"] = response.modifyPermissions || false;
                    }
                    if (callback) {
                        callback(this.permissions);
                    }
                }));
            }
        }, retrieveFoldersFiledIn:function (callback) {
            var self = this;
            var params = {repositoryId:this.repository.id, docid:this.id};
            if (this.repository._isP8()) {
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
            }
            var request = ecm.model.Request.invokeService("getFoldersFiledIn", this.repository.type, params, lang.hitch(this, function (response) {
                response.repository = self.repository;
                response.parentFolder = this;
                var results = ContentItem.createResultSet(response);
                if (callback) {
                    callback(results.getItems(), results.structure.cells[0]);
                }
            }));
        }, promoteVersion:function () {
            var params = {repositoryId:this.repository.id, docid:this.id};
            if (this.repository._isP8()) {
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
            }
            var request = ecm.model.Request.invokeService("promoteVersion", this.repository.type, params, lang.hitch(this, lang.hitch(this, function (response) {
                this._promoteVersionCompleted(response);
            })));
        }, _promoteVersionCompleted:function (response) {
            if (!response.fieldErrors) {
                var itemsJSON = response.rows;
                var promotedItem = ecm.model.ContentItem.createFromJSON(itemsJSON[0], this.repository, null);
                this.update(promotedItem);
                if (itemsJSON.length > 1) {
                    var oldReleasedVersion = ecm.model.ContentItem.createFromJSON(itemsJSON[1], this.repository, null);
                    promotedItem._updateReleasedOnly = true;
                    promotedItem.originalId = oldReleasedVersion.id;
                    this.repository.onChange([promotedItem]);
                    promotedItem._updateReleasedOnly = null;
                }
            }
        }, demoteVersion:function () {
            var params = {repositoryId:this.repository.id, docid:this.id};
            if (this.repository._isP8()) {
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
            }
            var request = ecm.model.Request.invokeService("demoteVersion", this.repository.type, params, lang.hitch(this, lang.hitch(this, function (response) {
                this._demoteVersionCompleted(response);
            })));
        }, _demoteVersionCompleted:function (response) {
            if (!response.fieldErrors) {
                var itemsJSON = response.rows;
                var demotedItem = ecm.model.ContentItem.createFromJSON(itemsJSON[0], this.repository, null);
                this.update(demotedItem);
                if (itemsJSON.length > 1) {
                    var newReleasedVersion = ecm.model.ContentItem.createFromJSON(itemsJSON[1], this.repository, null);
                    newReleasedVersion._updateReleasedOnly = true;
                    newReleasedVersion.originalId = this.id;
                    this.repository.onChange([newReleasedVersion]);
                }
            }
        }, getContentUrl:function () {
            var servicesUrl = ecm.model.desktop.servicesUrl;
            var docId = this.id;
            var docName = this.name;
            var template = this.getContentClass().id;
            var repositoryId = this.repository.id;
            var mimeType = this.mimetype || "";
            var serverType = this.repository.type;
            var vsId = this.vsId;
            var replicationGroup = this.replicationGroup;
            var docUrl = servicesUrl + "/" + serverType + "/getDocument.do?docid=" + encodeURIComponent(docId) + "&template_name=" + encodeURIComponent(template) + "&repositoryId=" + encodeURIComponent(repositoryId);
            if (vsId) {
                docUrl = docUrl + "&vsId=" + encodeURIComponent(vsId);
            }
            if (replicationGroup) {
                docUrl = docUrl + "&replicationGroup=" + replicationGroup;
            }
            docUrl = ecm.model.Request.setSecurityToken(docUrl);
            return docUrl;
        }, getPageImageUrl:function (pageNo, scale, rotation, inverted, brightness, contrast, displayableWidth, displayableHeight) {
            if (!this.hasContent()) {
                return "";
            }
            var servicesUrl = ecm.model.desktop.servicesUrl;
            var pageImageUrl = servicesUrl + "/getPageImage.do?docUrl=" + encodeURIComponent(this.getContentUrl()) + "&contentType=" + (this.mimetype || "") + "&serverType=" + this.repository.type + "&pageNo=" + pageNo;
            if (scale) {
                pageImageUrl += "&scale=" + scale;
            }
            if (rotation) {
                pageImageUrl += "&rotation=" + rotation;
            }
            if (inverted) {
                pageImageUrl += "&inverted=" + inverted;
            }
            if (brightness) {
                pageImageUrl += "&brightness=" + brightness;
            }
            if (contrast) {
                pageImageUrl += "&contrast=" + contrast;
            }
            if (displayableWidth) {
                pageImageUrl += "&displayableWidth=" + displayableWidth;
            }
            if (displayableHeight) {
                pageImageUrl += "&displayableHeight=" + displayableHeight;
            }
            var modifyDate = this.getModifyDate();
            if (modifyDate && modifyDate.length > 0) {
                var date = dojo_stamp.fromISOString(modifyDate);
                pageImageUrl += "&lastModified=" + date.valueOf();
            }
            pageImageUrl = ecm.model.Request.setSecurityToken(pageImageUrl);
            return pageImageUrl;
        }, getPageImageRequestParameters:function (pageNo, scale, rotation, inverted, brightness, contrast, displayableWidth, displayableHeight) {
            if (!this.hasContent()) {
                return "";
            }
            var params = {};
            params.serverType = this.repository.type;
            params.docUrl = this.getContentUrl();
            if (pageNo) {
                params.pageNo = pageNo;
            }
            if (scale) {
                params.scale = scale;
            }
            if (rotation) {
                params.rotation = rotation;
            }
            if (inverted) {
                params.inverted = inverted;
            }
            if (brightness) {
                params.brightness = brightness;
            }
            if (contrast) {
                params.contrast = contrast;
            }
            if (displayableWidth) {
                params.displayableWidth = displayableWidth;
            }
            if (displayableHeight) {
                params.displayableHeight = displayableHeight;
            }
            var modifyDate = this.getModifyDate();
            if (modifyDate && modifyDate.length > 0) {
                var date = dojo_stamp.fromISOString(modifyDate);
                params.lastModified = date.valueOf();
            }
            return params;
        }, retrieveVersion:function (version, callback) {
            var _this = this;
            if (!version || version.length == 0) {
                callback(null);
            } else {
                version = version.toLowerCase();
                if (this.repository._isCM()) {
                    if ((version == "released") || (version == "reservation")) {
                        version = "current";
                    }
                }
                var params = {repositoryId:this.repository.id, requestedVersion:version, docid:this.id};
                if (this.repository._isP8()) {
                    params.objectStoreId = this.objectStore ? this.objectStore.id : "";
                }
                ecm.model.Request.invokeService("getDocumentVersions", this.repository.type, params, function (response) {
                    var docItem = null;
                    if (response.rows && response.rows[0]) {
                        docItem = ecm.model.ContentItem.createFromJSON(response.rows[0], _this.repository, null, null);
                    }
                    callback(docItem);
                }, true);
            }
        }, retrieveAllVersions:function (callback) {
            if (this.repository) {
                this.repository.retrieveVersions(this, null, callback);
            }
        }, retrieveTeamspace:function (callback) {
            if (this._teamspace || this._teamspace === null) {
                callback(this._teamspace);
            } else {
                this._teamspace = null;
                if (this.repository._isP8() && this.repository.teamspacesEnabled) {
                    var path = this.getValue("PathName");
                    if (path && path.indexOf("/ClbTeamspaces/") == 0) {
                        var teamspacepath = null;
                        var indx = path.indexOf("/", 15);
                        if (indx > 0) {
                            teamspacepath = path.substring(0, indx);
                        } else {
                            teamspacepath = path;
                        }
                        var self = this;
                        if (teamspacepath) {
                            this.repository.retrieveTeamspaceById(teamspacepath, ecm.model.Teamspace.INSTANCE, function (teamspace) {
                                teamspace.initFromJson();
                                self._teamspace = teamspace;
                                callback(teamspace);
                            });
                            return;
                        }
                    }
                } else {
                    if (this.repository._isCM() && this.repository.teamspacesEnabled) {
                        this._retrieveCMTeamspace(callback);
                        return;
                    }
                }
                callback(null);
            }
        }, _retrieveCMTeamspace:function (callback) {
            var self = this;
            var params = {repositoryId:this.repository.id, id:this.id};
            var request = ecm.model.Request.invokeService("retrieveItemTeamspace", this.repository.type, params, lang.hitch(this, function (response) {
                if (response.workspaces.length > 0) {
                    var json = response.workspaces[0];
                    json.repository = this.repository;
                    var teamspace = ecm.model.Teamspace(json);
                    teamspace.initFromJson();
                    self._teamspace = teamspace;
                    callback(teamspace);
                } else {
                    callback(null);
                }
            }));
        }, getMarkingValues:function (properties) {
            var markingValues = [];
            var contentClass = this.getContentClass();
            var markingProperties = contentClass.markingProperties;
            if (markingProperties) {
                var attributes;
                if (properties) {
                    attributes = lang.clone(this.attributes);
                    dojo_array.forEach(properties, function (property) {
                        if (markingProperties[property.name]) {
                            attributes[property.name] = property.value;
                        }
                    });
                } else {
                    attributes = this.attributes;
                }
                for (i in attributes) {
                    var markings = markingProperties[i];
                    if (markings) {
                        var value = attributes[i] instanceof Array ? attributes[i].join() : attributes[i];
                        if (value.length > 0) {
                            markingValues.push(attributes[i]);
                        }
                    }
                }
            }
            return markingValues;
        }, isCommentable:function () {
            var os = this.getObjectStore();
            var repo = os ? os : this.repository;
            if (!repo.capabilityComment || repo.capabilityComment == this.repository.CAPABILITY_COMMENT.NONE) {
                return false;
            }
            if (this.repository.capabilityComment == this.repository.CAPABILITY_COMMENT.DOCUMENT_ONLY && this.isFolder()) {
                return false;
            }
            if (!this.hasPrivilege("privViewDoc")) {
                return false;
            }
            return true;
        }, isNotelogable:function () {
            if (!this.repository._isCM()) {
                return false;
            }
            if (!this.hasPrivilege("privViewNotes")) {
                return false;
            }
            return true;
        }, retrieveComments:function (callback, errorback) {
            var methodName = "retrieveComments";
            if (!this.isCommentable()) {
                return;
            }
            var params = {repositoryId:this.repository.id, itemId:this.id};
            var request = ecm.model.Request.invokeService("retrieveComments", this.repository.type, params, lang.hitch(this, function (response) {
                response.repository = this.repository;
                response.contentItem = this;
                var resultSet = ContentItem.createResultSet(response);
                if (lang.isFunction(callback)) {
                    callback(resultSet);
                }
            }), false, false, function (response) {
                if (lang.isFunction(errorback)) {
                    errorback(response);
                }
            });
            return request;
        }, retrieveNotelogs:function (callback, errorback) {
            var methodName = "retrieveNotelogs";
            if (!this.isNotelogable()) {
                return;
            }
            var params = {repositoryId:this.repository.id, docid:this.id};
            var request = ecm.model.Request.invokeService("getNotes", this.repository.type, params, function (response) {
                if (callback) {
                    response.repository = this.repository;
                    response.contentItem = this;
                    response.setType = "comment";
                    var resultSet = ContentItem.createResultSet(response);
                    callback(resultSet);
                }
            }, false, false, function (response) {
                if (errorback) {
                    errorback(response);
                }
            });
            return request;
        }, addNotelog:function (content, createVersion, callback, errorback) {
            var methodName = "addNotelog";
            if (!this.isNotelogable()) {
                return;
            }
            var params = {repositoryId:this.repository.id, docid:this.id, text:content, parm_create_new_version:createVersion};
            var request = ecm.model.Request.invokeService("addNote", this.repository.type, params, function (response) {
                if (callback) {
                    response.repository = this.repository;
                    response.contentItem = this;
                    response.setType = "comment";
                    var resultSet = ContentItem.createResultSet(response);
                    callback(resultSet);
                }
            }, false, false, function (response) {
                if (errorback) {
                    errorback(response);
                }
            });
            return request;
        }, updateNotelogs:function (content, createVersion, callback, errorback) {
            var methodName = "updateNotelogs";
            if (!this.isNotelogable()) {
                return;
            }
            var params = {repositoryId:this.repository.id, docid:this.id, text:content, parm_create_new_version:createVersion};
            var request = ecm.model.Request.invokeService("updateNotelogs", this.repository.type, params, function (response) {
                if (callback) {
                    response.repository = this.repository;
                    response.contentItem = this;
                    response.setType = "comment";
                    var resultSet = ContentItem.createResultSet(response);
                    callback(resultSet);
                }
            }, false, false, function (response) {
                if (errorback) {
                    errorback(response);
                }
            });
            return request;
        }, retrieveDownloadRecords:function (callback) {
            var methodName = "retrieveDownloadRecords";
            var params = {repositoryId:this.repository.id, itemId:this.id};
            var request = ecm.model.Request.invokeService("retrieveDownloadRecords", this.repository.type, params, function (response) {
                if (callback) {
                    callback(response);
                }
            });
            return request;
        }});
        ContentItem.registerFactory = function (factory) {
            if (!ContentItem._factories) {
                ContentItem._factories = [];
            }
            ContentItem._factories.push(factory);
        };
        ContentItem.createFromJSON = function (itemJSON, repository, resultSet, parent) {
            var item = null;
            ContentItem._factories && dojo_array.some(ContentItem._factories, function (factory) {
                if (factory && factory.createFromJSON) {
                    item = factory.createFromJSON(itemJSON, repository, resultSet, parent);
                }
                return !!item;
            });
            if (!item) {
                item = new ContentItem(itemJSON);
            }
            var attributes = {};
            var attributeTypes = {};
            var attributeFormats = {};
            var attributeDisplayValues = {};
            var attributeReadOnly = {};
            var attributeItems = {};
            for (var i in itemJSON.attributes) {
                var attr = itemJSON.attributes[i];
                attributes[i] = attr[0];
                if (attr.length > 1) {
                    attributeTypes[i] = attr[1];
                }
                if (attr.length > 2 && attr[2] != null) {
                    attributeFormats[i] = attr[2];
                }
                if (attr.length > 3 && attr[3] != null) {
                    attributeDisplayValues[i] = attr[3];
                }
                attributeReadOnly[i] = (attr.length > 4 && attr[4] === true);
                if (attr.length > 5 && attr[5] != null && attr[5].rows) {
                    attributeItems[i] = ecm.model.ContentItem.createFromJSON(attr[5].rows[0], this.repository, null);
                }
            }
            lang.mixin(item, {repository:repository, resultSet:resultSet, parent:parent, attributes:attributes, attributeTypes:attributeTypes, attributeFormats:attributeFormats, attributeDisplayValues:attributeDisplayValues, attributeReadOnly:attributeReadOnly, attributeItems:attributeItems});
            return item;
        };
        ContentItem.P8_VERSION_STATUS = {RELEASED:"1", IN_PROCESS:"2", RESERVED:"3", SUPERSEDED:"4"};
        ContentItem.NoContentMimeTypes = {"":true, "folder":true, "item":true, "application/x-filenet-external":true};
        ContentItem.NotViewableMimeClasses = {"ftNoContent":true, "ftExternalFile":true, "ftDocumentEntryTemplate":true, "ftFolderEntryTemplate":true, "ftEntryTemplate":true, "ftCustomObjectEntryTemplate":true, "ftFormTemplate":true, "ftFormData":true, "ftDeclareRecordEntryTemplate":true, "ftWorkflow":true, "ftPolicyDocument":true, "ftPolicyWorkflow":true, "ftSearchTemplate":true, "ftSearchStored":true, "ftUnifiedSearch":true};
        ContentItem.SystemItemMimeTypes = {"application/x-filenet-searchtemplate":true, "application/x-filenet-entrytemplate":true, "application/x-filenet-formdataentrytemplate":true, "application/x-filenet-customobjectentrytemplate":true, "application/x-filenet-documententrytemplate":true, "application/x-filenet-folderentrytemplate":true, "application/x-filenet-declarerecordentrytemplate":true, "application/x-filenet-search":true, "application/x-filenet-workflowpolicy":true};
        return ContentItem;
    });
}, "ecm/model/admin/RepositoryReadConfig":function () {
    define("ecm/model/admin/RepositoryReadConfig", ["dojo/_base/declare", "dojo/_base/lang", "./_ConfigurationObject"], function (declare, lang, _ConfigurationObject) {
        var RepositoryReadConfig = declare("ecm.model.admin.RepositoryReadConfig", [_ConfigurationObject], {MAX_IN_MEMORY_RETRIEVE_SIZE:"maxInMemoryRetrieveSize", MAX_DOWNLOAD_SIZE:"maxDownloadSize", TIMESTAMP_FORMAT:"timestampFormat", TIME_FORMAT:"timeFormat", DATE_FORMAT:"dateFormat", TEAMSPACES_ENABLED:"teamspacesEnabled", SERVER_NAME:"serverName", TYPE:"type", NAME:"name", DOCUMENT_SYSTEM_PROPERTIES:"documentSystemProperties", FOLDER_SYSTEM_PROPERTIES:"folderSystemProperties", UNIFIED_SEARCHES_ENABLED:"unifiedSearchesEnabled", SEARCH_MAX_RESULTS:"searchMaxResults", TIMEOUT_IN_SECONDS:"timeoutInSeconds", FOLDER_DEF_COLS:"folderDefCols", FOLDER_MAGAZINE_DEF_COLS:"folderMagazineDefCols", SEARCH_DEF_COLS:"searchDefCols", SEARCH_MAGAZINE_DEF_COLS:"searchMagazineDefCols", DOC_NAME_PROPERTY:"docNameProp", FOLDER_NAME_PROPERTY:"folderNameProp", SEARCH_FILTERED_DOCUMENT_PROPERTIES:"searchFilteredDocumentProperties", SEARCH_FILTERED_FOLDER_PROPERTIES:"searchFilteredFolderProperties", MATCH_ALL:"matchAll", STATUS_DOC_NOTES:"statusDocNotes", STATUS_DOC_HOLD:"statusDocHold", STATUS_DOC_CHECKED_OUT:"statusDocCheckedOut", STATUS_DOC_BOOKMARKS:"statusDocBookmarks", STATUS_DOC_DECLARED_RECORD:"statusDocDeclaredRecord", STATUS_DOC_MINOR_VERSIONS:"statusDocMinorVersions", STATUS_WORK_ITEM_CHECKED_OUT:"statusWorkItemCheckedOut", STATUS_WORK_ITEM_LOCKED:"statusWorkItemLocked", STATUS_WORK_ITEM_SUSPENDED:"statusWorkItemSuspended", STATUS_WORK_ITEM_DEADLINE:"statusWorkItemDeadline", PORT_NUMBER:"portNumber", AFP2PD_CONFIG_FILE:"afp2pdfConfigFile", XFORM_XML_FILE:"transformXMLFile", OD_SSL:"odSSL", OD_KEYRING_DBFILE:"odKeyringDBFile", OD_KEYRING_STASHFILE:"odKeyringStashFile", CUSTOM_PROPS:"customProperties", MAX_FOLDERS:"maxFolders", MAX_HITS:"maxHits", FOLDER_SEARCH_EXPRESSION:"folderSearchExpression", AFP2PD_INSTALL_DIR:"afp2pdfInstallDir", LANGUAGE:"language", TEMP_DIR:"tempDir", TRACE_DIR:"traceDir", TRACE_LEVEL:"traceLevel", OBJECT_STORE:"objectStore", OBJECT_STORE_DISPLAY_NAME:"objectStoreName", ADD_AS_MAJOR_VERSION:"addAsMajorVersion", CHECKIN_AS_MAJOR_VERSION:"checkinAsMajorVersion", ANNOTATION_SECURITY:"annotationSecurity", CONNECTION_POINT:"connectionPoint", INCLUDE_WORKFLOW_DEFINITION:"includeWorkflowDefinition", PROTOCOL:"protocol", CMIS_REPOS_ID:"cmisRepositoryID", USE_GZIP_ENCODING:"useGzipEncoding", USE_SSO:"useSSO", LANGUAGE_CODES:"languageCodes", PDF_CONVERSION:"pdfConversion", FOLDERING_ENABLED:"folderingEnabled", ROOT_FOLDER_ID:"rootFolderId", DEFAULT_EMAIL_CLASS_FOR_ADD:"defaultEmailClassForAdd", DEFAULT_FOLDER_CLASS_FOR_ADD:"defaultFolderClassForAdd", DIRECT_RETRIEVE_ENABLED:"directRetrieveEnabled", MAX_RESULTS:"maxResults", MAX_ITEM_TYPES:"maxItemTypes", MAX_WORKLISTS:"maxWorklists", UPDATE_STORAGE_COLLECTION:"UpdateStorageCollection", KEEP_IN_AUTO_FOLDER:"keepInAutoFolder", INCLUDE_MIME_TYPES_IN_SEARCH_RESULTS:"includeMIMETypesInSearchResults", tempId:null, OPERATOR_DATETIME:"datetimeOp", OPERATOR_FLOAT:"floatOp", OPERATOR_INTEGER:"integerOp", OPERATOR_STRING:"stringOp", OPERATOR_BOOLEAN:"booleanOp", OPERATOR_OBJECT:"objectOp", OPERATOR_USER:"userOp", OPERATOR_ID:"idOp", _DEFAULT_CONFIG:null, connected:false, constructor:function (id, name, action) {
            if (!this._DEFAULT_CONFIG) {
                this._DEFAULT_CONFIG = {};
            }
        }, getIncludeMIMETypesInSearchResults:function () {
            return this.getValue(this.INCLUDE_MIME_TYPES_IN_SEARCH_RESULTS);
        }, getPdfConversion:function () {
            return this.getValue(this.PDF_CONVERSION);
        }, getKeepInAutoFolder:function () {
            return this.getValue(this.KEEP_IN_AUTO_FOLDER);
        }, getUpdateStorageCollection:function () {
            return this.getValue(this.UPDATE_STORAGE_COLLECTION);
        }, getMaxWorklists:function () {
            return this.getValue(this.MAX_WORKLISTS);
        }, getMaxItemTypes:function () {
            return this.getValue(this.MAX_ITEM_TYPES);
        }, getLanguageCodes:function () {
            return this.getValue(this.LANGUAGE_CODES);
        }, getRootFolderId:function () {
            return this.getValue(this.ROOT_FOLDER_ID);
        }, getMaxResults:function () {
            return this.getValue(this.MAX_RESULTS);
        }, getUseSSO:function () {
            return this.getValue(this.USE_SSO);
        }, getDirectRetrieveEnabled:function () {
            return this.getValue(this.DIRECT_RETRIEVE_ENABLED);
        }, getConnectionPoint:function () {
            return this.getValue(this.CONNECTION_POINT);
        }, getObjectStore:function () {
            return this.getValue(this.OBJECT_STORE);
        }, getCMISReposID:function () {
            return this.getValue(this.CMIS_REPOS_ID);
        }, getUseGzipEncoding:function () {
            return this.getValue(this.USE_GZIP_ENCODING);
        }, getObjectStoreDisplayName:function () {
            return this.getValue(this.OBJECT_STORE_DISPLAY_NAME);
        }, getProtocol:function () {
            return this.getValue(this.PROTOCOL);
        }, getAddAsMajorVersion:function () {
            return this.getValue(this.ADD_AS_MAJOR_VERSION);
        }, getCheckinAsMajorVersion:function () {
            return this.getValue(this.CHECKIN_AS_MAJOR_VERSION);
        }, getIncludeWorkflowDefinition:function () {
            return this.getValue(this.INCLUDE_WORKFLOW_DEFINITION);
        }, getAnnotationSecurity:function () {
            return this.getValue(this.ANNOTATION_SECURITY);
        }, getFolderSearchExpression:function () {
            return this.getValue(this.FOLDER_SEARCH_EXPRESSION);
        }, getMaxHits:function () {
            return this.getValue(this.MAX_HITS);
        }, getMaxFolders:function () {
            return this.getValue(this.MAX_FOLDERS);
        }, getAfp2PdfConfigFile:function () {
            return this.getValue(this.AFP2PD_CONFIG_FILE);
        }, getTransformXMLFile:function () {
            return this.getValue(this.XFORM_XML_FILE);
        }, getODSSL:function () {
            return this.getValue(this.OD_SSL);
        }, getODKeyringDBFile:function () {
            return this.getValue(this.OD_KEYRING_DBFILE);
        }, getODKeyringStashFile:function () {
            return this.getValue(this.OD_KEYRING_STASHFILE);
        }, getCustomProperties:function () {
            return this.getValue(this.CUSTOM_PROPS);
        }, getAfp2PdfInstallDirectory:function () {
            return this.getValue(this.AFP2PD_INSTALL_DIR);
        }, getLanguage:function () {
            return this.getValue(this.LANGUAGE);
        }, getTempDir:function () {
            return this.getValue(this.TEMP_DIR);
        }, getTraceDir:function () {
            return this.getValue(this.TRACE_DIR);
        }, getTraceLevel:function () {
            return this.getValue(this.TRACE_LEVEL);
        }, getPortNumber:function () {
            return this.getValue(this.PORT_NUMBER);
        }, getMaxInMemoryRetrieveSize:function () {
            return this.getValue(this.MAX_IN_MEMORY_RETRIEVE_SIZE);
        }, getMaxDownloadSize:function () {
            return this.getValue(this.MAX_DOWNLOAD_SIZE);
        }, getTimestampFormat:function () {
            return this.getValue(this.TIMESTAMP_FORMAT);
        }, getTimeFormat:function () {
            return this.getValue(this.TIME_FORMAT);
        }, getDateFormat:function () {
            return this.getValue(this.DATE_FORMAT);
        }, getTeamspacesEnabled:function () {
            return this.getValue(this.TEAMSPACES_ENABLED);
        }, getUnifiedSearchesEnabled:function () {
            return this.getValue(this.UNIFIED_SEARCHES_ENABLED);
        }, getSearchMaxResults:function () {
            return this.getValue(this.SEARCH_MAX_RESULTS);
        }, getTimeoutInSeconds:function () {
            return this.getValue(this.TIMEOUT_IN_SECONDS);
        }, getServerName:function () {
            return this.getValue(this.SERVER_NAME);
        }, getDocNameProperty:function () {
            return this.getValue(this.DOC_NAME_PROPERTY);
        }, getFolderNameProperty:function () {
            return this.getValue(this.FOLDER_NAME_PROPERTY);
        }, getFolderDefaultColumns:function () {
            return this.getValues(this.FOLDER_DEF_COLS, null);
        }, getFolderMagazineDefaultColumns:function () {
            return this.getValues(this.FOLDER_MAGAZINE_DEF_COLS, null);
        }, getSearchMagazineDefaultColumns:function () {
            return this.getValues(this.SEARCH_MAGAZINE_DEF_COLS, null);
        }, getSearchDefaultColumns:function () {
            return this.getValues(this.SEARCH_DEF_COLS, null);
        }, getSearchFilteredDocumentProperties:function () {
            return this.getValues(this.SEARCH_FILTERED_DOCUMENT_PROPERTIES, null);
        }, getSearchFilteredFolderProperties:function () {
            return this.getValues(this.SEARCH_FILTERED_FOLDER_PROPERTIES, null);
        }, getMatchAll:function () {
            return this.getValue(this.MATCH_ALL);
        }, getType:function () {
            return this.getValue(this.TYPE);
        }, getDocumentSystemProperties:function () {
            return this.getValues(this.DOCUMENT_SYSTEM_PROPERTIES, null);
        }, getFolderSystemProperties:function () {
            return this.getValues(this.FOLDER_SYSTEM_PROPERTIES, null);
        }, getStatusDocNotes:function () {
            var bool = this.getValue(this.STATUS_DOC_NOTES, "false");
            return (bool === true || bool == "true");
        }, getStatusDocHold:function () {
            var bool = this.getValue(this.STATUS_DOC_HOLD, "false");
            return (bool === true || bool == "true");
        }, getStatusDocCheckedOut:function () {
            var bool = this.getValue(this.STATUS_DOC_CHECKED_OUT, "false");
            return (bool === true || bool == "true");
        }, getStatusDocBookmarks:function () {
            var bool = this.getValue(this.STATUS_DOC_BOOKMARKS, "false");
            return (bool === true || bool == "true");
        }, getStatusDocDeclaredRecord:function () {
            var bool = this.getValue(this.STATUS_DOC_DECLARED_RECORD, "false");
            return (bool === true || bool == "true");
        }, getStatusDocMinorVersions:function () {
            var bool = this.getValue(this.STATUS_DOC_MINOR_VERSIONS, "false");
            return (bool === true || bool == "true");
        }, getStatusWorkItemCheckedOut:function () {
            var bool = this.getValue(this.STATUS_WORK_ITEM_CHECKED_OUT, "false");
            return (bool === true || bool == "true");
        }, getStatusWorkItemLocked:function () {
            var bool = this.getValue(this.STATUS_WORK_ITEM_LOCKED, "false");
            return (bool === true || bool == "true");
        }, getStatusWorkItemSuspended:function () {
            var bool = this.getValue(this.STATUS_WORK_ITEM_SUSPENDED, "false");
            return (bool === true || bool == "true");
        }, getStatusWorkItemDeadline:function () {
            var bool = this.getValue(this.STATUS_WORK_ITEM_DEADLINE, "false");
            return (bool === true || bool == "true");
        }, getFolderingEnabled:function () {
            var bool = this.getValue(this.FOLDERING_ENABLED, "false");
            return (bool === true || bool == "true");
        }, getDefaultEmailClassForAdd:function () {
            return this.getValue(this.DEFAULT_EMAIL_CLASS_FOR_ADD);
        }, getDefaultFolderClassForAdd:function () {
            return this.getValue(this.DEFAULT_FOLDER_CLASS_FOR_ADD);
        }, getValue:function (attribute) {
            var value = null;
            if (attribute == "typeString") {
                value = this.getTypeString();
            } else {
                if (this.hasAttribute(attribute)) {
                    value = this.inherited(arguments);
                }
            }
            return value;
        }, _getDefaultConfig:function () {
            var type = this._attributes[this.TYPE];
            if (!type) {
                return null;
            }
            if (!this._DEFAULT_CONFIG[type]) {
                var defaultConfig = new RepositoryReadConfig(type + "defaultsettings", "RepositoryConfig", "user");
                this._DEFAULT_CONFIG[type] = defaultConfig;
                defaultConfig.getConfig(lang.hitch(this, function (response) {
                    this._DEFAULT_CONFIG[type] = response;
                }), true);
            }
            return this._DEFAULT_CONFIG[type];
        }, getValues:function (attribute) {
            var values = null;
            if (this.hasAttribute(attribute)) {
                values = this.inherited(arguments);
            }
            return values;
        }, getTempId:function () {
            return this.tempId;
        }, getTypeIconClass:function () {
            var type = this.getType();
            var iconStr = "";
            if (type == "od") {
                iconStr = "adminIconRepositoryOD";
            } else {
                if (type == "cm") {
                    iconStr = "adminIconRepositoryCM";
                } else {
                    if (type == "p8") {
                        iconStr = "adminIconRepositoryP8";
                    } else {
                        if (type == "ci") {
                            iconStr = "adminIconRepositoryCI";
                        } else {
                            if (type == "cmis") {
                                iconStr = "adminIconRepositoryCMIS";
                            } else {
                                iconStr = "adminIconRepository";
                            }
                        }
                    }
                }
            }
            return iconStr;
        }, getTypeString:function () {
            var type = this.getType();
            if (type == "od") {
                return this.messages.ondemand;
            } else {
                if (type == "cm") {
                    return this.messages.content_manager;
                } else {
                    if (type == "p8") {
                        return this.messages.filenet_p8;
                    } else {
                        if (type == "ci") {
                            return this.messages.content_integrator;
                        } else {
                            if (type == "cmis") {
                                return this.messages.cmis;
                            } else {
                                return type;
                            }
                        }
                    }
                }
            }
        }, getName:function () {
            return this.getValue(this.NAME);
        }, getRepositoryConfig:function (callback) {
            this.getConfig(callback);
            return this;
        }, getSearchFilteredOperators:function (type) {
            return this.getValues(type);
        }, isConnected:function () {
            return this.connected;
        }});
        RepositoryReadConfig.createRepositoryReadConfig = function (id) {
            return new RepositoryReadConfig(id, "RepositoryConfig", "user");
        };
        return RepositoryReadConfig;
    });
}, "ecm/model/FavoritesTreeModel":function () {
    define("ecm/model/FavoritesTreeModel", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/connect", "dojo/dnd/Manager", "./_ModelObject", "./FavoritesResultSet", "./ResultSet", "./Item", "./Message", "./Desktop", "./Dnd"], function (declare, lang, array, connect, DNDManager, _ModelObject, FavoritesResultSet, ResultSet, Item, Message, Desktop, Dnd) {
        return declare("ecm.model.FavoritesTreeModel", [_ModelObject], {constructor:function (rootItem, data) {
            this._rootItem = rootItem;
            this._data = data;
            this._dndModel = new Dnd();
        }, getRoot:function (onItem) {
            onItem(this._rootItem);
        }, mayHaveChildren:function (item) {
            if (item === this._rootItem) {
                return true;
            } else {
                if (item && item.isFolder && item.isFolder()) {
                    return true;
                } else {
                    return false;
                }
            }
        }, getChildren:function (parentItem, onComplete) {
            var _this = this;
            if (parentItem === this._rootItem) {
                this._retrieveFavorites(onComplete);
            } else {
                if (!parentItem.repository.connected) {
                    onComplete([]);
                } else {
                    var repository = parentItem.repository;
                    if (parentItem && parentItem.isInstanceOf && parentItem.isInstanceOf(ecm.model.Favorite)) {
                        var favItem = parentItem.item;
                        if (favItem) {
                            this.retrieveChildren(favItem, onComplete, parentItem);
                        } else {
                            var handler = lang.hitch(this, function (item) {
                                this.retrieveChildren(item, onComplete, parentItem);
                            });
                            parentItem.retrieveFavorite(handler);
                        }
                    } else {
                        this.retrieveChildren(parentItem, onComplete);
                    }
                }
            }
        }, retrieveChildren:function (parentItem, onComplete, favoritesItem) {
            var _this = this;
            var repository = parentItem.repository;
            var filterType = repository.isSearchTemplateSupported() && (repository._isCM() || repository._isP8()) ? "searchAndFolderSearch" : "folderSearch";
            var request = parentItem.retrieveFolderContents(true, function (results) {
                var childItems = [].concat(results.getItems());
                _this._addPageForwardItem(childItems, results, parentItem, favoritesItem);
                onComplete(childItems);
            }, null, false, false, null, filterType, favoritesItem);
            if (request) {
                connect.connect(request, "onRequestCompleted", this, function () {
                    this.onProcessingComplete(parentItem);
                });
            }
        }, _addPageForwardItem:function (children, resultSet, parentItem, favoritesItem) {
            var continuable = resultSet.hasContinuation();
            if (continuable) {
                var id = "continuation_" + new Date().getTime();
                var parent = favoritesItem ? favoritesItem : parentItem;
                var moreLink = new Item({"id":id, "name":this.messages.more_paging_link, "repository":resultSet.repository, "resultSet":resultSet, "parent":parent});
                moreLink.continuationData = resultSet.continuationData;
                moreLink.pagedResultSet = resultSet;
                children.push(moreLink);
                parentItem.moreLink = moreLink;
            }
        }, fetchNextPage:function (pagedResultSet, parentItem, onComplete) {
            pagedResultSet.retrieveNextPage(lang.hitch(this, function () {
                this.replaceChildren(parentItem, pagedResultSet);
                this.onProcessingComplete(parentItem);
                if (onComplete) {
                    onComplete();
                }
            }));
        }, replaceChildren:function (parentItem, results) {
            var childItems = [].concat(results.getItems());
            this._addPageForwardItem(childItems, results, parentItem);
            this._onChildrenChange(parentItem, childItems);
        }, getResultSet:function () {
            return this.resultSet;
        }, _retrieveFavorites:function (callback) {
            if (this._data) {
                var params = {application:"navigator", userid:ecm.model.desktop.id + "." + ecm.model.desktop.defaultRepositoryId};
                var self = this;
                ecm.model.Request.invokeService("listFavorites", null, params, lang.hitch(this, function (response) {
                    if (self._data) {
                        response.rows = self._data;
                    }
                    for (var i in response.columns.cells[0]) {
                        var cell = response.columns.cells[0][i];
                        if (cell && cell.field == "label") {
                            cell.field = "{NAME}";
                            break;
                        }
                    }
                    var repository = ecm.model.desktop.getRepository(self._data[0].repositoryId);
                    response.id = "__favorites";
                    response.name = "__favorites";
                    response.repository = repository;
                    response.parentFolder = self._rootItem;
                    self.resultSet = new ResultSet(response);
                    if (callback) {
                        callback(self.resultSet.items);
                    }
                }));
            } else {
                ecm.model.desktop.loadFavorites(lang.hitch(this, function (favorites, structure, magazineStructure) {
                    if (favorites) {
                        if (!this.resultSet) {
                            this.resultSet = new FavoritesResultSet({id:"__favorites", name:"__favorites", items:favorites, structure:lang.clone(structure), magazineStructure:lang.clone(magazineStructure), parentFolder:this._rootItem});
                        } else {
                            this.resultSet.items = favorites;
                        }
                        for (var i in favorites) {
                            favorites[i].parentFolder = this._rootItem;
                        }
                        this._items = array.filter(this.resultSet.items, function (item) {
                            return item.type != "document";
                        });
                        if (callback) {
                            callback(this._items);
                        }
                    }
                }));
            }
        }, reload:function (callback) {
            this._items = null;
            if (Desktop.connected) {
                this._retrieveFavorites(lang.hitch(this, function (items) {
                    this._onChildrenChange(this._rootItem, items);
                    if (callback) {
                        callback(items);
                    }
                }));
            } else {
                this._onChildrenChange(this._rootItem, []);
                if (callback) {
                    callback([]);
                }
            }
        }, reloadChildren:function (item, favItem) {
            if (item && item.unloadFolderContents) {
                item.unloadFolderContents();
                this.retrieveChildren(item, lang.hitch(this, function (children) {
                    var parentItem = favItem ? favItem : item;
                    this._onChildrenChange(parentItem, children);
                }));
            }
        }, isItem:function (something) {
            if (something && something.isInstanceOf && something.isInstanceOf(_ModelObject)) {
                return true;
            }
            return false;
        }, fetchItemByIdentity:function (keywordArgs) {
            var identity = keywordArgs.identity || "";
            var items = this.resultSet.items;
            var arr = [];
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (this.getIdentity(item) == identity) {
                    if (keywordArgs.onItem) {
                        keywordArgs.onItem(item);
                    }
                    arr.push(item);
                }
            }
            if (keywordArgs.onComplete) {
                keywordArgs.onComplete(arr);
            }
        }, getIdentity:function (item) {
            return item && item.id ? item.id : "";
        }, getLabel:function (item) {
            return item && item.name ? item.name : "";
        }, newItem:function (args, parent, insertIndex) {
            if (args && args.sourceItems && args.sourceItems.length > 0) {
                if (DNDManager.manager().copy) {
                    this._dndModel.dropCopy(args.sourceItems, parent);
                } else {
                    this._dndModel.dropMove(args.sourceItems, parent);
                }
            }
        }, pasteItem:function (childItem, oldParentItem, newParentItem, bCopy) {
            if (bCopy && newParentItem.repository.type == "p8" && childItem.isFolder()) {
                return;
            } else {
                if (newParentItem.repository.id != childItem.repository.id) {
                    return;
                }
            }
            var sourceItems = [childItem];
            if (bCopy) {
                this._dndModel.dropCopy(sourceItems, newParentItem);
            } else {
                this._dndModel.dropMove(sourceItems, newParentItem, oldParentItem);
            }
        }, setValue:function (item, attribute, value) {
            var id = this.getIdentity(item);
            var items = this.resultSet.items;
            for (var i = 0; i < items.length; i++) {
                if (this.getIdentity(items[i]) == id) {
                    items[i][attribute] = value;
                    this.onChange(items[i]);
                    break;
                }
            }
        }, onProcessingComplete:function (item) {
        }, _onChildrenChange:function (parent, newChildrenList) {
            this.onChildrenChange(parent, newChildrenList);
            if (newChildrenList && newChildrenList.length > 0) {
                for (var i = 0; i < newChildrenList.length; i++) {
                    this.onChange(newChildrenList[i]);
                }
            }
        }, onChange:function (item) {
        }, onChildrenChange:function (parent, newChildrenList) {
        }});
    });
}, "ecm/model/admin/MenuConfig":function () {
    define(["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/json", "./_ConfigurationObject", "../Action"], function (declare, lang, array, dojojson, _ConfigurationObject, Action) {
        var MenuConfig = declare("ecm.model.admin.MenuConfig", [_ConfigurationObject], {TYPE:"type", TYPE_LABEL:"typeLabel", NAME:"name", DESCRIPTION:"description", ID:"id", PLUGIN_ID:"pluginId", ITEMS:"items", constructor:function (id, name) {
            this._attributes.id = id;
        }, getValue:function (att) {
            if (att == "typeSorter") {
                if (this.getPluginId()) {
                    if (this.isToolbar()) {
                        return "3";
                    } else {
                        return "2";
                    }
                } else {
                    if (this.isToolbar()) {
                        return "1";
                    } else {
                        return "0";
                    }
                }
            } else {
                return this.inherited(arguments);
            }
        }, isToolbar:function () {
            return this.getType().indexOf("Toolbar") > -1 ? true : false;
        }, isContextMenu:function () {
            return this.getType().indexOf("ContextMenu") > -1 ? true : false;
        }, getIconClass:function () {
            var iconClass = "adminIconMenu";
            if (this.getPluginId()) {
                if (this.isToolbar()) {
                    iconClass = "adminIconMenuToolbarCustom";
                } else {
                    iconClass = "adminIconMenuContextMenuCustom";
                }
            } else {
                if (this.isToolbar()) {
                    iconClass = "adminIconMenuToolbar";
                } else {
                    iconClass = "adminIconMenuContextMenu";
                }
            }
            return iconClass;
        }, getActions:function (callback) {
            this.getActionsForMenuId(this.id, null, null, callback);
        }, getActionsForMenuId:function (menuId, sorted, includeCustomActions, callback) {
            var params = {action_id:menuId, action_list_suffix:this.getType()};
            if (sorted != undefined) {
                params.sorted = sorted;
            }
            if (includeCustomActions != undefined) {
                params.includeCustomActions = includeCustomActions;
            }
            var request = ecm.model.Request.invokeService("getActions", null, params, lang.hitch(this, function (response) {
                var actions = [];
                this._loadActions(response.actions, actions);
                callback(actions);
            }));
        }, _loadActions:function (actionsJSON, actions) {
            for (var i in actionsJSON) {
                var actionJSON = actionsJSON[i];
                var action = new Action(actionJSON);
                if (actionJSON.actions && actionJSON.actions.length > 0) {
                    this._loadActions(actionJSON.actions, action.subActions);
                }
                actions.push(action);
            }
        }, getDescription:function () {
            return this.getValue(this.DESCRIPTION);
        }, setDescription:function (description) {
            this.setValue(this.DESCRIPTION, description);
        }, getName:function () {
            return this.getValue(this.NAME);
        }, setName:function (name) {
            this.setValue(this.NAME, name);
        }, getType:function () {
            return this.getValue(this.TYPE);
        }, setType:function (type) {
            this.setValue(this.TYPE, type);
        }, getTypeLabel:function () {
            return this.getValue(this.TYPE_LABEL);
        }, setTypeLabel:function (typeLabel) {
            this.setValue(this.TYPE_LABEL, typeLabel);
        }, getPluginId:function () {
            return this.getValue(this.PLUGIN_ID);
        }, setPluginId:function (pluginId) {
            this.setValue(this.PLUGIN_ID, pluginId);
        }, setDataToSave:function (items, subActionObjs) {
            this._originalMenuIds = this.getValues(this.ITEMS);
            this.setValues(this.ITEMS, items);
            this._subActionObjs = subActionObjs;
        }, getItemObjects:function (callback) {
            var menus = this.getValues(this.ITEMS);
            if (menus && menus.length > 0) {
                var menuObjects = [];
                array.forEach(menus, lang.hitch(this, function (entry, index) {
                    var menu = MenuConfig.createMenuConfig(entry);
                    menu.getConfig(function (response) {
                        menuObjects.push(menu);
                        if (menuObjects.length == menus.length && callback) {
                            callback(menuObjects);
                        }
                    });
                }));
                return menuObjects;
            }
        }, deleteConfigs:function (configs, name, callback) {
            var ids = [];
            var prefixids = [];
            for (var i in configs) {
                ids.push(configs[i].id);
                prefixids.push(configs[i].id + "_L$");
            }
            var params = lang.mixin({action:"deleteList", ids:dojojson.toJson(ids), id:this.id, configuration:configs[0].name, "delete_list_configuration":configs[0].name, "delete_list_prefix_id":dojojson.toJson(prefixids), "delete_list_type":"menu", "update_app_configuration_type":name}, this.default_params);
            var request = ecm.model.Request.invokeService("admin/configuration", null, params, function (response) {
                if (callback) {
                    callback(response);
                }
            });
        }, addConfig:function (callback) {
            var actionArray = [];
            var data = {};
            for (var i in this._attributes) {
                data[i] = this._attributes[i];
            }
            var updateAction = {"action":"add", "configuration":this.name, "id":this.id, "data":data, "update_list_configuration":ecm.model.admin.appCfg.name, "update_list_id":ecm.model.admin.appCfg.id, "update_list_type":ecm.model.admin.appCfg.MENUS};
            actionArray.push(updateAction);
            if (this._subActionObjs && this._subActionObjs.length > 0) {
                var updateListAction = {"action":"addList", "configuration":"MenuConfig", "data":this._subActionObjs};
                actionArray.push(updateListAction);
            }
            var params = lang.mixin({"action":"multiple", "id":this.id, "configuration":this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(actionArray), lang.hitch(this, function (response) {
                lang.mixin(this, {_attributes:response.configuration});
                if (callback) {
                    callback();
                }
            }));
            return this;
        }, updateMenuConfig:function (callback) {
            var actionArray = [];
            if (this._originalMenuIds && this._originalMenuIds.length > 0) {
                var deleteListAction = {"action":"deleteList", "configuration":"MenuConfig", "ids":this._originalMenuIds};
                actionArray.push(deleteListAction);
            }
            var data = {};
            for (var i in this._attributes) {
                data[i] = this._attributes[i];
            }
            var updateAction = {"action":"update", "configuration":this.name, "id":this.id, "data":data};
            actionArray.push(updateAction);
            if (this._subActionObjs && this._subActionObjs.length > 0) {
                var updateListAction = {"action":"addList", "configuration":"MenuConfig", "data":this._subActionObjs};
                actionArray.push(updateListAction);
            }
            var params = lang.mixin({"action":"multiple", "id":this.id, "configuration":this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(actionArray), lang.hitch(this, function (response) {
                lang.mixin(this, {_attributes:response.configuration});
                if (callback) {
                    callback();
                }
            }));
            return this;
        }});
        MenuConfig.createMenuConfig = function (id) {
            ecm.logger.logDebug("ecm.model.admin.createMenuConfig", "id: " + id);
            return new MenuConfig(id, "MenuConfig");
        };
        return MenuConfig;
    });
}, "ecm/model/EntryTemplateOption":function () {
    define("ecm/model/EntryTemplateOption", ["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        return declare("ecm.model.EntryTemplateOption", [_ModelObject], {on:false, readOnly:false, hidden:false});
    });
}, "dojo/date":function () {
    define("dojo/date", ["./has", "./_base/lang"], function (has, lang) {
        var date = {};
        date.getDaysInMonth = function (dateObject) {
            var month = dateObject.getMonth();
            var days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            if (month == 1 && date.isLeapYear(dateObject)) {
                return 29;
            }
            return days[month];
        };
        date.isLeapYear = function (dateObject) {
            var year = dateObject.getFullYear();
            return !(year % 400) || (!(year % 4) && !!(year % 100));
        };
        date.getTimezoneName = function (dateObject) {
            var str = dateObject.toString();
            var tz = "";
            var match;
            var pos = str.indexOf("(");
            if (pos > -1) {
                tz = str.substring(++pos, str.indexOf(")"));
            } else {
                var pat = /([A-Z\/]+) \d{4}$/;
                if ((match = str.match(pat))) {
                    tz = match[1];
                } else {
                    str = dateObject.toLocaleString();
                    pat = / ([A-Z\/]+)$/;
                    if ((match = str.match(pat))) {
                        tz = match[1];
                    }
                }
            }
            return (tz == "AM" || tz == "PM") ? "" : tz;
        };
        date.compare = function (date1, date2, portion) {
            date1 = new Date(+date1);
            date2 = new Date(+(date2 || new Date()));
            if (portion == "date") {
                date1.setHours(0, 0, 0, 0);
                date2.setHours(0, 0, 0, 0);
            } else {
                if (portion == "time") {
                    date1.setFullYear(0, 0, 0);
                    date2.setFullYear(0, 0, 0);
                }
            }
            if (date1 > date2) {
                return 1;
            }
            if (date1 < date2) {
                return -1;
            }
            return 0;
        };
        date.add = function (date, interval, amount) {
            var sum = new Date(+date);
            var fixOvershoot = false;
            var property = "Date";
            switch (interval) {
              case "day":
                break;
              case "weekday":
                var days, weeks;
                var mod = amount % 5;
                if (!mod) {
                    days = (amount > 0) ? 5 : -5;
                    weeks = (amount > 0) ? ((amount - 5) / 5) : ((amount + 5) / 5);
                } else {
                    days = mod;
                    weeks = parseInt(amount / 5);
                }
                var strt = date.getDay();
                var adj = 0;
                if (strt == 6 && amount > 0) {
                    adj = 1;
                } else {
                    if (strt == 0 && amount < 0) {
                        adj = -1;
                    }
                }
                var trgt = strt + days;
                if (trgt == 0 || trgt == 6) {
                    adj = (amount > 0) ? 2 : -2;
                }
                amount = (7 * weeks) + days + adj;
                break;
              case "year":
                property = "FullYear";
                fixOvershoot = true;
                break;
              case "week":
                amount *= 7;
                break;
              case "quarter":
                amount *= 3;
              case "month":
                fixOvershoot = true;
                property = "Month";
                break;
              default:
                property = "UTC" + interval.charAt(0).toUpperCase() + interval.substring(1) + "s";
            }
            if (property) {
                sum["set" + property](sum["get" + property]() + amount);
            }
            if (fixOvershoot && (sum.getDate() < date.getDate())) {
                sum.setDate(0);
            }
            return sum;
        };
        date.difference = function (date1, date2, interval) {
            date2 = date2 || new Date();
            interval = interval || "day";
            var yearDiff = date2.getFullYear() - date1.getFullYear();
            var delta = 1;
            switch (interval) {
              case "quarter":
                var m1 = date1.getMonth();
                var m2 = date2.getMonth();
                var q1 = Math.floor(m1 / 3) + 1;
                var q2 = Math.floor(m2 / 3) + 1;
                q2 += (yearDiff * 4);
                delta = q2 - q1;
                break;
              case "weekday":
                var days = Math.round(date.difference(date1, date2, "day"));
                var weeks = parseInt(date.difference(date1, date2, "week"));
                var mod = days % 7;
                if (mod == 0) {
                    days = weeks * 5;
                } else {
                    var adj = 0;
                    var aDay = date1.getDay();
                    var bDay = date2.getDay();
                    weeks = parseInt(days / 7);
                    mod = days % 7;
                    var dtMark = new Date(date1);
                    dtMark.setDate(dtMark.getDate() + (weeks * 7));
                    var dayMark = dtMark.getDay();
                    if (days > 0) {
                        switch (true) {
                          case aDay == 6:
                            adj = -1;
                            break;
                          case aDay == 0:
                            adj = 0;
                            break;
                          case bDay == 6:
                            adj = -1;
                            break;
                          case bDay == 0:
                            adj = -2;
                            break;
                          case (dayMark + mod) > 5:
                            adj = -2;
                        }
                    } else {
                        if (days < 0) {
                            switch (true) {
                              case aDay == 6:
                                adj = 0;
                                break;
                              case aDay == 0:
                                adj = 1;
                                break;
                              case bDay == 6:
                                adj = 2;
                                break;
                              case bDay == 0:
                                adj = 1;
                                break;
                              case (dayMark + mod) < 0:
                                adj = 2;
                            }
                        }
                    }
                    days += adj;
                    days -= (weeks * 2);
                }
                delta = days;
                break;
              case "year":
                delta = yearDiff;
                break;
              case "month":
                delta = (date2.getMonth() - date1.getMonth()) + (yearDiff * 12);
                break;
              case "week":
                delta = parseInt(date.difference(date1, date2, "day") / 7);
                break;
              case "day":
                delta /= 24;
              case "hour":
                delta /= 60;
              case "minute":
                delta /= 60;
              case "second":
                delta /= 1000;
              case "millisecond":
                delta *= date2.getTime() - date1.getTime();
            }
            return Math.round(delta);
        };
        1 && lang.mixin(lang.getObject("dojo.date", true), date);
        return date;
    });
}, "ecm/Messages":function () {
    define("ecm/Messages", ["dojo/_base/declare", "dojo/i18n!./nls/messages", "./version"], function (declare, messages, version) {
        ecm.messages = messages;
        ecm.messages.product_name = "IBM Content Navigator";
        ecm.messages.product_version = ecm.version.getVersion();
        ecm.messages.content_manager = "Content Manager";
        ecm.messages.ondemand = "Content Manager OnDemand";
        ecm.messages.filenet_p8 = "FileNet Content Manager";
        ecm.messages.content_integrator = "Content Integrator";
        ecm.messages.cmis = "Content Management Interoperability Services (CMIS)";
        return ecm.messages;
    });
}, "ecm/model/SearchFolder":function () {
    define("ecm/model/SearchFolder", ["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        return declare("ecm.model.SearchFolder", [_ModelObject], {VIEW:{EDITABLE:"editable", HIDDEN:"hidden"}, objectStoreId:null, objectStoreName:null, searchSubfolders:false, view:null, itemId:"", constructor:function (id, pathName, objectStoreId, objectStoreName, searchSubfolders, view, itemId) {
            this.objectStoreId = objectStoreId;
            this.objectStoreName = objectStoreName;
            this.searchSubfolders = searchSubfolders;
            this.view = view || this.VIEW.EDITABLE;
            this.itemId = itemId || "";
        }, setPathName:function (pathName) {
            this.name = pathName;
        }, getPathName:function () {
            return this.name;
        }, isHidden:function () {
            return this.view == this.VIEW.HIDDEN;
        }, equals:function (searchFolder) {
            var id = this.id.split(",");
            id = id.length == 3 ? id[2] : id[0];
            var id2 = searchFolder.id.split(",");
            id2 = id2.length == 3 ? id2[2] : id2[0];
            return id == id2 && (this.objectStoreId == searchFolder.objectStoreId || this.objectStoreName == searchFolder.objectStoreName) && new Boolean(this.searchSubfolders).valueOf() == new Boolean(searchFolder.searchSubfolders).valueOf();
        }});
    });
}, "ecm/model/Item":function () {
    define("ecm/model/Item", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/window", "dojo/_base/array", "dojo/io-query", "dojo/has", "dojo/dom-construct", "dojo/dom-attr", "./_ModelObject"], function (declare, lang, win, array, ioQuery, has, domConstruct, domAttr, _ModelObject) {
        var ItemFactory = declare("ecm.model.Item", [_ModelObject], {mimetype:undefined, repository:null, attributes:null, resultSet:null, parent:null, privileges:0, locked:false, lockedUser:"", entryTemplateId:undefined, deleted:false, dataObject:false, attributeLabels:null, attributeTypes:null, attributeFormats:null, attributeDisplayValues:null, attributeReadOnly:null, attributeSystemProperty:null, attributeItems:null, constructor:function () {
            if (this.objectStore == null && this.objectStoreId != null) {
                this.objectStore = {id:this.objectStoreId, symbolicName:this.objectStoreName, displayName:this.objectStoreDisplayName, capabilityComment:this.capabilityComment};
            }
            if (!this.attributes) {
                this.attributes = {};
            }
            if (!this.attributeLabels) {
                this.attributeLabels = {};
            }
            if (!this.attributeTypes) {
                this.attributeTypes = {};
            }
            if (!this.attributeFormats) {
                this.attributeFormats = {};
            }
            if (!this.attributeDisplayValues) {
                this.attributeDisplayValues = {};
            }
            if (!this.attributeReadOnly) {
                this.attributeReadOnly = {};
            }
            if (!this.attributeSystemProperty) {
                this.attributeSystemProperty = {};
            }
        }, getContentType:function () {
            return this.mimetype || "";
        }, getPath:function () {
            var array = [];
            var item = this;
            while (item) {
                array.push(item);
                item = item.parentFolder ? item.parentFolder : item.parent;
            }
            return array.reverse();
        }, retrieveAttributes:function (callback) {
            if (callback) {
                callback(this);
            }
        }, getContentClass:function () {
            if (!this.template) {
                return null;
            }
            return this.repository.getContentClass(this.template);
        }, containsValue:function (attribute, value) {
            var v = this.attributes[attribute];
            if (value == v) {
                return true;
            } else {
                if (lang.isArray(v)) {
                    for (var i in v) {
                        if (value == v[i]) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }, getValue:function (attribute) {
            return this.attributes[attribute];
        }, getValues:function (attribute) {
            var v = this.attributes[attribute];
            if (v instanceof Array) {
                return v;
            } else {
                return [v];
            }
        }, setValue:function (attribute, value) {
            this.attributes[attribute] = value;
        }, setValues:function (attribute, values) {
            this.attributes[attribute] = values;
        }, getItemValue:function (attribute) {
            var itemValue = null;
            if (this.attributeItems && this.attributeItems[attribute]) {
                itemValue = this.attributeItems[attribute];
            }
            return itemValue;
        }, getAttrLabel:function (attribute) {
            return this.attributeLabels[attribute];
        }, isSystemProperty:function (attribute) {
            return this.attributeSystemProperty[attribute];
        }, getMimeClass:function () {
            var mimeType = this.mimetype || "";
            var iconClass;
            if (this.isFolder()) {
                iconClass = "dijitIconFolderClosed";
            } else {
                iconClass = ecm.model.Item.MimeTypeToFileType[mimeType];
                if (!iconClass) {
                    if ((mimeType == "") || (mimeType == "item")) {
                        iconClass = "ftNoContent";
                    } else {
                        if (mimeType.substr(0, "audio/".length) == "audio/") {
                            iconClass = ecm.model.Item.MimeTypeToFileType["audio/*"] || "ftAudio";
                        } else {
                            if (mimeType.substr(0, "image/".length) == "image/") {
                                iconClass = ecm.model.Item.MimeTypeToFileType["image/*"] || "ftGraphic";
                            } else {
                                if (mimeType.substr(0, "video/".length) == "video/") {
                                    iconClass = ecm.model.Item.MimeTypeToFileType["video/*"] || "ftVideo";
                                } else {
                                    if (mimeType == "teamspace" || mimeType == "Teamspace") {
                                        iconClass = "ecmTeamspaceIcon";
                                    } else {
                                        iconClass = "ftDefault";
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return iconClass;
        }, getStateClass:function (state) {
            var stateClass = ecm.model.Item.StateToCssClass[state];
            if (!stateClass) {
                stateClass = "";
            }
            return stateClass;
        }, getDisplayValue:function (attribute) {
            if (this.attributeDisplayValues[attribute]) {
                return this.attributeDisplayValues[attribute];
            }
            return ecm.model.desktop.valueFormatter.formatValue(this.attributes[attribute], this.attributeTypes[attribute], this.attributeFormats[attribute]);
        }, isAttributeReadOnly:function (attribute) {
            var readOnly = false;
            var contentClass = this.getContentClass();
            var attrDef = contentClass && contentClass.attributeDefinitionsById && contentClass.attributeDefinitionsById[attribute];
            if (attrDef != null) {
                readOnly = attrDef.readOnly;
            }
            if (!readOnly && this.attributeReadOnly[attribute] === true) {
                readOnly = true;
            }
            return readOnly;
        }, hasAttribute:function (attribute) {
            return (typeof this.attributes[attribute] != "undefined");
        }, getAttributeType:function (attribute) {
            return this.attributeTypes[attribute];
        }, getAttributeFormat:function (attribute) {
            return this.attributeFormats[attribute];
        }, isFolder:function () {
            return this.mimetype == "folder";
        }, getModifyDate:function () {
            return this.attributes["Date Last Modified"] || this.attributes["DateLastModified"] || this.attributes["modifiedTimestamp"] || null;
        }, getModifyUser:function () {
            return this.attributes["Last Modifier"] || this.attributes["LastModifier"] || this.attributes["modifiedBy"] || null;
        }, hasPrivilege:function (privilege) {
            if (this.privileges && ecm.model.Item.PrivilegeToBitmask[privilege]) {
                var returnValue = (this.privileges & ecm.model.Item.PrivilegeToBitmask[privilege]) != 0;
            } else {
                var returnValue = this[privilege] ? (this[privilege] == "true" || this[privilege] == true) : false;
            }
            if (returnValue && (this.locked == true || this.locked == "true")) {
                if (privilege == "privEditDoc" || privilege == "privEditProperties" || (privilege == "privEditAnnotations" && this.repository.type == "cm")) {
                    returnValue = this.repository.userId.toUpperCase() == this.lockedUser.toUpperCase();
                }
            }
            return returnValue;
        }});
        ItemFactory.getBookmark = function (item, version, desktopId, repositoryId, repositoryType, templateName, wcProxy) {
            var linkUrl;
            var _templateName;
            if (item.isInstanceOf && item.isInstanceOf(ecm.model.Teamspace)) {
                _templateName = item.className;
            } else {
                _templateName = templateName ? templateName : item.template;
            }
            var queryParams = {desktop:(desktopId ? desktopId : ecm.model.desktop.id), repositoryId:(repositoryId ? repositoryId : item.repository.id), docid:item.id, template_name:_templateName};
            if (!repositoryType) {
                repositoryType = item.repository.type;
            }
            if (version && version != null) {
                queryParams.version = version;
                if (!(item.isInstanceOf && item.isInstanceOf(ecm.model.Teamspace)) && item.vsId) {
                    queryParams.vsId = item.vsId;
                }
            }
            if (wcProxy && wcProxy != null) {
                queryParams.proxy = wcProxy;
            }
            var mimeClass = item.getMimeClass();
            linkUrl = ecm.model.desktop._cServicesUrl + "/bookmark.jsp?" + ioQuery.objectToQuery(queryParams);
            return (window.location.protocol + "//" + window.location.host + linkUrl);
        };
        ItemFactory.PrivilegeToBitmask = {"privEditProperties":1, "privEditDoc":2, "privViewNotes":4, "privAddDoc":8, "privAddItem":16, "privEmailDoc":32, "privExport":64, "privAddToFolder":128, "privRemoveFromFolder":256, "privAddLink":512, "privRemoveLink":1024, "privAddNotes":4096, "privPrintNotes":8192, "privPrintDoc":16384, "privCheckInOutDoc":32768, "privCheckInDoc":65536, "privCheckOutDoc":131072, "privCancelCheckOutDoc":262144, "privViewAnnotations":524288, "privEditAnnotations":1048576, "privViewDoc":2097152, "privDelete":4194304, "privStartWorkflow":8388608, "privHold":16777216, "privMoveToFolder":33554432, "privChangeClass":67108864, "privMajorVersion":134217728, "privMinorVersion":268435456, "privIERRecordDeclare":536870912, "privModifyNotes":1073741824};
        ItemFactory.MimeTypeToFileType = {"":"ftNoContent", "item":"ftNoContent", "application/afp":"ftAfp", "application/pdf":"ftPdf", "text/plain":"ftPlain", "application/rtf":"ftPlain", "application/x-rtf":"ftPlain", "text/richtext":"ftPlain", "application/dca-rft":"ftPlain", "text/html":"ftWeb", "text/htm":"ftWeb", "application/x-compress":"ftCompressed", "application/x-compressed":"ftCompressed", "application/x-zip-compressed":"ftCompressed", "application/zip":"ftCompressed", "multipart/x-zip":"ftCompressed", "text/xml":"ftCode", "application/xml":"ftCode", "application/x-vnd.oasis.opendocument.presentation":"ftPresentation", "application/vnd.ms-powerpoint":"ftPresentation", "application/vnd.lotus-freelance":"ftPresentation", "application/vnd.oasis.opendocument.presentation":"ftPresentation", "application/vnd.openxmlformats-officedocument.presentationml.presentation":"ftPresentation", "application/vnd.openxmlformats-officedocument.presentationml.slideshow":"ftPresentation", "application/vnd.openxmlformats-officedocument.presentationml.template":"ftPresentation", "application/vnd.ms-powerpoint.presentation.macroEnabled.12":"ftPresentation", "application/vnd.ms-powerpoint.template.macroEnabled.12":"ftPresentation", "application/x-mspowerpoint":"ftPresentation", "application/line":"ftData", "application/x-vnd.oasis.opendocument.spreadsheet":"ftData", "application/vnd.ms-excel":"ftData", "application/vnd.ms-excel.sheet.binary.macroEnabled.12":"ftData", "application/vnd.ms-excel.addin.macroEnabled.12":"ftData", "application/vnd.ms-excel.sheet.macroEnabled.12":"ftData", "application/vnd.lotus-1-2-3":"ftData", "application/vnd.openxmlformats-officedocument.spreadsheetml.template":"ftData", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":"ftData", "application/vnd.oasis.opendocument.spreadsheet":"ftData", "application/x-msexcel":"ftData", "application/x-vnd.oasis.opendocument.text":"ftWordProcessing", "application/msword":"ftWordProcessing", "application/vnd.lotus-wordpro":"ftWordProcessing", "application/wordperfect5.1":"ftWordProcessing", "application/vnd.oasis.opendocument.text":"ftWordProcessing", "application/vnd.openxmlformats-officedocument.wordprocessingml.document":"ftWordProcessing", "application/vnd.openxmlformats-officedocument.wordprocessingml.template":"ftWordProcessing", "application/vnd.ms-word.template.macroEnabled.12":"ftWordProcessing", "application/vnd.ms-word.document.macroEnabled.12":"ftWordProcessing", "application/x-msword":"ftWordProcessing", "application/x-filenet-searchtemplate":"ftSearchTemplate", "application/x-searchtemplate":"ftSearchTemplate", "application/x-searchtemplate.automatic":"ftSearchStored", "application/x-unifiedsearchtemplate":"ftUnifiedSearch", "application/x-filenet-entrytemplate":"ftEntryTemplate", "application/x-filenet-formdataentrytemplate":"ftEntryTemplate", "application/x-filenet-customobjectentrytemplate":"ftCustomObjectEntryTemplate", "application/x-filenet-documententrytemplate":"ftDocumentEntryTemplate", "application/x-filenet-folderentrytemplate":"ftFolderEntryTemplate", "application/x-filenet-declarerecordentrytemplate":"ftDeclareRecordEntryTemplate", "application/x-filenet-search":"ftSearchStored", "application/x-filenet-workflowdefinition":"ftWorkflow", "application/x-filenet-xpdlworkflowdefinition":"ftWorkflow", "application/x-workitem":"ftWorkItem", "application/x-tracker":"ftTracker", "application/x-filenet-documentpolicy":"ftPolicyDocument", "application/x-filenet-workflowpolicy":"ftPolicyWorkflow", "application/x-filenet-formdata":"ftFormData", "application/x-filenet-itxformtemplate":"ftFormTemplate", "application/x-filenet-external":"ftExternalFile", "application/csbundled":"ftMail", "application/icccsn":"ftNotesMail", "message/rfc822":"ftMail", "application/iccxit":"ftMail", "application/x-filenet-filetype-msg":"ftMail", "application/vnd.ms-outlook":"ftOutlookMail"};
        ItemFactory.loadIconMapping = function (iconMapping) {
            var map = {};
            var css = "";
            var count = 0;
            array.forEach(iconMapping, function (iconConfig) {
                var className = iconConfig.getClassName();
                if (!className) {
                    var fileName = iconConfig.getFileName();
                    if (fileName) {
                        className = "ftCustom" + count++;
                        css += "." + className + "{width:16px;height:16px;background:url(" + fileName + ") no-repeat;}";
                    } else {
                        return;
                    }
                }
                array.forEach(iconConfig.getContentTypes(), function (type) {
                    map[type] = className;
                });
            });
            ItemFactory.MimeTypeToFileType = map;
            if (css) {
                var styleSheet = ItemFactory._mimeTypeStyleSheet;
                if (has("ie")) {
                    if (!styleSheet) {
                        styleSheet = win.doc.createStyleSheet();
                    }
                    styleSheet.cssText = css;
                } else {
                    if (!styleSheet) {
                        styleSheet = domConstruct.create("style", {type:"text/css", innerHTML:css}, win.doc.getElementsByTagName("head")[0]);
                    } else {
                        domAttr.set(styleSheet, "innerHTML", css);
                    }
                }
                ItemFactory._mimeTypeStyleSheet = styleSheet;
            }
        };
        ItemFactory.StateToCssClass = {};
        ItemFactory.loadIconStateMapping = function (iconStateMapping) {
            var map = {};
            var css = "";
            var count = 0;
            array.forEach(iconStateMapping, function (iconStateConfig) {
                var className;
                var fileName = iconStateConfig.getFileName();
                if (fileName) {
                    className = "ecmCustomState" + count++;
                    css += "." + className + "{width:16px;height:16px;background:url(" + fileName + ") no-repeat;}";
                } else {
                    className = iconStateConfig.getClassName();
                }
                map[iconStateConfig.id] = className;
            });
            ItemFactory.StateToCssClass = map;
            if (css) {
                var styleSheet = ItemFactory._stateIconStyleSheet;
                if (has("ie")) {
                    if (!styleSheet) {
                        styleSheet = win.doc.createStyleSheet();
                    }
                    styleSheet.cssText = css;
                } else {
                    if (!styleSheet) {
                        styleSheet = domConstruct.create("style", {type:"text/css", innerHTML:css}, win.doc.getElementsByTagName("head")[0]);
                    } else {
                        domAttr.set(styleSheet, "innerHTML", css);
                    }
                }
                ItemFactory._stateIconStyleSheet = styleSheet;
            }
        };
        return ItemFactory;
    });
}, "ecm/model/ValueFormatter":function () {
    define("ecm/model/ValueFormatter", ["dojo/_base/declare", "dojo/_base/config", "dojo/_base/lang", "dojo/date/locale", "dojo/date/stamp", "dojo/number", "./_ModelObject", "dojox/string/BidiComplex"], function (declare, config, lang, locale, stamp, number, _ModelObject, BidiComplex) {
        return declare("ecm.model.ValueFormatter", [_ModelObject], {constructor:function () {
            this.locale = config.locale;
            this.numberBundle = dojo.i18n.getLocalization("dojo.cldr", "number", this.locale);
            this.gregorian = dojo.i18n.getLocalization("dojo.cldr", "gregorian", this.locale);
        }, setLocale:function (locale) {
            if (locale) {
                this.locale = locale;
                this.numberBundle = dojo.i18n.getLocalization("dojo.cldr", "number", this.locale);
                this.gregorian = dojo.i18n.getLocalization("dojo.cldr", "gregorian", this.locale);
            }
        }, getSeparator:function () {
            return this.numberBundle["list"] || ",";
        }, getDecimalPoint:function () {
            return this.numberBundle["decimal"] || ".";
        }, formatValue:function (value, type, format) {
            var formattedValue = "";
            if (lang.isArray(value)) {
                for (var i in value) {
                    var v = value[i];
                    if (!formattedValue) {
                        formattedValue = this.formatValue(v, type, format);
                    } else {
                        formattedValue += this.getSeparator() + " " + this.formatValue(v, type);
                    }
                }
            } else {
                if (value == null) {
                    formattedValue = "";
                } else {
                    if (format == "fileSize") {
                        var valueFloat = parseFloat(value);
                        if (isNaN(valueFloat)) {
                            formattedValue = "" + value;
                        } else {
                            if (valueFloat == 0) {
                                formattedValue = "0 KB";
                            } else {
                                if (valueFloat < (1024 * 1024)) {
                                    if (valueFloat / 1024 < 1) {
                                        formattedValue = "1 KB";
                                    } else {
                                        formattedValue = number.format((valueFloat / 1024), {locale:this.locale, places:0}) + " KB";
                                    }
                                } else {
                                    var valueMB = number.format((valueFloat / 1024 / 1024), {locale:this.locale, places:1});
                                    var temp = number.parse(valueMB);
                                    if (temp < 1024) {
                                        formattedValue = valueMB + " MB";
                                    } else {
                                        formattedValue = number.format((valueFloat / 1024 / 1024 / 1024), {locale:this.locale, places:1}) + " GB";
                                    }
                                }
                            }
                        }
                    } else {
                        if (format == "path") {
                            formattedValue = this.formatPath(value);
                        } else {
                            if (type == "xs:date") {
                                if (!value || value == "") {
                                    formattedValue = "";
                                } else {
                                    var date = stamp.fromISOString(value);
                                    if (date == null) {
                                        return ecm.messages.error;
                                    }
                                    if (format) {
                                        formattedValue = locale.format(date, {locale:this.locale, selector:"date", datePattern:format});
                                    } else {
                                        formattedValue = locale.format(date, {locale:this.locale, selector:"date", formatLength:"short", fullYear:true});
                                    }
                                }
                            } else {
                                if (type == "xs:time") {
                                    if (!value || value == "") {
                                        formattedValue = "";
                                    } else {
                                        var date = stamp.fromISOString(value);
                                        if (format) {
                                            formattedValue = locale.format(date, {locale:this.locale, selector:"time", timePattern:format});
                                        } else {
                                            formattedValue = locale.format(date, {locale:this.locale, selector:"time", formatLength:"short"});
                                        }
                                    }
                                } else {
                                    if (type == "xs:timestamp") {
                                        if (!value || value == "") {
                                            formattedValue = "";
                                        } else {
                                            var date = stamp.fromISOString(value);
                                            if (format) {
                                                formattedValue = locale.format(date, {locale:this.locale, selector:"date", datePattern:format});
                                            } else {
                                                formattedValue = locale.format(date, {locale:this.locale, formatLength:"short", fullYear:true});
                                            }
                                        }
                                    } else {
                                        if (type == "xs:boolean") {
                                            formattedValue = value ? ecm.messages.true_label : ecm.messages.false_label;
                                        } else {
                                            if (type == "xs:decimal" || type == "xs:double") {
                                                var decimalPoint = this.getDecimalPoint();
                                                if (decimalPoint != ".") {
                                                    formattedValue = ("" + value).replace(".", decimalPoint);
                                                } else {
                                                    formattedValue = "" + value;
                                                }
                                            } else {
                                                formattedValue = "" + value;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return formattedValue;
        }, getDefaultFormat:function (type) {
            var format = null;
            var gregorian = this.gregorian;
            if (type == "xs:timestamp") {
                format = lang.replace(gregorian["dateTimeFormat-short"], [gregorian["timeFormat-short"], gregorian["dateFormat-short"]]);
            } else {
                if (type == "xs:date") {
                    format = gregorian["dateFormat-short"];
                } else {
                    if (type == "xs:time") {
                        format = gregorian["timeFormat-short"];
                    }
                }
            }
            if (format && format.indexOf("yy") >= 0 && format.indexOf("yyyy") < 0) {
                format = format.replace("yy", "yyyy");
            }
            return format;
        }, formatDate:function (date, options) {
            if (!options) {
                options = {formatLength:"short", fullYear:true};
            }
            options.locale = this.locale;
            return locale.format(date, options);
        }, parseDate:function (dateString, options) {
            if (!options) {
                options = {formatLength:"short", fullYear:true};
            }
            options.locale = this.locale;
            return locale.parse(dateString, options);
        }, getLocale:function () {
            return this.locale;
        }, formatPath:function (pathIn) {
            var formattedPathName = null;
            if (pathIn) {
                formattedPathName = BidiComplex.createDisplayString(pathIn, "FILE_PATH");
            }
            return formattedPathName;
        }});
    });
}, "ecm/model/admin/DataSourceConfig":function () {
    define(["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var DataSourceConfig = declare("ecm.model.admin.DataSourceConfig", [_ConfigurationObject], {NAME:"name", DESCRIPTION:"description", MODEL_CLASS:"modelClass", PLUGIN_ID:"pluginId", constructor:function (id, name) {
        }, getName:function () {
            return this.getValue(this.NAME);
        }, getDescription:function () {
            return this.getValue(this.DESCRIPTION);
        }, getModelClass:function () {
            return this.getValue(this.MODEL_CLASS);
        }, getPluginId:function () {
            return this.getValue(this.PLUGIN_ID);
        }, getDataSourceConfig:function (callback) {
            this.getConfig(callback);
        }});
        DataSourceConfig.createDataSourceConfig = function (id) {
            return new DataSourceConfig(id, "DataSourceConfig");
        };
        return DataSourceConfig;
    });
}, "ecm/model/_RecentSearchesMixin":function () {
    define("ecm/model/_RecentSearchesMixin", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/json", "./SearchTemplate", "./UnifiedSearchTemplate"], function (declare, lang, array, dojojson, SearchTemplate, UnifiedSearchTemplate) {
        return declare("ecm.model._RecentSearchesMixin", null, {constructor:function () {
            this._recentSearches = null;
        }, _getUserId:function () {
            var id = (this.isInstanceOf && this.isInstanceOf(ecm.model.Teamspace)) ? this.id + "-" : "";
            if (this.userId) {
                id += this.userId;
            } else {
                if (this.repository) {
                    id += this.repository.userId;
                }
            }
            if (id) {
                id.toLowerCase();
            }
            return id;
        }, _getRepository:function () {
            return (this.isInstanceOf && this.isInstanceOf(ecm.model.Repository)) ? this : (this.repository || null);
        }, _getUserConfigId:function () {
            return ecm.model.desktop.id + "." + this._getRepository().id + "." + this._getUserId();
        }, clearRecentSearches:function () {
            this._recentSearches = null;
        }, retrieveRecentSearches:function (callback) {
            if (this._recentSearches) {
                if (callback) {
                    callback(this._recentSearches);
                }
            } else {
                var params = {application:"navigator", configuration:"UserConfig", id:this._getUserConfigId(), action:"list", type:"recentSearches"};
                ecm.model.Request.postService("user", null, params, null, null, lang.hitch(this, function (response) {
                    this._retrieveRecentSearchesCompleted(response, callback);
                }));
            }
        }, _retrieveRecentSearchesCompleted:function (response, callback) {
            this._recentSearches = [];
            if (response.list) {
                array.forEach(response.list, function (data) {
                    if (!data.templateId) {
                        return;
                    }
                    var repository = this._getRepository();
                    if (repository) {
                        var id = data.templateId.toString();
                        var name = (data.name || "").toString();
                        var description = (data.description || "").toString();
                        var mimeType = data.mimeType;
                        var args = {id:id, name:name, repository:repository, description:description, mimetype:mimeType};
                        if (data.vsId) {
                            args.vsId = data.vsId;
                        }
                        var template = null;
                        if (mimeType == "application/x-unifiedsearchtemplate") {
                            template = new UnifiedSearchTemplate(args);
                        } else {
                            template = new SearchTemplate(args);
                        }
                        this._recentSearches.push(template);
                    }
                }, this);
            }
            if (callback) {
                callback(this._recentSearches);
            }
        }, addRecentSearch:function (search, callback) {
            var params = {application:"navigator", action:"add", configuration:"RecentSearchConfig", id:search.generateUUID(), update_list_configuration:"UserConfig", update_list_id:this._getUserConfigId(), update_list_type:"recentSearches"};
            var json = dojojson.toJson({templateId:search.id, name:search.name, description:search.description || "", vsId:search.vsId, mimeType:search.getContentType()});
            ecm.model.Request.postService("user", null, params, "text/json", json, lang.hitch(this, function (response) {
                this._addRecentSearchCompleted(response, callback);
            }));
        }, _addRecentSearchCompleted:function (response, callback) {
            this._retrieveRecentSearchesCompleted(response, callback);
            this.onRecentSearchAdded(this._recentSearches);
        }, onRecentSearchAdded:function (recentSearches) {
        }, removeRecentSearches:function (searches, callback) {
            if (!lang.isArray(this._recentSearches) || this._recentSearches.length < 1) {
                return;
            }
            var ids = [];
            array.forEach(searches, function (search) {
                var uuid = search.generateUUID();
                for (var i in this._recentSearches) {
                    if (uuid == this._recentSearches[i].generateUUID()) {
                        ids.push(search.vsId || search.id);
                        break;
                    }
                }
            }, this);
            if (ids.length < 1) {
                return;
            }
            var params = {application:"navigator", action:"deleteList", configuration:"RecentSearchConfig", id:"nexus", ids:dojojson.toJson(ids), update_list_configuration:"UserConfig", update_list_id:this._getUserConfigId(), update_list_type:"recentSearches"};
            ecm.model.Request.postService("user", null, params, null, null, lang.hitch(this, function (response) {
                this._removeRecentSearchesCompleted(response, callback);
            }));
        }, _removeRecentSearchesCompleted:function (response, callback) {
            this._retrieveRecentSearchesCompleted(response, callback);
            this.onRecentSearchesRemoved(this._recentSearches);
        }, onRecentSearchesRemoved:function (recentSearches) {
        }});
    });
}, "ecm/model/SearchClass":function () {
    define("ecm/model/SearchClass", ["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        return declare("ecm.model.SearchClass", [_ModelObject], {EDIT_PROPERTY:{EDITABLE:"editable", HIDDEN:"hidden", READONLY:"readonly"}, objectType:null, searchSubclasses:false, editProperty:"editable", itemId:"", selected:true, isReadOnly:function () {
            return this.editProperty == this.EDIT_PROPERTY.READONLY;
        }, isHidden:function () {
            return this.editProperty == this.EDIT_PROPERTY.HIDDEN;
        }, equals:function (searchClass) {
            return this.id == searchClass.id && this.objectType == searchClass.objectType && new Boolean(this.searchSubclasses).valueOf() == new Boolean(searchClass.searchSubclasses).valueOf() && new Boolean(this.selected).valueOf() == new Boolean(searchClass.selected).valueOf();
        }});
    });
}, "ecm/model/admin/UserActionMacroConfig":function () {
    define("ecm/model/admin/UserActionMacroConfig", ["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var UserActionMacroConfig = declare("ecm.model.admin.UserActionMacroConfig", [_ConfigurationObject], {NAME:"name", SERVER_TYPE:"serverType", USER_PROPERTY:"userProperty", DATE_PROPERTY:"dateProperty", RESERVED:"reserved", constructor:function (id, name) {
        }, getName:function () {
            return this.getValue(this.NAME);
        }, setName:function (name) {
            this.setValue(this.NAME, name);
        }, getServerType:function () {
            return this.getValue(this.SERVER_TYPE);
        }, setServerType:function (serverType) {
            this.setValue(this.SERVER_TYPE, serverType);
        }, getUserProperty:function () {
            return this.getValues(this.USER_PROPERTY);
        }, setUserProperty:function (userProperty) {
            this.setValue(this.USER_PROPERTY, userProperty);
        }, getDateProperty:function () {
            return this.getValues(this.DATE_PROPERTY);
        }, setDateProperty:function (dateProperty) {
            this.setValue(this.DATE_PROPERTY, dateProperty);
        }, getReserved:function () {
            return this.getValues(this.RESERVED);
        }, setReserved:function (reserved) {
            this.setValue(this.RESERVED, reserved);
        }});
        UserActionMacroConfig.createUserActionMacroConfig = function (id) {
            return new UserActionMacroConfig(id, "UserActionMacroConfig");
        };
        return UserActionMacroConfig;
    });
}, "ecm/model/AsyncTaskResultSet":function () {
    define("ecm/model/AsyncTaskResultSet", ["dojo/_base/declare", "dojo/data/util/sorter", "dojo/_base/lang", "./Request", "./ResultSet", "./Desktop"], function (declare, dojo_data_util_Sorter, lang, Request, ResultSet, Desktop) {
        return declare("ecm.model.AsyncTaskResultSet", [ResultSet], {setType:"asyncTask", repository:null, sortIndex:6, sortDirection:-1, constructor:function () {
            this.repository = ecm.model.desktop.getAuthenticatingRepository();
            if (this.setType == "asyncTask") {
                this.sortDirection = -1;
                this.sortIndex = 6;
            } else {
                if (this.setType == "asyncTaskInstance") {
                    this.sortDirection = -1;
                    this.sortIndex = 5;
                }
            }
        }, getActionsMenuItemsType:function (items) {
            return null;
        }, buildItems:function (jsonItemsArray, templates) {
            if (this.setType == "asyncTask") {
                var result = [];
                for (var i in jsonItemsArray) {
                    var itemJSON = jsonItemsArray[i];
                    var item = ecm.model.AsyncTask.createFromJSON(itemJSON);
                    item.resultSet = this;
                    item.parent = this.parentFolder;
                    result.push(item);
                }
                return result;
            } else {
                if (this.setType == "asyncTaskInstance") {
                    var result = [];
                    for (var i in jsonItemsArray) {
                        var itemJSON = jsonItemsArray[i];
                        var item = ecm.model.AsyncTaskInstance.createFromJSON(itemJSON);
                        item.resultSet = this;
                        item.parent = this.parentFolder;
                        result.push(item);
                    }
                    return result;
                } else {
                    return this.inherited(arguments);
                }
            }
        }, retrieveNextPage:function (retrievedCallback, itemsNeeded) {
            if (this.setType == "asyncTask") {
                var params = {};
                params["sortBy"] = this.columnNames ? this.columnNames[this.sortIndex - 1] : null;
                params["sortIndex"] = this.sortIndex;
                params["sortAsc"] = this.sortDirection;
                params["userId"] = this.userId;
                params["taskType"] = this.taskType;
                params["taskStatus"] = this.taskStatus;
                params["continuationData"] = this.continuationData;
                ecm.model.desktop.taskManager.retrieveAsyncTasks(params, lang.hitch(this, function (response) {
                    var moreItems = this.buildItems(response.rows, response.templates);
                    this.items = this.items.concat(moreItems);
                    this.continuationData = response.continuationData;
                    retrievedCallback(this.items);
                }));
            } else {
                if (this.setType == "asyncTaskInstance") {
                    this.parentFolder.refresh();
                    this.parentFolder.retrieveAsyncTaskInstances();
                }
            }
        }, refresh:function () {
            if (this.setType == "asyncTask") {
                var params = {};
                params["sortBy"] = this.columnNames ? this.columnNames[this.sortIndex - 1] : null;
                params["sortAsc"] = this.sortDirection;
                params["sortIndex"] = this.sortIndex;
                params["userId"] = this.userId;
                params["taskType"] = this.taskType;
                params["taskStatus"] = this.taskStatus;
                params["continuationData"] = "0";
                ecm.model.desktop.taskManager.retrieveAsyncTasks(params, lang.hitch(this, function (response) {
                    this.items = this.buildItems(response.rows, response.templates);
                    this.continuationData = response.continuationData;
                    this.sortIndex = response.sortIndex;
                    this.sortDirection = response.sortDirection;
                    this.maxResultsReached = response.maxResultsReached;
                    if (response.parentFolder) {
                        this.parentFolder = response.parentFolder;
                    }
                    this.onChange(this);
                }));
            } else {
                if (this.setType == "asyncTaskInstance") {
                    this.parentFolder.refresh();
                    this.parentFolder.retrieveAsyncTaskInstances();
                }
            }
        }, getToolbarDef:function () {
            if (this.toolbarDef) {
                return this.toolbarDef;
            } else {
                var toolbarDef = "ContentListToolbar";
                return toolbarDef;
            }
        }, doSort:function (params, callback, store) {
            if (params && params.colId && params.descending) {
                this.sortIndex = params.colId;
                this.sortDirection = params.descending == 0 ? 1 : -1;
            }
            var sortColumn = this.sortIndex > 0 ? this.columnNames[this.sortIndex - 1] : null;
            if (this.items && this.continuationData != "0" && sortColumn != "typeInternalIconColumn" && sortColumn != "statusInternalIconColumn") {
                if (params && store && this.items) {
                    this.items.sort(dojo_data_util_Sorter.createSortFunction(params, store));
                    if (callback) {
                        callback(this);
                    }
                }
            } else {
                this.refresh();
            }
        }});
    });
}, "ecm/model/admin/ApplicationConfig":function () {
    define(["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/json", "../Action", "../DataSource", "./_ConfigurationObject", "./PluginConfig", "./IconConfig", "./IconStatusConfig", "./SettingsConfig", "./ViewerConfig", "./ViewerDefConfig", "./ViewerContentTypeConfig", "./ViewerMappingConfig", "./ServerConfig", "./DesktopConfig", "./RepositoryConfig", "./DataSourceConfig", "./MenuConfig", "./MenuTypeConfig", "./InterfaceTextConfig", "./LocaleConfig", "./InterfaceTextLocaleConfig", "./InterfaceTextLabelConfig", "./MobileFeatureConfig", "./IdLabelConfig"], function (declare, lang, dojojson, Action, DataSource, _ConfigurationObject, PluginConfig, IconConfig, IconStatusConfig, SettingsConfig, ViewerConfig, ViewerDefConfig, ViewerContentTypeConfig, ViewerMappingConfig, ServerConfig, DesktopConfig, RepositoryConfig, DataSourceConfig, MenuConfig, MenuTypeConfig, InterfaceTextConfig, LocaleConfig, InterfaceTextLocaleConfig, InterfaceTextLabelConfig, MobileFeatureConfig, IdLabelConfig) {
        var ApplicationConfig = declare("ecm.model.admin.ApplicationConfig", [_ConfigurationObject], {PLUGINS:"plugins", DESKTOPS:"desktops", REPOSITORIES:"repositories", DATA_SOURCES:"dataSources", MENUS:"menus", VIEWERS:"viewers", SERVERS:"servers", DESKTOP:"desktop", OBJECT_EXPIRATION:"objectExpiration", THREAD_SLEEP_TIME:"threadSleepTime", _initialized:false, constructor:function (id, name) {
            this.serverObjects = [];
        }, getDesktopName:function () {
            return this.getValue(this.DESKTOP);
        }, getObjectExpiration:function () {
            return this.getValue(this.OBJECT_EXPIRATION);
        }, setObjectExpiration:function (value) {
            this.setValue(this.OBJECT_EXPIRATION, value);
        }, getSettingsConfigObject:function (callback) {
            var settingsConfig = SettingsConfig.createSettingsConfig("default");
            settingsConfig.getSettingsConfig(callback);
        }, getIconStatusObjects:function (callback) {
            var params = {};
            var request = ecm.model.Request.invokeService("getIconMapping", null, params, lang.hitch(this, function (response) {
                var defaultClasses = [];
                for (var i in response.iconStatusClasses) {
                    var iconStatusClassJSON = response.iconStatusClasses[i];
                    var iconStatusClassConfig = IdLabelConfig.createIdLabelConfig(iconStatusClassJSON.id);
                    iconStatusClassConfig.setLabel(iconStatusClassJSON.label);
                    defaultClasses.push(iconStatusClassConfig);
                }
                var iconStatuses = [];
                for (var i in response.iconStatus) {
                    var iconStatusJSON = response.iconStatus[i];
                    var id = iconStatusJSON.id;
                    var iconStatusConfig = IconStatusConfig.createIconStatusConfig(id);
                    iconStatusConfig.setClassName(iconStatusJSON.className);
                    iconStatusConfig.setFileName(iconStatusJSON.fileName);
                    iconStatusConfig.setServers(iconStatusJSON.servers);
                    iconStatusConfig.setLabel(iconStatusJSON.label);
                    iconStatuses.push(iconStatusConfig);
                }
                callback(iconStatuses, defaultClasses);
            }));
        }, getIconObjects:function (callback) {
            var params = {};
            var request = ecm.model.Request.invokeService("getIconMapping", null, params, lang.hitch(this, function (response) {
                var defaultContentTypes = [];
                for (var i in response.defaultContentTypes) {
                    var defaultContentType = response.defaultContentTypes[i];
                    defaultContentTypes.push(defaultContentType);
                }
                var defaultContentTypeClasses = [];
                for (var i in response.defaultContentTypeClasses) {
                    var jsonData = response.defaultContentTypeClasses[i];
                    var config = IdLabelConfig.createIdLabelConfig(jsonData.id);
                    config.setLabel(jsonData.label);
                    defaultContentTypeClasses.push(config);
                }
                var iconMappings = [];
                for (var i in response.iconMappings) {
                    var iconMappingJSON = response.iconMappings[i];
                    var id = iconMappingJSON.id;
                    var iconConfig = IconConfig.createIconConfig(id);
                    iconConfig.setClassName(iconMappingJSON.className);
                    iconConfig.setFileName(iconMappingJSON.fileName);
                    iconConfig.setContentTypes(iconMappingJSON.contentTypes);
                    iconMappings.push(iconConfig);
                }
                callback(iconMappings, defaultContentTypes, defaultContentTypeClasses);
            }));
        }, updateApplicationIconMapping:function (iconMimeMappingData, iconStatusData, callback) {
            var data = {"iconMimeMappingData":iconMimeMappingData, "iconStatusData":iconStatusData};
            var params = lang.mixin({action:"updateIconMapping", id:this.id, configuration:this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(data), lang.hitch(this, function (response) {
                if (callback) {
                    callback(response);
                }
            }));
            return this;
        }, updateFileTypesMapping:function (fileTypesMappingData, callback) {
            var data = {"fileTypesMappingData":fileTypesMappingData};
            var params = lang.mixin({action:"updateFileTypesMapping", id:this.id, configuration:this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(data), lang.hitch(this, function (response) {
                if (callback) {
                    callback(response);
                }
            }));
            return this;
        }, getPluginObjects:function (callback) {
            var pluginObjects = [];
            this.listConfig(this.PLUGINS, lang.hitch(this, function (list) {
                for (var i in list) {
                    var entry = list[i];
                    var id = entry.id ? entry.id : "" + i;
                    var plugin = PluginConfig.createPluginConfig(id);
                    lang.mixin(plugin, {_attributes:entry});
                    if (plugin.getName()) {
                        pluginObjects.push(plugin);
                    }
                }
                if (callback) {
                    callback(pluginObjects);
                }
            }));
        }, getServerObjects:function (callback) {
            if (this._serverObjects) {
                if (callback) {
                    callback(this._serverObjects, this._locales, this._localizeSettings);
                }
            } else {
                var params = {};
                var request = ecm.model.Request.invokeService("getServers", null, params, lang.hitch(this, function (response) {
                    var servers = [];
                    for (var i in response.servers) {
                        var jsonData = response.servers[i];
                        var serverConfig = ServerConfig.createServerConfig(jsonData.id);
                        lang.mixin(serverConfig, {_attributes:jsonData});
                        servers.push(serverConfig);
                    }
                    var locales = [];
                    for (var i in response.locales) {
                        var jsonData = response.locales[i];
                        var localeConfig = LocaleConfig.createLocaleConfig(jsonData.id);
                        localeConfig.setLabel(jsonData.label);
                        locales.push(localeConfig);
                    }
                    var localizeSettings = [];
                    for (var i in response.localizeSettings) {
                        var jsonData = response.localizeSettings[i];
                        var localeConfig = LocaleConfig.createLocaleConfig(jsonData.id);
                        localeConfig.setLabel(jsonData.label);
                        localizeSettings.push(localeConfig);
                    }
                    this._serverObjects = servers;
                    this._locales = locales;
                    this._localizeSettings = localizeSettings;
                    callback(servers, locales, this._localizeSettings);
                }));
            }
        }, getViewersObjects:function (callback) {
            var viewersObjects = [];
            this.listConfig(this.VIEWERS, lang.hitch(this, function (list) {
                for (var i in list) {
                    var entry = list[i];
                    var id = entry.id ? entry.id : "" + i;
                    var viewer = ViewerConfig.createViewerConfig(id);
                    lang.mixin(viewer, {_attributes:entry});
                    if (viewer.getName()) {
                        viewersObjects.push(viewer);
                    }
                }
                if (callback) {
                    callback(viewersObjects);
                }
            }), "true");
        }, getDefaultViewerData:function (callback) {
            if (this._viewerDefs && this._viewerContentTypes && this._defaultViewerMappings) {
                if (callback) {
                    callback(this._viewerDefs, this._viewerContentTypes, this._defaultViewerMappings);
                }
            } else {
                var self = this;
                var params = {"adminData":"true"};
                var request = ecm.model.Request.invokeService("getViewers", null, params, function (response) {
                    self._defaultViewerDataLoaded(response, callback);
                });
            }
        }, _defaultViewerDataLoaded:function (response, callback) {
            this._viewerDefs = [];
            for (var i in response.viewerDefs) {
                var viewerJSON = response.viewerDefs[i];
                var id = viewerJSON.id ? viewerJSON.id : "" + i;
                var viewerDef = ViewerDefConfig.createViewerDefConfig(id);
                lang.mixin(viewerDef, {_attributes:viewerJSON});
                this._viewerDefs.push(viewerDef);
            }
            this._viewerContentTypes = [];
            for (var i in response.viewerContentTypes) {
                var viewerJSON = response.viewerContentTypes[i];
                var id = viewerJSON.id ? viewerJSON.id : "" + i;
                var viewerContentType = ViewerContentTypeConfig.createViewerContentTypeConfig(id);
                lang.mixin(viewerContentType, {_attributes:viewerJSON});
                this._viewerContentTypes.push(viewerContentType);
            }
            this._defaultViewerMappings = [];
            for (var i in response.defaultViewerMappings) {
                var viewerJSON = response.defaultViewerMappings[i];
                var id = viewerJSON.id ? viewerJSON.id : "" + i;
                var viewerMapping = ViewerMappingConfig.createViewerMappingConfig(id);
                lang.mixin(viewerMapping, {_attributes:viewerJSON});
                this._defaultViewerMappings.push(viewerMapping);
            }
            if (callback) {
                callback(this._viewerDefs, this._viewerContentTypes, this._defaultViewerMappings);
            }
        }, getMimeAndStateIconObjects:function (callback) {
            var params = {};
            var request = ecm.model.Request.invokeService("getIconMapping", null, params, lang.hitch(this, function (response) {
                var iconMappings = [];
                for (var i in response.iconMappings) {
                    var iconMappingJSON = response.iconMappings[i];
                    var id = iconMappingJSON.id;
                    var iconConfig = IconConfig.createIconConfig(id);
                    iconConfig.setClassName(iconMappingJSON.className);
                    iconConfig.setFileName(iconMappingJSON.fileName);
                    iconConfig.setContentTypes(iconMappingJSON.contentTypes);
                    iconMappings.push(iconConfig);
                }
                var iconStates = [];
                for (var i in response.iconStatus) {
                    var iconStatusJSON = response.iconStatus[i];
                    var id = iconStatusJSON.id;
                    var iconStatusConfig = IconStatusConfig.createIconStatusConfig(id);
                    iconStatusConfig.setClassName(iconStatusJSON.className);
                    iconStatusConfig.setFileName(iconStatusJSON.fileName);
                    iconStatusConfig.setServers(iconStatusJSON.servers);
                    iconStatusConfig.setLabel(iconStatusJSON.label);
                    iconStates.push(iconStatusConfig);
                }
                callback(iconMappings, iconStates);
            }));
        }, getAllLabels:function (callback) {
            if (this.allLabels) {
                if (callback) {
                    callback(this.allLabels);
                }
            } else {
                var params = {action_id:"allLabels", firstLevelOnly:"true", sorted:"true"};
                var request = ecm.model.Request.invokeService("getActions", null, params, lang.hitch(this, function (response) {
                    var actions = [];
                    this._loadActions(response.actions, actions);
                    this.allLabels = actions;
                    if (callback) {
                        callback(this.allLabels);
                    }
                }));
            }
        }, _loadActions:function (actionsJSON, actions) {
            for (var i in actionsJSON) {
                var actionJSON = actionsJSON[i];
                var action = new Action(actionJSON);
                if (actionJSON.actions && actionJSON.actions.length > 0) {
                    this._loadActions(actionJSON.actions, action.subActions);
                }
                actions.push(action);
            }
        }, getRepositoryObjects:function (callback) {
            var repositoryObjects = [];
            this.listConfig(this.REPOSITORIES, lang.hitch(this, function (list) {
                for (var i in list) {
                    var entry = list[i];
                    var id = entry.id ? entry.id : "" + i;
                    var repository = RepositoryConfig.createRepositoryConfig(id);
                    lang.mixin(repository, {_attributes:entry});
                    if (repository.name) {
                        repositoryObjects.push(repository);
                    }
                }
                if (callback) {
                    callback(repositoryObjects);
                }
            }), "true");
        }, getDataSourceObjects:function (callback) {
            var dataSourceObjects = [];
            this.listConfig(this.DATA_SOURCES, lang.hitch(this, function (list) {
                for (var i in list) {
                    var entry = list[i];
                    var id = entry.id ? entry.id : "" + i;
                    var dataSource = DataSourceConfig.createDataSourceConfig(id);
                    lang.mixin(dataSource, {_attributes:entry});
                    if (dataSource.name) {
                        dataSourceObjects.push(dataSource);
                    }
                }
                if (callback) {
                    callback(dataSourceObjects);
                }
            }), "true");
        }, getMenuTypeObjects:function (callback) {
            if (this.allMenuTypes) {
                if (callback) {
                    callback(this.allMenuTypes);
                }
            } else {
                var params = {};
                var request = ecm.model.Request.invokeService("getMenuTypes", null, params, lang.hitch(this, function (response) {
                    var menuTypes = [];
                    for (var i in response.menuTypes) {
                        var menuTypeJSON = response.menuTypes[i];
                        var menuType = MenuTypeConfig.createMenuTypeConfig(menuTypeJSON.id);
                        lang.mixin(menuType, {_attributes:menuTypeJSON});
                        menuTypes.push(menuType);
                    }
                    this.allMenuTypes = menuTypes;
                    if (callback) {
                        callback(this.allMenuTypes);
                    }
                }));
            }
        }, getMenuObjects:function (callback) {
            var menuObjects = [];
            this.listConfig("menus", lang.hitch(this, function (list) {
                for (var i in list) {
                    var entry = list[i];
                    var id = entry.id ? entry.id : "" + i;
                    var menu = MenuConfig.createMenuConfig(id);
                    lang.mixin(menu, {_attributes:entry});
                    if (menu.getName()) {
                        menuObjects.push(menu);
                    }
                }
                if (callback) {
                    callback(menuObjects);
                }
            }), "true");
        }, getDesktopObjects:function (callback) {
            var desktopObjects = [];
            this.listConfig(this.DESKTOPS, lang.hitch(this, function (list) {
                for (var i in list) {
                    var entry = list[i];
                    var id = entry.id ? entry.id : "" + i;
                    var desktop = DesktopConfig.createDesktopConfig(id);
                    lang.mixin(desktop, {_attributes:entry});
                    if (desktop.getName()) {
                        desktopObjects.push(desktop);
                    }
                }
                if (callback) {
                    callback(desktopObjects);
                }
            }), "true");
        }, getUIApplicationLabelObjects:function (callback) {
            var params = {};
            var request = ecm.model.Request.invokeService("getUIApplicationLabels", null, params, lang.hitch(this, function (response) {
                var uiLabels = [];
                for (var i in response.uiLabels) {
                    var uiLabelJSON = response.uiLabels[i];
                    var id = uiLabelJSON.id;
                    var uiLabel = InterfaceTextConfig.createInterfaceTextConfig(id);
                    lang.mixin(uiLabel, {_attributes:uiLabelJSON});
                    var localeId = uiLabelJSON.localeData && uiLabelJSON.localeData.id ? uiLabelJSON.localeData.id : "" + i;
                    var uiLabelLocale = InterfaceTextLocaleConfig.createInterfaceTextLocaleConfig(localeId);
                    uiLabel.setLocaleData(uiLabelLocale);
                    if (uiLabelJSON.localeData) {
                        lang.mixin(uiLabelLocale, {_attributes:uiLabelJSON.localeData});
                    }
                    uiLabels.push(uiLabel);
                }
                callback(uiLabels);
            }));
        }, getInterfaceTextsObjects:function (callback) {
            var params = {};
            var request = ecm.model.Request.invokeService("getUILabels", null, params, lang.hitch(this, function (response) {
                var uiLabels = [];
                for (var i in response.uiLabels) {
                    var uiLabelJSON = response.uiLabels[i];
                    var id = uiLabelJSON.id;
                    var uiLabel = InterfaceTextConfig.createInterfaceTextConfig(id);
                    lang.mixin(uiLabel, {_attributes:uiLabelJSON});
                    var localeId = uiLabelJSON.localeData && uiLabelJSON.localeData.id ? uiLabelJSON.localeData.id : "" + i;
                    var uiLabelLocale = InterfaceTextLocaleConfig.createInterfaceTextLocaleConfig(localeId);
                    uiLabel.setLocaleData(uiLabelLocale);
                    if (uiLabelJSON.localeData) {
                        lang.mixin(uiLabelLocale, {_attributes:uiLabelJSON.localeData});
                    }
                    var uiLabelServerLabel = InterfaceTextLabelConfig.createInterfaceTextLabelConfig(localeId);
                    uiLabel.setLabelData(uiLabelServerLabel);
                    if (uiLabelJSON.labelData) {
                        lang.mixin(uiLabelServerLabel, {_attributes:uiLabelJSON.labelData});
                    }
                    uiLabels.push(uiLabel);
                }
                callback(uiLabels);
            }));
        }, addApplicationViewerConfig:function (viewerConfig, mapping, callback) {
            viewerConfig.addConfig(mapping, this.VIEWERS, callback);
            return this;
        }, addApplicationRepositoryConfig:function (repositoryConfig, callback) {
            repositoryConfig.addConfig(callback, this.name, this.id, this.REPOSITORIES);
            return this;
        }, addApplicationMenuConfig:function (menuConfig, callback) {
            menuConfig.addConfig(callback);
            return this;
        }, addApplicationPluginConfig:function (pluginConfig, callback) {
            this.allMenuTypes = null;
            this._defaultViewerMappings = null;
            pluginConfig.addConfig(callback, this.name, this.id, this.PLUGINS);
            return this;
        }, addApplicationDesktopConfig:function (desktopConfig, callback, desktopAccessConfig) {
            desktopConfig.addConfig(lang.hitch(this, function () {
                if (desktopAccessConfig) {
                    desktopAccessConfig.addConfig(callback);
                } else {
                    if (callback) {
                        callback();
                    }
                }
            }), this.name, this.id, this.DESKTOPS);
            return this;
        }, updateApplicationPluginConfig:function (pluginConfig, callback) {
            pluginConfig.updateConfig(callback);
            return this;
        }, updateApplicationSettingsConfig:function (settingsConfig, callback) {
            settingsConfig.updateConfig(callback);
            return this;
        }, updateApplicationDesktopConfig:function (desktopConfig, callback, desktopAccessConfig) {
            desktopConfig.updateConfig(lang.hitch(this, function (response) {
                if (desktopAccessConfig) {
                    desktopAccessConfig.updateConfig(callback);
                } else {
                    if (callback) {
                        callback();
                    }
                }
            }));
            return this;
        }, updateApplicationRepositoryConfig:function (repositoryConfig, callback) {
            repositoryConfig.updateConfig(callback);
            return this;
        }, updateApplicationViewerConfig:function (viewerConfig, mappingData, callback) {
            viewerConfig.updateConfig(mappingData, callback);
            return this;
        }, updateApplicationMenuConfig:function (menuConfig, callback) {
            menuConfig.updateMenuConfig(callback);
            return this;
        }, deleteApplicationRepositoriesConfig:function (repositoryConfigArray, callback) {
            this.deleteConfigs(repositoryConfigArray, this.REPOSITORIES, callback);
            return this;
        }, deleteApplicationViewersConfig:function (viewerConfigArray, callback) {
            viewerConfigArray[0].deleteConfigs(viewerConfigArray, this.VIEWERS, callback);
            return this;
        }, deleteApplicationMenusConfig:function (menuConfigArray, callback) {
            menuConfigArray[0].deleteConfigs(menuConfigArray, this.MENUS, callback);
            return this;
        }, deleteApplicationPluginsConfig:function (pluginConfigArray, callback) {
            this.allMenuTypes = null;
            this._defaultViewerMappings = null;
            this.deleteConfigs(pluginConfigArray, this.PLUGINS, callback);
            return this;
        }, deleteApplicationDesktopsConfig:function (desktopConfigArray, callback) {
            this.deleteConfigs(desktopConfigArray, this.DESKTOPS, callback);
            return this;
        }, getApplicationConfig:function (callback) {
            var func = lang.hitch(this, function (obj) {
                this._initialized = true;
                if (callback) {
                    callback(obj);
                }
            });
            this.getConfig(func);
            return this;
        }, getFeaturesList:function (desktopId, callback) {
            var featureObjects = [];
            var params = lang.mixin({action:"list", id:desktopId, type:"mobileFeatures", sorted:false, configuration:"DesktopConfig"}, this.default_params);
            var self = this;
            var request = ecm.model.Request.invokeService(this.action, null, params, function (response) {
                var list = response.list;
                for (var i in list) {
                    var entry = list[i];
                    var id = entry.id ? entry.id : "" + i;
                    var feature = MobileFeatureConfig.createMobileFeatureConfig(id);
                    lang.mixin(feature, {_attributes:entry});
                    featureObjects.push(feature);
                }
                if (callback) {
                    callback(featureObjects);
                }
            });
        }, exportConfiguration:function (data, callback) {
            var featureObjects = [];
            var params = lang.mixin({action:"export", id:this.id, application:this.id, configuration:this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/importExport", null, params, "text/json", dojojson.toJson(data), lang.hitch(this, function (response) {
                if (callback) {
                    callback(response);
                }
            }));
        }, updateApplicationObjectExpiration:function (objectExpiration, callback) {
            var data = {"objectExpiration":objectExpiration};
            var params = lang.mixin({action:"updateObjectExpiration", id:this.id, configuration:this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(data), lang.hitch(this, function (response) {
                if (callback) {
                    callback(response);
                }
            }));
            return this;
        }, isInitialized:function () {
            return this._initialized;
        }});
        ecm.model.admin.appCfg = new ApplicationConfig("navigator", "ApplicationConfig");
        return ecm.model.admin.appCfg;
    });
}, "ecm/model/Message":function () {
    define(["dojo/_base/declare", "dojo/string", "./_ModelObject"], function (declare, string, _ModelObject) {
        var MessageFactory = declare("ecm.model.Message", [_ModelObject], {number:0, level:0, text:"", explanation:"", userResponse:"", adminResponse:"", moreInformation:"", messageProductId:"", backgroundRequest:false});
        MessageFactory.createErrorMessage = function (messagePrefix, inserts, backgroundRequest) {
            inserts = inserts || [];
            var message = {id:"id???", number:ecm.messages[messagePrefix + "_number"], level:4, text:ecm.messages[messagePrefix] ? string.substitute(ecm.messages[messagePrefix], inserts) : messagePrefix, explanation:ecm.messages[messagePrefix + "_explanation"] ? string.substitute(ecm.messages[messagePrefix + "_explanation"], inserts) : "", userResponse:ecm.messages[messagePrefix + "_userResponse"] ? string.substitute(ecm.messages[messagePrefix + "_userResponse"], inserts) : "", adminResponse:ecm.messages[messagePrefix + "_adminResponse"] ? string.substitute(ecm.messages[messagePrefix + "_adminResponse"], inserts) : "", messageProductId:"CIWEB", backgroundRequest:backgroundRequest};
            return new MessageFactory(message);
        };
        return MessageFactory;
    });
}, "ecm/model/admin/InterfaceTextLabelConfig":function () {
    define("ecm/model/admin/InterfaceTextLabelConfig", ["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var InterfaceTextLabelConfig = declare("ecm.model.admin.InterfaceTextLabelConfig", [_ConfigurationObject], {ID:"id", constructor:function (id, name) {
        }, hasLabelData:function () {
            return this.getValue("en") != undefined;
        }, getId:function () {
            return this.getValue(this.ID);
        }});
        InterfaceTextLabelConfig.createInterfaceTextLabelConfig = function (id) {
            return new InterfaceTextLabelConfig(id, "InterfaceTextLabelConfig");
        };
        return InterfaceTextLabelConfig;
    });
}, "ecm/model/Directory":function () {
    define("ecm/model/Directory", ["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        return declare("ecm.model.Directory", [_ModelObject], {});
    });
}, "ecm/model/admin/RepositoryConfig":function () {
    define("ecm/model/admin/RepositoryConfig", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/json", "ecm/model/admin/RepositoryReadConfig", "ecm/model/admin/PropertyMappingConfig"], function (declare, lang, dojojson, RepositoryReadConfig, PropertyMappingConfig) {
        var RepositoryConfig = declare("ecm.model.admin.RepositoryConfig", [RepositoryReadConfig], {connected:false, constructor:function (id, name, action) {
        }, setIncludeMIMETypesInSearchResults:function (includeMIMETypesInSearchResults) {
            this.setValue(this.INCLUDE_MIME_TYPES_IN_SEARCH_RESULTS, includeMIMETypesInSearchResults);
        }, setPdfConversion:function (pdfConversion) {
            this.setValue(this.PDF_CONVERSION, pdfConversion);
        }, setKeepInAutoFolder:function (keepInAutoFolder) {
            this.setValue(this.KEEP_IN_AUTO_FOLDER, keepInAutoFolder);
        }, setUpdateStorageCollection:function (updateStorageCollection) {
            this.setValue(this.UPDATE_STORAGE_COLLECTION, updateStorageCollection);
        }, setMaxWorklists:function (maxWorklists) {
            this.setValue(this.MAX_WORKLISTS, maxWorklists);
        }, setMaxItemTypes:function (maxItemTypes) {
            this.setValue(this.MAX_ITEM_TYPES, maxItemTypes);
        }, setLanguageCodes:function (languageCodes) {
            this.setValue(this.LANGUAGE_CODES, languageCodes);
        }, setRootFolderId:function (rootFolderId) {
            this.setValue(this.ROOT_FOLDER_ID, rootFolderId);
        }, setMaxResults:function (maxResults) {
            this.setValue(this.MAX_RESULTS, maxResults);
        }, setUseSSO:function (useSSO) {
            this.setValue(this.USE_SSO, useSSO);
        }, setDirectRetrieveEnabled:function (directRetrieveEnabled) {
            this.setValue(this.DIRECT_RETRIEVE_ENABLED, directRetrieveEnabled);
        }, setConnectionPoint:function (connectionPoint) {
            this.setValue(this.CONNECTION_POINT, connectionPoint);
        }, setObjectStore:function (objectStore) {
            this.setValue(this.OBJECT_STORE, objectStore);
        }, setCMISReposID:function (cmisReposID) {
            this.setValue(this.CMIS_REPOS_ID, cmisReposID);
        }, setUseGzipEncoding:function (useGzipEncoding) {
            this.setValue(this.USE_GZIP_ENCODING, useGzipEncoding);
        }, setObjectStoreDisplayName:function (objectStore) {
            this.setValue(this.OBJECT_STORE_DISPLAY_NAME, objectStore);
        }, setProtocol:function (protocol) {
            this.setValue(this.PROTOCOL, protocol);
        }, setAddAsMajorVersion:function (addAsMajorVersion) {
            this.setValue(this.ADD_AS_MAJOR_VERSION, addAsMajorVersion);
        }, setCheckinAsMajorVersion:function (checkinAsMajorVersion) {
            this.setValue(this.CHECKIN_AS_MAJOR_VERSION, checkinAsMajorVersion);
        }, setIncludeWorkflowDefinition:function (includeWorkflowDefinition) {
            this.setValue(this.INCLUDE_WORKFLOW_DEFINITION, includeWorkflowDefinition);
        }, setAnnotationSecurity:function (annotationSecurity) {
            this.setValue(this.ANNOTATION_SECURITY, annotationSecurity);
        }, setFolderSearchExpression:function (folderSearchExpression) {
            this.setValue(this.FOLDER_SEARCH_EXPRESSION, folderSearchExpression);
        }, setMaxHits:function (maxHits) {
            this.setValue(this.MAX_HITS, maxHits);
        }, setMaxFolders:function (maxFolders) {
            this.setValue(this.MAX_FOLDERS, maxFolders);
        }, setAfp2PdfConfigFile:function (afp2PdfConfigFile) {
            this.setValue(this.AFP2PD_CONFIG_FILE, afp2PdfConfigFile);
        }, setTransformXMLFile:function (transformXMLFile) {
            this.setValue(this.XFORM_XML_FILE, transformXMLFile);
        }, setODSSL:function (odSSL) {
            this.setValue(this.OD_SSL, odSSL);
        }, setODKeyringDBFile:function (odKeyringDBFile) {
            this.setValue(this.OD_KEYRING_DBFILE, odKeyringDBFile);
        }, setODKeyringStashFile:function (odKeyringStashFile) {
            this.setValue(this.OD_KEYRING_STASHFILE, odKeyringStashFile);
        }, setCustomProperties:function (customProps) {
            this.setValue(this.CUSTOM_PROPS, customProps);
        }, setAfp2PdInstallDirectory:function (afp2PdfInstallDir) {
            this.setValue(this.AFP2PD_INSTALL_DIR, afp2PdfInstallDir);
        }, setLanguage:function (language) {
            this.setValue(this.LANGUAGE, language);
        }, setTempDir:function (tempDir) {
            this.setValue(this.TEMP_DIR, tempDir);
        }, setTraceDir:function (traceDir) {
            this.setValue(this.TRACE_DIR, traceDir);
        }, setTraceLevel:function (traceLevel) {
            this.setValue(this.TRACE_LEVEL, traceLevel);
        }, setPortNumber:function (portNumber) {
            this.setValue(this.PORT_NUMBER, portNumber);
        }, setMaxInMemoryRetrieveSize:function (maxInMemoryRetrieveSize) {
            this.setValue(this.MAX_IN_MEMORY_RETRIEVE_SIZE, maxInMemoryRetrieveSize);
        }, setMaxDownloadSize:function (maxDownloadSize) {
            this.setValue(this.MAX_DOWNLOAD_SIZE, maxDownloadSize);
        }, setTimestampFormat:function (timestampFormat) {
            this.setValue(this.TIMESTAMP_FORMAT, timestampFormat);
        }, setTimeFormat:function (timeFormat) {
            this.setValue(this.TIME_FORMAT, timeFormat);
        }, setDateFormat:function (dateFormat) {
            this.setValue(this.DATE_FORMAT, dateFormat);
        }, setTeamspacesEnabled:function (teamspacesEnabled) {
            this.setValue(this.TEAMSPACES_ENABLED, teamspacesEnabled);
        }, setUnifiedSearchesEnabled:function (unifiedSearchesEnabled) {
            this.setValue(this.UNIFIED_SEARCHES_ENABLED, unifiedSearchesEnabled);
        }, setSearchMaxResults:function (searchMaxResults) {
            this.setValue(this.SEARCH_MAX_RESULTS, searchMaxResults);
        }, setTimeoutInSeconds:function (timeoutInSeconds) {
            this.setValue(this.TIMEOUT_IN_SECONDS, timeoutInSeconds);
        }, setServerName:function (serverName) {
            this.setValue(this.SERVER_NAME, serverName);
        }, setDocNameProperty:function (docNameProp) {
            this.setValue(this.DOC_NAME_PROPERTY, docNameProp);
        }, setFolderNameProperty:function (folderNameProp) {
            this.setValue(this.FOLDER_NAME_PROPERTY, folderNameProp);
        }, setFolderDefaultColumns:function (folderDefCols) {
            return this.setValues(this.FOLDER_DEF_COLS, folderDefCols);
        }, setFolderMagazineDefaultColumns:function (folderDefCols) {
            return this.setValues(this.FOLDER_MAGAZINE_DEF_COLS, folderDefCols);
        }, setSearchMagazineDefaultColumns:function (searchDefCols) {
            return this.setValues(this.SEARCH_MAGAZINE_DEF_COLS, searchDefCols);
        }, setSearchDefaultColumns:function (searchDefCols) {
            return this.setValues(this.SEARCH_DEF_COLS, searchDefCols);
        }, setSearchFilteredDocumentProperties:function (searchProperties) {
            return this.setValues(this.SEARCH_FILTERED_DOCUMENT_PROPERTIES, searchProperties);
        }, setSearchFilteredFolderProperties:function (searchProperties) {
            return this.setValues(this.SEARCH_FILTERED_FOLDER_PROPERTIES, searchProperties);
        }, setMatchAll:function (matchAll) {
            this.setValue(this.MATCH_ALL, matchAll);
        }, setType:function (type) {
            this.setValue(this.TYPE, type);
        }, setDocumentSystemProperties:function (documentSystemProps) {
            return this.setValues(this.DOCUMENT_SYSTEM_PROPERTIES, documentSystemProps);
        }, setFolderSystemProperties:function (folderSystemProps) {
            return this.setValues(this.FOLDER_SYSTEM_PROPERTIES, folderSystemProps);
        }, setStatusDocNotes:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_DOC_NOTES, (bool ? "true" : "false"));
        }, setStatusDocHold:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_DOC_HOLD, (bool ? "true" : "false"));
        }, setStatusDocCheckedOut:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_DOC_CHECKED_OUT, (bool ? "true" : "false"));
        }, setStatusDocBookmarks:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_DOC_BOOKMARKS, (bool ? "true" : "false"));
        }, setStatusDocDeclaredRecord:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_DOC_DECLARED_RECORD, (bool ? "true" : "false"));
        }, setStatusDocMinorVersions:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_DOC_MINOR_VERSIONS, (bool ? "true" : "false"));
        }, setStatusWorkItemCheckedOut:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_WORK_ITEM_CHECKED_OUT, (bool ? "true" : "false"));
        }, setStatusWorkItemLocked:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_WORK_ITEM_LOCKED, (bool ? "true" : "false"));
        }, setStatusWorkItemSuspended:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_WORK_ITEM_SUSPENDED, (bool ? "true" : "false"));
        }, setStatusWorkItemDeadline:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.STATUS_WORK_ITEM_DEADLINE, (bool ? "true" : "false"));
        }, setFolderingEnabled:function (bool) {
            bool = (bool === true || bool == "true");
            this.setValue(this.FOLDERING_ENABLED, (bool ? "true" : "false"));
        }, setTempId:function (tempId) {
            this.tempId = tempId;
        }, setName:function (name) {
            this.setValue(this.NAME, name);
        }, setSearchFilteredOperators:function (type, values) {
            this.setValues(type, values);
        }, setConnected:function (connected) {
            this.connected = connected;
        }, setDefaultEmailClassForAdd:function (value) {
            this.setValue(this.DEFAULT_EMAIL_CLASS_FOR_ADD, value);
        }, setDefaultFolderClassForAdd:function (value) {
            this.setValue(this.DEFAULT_FOLDER_CLASS_FOR_ADD, value);
        }, getPropertiesMapping:function (callback) {
            var propertiesMappingObjects = [];
            this.listConfig("propertiesMapping", lang.hitch(this, function (list) {
                for (var i in list) {
                    var entry = list[i];
                    var id = entry.id ? entry.id : "" + i;
                    var propertyMapping = PropertyMappingConfig.createPropertyMappingConfig(id);
                    lang.mixin(propertyMapping, {_attributes:entry});
                    propertiesMappingObjects.push(propertyMapping);
                }
                if (callback) {
                    callback(propertiesMappingObjects);
                }
            }), "true");
        }, updatePropertiesMapping:function (propertiesMappingData, callback) {
            var data = {"propertiesMappingData":propertiesMappingData};
            var params = lang.mixin({action:"updatePropertiesMapping", id:this.id, configuration:this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(data), lang.hitch(this, function (response) {
                if (callback) {
                    callback(response);
                }
            }));
            return this;
        }});
        RepositoryConfig.createRepositoryConfig = function (id) {
            return new RepositoryConfig(id, "RepositoryConfig", "admin/configuration");
        };
        RepositoryConfig.getDefaultRepositoryConfig = function (type, callback) {
            var repositoryConfig = RepositoryConfig.createRepositoryConfig(type + "defaultsettings");
            repositoryConfig.getConfig(function (response) {
                response.id = null;
                if (callback) {
                    callback(response);
                }
            });
        };
        return RepositoryConfig;
    });
}, "ecm/model/Comment":function () {
    define("ecm/model/Comment", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/window", "dojo/dom-construct", "./Request", "./Item", "./ContentItem"], function (declare, lang, win, domConstruct, Request, Item, ContentItem) {
        var Comment = declare("ecm.model.Comment", [Item], {contentItem:null, getCommentTextNode:function () {
            var textNode = win.doc.createDocumentFragment();
            var text = this.getValue("commentText");
            if (text) {
                var text = text.replace("\r\n", "\n");
                var textParts = text.split("\n");
                for (var i = 0; i < textParts.length; i++) {
                    textNode.appendChild(win.doc.createTextNode(textParts[i]));
                    if (i < textParts.length - 1) {
                        domConstruct.create("br", null, textNode);
                    }
                }
            }
            return textNode;
        }, getCommentText:function () {
            return this.getValue("commentText");
        }, setCommentText:function (commentText) {
            this.setValue("commentText", commentText);
        }, getOriginatorShortName:function () {
            return this.getValue("originator");
        }, getOriginatorDisplayName:function () {
            var name = this.getDisplayValue("originator");
            if (!name) {
                name = this.getValue("originator");
            }
            return name;
        }, getDateAdded:function (isoDate) {
            var date = this.getDisplayValue("dateAdded");
            if (!date) {
                date = this.getValue("dateAdded");
            }
            return date;
        }, getItemVersion:function () {
            return this.getValue("itemVersion");
        }, isMyComment:function () {
            var commenter = this.getOriginatorShortName();
            if (!this.repository || !commenter) {
                return true;
            }
            return commenter == this.repository.userId;
        }, isCommentEditable:function () {
            return this.hasPrivilege("commentEditable");
        }, isCommentDeletable:function () {
            return this.hasPrivilege("commentDeletable");
        }, saveComment:function (callback, errorback) {
            var methodName = "saveComment";
            if (!this.contentItem || !this.contentItem.id) {
                return;
            }
            if (!this.id && !this.contentItem.isCommentable() || this.id && (!this.isCommentEditable() || !this.isMyComment())) {
                return;
            }
            this._saveComment(callback, errorback);
        }, _saveComment:function (callback, errorback) {
            var methodName = "_saveComment";
            var text = this.getCommentText();
            Request.invokeService("saveComment", this.repository.type, {repositoryId:this.repository.id, id:this.id, itemId:this.contentItem.id, commentText:text}, lang.hitch(this, function (response) {
                var c = Comment.createFromJSON(response.savedComment, this.contentItem, null);
                lang.mixin(this, c);
                this._actionCompleted(response, callback);
            }), false, false, lang.hitch(this, function (response) {
                if (lang.isFunction(errorback)) {
                    errorback(response);
                }
            }));
        }, deleteComment:function (callback, errorback) {
            var methodName = "deleteComment";
            if (!this.id || !this.contentItem || !this.contentItem.id || !this.isCommentDeletable()) {
                return;
            }
            this._deleteComment(callback, errorback);
        }, _deleteComment:function (callback, errorback) {
            var methodName = "_deleteComment";
            Request.invokeService("deleteComment", this.repository.type, {repositoryId:this.repository.id, id:this.id, itemId:this.contentItem.id}, lang.hitch(this, function (response) {
                this._actionCompleted(response, callback);
            }), false, false, lang.hitch(this, function (response) {
                if (lang.isFunction(errorback)) {
                    errorback(response);
                }
            }));
        }, _actionCompleted:function (response, callback) {
            response.repository = this.contentItem.repository;
            response.contentItem = this.contentItem;
            response.setType = "comment";
            if (lang.isFunction(callback)) {
                callback(this, response);
            }
            this.onChange();
        }, onChange:function () {
            this.contentItem.onChange(this.contentItem);
        }, getDisplayValue:function (attribute) {
            if (attribute == "itemCurrentVersion") {
                return this.getValue(attribute);
            }
            return this.inherited(arguments);
        }});
        Comment.createFromJSON = function (commentJSON, contentItem, resultSet) {
            var comment = new Comment(commentJSON);
            var attributes = {};
            var attributeTypes = {};
            var attributeFormats = {};
            var attributeDisplayValues = {};
            for (var i in commentJSON.attributes) {
                var attr = commentJSON.attributes[i];
                attributes[i] = attr[0];
                if (attr.length > 1) {
                    attributeTypes[i] = attr[1];
                }
                if (attr.length > 2 && attr[2] != null) {
                    attributeFormats[i] = attr[2];
                }
                if (attr.length > 3 && attr[3] != null) {
                    attributeDisplayValues[i] = attr[3];
                }
            }
            lang.mixin(comment, {repository:contentItem.repository, resultSet:resultSet, contentItem:contentItem, attributes:attributes, attributeTypes:attributeTypes, attributeFormats:attributeFormats, attributeDisplayValues:attributeDisplayValues});
            return comment;
        };
        return Comment;
    });
}, "ecm/model/AttributeDefinition":function () {
    define("ecm/model/AttributeDefinition", ["dojo/_base/declare", "dojo/_base/lang", "./_ModelObject", "./_AttributeMixin"], function (declare, lang, _ModelObject, _AttributeMixin) {
        var AttributeDefinition = declare("ecm.model.AttributeDefinition", [_ModelObject, _AttributeMixin], {repositoryType:null, dataType:"xs:string", format:"", defaultValue:"", required:false, cardinality:"SINGLE", uniqueValues:false, requiredClass:null, choiceList:null, readOnly:false, hidden:false, system:false, settability:"readWrite", allowedValues:null, maxLength:undefined, minLength:undefined, minValue:undefined, maxValue:undefined, contentClass:null, searchable:true, textSearchable:false, nullable:true, hasDependentAttributes:false, usesLongColumn:false, formatDescription:"", orderable:true, markingList:null, subClassAttribute:false, foreignKey:null, openChoice:false, constructor:function () {
            if (!this.format) {
                this.format = ecm.model.desktop.valueFormatter.getDefaultFormat(this.dataType);
            } else {
                if (this.dataType == "xs:date" && this.format == "%m/%d/%y") {
                    this.format = "MM/dd/yy";
                }
            }
            if (this.markingList) {
                this._fillInChoiceListDisplayNames(this.markingList);
            } else {
                if (this.choiceList) {
                    this._fillInChoiceListDisplayNames(this.choiceList);
                }
            }
        }, _fillInChoiceListDisplayNames:function (choiceList) {
            for (var i in choiceList.choices) {
                var choice = choiceList.choices[i];
                if (choice.choices) {
                    this._fillInChoiceListDisplayNames(choice.choices);
                } else {
                    if (choice.displayName) {
                    } else {
                        choice.displayName = ecm.model.desktop.valueFormatter.formatValue(choice.value, this.dataType, this.format);
                    }
                }
            }
        }, clone:function () {
            var thisClone = new ecm.model.AttributeDefinition({id:this.id, name:this.name});
            for (var prop in this) {
                if (this.hasOwnProperty(prop)) {
                    if (prop == "contentClass") {
                        thisClone[prop] = this[prop];
                    } else {
                        thisClone[prop] = lang.clone(this[prop]);
                    }
                }
            }
            return thisClone;
        }, setMetaData:function (metaName, metaData) {
            if (!this.metaData) {
                this.metaData = {};
            }
            this.metaData[metaName] = metaData;
        }, getMetaData:function (metaName) {
            if (this.metaData) {
                return this.metaData[metaName];
            } else {
                return null;
            }
        }, isNumeric:function () {
            return this.dataType && (this.dataType == "xs:decimal" || this.dataType == "xs:double" || this.dataType == "xs:short" || this.dataType == "xs:integer" || this.dataType == "xs:long");
        }, isDateTime:function () {
            return this.dataType && (this.dataType == "xs:date" || this.dataType == "xs:time" || this.dataType == "xs:timestamp");
        }});
        AttributeDefinition.isValueEmpty = function (value) {
            if (value == null) {
                return true;
            } else {
                if (typeof value == "string" || value instanceof String) {
                    return (value == "");
                } else {
                    if (value instanceof Array || (value.propertyIsEnumerable("length") && (typeof value === "object") && (typeof value.length === "number"))) {
                        if (value.length == 0) {
                            return true;
                        }
                        if (value.length == 1) {
                            return AttributeDefinition.isValueEmpty(value[0]);
                        }
                    }
                }
            }
            return false;
        };
        return AttributeDefinition;
    });
}, "ecm/model/admin/_ConfigurationObject":function () {
    define(["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/json", "../_ModelObject"], function (declare, lang, dojojson, _ModelObject) {
        return declare("ecm.model.admin._ConfigurationObject", [_ModelObject], {action:"admin/configuration", default_params:{application:"navigator"}, constructor:function (id, name, action) {
            this._attributes = {};
            if (action) {
                this.action = action;
            }
        }, setAction:function (action) {
            if (action) {
                this.action = action;
            }
        }, getValue:function (attribute) {
            if (this._attributes) {
                return this._attributes[attribute];
            }
        }, getValues:function (attribute) {
            if (this._attributes) {
                var v = this._attributes[attribute];
                if (lang.isArray(v)) {
                    return v;
                } else {
                    if (v) {
                        return [v];
                    }
                }
            }
        }, setValue:function (attribute, value) {
            this._attributes[attribute] = value;
        }, setValues:function (attribute, values) {
            this._attributes[attribute] = values;
        }, hasAttribute:function (attribute) {
            return (typeof this._attributes[attribute] != "undefined");
        }, getAttributes:function () {
            return this._attributes;
        }, isEmpty:function () {
            var count = 0;
            if (this._attributes) {
                for (var property in this._attributes) {
                    if (this._attributes.hasOwnProperty(property)) {
                        count++;
                    }
                }
            }
            return (count <= 1);
        }, listConfig:function (type, callback, sorted) {
            if (sorted == undefined) {
                sorted = "false";
            }
            var params = lang.mixin({action:"list", id:this.id, type:type, sorted:sorted, configuration:this.name}, this.default_params);
            var self = this;
            var request = ecm.model.Request.invokeService(this.action, null, params, function (response) {
                if (callback) {
                    callback(response.list);
                }
            });
            return self;
        }, getConfig:function (callback, synchronous) {
            var params = lang.mixin({action:"get", id:this.id, configuration:this.name}, this.default_params);
            var self = this;
            var request = ecm.model.Request.invokeService(this.action, null, params, function (response) {
                lang.mixin(self, {_attributes:response.configuration});
                if (callback) {
                    callback(self);
                }
            }, false, synchronous);
            return self;
        }, getUniqueConfig:function (callback) {
            var params = lang.mixin({action:"get", id:this.id, configuration:this.name, operator:"unique"}, this.default_params);
            var self = this;
            var request = ecm.model.Request.invokeService(this.action, null, params, function (response) {
                lang.mixin(self, {_attributes:response.configuration});
                if (callback) {
                    callback(self);
                }
            });
            return self;
        }, addConfig:function (callback, updateListConfig, updateListId, updateListType) {
            var params = lang.mixin({action:"add", id:this.id, configuration:this.name}, this.default_params);
            if (updateListConfig && updateListId && updateListType) {
                params.update_list_configuration = updateListConfig;
                params.update_list_id = updateListId;
                params.update_list_type = updateListType;
            }
            var request = ecm.model.Request.postService(this.action, null, params, "text/json", JSON.stringify(this._attributes, null), function (response) {
                if (callback) {
                    callback(response);
                }
            });
            return this;
        }, updateConfig:function (callback) {
            var params = lang.mixin({action:"update", id:this.id, configuration:this.name}, this.default_params);
            var request = ecm.model.Request.postService(this.action, null, params, "text/json", JSON.stringify(this._attributes, null), function (response) {
                if (callback) {
                    callback(response);
                }
            });
            return this;
        }, deleteConfigs:function (configs, name, callback) {
            var ids = [];
            for (var i in configs) {
                ids.push(configs[i].id);
            }
            var params = lang.mixin({action:"deleteList", ids:dojojson.toJson(ids), id:this.id, configuration:configs[0].name, update_app_configuration_type:name}, this.default_params);
            var request = ecm.model.Request.invokeService(this.action, null, params, function (response) {
                if (callback) {
                    callback(response);
                }
            });
            return this;
        }, deleteConfig:function (callback) {
            var params = lang.mixin({action:"delete", id:this.id, configuration:this.name}, this.default_params);
            var request = ecm.model.Request.invokeService(this.action, null, params, function (response) {
                if (callback) {
                    callback(response);
                }
            });
            return this;
        }});
    });
}, "ecm/model/admin/ViewerContentTypeConfig":function () {
    define(["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var ViewerContentTypeConfig = declare("ecm.model.admin.ViewerContentTypeConfig", [_ConfigurationObject], {CONTENT_TYPE:"contentType", VIEWERS:"viewers", constructor:function (id, name) {
        }, getContentType:function () {
            return this.getValue(this.CONTENT_TYPE);
        }, setContentType:function (contentType) {
            this.setValue(this.CONTENT_TYPE, contentType);
        }, getViewers:function () {
            var viewers = this.getValue(this.VIEWERS);
            if (viewers instanceof Array) {
                return viewers;
            } else {
                if (viewers) {
                    return [viewers];
                } else {
                    return [];
                }
            }
        }, setViewers:function (viewers) {
            this.setValue(this.VIEWERS, viewers);
        }, supportsViewer:function (viewerID) {
            var array = this.getViewers();
            if (array) {
                for (var i in array) {
                    if (array[i] == viewerID) {
                        return true;
                    }
                }
            }
            return false;
        }});
        ViewerContentTypeConfig.createViewerContentTypeConfig = function (id) {
            return new ViewerContentTypeConfig(id, "ViewerContentTypeConfig");
        };
        return ViewerContentTypeConfig;
    });
}, "ecm/model/SecurityTemplate":function () {
    define(["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        return declare("ecm.model.SecurityTemplate", [_ModelObject], {applyStateId:null, isEnabled:false, permissions:null});
    });
}, "ecm/model/TaskManager":function () {
    define("ecm/model/TaskManager", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/json", "./_ModelObject", "./Desktop", "./Request", "./AsyncTaskResultSet"], function (declare, lang, dojo_json, ModelObject, Desktop, Request, AsyncTaskResultSet) {
        var TaskManager = declare("ecm.model.TaskManager", [ModelObject], {taskSecurityRoles:null, serviceURL:null, retrieveAsyncTasks:function (parameters, callback) {
            var params = {requestParams:{}};
            lang.mixin(params.requestParams, parameters);
            params.requestCompleteCallback = lang.hitch(this, function (response) {
                if (callback) {
                    callback(response);
                }
            });
            Request.postServiceAPI("getAsyncTasks", null, "text/json", params);
        }, scheduleAsyncTask:function (schedule, handlerClassName, parameters, data, callback) {
            var params = {requestParams:{}, requestBody:{}};
            params.requestParams["isRecurring"] = schedule.recurring;
            params.requestParams["repeatCycle"] = schedule.interval;
            params.requestParams["startTime"] = schedule.startTime;
            params.requestParams["endTime"] = schedule.endTime;
            params.requestParams["description"] = schedule.description;
            params.requestParams["name"] = schedule.name;
            params.requestParams["userId"] = schedule.username;
            params.requestParams["password"] = schedule.password;
            params.requestParams["emailAddress"] = schedule.email;
            params.requestParams["handlerClassName"] = lang.mixin(params.requestParams, parameters);
            var requestBodyParams = new Object();
            lang.mixin(data, data);
            params["requestBody"] = requestBodyParams;
            params.requestCompleteCallback = lang.hitch(this, function (response) {
                if (callback) {
                    callback();
                }
            });
            Request.postServiceAPI("scheduleAsyncTask", null, "text/json", params);
        }, isTaskAdmin:function () {
            if (this.taskSecurityRoles) {
                return this.taskSecurityRoles.isTaskAdmin;
            }
            return false;
        }, isTaskUser:function () {
            if (this.taskSecurityRoles) {
                return this.taskSecurityRoles.isTaskUser;
            }
            return false;
        }, isTaskAuditor:function () {
            if (this.taskSecurityRoles) {
                return this.taskSecurityRoles.isTaskAuditor;
            }
            return false;
        }, onAsyncTaskItemAdded:function (task) {
        }, onAsyncTaskItemOpened:function (task) {
        }, logoff:function () {
            this.taskSecurityRoles = null;
        }});
        return TaskManager;
    });
}, "dojo/number":function () {
    define("dojo/number", ["./_base/lang", "./i18n", "./i18n!./cldr/nls/number", "./string", "./regexp"], function (lang, i18n, nlsNumber, dstring, dregexp) {
        var number = {};
        lang.setObject("dojo.number", number);
        number.format = function (value, options) {
            options = lang.mixin({}, options || {});
            var locale = i18n.normalizeLocale(options.locale), bundle = i18n.getLocalization("dojo.cldr", "number", locale);
            options.customs = bundle;
            var pattern = options.pattern || bundle[(options.type || "decimal") + "Format"];
            if (isNaN(value) || Math.abs(value) == Infinity) {
                return null;
            }
            return number._applyPattern(value, pattern, options);
        };
        number._numberPatternRE = /[#0,]*[#0](?:\.0*#*)?/;
        number._applyPattern = function (value, pattern, options) {
            options = options || {};
            var group = options.customs.group, decimal = options.customs.decimal, patternList = pattern.split(";"), positivePattern = patternList[0];
            pattern = patternList[(value < 0) ? 1 : 0] || ("-" + positivePattern);
            if (pattern.indexOf("%") != -1) {
                value *= 100;
            } else {
                if (pattern.indexOf("\u2030") != -1) {
                    value *= 1000;
                } else {
                    if (pattern.indexOf("\xa4") != -1) {
                        group = options.customs.currencyGroup || group;
                        decimal = options.customs.currencyDecimal || decimal;
                        pattern = pattern.replace(/\u00a4{1,3}/, function (match) {
                            var prop = ["symbol", "currency", "displayName"][match.length - 1];
                            return options[prop] || options.currency || "";
                        });
                    } else {
                        if (pattern.indexOf("E") != -1) {
                            throw new Error("exponential notation not supported");
                        }
                    }
                }
            }
            var numberPatternRE = number._numberPatternRE;
            var numberPattern = positivePattern.match(numberPatternRE);
            if (!numberPattern) {
                throw new Error("unable to find a number expression in pattern: " + pattern);
            }
            if (options.fractional === false) {
                options.places = 0;
            }
            return pattern.replace(numberPatternRE, number._formatAbsolute(value, numberPattern[0], {decimal:decimal, group:group, places:options.places, round:options.round}));
        };
        number.round = function (value, places, increment) {
            var factor = 10 / (increment || 10);
            return (factor * +value).toFixed(places) / factor;
        };
        if ((0.9).toFixed() == 0) {
            var round = number.round;
            number.round = function (v, p, m) {
                var d = Math.pow(10, -p || 0), a = Math.abs(v);
                if (!v || a >= d) {
                    d = 0;
                } else {
                    a /= d;
                    if (a < 0.5 || a >= 0.95) {
                        d = 0;
                    }
                }
                return round(v, p, m) + (v > 0 ? d : -d);
            };
        }
        number._formatAbsolute = function (value, pattern, options) {
            options = options || {};
            if (options.places === true) {
                options.places = 0;
            }
            if (options.places === Infinity) {
                options.places = 6;
            }
            var patternParts = pattern.split("."), comma = typeof options.places == "string" && options.places.indexOf(","), maxPlaces = options.places;
            if (comma) {
                maxPlaces = options.places.substring(comma + 1);
            } else {
                if (!(maxPlaces >= 0)) {
                    maxPlaces = (patternParts[1] || []).length;
                }
            }
            if (!(options.round < 0)) {
                value = number.round(value, maxPlaces, options.round);
            }
            var valueParts = String(Math.abs(value)).split("."), fractional = valueParts[1] || "";
            if (patternParts[1] || options.places) {
                if (comma) {
                    options.places = options.places.substring(0, comma);
                }
                var pad = options.places !== undefined ? options.places : (patternParts[1] && patternParts[1].lastIndexOf("0") + 1);
                if (pad > fractional.length) {
                    valueParts[1] = dstring.pad(fractional, pad, "0", true);
                }
                if (maxPlaces < fractional.length) {
                    valueParts[1] = fractional.substr(0, maxPlaces);
                }
            } else {
                if (valueParts[1]) {
                    valueParts.pop();
                }
            }
            var patternDigits = patternParts[0].replace(",", "");
            pad = patternDigits.indexOf("0");
            if (pad != -1) {
                pad = patternDigits.length - pad;
                if (pad > valueParts[0].length) {
                    valueParts[0] = dstring.pad(valueParts[0], pad);
                }
                if (patternDigits.indexOf("#") == -1) {
                    valueParts[0] = valueParts[0].substr(valueParts[0].length - pad);
                }
            }
            var index = patternParts[0].lastIndexOf(","), groupSize, groupSize2;
            if (index != -1) {
                groupSize = patternParts[0].length - index - 1;
                var remainder = patternParts[0].substr(0, index);
                index = remainder.lastIndexOf(",");
                if (index != -1) {
                    groupSize2 = remainder.length - index - 1;
                }
            }
            var pieces = [];
            for (var whole = valueParts[0]; whole; ) {
                var off = whole.length - groupSize;
                pieces.push((off > 0) ? whole.substr(off) : whole);
                whole = (off > 0) ? whole.slice(0, off) : "";
                if (groupSize2) {
                    groupSize = groupSize2;
                    delete groupSize2;
                }
            }
            valueParts[0] = pieces.reverse().join(options.group || ",");
            return valueParts.join(options.decimal || ".");
        };
        number.regexp = function (options) {
            return number._parseInfo(options).regexp;
        };
        number._parseInfo = function (options) {
            options = options || {};
            var locale = i18n.normalizeLocale(options.locale), bundle = i18n.getLocalization("dojo.cldr", "number", locale), pattern = options.pattern || bundle[(options.type || "decimal") + "Format"], group = bundle.group, decimal = bundle.decimal, factor = 1;
            if (pattern.indexOf("%") != -1) {
                factor /= 100;
            } else {
                if (pattern.indexOf("\u2030") != -1) {
                    factor /= 1000;
                } else {
                    var isCurrency = pattern.indexOf("\xa4") != -1;
                    if (isCurrency) {
                        group = bundle.currencyGroup || group;
                        decimal = bundle.currencyDecimal || decimal;
                    }
                }
            }
            var patternList = pattern.split(";");
            if (patternList.length == 1) {
                patternList.push("-" + patternList[0]);
            }
            var re = dregexp.buildGroupRE(patternList, function (pattern) {
                pattern = "(?:" + dregexp.escapeString(pattern, ".") + ")";
                return pattern.replace(number._numberPatternRE, function (format) {
                    var flags = {signed:false, separator:options.strict ? group : [group, ""], fractional:options.fractional, decimal:decimal, exponent:false}, parts = format.split("."), places = options.places;
                    if (parts.length == 1 && factor != 1) {
                        parts[1] = "###";
                    }
                    if (parts.length == 1 || places === 0) {
                        flags.fractional = false;
                    } else {
                        if (places === undefined) {
                            places = options.pattern ? parts[1].lastIndexOf("0") + 1 : Infinity;
                        }
                        if (places && options.fractional == undefined) {
                            flags.fractional = true;
                        }
                        if (!options.places && (places < parts[1].length)) {
                            places += "," + parts[1].length;
                        }
                        flags.places = places;
                    }
                    var groups = parts[0].split(",");
                    if (groups.length > 1) {
                        flags.groupSize = groups.pop().length;
                        if (groups.length > 1) {
                            flags.groupSize2 = groups.pop().length;
                        }
                    }
                    return "(" + number._realNumberRegexp(flags) + ")";
                });
            }, true);
            if (isCurrency) {
                re = re.replace(/([\s\xa0]*)(\u00a4{1,3})([\s\xa0]*)/g, function (match, before, target, after) {
                    var prop = ["symbol", "currency", "displayName"][target.length - 1], symbol = dregexp.escapeString(options[prop] || options.currency || "");
                    before = before ? "[\\s\\xa0]" : "";
                    after = after ? "[\\s\\xa0]" : "";
                    if (!options.strict) {
                        if (before) {
                            before += "*";
                        }
                        if (after) {
                            after += "*";
                        }
                        return "(?:" + before + symbol + after + ")?";
                    }
                    return before + symbol + after;
                });
            }
            return {regexp:re.replace(/[\xa0 ]/g, "[\\s\\xa0]"), group:group, decimal:decimal, factor:factor};
        };
        number.parse = function (expression, options) {
            var info = number._parseInfo(options), results = (new RegExp("^" + info.regexp + "$")).exec(expression);
            if (!results) {
                return NaN;
            }
            var absoluteMatch = results[1];
            if (!results[1]) {
                if (!results[2]) {
                    return NaN;
                }
                absoluteMatch = results[2];
                info.factor *= -1;
            }
            absoluteMatch = absoluteMatch.replace(new RegExp("[" + info.group + "\\s\\xa0" + "]", "g"), "").replace(info.decimal, ".");
            return absoluteMatch * info.factor;
        };
        number._realNumberRegexp = function (flags) {
            flags = flags || {};
            if (!("places" in flags)) {
                flags.places = Infinity;
            }
            if (typeof flags.decimal != "string") {
                flags.decimal = ".";
            }
            if (!("fractional" in flags) || /^0/.test(flags.places)) {
                flags.fractional = [true, false];
            }
            if (!("exponent" in flags)) {
                flags.exponent = [true, false];
            }
            if (!("eSigned" in flags)) {
                flags.eSigned = [true, false];
            }
            var integerRE = number._integerRegexp(flags), decimalRE = dregexp.buildGroupRE(flags.fractional, function (q) {
                var re = "";
                if (q && (flags.places !== 0)) {
                    re = "\\" + flags.decimal;
                    if (flags.places == Infinity) {
                        re = "(?:" + re + "\\d+)?";
                    } else {
                        re += "\\d{" + flags.places + "}";
                    }
                }
                return re;
            }, true);
            var exponentRE = dregexp.buildGroupRE(flags.exponent, function (q) {
                if (q) {
                    return "([eE]" + number._integerRegexp({signed:flags.eSigned}) + ")";
                }
                return "";
            });
            var realRE = integerRE + decimalRE;
            if (decimalRE) {
                realRE = "(?:(?:" + realRE + ")|(?:" + decimalRE + "))";
            }
            return realRE + exponentRE;
        };
        number._integerRegexp = function (flags) {
            flags = flags || {};
            if (!("signed" in flags)) {
                flags.signed = [true, false];
            }
            if (!("separator" in flags)) {
                flags.separator = "";
            } else {
                if (!("groupSize" in flags)) {
                    flags.groupSize = 3;
                }
            }
            var signRE = dregexp.buildGroupRE(flags.signed, function (q) {
                return q ? "[-+]" : "";
            }, true);
            var numberRE = dregexp.buildGroupRE(flags.separator, function (sep) {
                if (!sep) {
                    return "(?:\\d+)";
                }
                sep = dregexp.escapeString(sep);
                if (sep == " ") {
                    sep = "\\s";
                } else {
                    if (sep == "\xa0") {
                        sep = "\\s\\xa0";
                    }
                }
                var grp = flags.groupSize, grp2 = flags.groupSize2;
                if (grp2) {
                    var grp2RE = "(?:0|[1-9]\\d{0," + (grp2 - 1) + "}(?:[" + sep + "]\\d{" + grp2 + "})*[" + sep + "]\\d{" + grp + "})";
                    return ((grp - grp2) > 0) ? "(?:" + grp2RE + "|(?:0|[1-9]\\d{0," + (grp - 1) + "}))" : grp2RE;
                }
                return "(?:0|[1-9]\\d{0," + (grp - 1) + "}(?:[" + sep + "]\\d{" + grp + "})*)";
            }, true);
            return signRE + numberRE;
        };
        return number;
    });
}, "ecm/model/FolderTreeModel":function () {
    define("ecm/model/FolderTreeModel", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/connect", "dojo/dnd/Manager", "dojo/data/util/filter", "./_ModelObject", "./Item", "./ContentItem", "./Dnd"], function (declare, lang, connect, DNDManager, datafilter, _ModelObject, Item, ContentItem, Dnd) {
        var FolderTreeModel = declare("ecm.model.FolderTreeModel", [_ModelObject], {isFirstNodeasTeamspaces:false, filter:null, isChildrenNodeTeamspace:false, isShowThisTeamspace:false, thisTeamspaceName:ecm.messages.search_in_thisteamspaces, constructor:function (rootItem, showFoldersOnly, isFirstNodeasTeamspaces, isShowThisTeamspace, thisTeamspacename, filterType) {
            this.id = "Root:" + rootItem.id;
            this.name = this.id;
            this._loadedItems = {};
            this._rootItem = rootItem;
            this.showFoldersOnly = showFoldersOnly || false;
            this._desktopChangeHandler = connect.connect(ecm.model.desktop, "onChange", this, "_onDesktopChanged");
            this.isFirstNodeasTeamspaces = isFirstNodeasTeamspaces;
            this.isShowThisTeamspace = isShowThisTeamspace;
            if (thisTeamspacename) {
                this.thisTeamspaceName = thisTeamspacename;
            }
            this._filterType = filterType;
            this._dndModel = new Dnd();
        }, _onDesktopChanged:function (modelObject) {
            if (modelObject == this._rootItem.repository) {
                if (this._rootItem.repository.connected == false) {
                    this._loadedItems = [];
                    this.reload(this._rootItem);
                } else {
                    for (var i in this._loadedItems) {
                        this.reload(this._loadedItems[i]);
                    }
                }
            } else {
                if (this.isItem(modelObject) && this.isLoaded(modelObject) && modelObject.repository == this._rootItem.repository) {
                    this.reload(modelObject);
                }
            }
        }, destroy:function () {
            connect.disconnect(this._desktopChangeHandler);
        }, isLoaded:function (item) {
            return this._loadedItems[this.getIdentity(item)] ? true : false;
        }, getRoot:function (onItem) {
            onItem(this._rootItem);
        }, mayHaveChildren:function (item) {
            return item.isFolder();
        }, fetchNextPage:function (pagedResultSet, parentItem, onComplete) {
            this.onProcessingStarted(parentItem);
            pagedResultSet.retrieveNextPage(lang.hitch(this, function () {
                this.replaceChildren(parentItem, pagedResultSet);
                this.onProcessingComplete(parentItem);
                if (onComplete) {
                    onComplete();
                }
            }));
        }, replaceChildren:function (parentItem, resultSet) {
            var childItems = [].concat(resultSet.getItems());
            this._addPageForwardItem(childItems, resultSet, parentItem);
            this.onChildrenChange(parentItem, childItems);
        }, getTeamspacesItem:function (parentItem, onComplete) {
            if (!parentItem.repository.teamspacesEnabled) {
                onComplete([]);
            } else {
                this._getTeamspaceIds(parentItem.repository, lang.hitch(this, function (teamspaceIds) {
                    var request = parentItem.repository.retrieveMultiItem(teamspaceIds, lang.hitch(this, function (teamspaceFolders) {
                        this._loadedItems[this.getIdentity(parentItem)] = parentItem;
                        var childitems = [];
                        for (var i = 0; i < teamspaceFolders.length; i++) {
                            var teamspaceItem = teamspaceFolders[i];
                            if (!this.filter || (teamspaceItem.name && teamspaceItem.name.match(this.filter))) {
                                childitems.push(teamspaceItem);
                            }
                        }
                        if (this.isShowThisTeamspace) {
                            var pathname = parentItem.repository.type == "p8" ? "/Teamspaces/" + this.thisTeamspaceName : "/" + this.thisTeamspaceName;
                            var teamspaceItem = new ContentItem({id:ecm.model.FolderTreeModel.THIS_TEAMSPACE_ID, name:ecm.messages.search_in_thisteamspaces, repository:parentItem.repository, PathName:pathname, template:"Teamspace"});
                            childitems.unshift(teamspaceItem);
                        }
                        for (var i = 0; i < childitems.length; i++) {
                            childitems[i].parent = parentItem;
                        }
                        onComplete(childitems);
                    }));
                    return request;
                }));
            }
        }, _getTeamspaceIds:function (repository, callback) {
            if (repository.teamspaces) {
                var array = [];
                for (var i = 0; i < repository.teamspaces.length; i++) {
                    array.push(repository.teamspaces[i].id);
                }
                callback(array);
            } else {
                repository.retrieveTeamspaceFolders(lang.hitch(this, function (teamspaces) {
                    var array = [];
                    for (var i = 0; i < teamspaces.length; i++) {
                        array.push(teamspaces[i].id);
                    }
                    callback(array);
                }));
            }
        }, getChildren:function (parentItem, onComplete) {
            if (!parentItem.repository.connected) {
                onComplete([]);
            } else {
                if (this.isFirstNodeasTeamspaces && this._rootItem && parentItem == this._rootItem) {
                    this.isChildrenNodeTeamspace = true;
                }
                if (parentItem.template && parentItem.template.indexOf("Teamspace") >= 0) {
                    this.isChildrenNodeTeamspace = false;
                }
                if (this.isFirstNodeasTeamspaces && this.isChildrenNodeTeamspace) {
                    this.getTeamspacesItem(parentItem, onComplete);
                } else {
                    this.onProcessingStarted(parentItem);
                    var request = parentItem.retrieveFolderContents(this.showFoldersOnly, lang.hitch(this, function (results) {
                        var childItems = [].concat(results.getItems());
                        this._addPageForwardItem(childItems, results, parentItem);
                        this._loadedItems[this.getIdentity(parentItem)] = parentItem;
                        this.onProcessingComplete(parentItem);
                        onComplete(childItems);
                    }), null, false, false, this._teamspaceId, this._filterType);
                }
            }
        }, applyFilter:function (filter) {
            if (filter && filter.length > 0) {
                this.filter = datafilter.patternToRegExp(filter, true);
            } else {
                this.filter = null;
            }
            this.reload(this._rootItem);
        }, _addPageForwardItem:function (children, resultSet, parentItem) {
            if (resultSet.hasContinuation()) {
                var moreLink = new Item({"id":"continuation_" + new Date().getTime(), "name":ecm.messages.more_paging_link, "repository":resultSet.repository, "resultSet":resultSet, "parent":parentItem});
                moreLink.continuationData = resultSet.continuationData;
                moreLink.pagedResultSet = resultSet;
                children.push(moreLink);
                parentItem.moreLink = moreLink;
            }
        }, isItem:function (something) {
            if (something && something.isInstanceOf && something.isInstanceOf(ecm.model.Item)) {
                return true;
            }
            return false;
        }, fetchItemByIdentity:function (keywordArgs) {
        }, getIdentity:function (item) {
            return item.id;
        }, getLabel:function (item) {
            var label = item.name;
            if (item.hasAttribute("{NAME}") && (item.getAttributeType("{NAME}") != "xs:string")) {
                label = item.getDisplayValue("{NAME}");
            }
            if (this.isChildrenNodeTeamspace) {
                if (item.attributes.ClbTeamspaceName) {
                    label = item.attributes.ClbTeamspaceName;
                } else {
                    if (item.attributes.clbTitle) {
                        label = item.attributes.clbTitle;
                    }
                }
            }
            return label;
        }, reload:function (parent) {
            this.onProcessingStarted(parent);
            if (parent.unloadFolderContents) {
                parent.unloadFolderContents();
                this.getChildren(parent, lang.hitch(this, function (newChildren) {
                    this.onChildrenChange(parent, newChildren);
                    for (var i in newChildren) {
                        this.onChange(newChildren[i]);
                    }
                }));
            }
        }, newItem:function (args, parent) {
            if (args && args.sourceItems && args.sourceItems.length > 0) {
                if (DNDManager.manager().copy) {
                    this._dndModel.dropCopy(args.sourceItems, parent);
                } else {
                    this._dndModel.dropMove(args.sourceItems, parent);
                }
            }
        }, pasteItem:function (childItem, oldParentItem, newParentItem, bCopy) {
            if (bCopy && newParentItem.repository.type == "p8" && childItem.isFolder()) {
                return;
            } else {
                if (newParentItem.repository.id != childItem.repository.id) {
                    return;
                }
            }
            var sourceItems = [childItem];
            if (bCopy) {
                this._dndModel.dropCopy(sourceItems, newParentItem);
            } else {
                this._dndModel.dropMove(sourceItems, newParentItem, oldParentItem);
            }
        }, onChange:function (item) {
        }, onChildrenChange:function (parent, newChildrenList) {
        }, onProcessingStarted:function (item) {
        }, onProcessingComplete:function (item) {
        }});
        FolderTreeModel.THIS_TEAMSPACE_ID = "{this_teamspace_id}";
        return FolderTreeModel;
    });
}, "ecm/model/FavoritesResultSet":function () {
    define("ecm/model/FavoritesResultSet", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/sniff", "dojo/_base/array", "dojo/data/util/sorter", "dojo/_base/Deferred", "dojo/DeferredList", "./_ModelObject", "./_ModelStore"], function (declare, lang, has, array, sorter, Deferred, DeferredList, _ModelObject, _ModelStore) {
        return declare("ecm.model.FavoritesResultSet", [_ModelObject], {items:null, parentFolder:null, structure:null, magazineStructure:null, mimeIndex:0, hasToolbar:true, columnNames:null, pageSize:200, constructor:function () {
            if (this.structure && this.structure.cells) {
                for (var i in this.structure.cells[0]) {
                    var cell = this.structure.cells[0][i];
                    if (has("webkit")) {
                        if (cell.field == "icon" || cell.field == "mimeTypeIcon") {
                            cell.width = "25px";
                        } else {
                            if (cell.field == "multiStateIcon") {
                                cell.width = cell.widthWebKit;
                            }
                        }
                    }
                    if (cell.field == "mimeTypeIcon") {
                        cell.sortable = true;
                    }
                }
            }
        }, doSort:function (p, afterSort, store) {
            var col = p[0];
            var sortProperty = col.attribute;
            var clientAttribute = col.clientAttribute;
            if (clientAttribute) {
                delete col.clientAttribute;
            }
            function isNumericAttribute(store, attribute) {
                return (attribute && (store.comparatorMap[attribute] == _ModelStore.numericComparator || store.comparatorMap[attribute] == _ModelStore.longComparator));
            }
            if (store && this.items && (isNumericAttribute(store, sortProperty) || !ecm.model.desktop.culturalCollation)) {
                if (clientAttribute) {
                    col.attribute = clientAttribute;
                }
                var sortStore = {comparatorMap:store.comparatorMap, getValue:function (item, attribute) {
                    var value = null;
                    if (item && item.getValue) {
                        value = item.getValue(attribute);
                        if (attribute == "type") {
                            if (value == "folder") {
                                value = 2;
                            } else {
                                if (value == "search") {
                                    value = 3;
                                } else {
                                    if (value == "teamspace") {
                                        value = 1;
                                    } else {
                                        value = 4;
                                    }
                                }
                            }
                        }
                    }
                    return value;
                }};
                p = [{attribute:"type", descending:p[0].descending}].concat(p);
                this.items.sort(sorter.createSortFunction(p, sortStore));
                if (afterSort) {
                    afterSort(this);
                }
                return;
            }
        }, getItems:function (handler) {
            if (handler) {
                handler(this.items);
            }
            return this.items;
        }, getColumns:function () {
            if (!this.columnNames) {
                if (this.structure && this.structure.cells) {
                    var array = [];
                    for (var i in this.structure.cells) {
                        for (var j in this.structure.cells[i]) {
                            if (this.structure.cells[i][j].field) {
                                array.push(this.structure.cells[i][j].field);
                            }
                        }
                    }
                    this.columnNames = array;
                } else {
                    this.columnNames = [];
                }
            }
            return this.columnNames;
        }, getStore:function () {
            return new _ModelStore(this, this.getItems, null, lang.hitch(this, this._deleteItem));
        }, saveStructure:function (structure, saveStructureCallback) {
        }, getItem:function (index) {
            return this.items[index];
        }, getIndexOfItem:function (item) {
            return array.indexOf(this.items, item);
        }, _deleteItem:function (item) {
            for (var index in this.items) {
                if (item.id == this.items[index].id) {
                    this.items.splice(index, 1);
                    return true;
                }
            }
            return false;
        }, isMaxResultsReached:function () {
            return true;
        }, hasContinuation:function () {
            return false;
        }, setItem:function (index, item) {
            this.items[index] = item;
        }, refresh:function () {
            var self = this;
            this.parentFolder.refresh();
        }, _refreshCompleted:function (items, structure) {
            this.columnNames = null;
            this.items = items;
            this.structure = structure;
            this.onChange(this);
        }, isResultSetForItem:function (item) {
            if (this.parentFolder && this.parentFolder.id == item.id) {
                return true;
            } else {
                return false;
            }
        }, getActionsMenuItemsType:function (items) {
            var contextMenuType = "FavoriteFolderContextMenu";
            if (items && items.length > 0) {
                var favType = items[0].type;
                if (favType == "search") {
                    contextMenuType = "FavoriteSearchTemplateContextMenu";
                } else {
                    if (favType == "teamspace") {
                        contextMenuType = "FavoriteTeamspaceContextMenu";
                    } else {
                        if (favType == "folder") {
                            contextMenuType = "FavoriteFolderContextMenu";
                        } else {
                            contextMenuType = "FavoriteItemContextMenu";
                        }
                    }
                }
            }
            return contextMenuType;
        }, loadContextMenu:function (items, callback) {
            if (items.length > 0) {
                var deferArray = [];
                array.forEach(items, function (item) {
                    if (item && item.isInstanceOf && item.isInstanceOf(ecm.model.Favorite)) {
                        if (!item.item) {
                            var deferred = new Deferred();
                            deferArray.push(deferred);
                            item.retrieveFavorite(function () {
                                deferred.resolve();
                            });
                        }
                    }
                });
                if (deferArray && deferArray.length > 0) {
                    var self = this;
                    var defs = new DeferredList(deferArray);
                    defs.then(function () {
                        ecm.model.desktop.loadMenuActions(self.getActionsMenuItemsType(items), callback);
                        return true;
                    });
                } else {
                    ecm.model.desktop.loadMenuActions(this.getActionsMenuItemsType(items), callback);
                }
            }
        }, getToolbarDef:function () {
            return "FavoritesToolbar";
        }, loadToolbar:function (callback) {
            if (this.hasToolbar && callback) {
                ecm.model.desktop.loadMenuActions("FavoritesToolbar", callback);
            }
        }});
    });
}, "ecm/model/ViewerMapping":function () {
    define("ecm/model/ViewerMapping", ["dojo/_base/declare", "./_ModelObject"], function (declare, _ModelObject) {
        return declare("ecm.model.ViewerMapping", [_ModelObject], {contentType:"", serverType:"", itemType:"", viewer:null, constructor:function () {
            var keyParts = [];
            if (this.serverType) {
                keyParts.push(this.serverType);
            }
            if (this.itemType) {
                keyParts.push(this.itemType);
            }
            if (this.contentType) {
                keyParts.push(this.contentType);
            }
            this._key = keyParts.join("");
            if (this.serverType && this.viewer && this.contentType) {
                this.viewer.addViewerMapping(this);
            }
        }, getKey:function () {
            return this._key;
        }, useViewer:function (item, explicitMatchRequired) {
            var returnViewer = null;
            if (explicitMatchRequired && explicitMatchRequired == true && this.contentType == "") {
                returnViewer = null;
            } else {
                var contentType = item.mimetype || "";
                if (item.repository) {
                    var serverType = item.repository.type;
                } else {
                    var serverType = "";
                }
                if (item.getContentClass && item.getContentClass()) {
                    var itemType = item.getContentClass().id;
                } else {
                    var itemType = "";
                }
                if (this.contentType == "" || contentType.indexOf(this.contentType) === 0) {
                    if (this.serverType == "" || this.serverType == serverType) {
                        if (this.itemType == "" || this.itemType == itemType) {
                            returnViewer = this.viewer;
                        }
                    }
                }
            }
            return returnViewer;
        }, equals:function (viewer) {
            return this.viewer == viewer;
        }});
    });
}, "ecm/model/WorklistsTreeModel":function () {
    define("ecm/model/WorklistsTreeModel", ["dojo/_base/declare", "dojo/_base/connect", "./_ModelObject"], function (declare, connect, _ModelObject) {
        return declare("ecm.model.WorklistsTreeModel", [_ModelObject], {constructor:function () {
            if (!this.id) {
                this.id = this.repository.id;
            }
            if (!this.name) {
                this.name = this.id;
            }
            this._rootNode = new _ModelObject("worklistsRoot", "");
        }, setRepository:function (repository) {
            this.repository = repository;
            this.onChange(this._rootNode);
        }, destroy:function () {
        }, getRoot:function (onItem) {
            onItem(this._rootNode);
        }, mayHaveChildren:function (item) {
            if (item == this._rootNode) {
                return true;
            }
            if (item && item.isInstanceOf && (item.isInstanceOf(ecm.model.Worklist) || item.isInstanceOf(ecm.model.ProcessInbasket))) {
                return false;
            }
            return true;
        }, getChildren:function (parentItem, onComplete) {
            if (parentItem == this._rootNode) {
                if (!this.repository) {
                    onComplete([]);
                } else {
                    var request = this.repository.retrieveWorklistContainers(function (worklistFolders) {
                        var childItems = [];
                        for (var i = 0; i < worklistFolders.length; i++) {
                            var worklistFolder = worklistFolders[i];
                            childItems.push(worklistFolder);
                        }
                        onComplete(childItems);
                    });
                }
            } else {
                if (parentItem.isInstanceOf && (parentItem.isInstanceOf(ecm.model.WorklistFolder) || parentItem.isInstanceOf(ecm.model.ProcessRole) || parentItem.isInstanceOf(ecm.model.ProcessApplicationSpace))) {
                    var request = parentItem.retrieveWorklists(function (worklists) {
                        var childItems = [];
                        for (var i = 0; i < worklists.length; i++) {
                            var worklist = worklists[i];
                            childItems.push(worklist);
                        }
                        onComplete(childItems);
                    });
                } else {
                    onComplete([]);
                }
            }
            if (request) {
                connect.connect(request, "onRequestCompleted", this, function () {
                    this.onProcessingComplete(parentItem);
                });
            }
        }, isItem:function (something) {
            if (something == this._rootNode) {
                return true;
            }
            if (something && something.isInstanceOf && (something.isInstanceOf(ecm.model.Worklist) || something.isInstanceOf(ecm.model.ProcessApplicationSpace) || something.isInstanceOf(ecm.model.ProcessRole) || something.isInstanceOf(ecm.model.ProcessInbasket))) {
                return true;
            }
            return false;
        }, fetchItemByIdentity:function (keywordArgs) {
        }, getIdentity:function (item) {
            return item.id;
        }, getLabel:function (item) {
            return item.name;
        }, newItem:function (args, parent, insertIndex) {
        }, pasteItem:function (childItem, oldParentItem, newParentItem, bCopy) {
        }, onChange:function (item) {
        }, onChildrenChange:function (parent, newChildrenList) {
        }, onProcessingStarted:function (item) {
        }, onProcessingComplete:function (item) {
        }});
    });
}, "ecm/model/admin/DesktopConfig":function () {
    define("ecm/model/admin/DesktopConfig", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/json", "./_ConfigurationObject", "./ServerConfig", "./RepositoryConfig"], function (declare, lang, array, dojojson, _ConfigurationObject, ServerConfig, RepositoryConfig) {
        var DesktopConfig = declare("ecm.model.admin.DesktopConfig", [_ConfigurationObject], {SHOW_FIELD_HOVER_HELP:"showFieldHoverHelp", APPLICATION_NAME:"applicationName", LOGIN_LOGO_URL:"loginLogoUrl", BANNER_LOGO_URL:"bannerLogoUrl", BANNER_BACKGROUND_COLOR:"bannerBackgroundColor", BANNER_APPLICATION_NAME_COLOR:"bannerApplicationNameColor", BANNER_MENU_COLOR:"bannerMenuColor", LOGIN_INFORMATION_URL:"loginInformationUrl", PASSWORD_RULES_URL:"passwordRulesUrl", LAYOUT:"layout", FEATURES:"features", DEFAULT_FEATURE:"defaultFeature", MESSAGE_SEARCH_URL:"messageSearchUrl", HELP_URL:"helpUrl", REPOSITORIES:"repositories", SERVERS:"servers", NAME:"name", DESCRIPTION:"description", IS_DEFAULT:"isDefault", FILE_INTO_FOLDER:"fileIntoFolder", SHOW_SECURITY:"showSecurity", LAYOUT_ACTION_HANDLER:"actionHandler", LAYOUT_LOG_FILE:"layoutLogFile", TEAMSPACES_DEFAULT_REPOSITORY:"teamspacesDefaultRepository", WORK_DEFAULT_REPOSITORY:"workDefaultRepository", OTHER_FEATURES_DEFAULT_REPOSITORY:"otherFeaturesDefaultRepository", SHOW_THUMBNAILS:"showThumbnails", SHOW_VIEWFILMSTRIP:"showViewFilmstrip", SHOW_GLOBETOOLBAR:"showGlobalToolbar", DEFAULT_REPOSITORY:"defaultRepository", VIEWER:"viewer", APPLICATION_SPACE_LABELS:"appSpaceLabels", SUPPORT_WORKFLOW_NOTIFICATION:"workflowNotification", PREVENT_CREATE_NEW_SEARCH:"preventCreateNewSearch", PREVENT_CREATE_NEW_UNIFIED_SEARCH:"preventCreateNewUnifiedSearch", MAX_NUMBER_DOC_TO_ADD:"maxNumberDocToAdd", MAX_NUMBER_DOC_TO_MODIFY:"maxNumberDocToModify", AUTHENTICATION_TYPE:"authenticationType", DEFAULT_DATA_SOURCE:"defaultDataSource", DATA_SOURCES:"dataSources", CHECKOUT_ON_OPEN_DOC:"checkoutOnOpenDoc", PROMPT_CLOSING_OFFICE:"promptCloseOffice", DELETE_LOCAL_ON_ADD:"deleteLocalOnAdd", DELETE_LOCAL_ON_SAVE:"deleteLocalOnSave", ADD_WITH_ENTRY_TEMPLATE_ONLY:"addWithEntryTemplateOnly", PROMPT_FOR_PROPERTIES_ON_ADD:"promptForPropsOnAdd", DELETE_EMAIL_ON_ADD:"deleteEmailOnAdd", SEND_EMAIL_AS_LINK_ONLY:"sendEmailAsLinkOnly", ENABLE_PROP_MAPPING_FOR_ADD:"enablePropMappingForAdd", MOBILE_APP_ACCESS:"mobileAppAccess", ADD_PHOTO_FROM_MOBILE:"addPhotoFromMobile", ADD_DOC_FOLDERS_TO_REPO:"addDocFoldersToRepo", OPEN_DOC_FROM_OTHER_APP:"openDocFromOtherApp", IS_VALID:"isValid", ACCESS_CONTROL_ENABLED:"accessControlEnabled", constructor:function (id, name) {
        }, getShowFieldHoverHelp:function () {
            return this.getValue(this.SHOW_FIELD_HOVER_HELP);
        }, setShowFieldHoverHelp:function (showFieldHoverHelp) {
            this.setValue(this.SHOW_FIELD_HOVER_HELP, showFieldHoverHelp);
        }, getPasswordRulesUrl:function () {
            return this.getValue(this.PASSWORD_RULES_URL);
        }, setPasswordRulesUrl:function (passwordRulesUrl) {
            this.setValue(this.PASSWORD_RULES_URL, passwordRulesUrl);
        }, getLoginInformationUrl:function () {
            return this.getValue(this.LOGIN_INFORMATION_URL);
        }, setLoginInformationUrl:function (loginInformationUrl) {
            this.setValue(this.LOGIN_INFORMATION_URL, loginInformationUrl);
        }, getLoginLogoUrl:function () {
            return this.getValue(this.LOGIN_LOGO_URL);
        }, setLoginLogoUrl:function (loginLogoUrl) {
            this.setValue(this.LOGIN_LOGO_URL, loginLogoUrl);
        }, getBannerLogoUrl:function () {
            return this.getValue(this.BANNER_LOGO_URL);
        }, setBannerLogoUrl:function (bannerLogoUrl) {
            this.setValue(this.BANNER_LOGO_URL, bannerLogoUrl);
        }, getApplicationName:function () {
            return this.getValue(this.APPLICATION_NAME);
        }, setApplicationName:function (applicationName) {
            this.setValue(this.APPLICATION_NAME, applicationName);
        }, getMessageSearchUrl:function () {
            return this.getValue(this.MESSAGE_SEARCH_URL);
        }, setMessageSearchUrl:function (messageSearchUrl) {
            this.setValue(this.MESSAGE_SEARCH_URL, messageSearchUrl);
        }, getHelpUrl:function () {
            return this.getValue(this.HELP_URL);
        }, setHelpUrl:function (helpUrl) {
            this.setValue(this.HELP_URL, helpUrl);
        }, getName:function () {
            return this.getValue(this.NAME);
        }, setName:function (name) {
            this.setValue(this.NAME, name);
        }, getDescription:function () {
            return this.getValue(this.DESCRIPTION);
        }, setDescription:function (description) {
            this.setValue(this.DESCRIPTION, description);
        }, getFileIntoFolder:function () {
            return this.getValue(this.FILE_INTO_FOLDER);
        }, setFileIntoFolder:function (fileIntoFolder) {
            this.setValue(this.FILE_INTO_FOLDER, fileIntoFolder);
        }, getShowSecurity:function () {
            return this.getValue(this.SHOW_SECURITY);
        }, setShowSecurity:function (showSecurity) {
            this.setValue(this.SHOW_SECURITY, showSecurity);
        }, getLayoutActionHandler:function () {
            return this.getValue(this.LAYOUT_ACTION_HANDLER);
        }, setLayoutActionHandler:function (layoutActionHandler) {
            this.setValue(this.LAYOUT_ACTION_HANDLER, layoutActionHandler);
        }, getLayout:function () {
            return this.getValue(this.LAYOUT);
        }, setLayout:function (layout) {
            this.setValue(this.LAYOUT, layout);
        }, getFeatures:function () {
            return this.getValues(this.FEATURES);
        }, setFeatures:function (features) {
            return this.setValues(this.FEATURES, features);
        }, getDefaultFeature:function () {
            return this.getValue(this.DEFAULT_FEATURE);
        }, setDefaultFeature:function (defaultFeature) {
            this.setValue(this.DEFAULT_FEATURE, defaultFeature);
        }, getLayoutLogFile:function () {
            return this.getValue(this.LAYOUT_LOG_FILE);
        }, setLayoutLogFile:function (logFile) {
            this.setValue(this.LAYOUT_LOG_FILE, logFile);
        }, getBannerBackgroundColor:function () {
            return this.getValue(this.BANNER_BACKGROUND_COLOR);
        }, setBannerBackgroundColor:function (bannerBackgroundColor) {
            this.setValue(this.BANNER_BACKGROUND_COLOR, bannerBackgroundColor);
        }, getBannerApplicationNameColor:function () {
            return this.getValue(this.BANNER_APPLICATION_NAME_COLOR);
        }, setBannerApplicationNameColor:function (bannerApplicationNameColor) {
            this.setValue(this.BANNER_APPLICATION_NAME_COLOR, bannerApplicationNameColor);
        }, getBannerMenuColor:function () {
            return this.getValue(this.BANNER_MENU_COLOR);
        }, setBannerMenuColor:function (bannerMenuColor) {
            this.setValue(this.BANNER_MENU_COLOR, bannerMenuColor);
        }, getTeamspacesDefaultRepository:function () {
            return this.getValue(this.TEAMSPACES_DEFAULT_REPOSITORY);
        }, setTeamspacesDefaultRepository:function (defaultRepository) {
            this.setValue(this.TEAMSPACES_DEFAULT_REPOSITORY, defaultRepository);
        }, getWorkDefaultRepository:function () {
            return this.getValue(this.WORK_DEFAULT_REPOSITORY);
        }, setWorkDefaultRepository:function (defaultRepository) {
            this.setValue(this.WORK_DEFAULT_REPOSITORY, defaultRepository);
        }, getOtherFeaturesDefaultRepository:function () {
            return this.getValue(this.OTHER_FEATURES_DEFAULT_REPOSITORY);
        }, setOtherFeaturesDefaultRepository:function (defaultRepository) {
            this.setValue(this.OTHER_FEATURES_DEFAULT_REPOSITORY, defaultRepository);
        }, getShowThumbnails:function () {
            return this.getValue(this.SHOW_THUMBNAILS);
        }, setShowThumbnails:function (showThumbnails) {
            this.setValue(this.SHOW_THUMBNAILS, showThumbnails);
        }, getShowViewFilmstrip:function () {
            var value = this.getValue(this.SHOW_VIEWFILMSTRIP);
            if (value == undefined) {
                return this.getShowThumbnails();
            } else {
                return value;
            }
        }, setShowViewFilmstrip:function (showViewFilmstrip) {
            this.setValue(this.SHOW_VIEWFILMSTRIP, showViewFilmstrip);
        }, getShowGlobalToolbar:function () {
            return this.getValue(this.SHOW_GLOBETOOLBAR);
        }, setShowGlobalToolbar:function (showGlobalToolbar) {
            this.setValue(this.SHOW_GLOBETOOLBAR, showGlobalToolbar);
        }, getDefault:function () {
            return this.getValue(this.IS_DEFAULT);
        }, setDefault:function (isDefault) {
            this.setValue(this.IS_DEFAULT, isDefault);
        }, isValid:function () {
            return this.getValue(this.IS_VALID);
        }, setValid:function (isValid) {
            this.setValue(this.IS_VALID, isValid);
        }, getDefaultRepository:function () {
            return this.getValue(this.DEFAULT_REPOSITORY);
        }, setDefaultRepository:function (defaultRepository) {
            this.setValue(this.DEFAULT_REPOSITORY, defaultRepository);
        }, getViewer:function () {
            return this.getValue(this.VIEWER);
        }, setViewer:function (viewer) {
            this.setValue(this.VIEWER, viewer);
        }, getServerObjects:function (callback) {
            var servers = this.getValues(this.SERVERS);
            if (servers && servers.length > 0) {
                var serverObjects = [];
                array.forEach(servers, lang.hitch(this, function (entry, index) {
                    var server = ServerConfig.createServerConfig(entry);
                    server.getConfig(function (response) {
                        serverObjects.push(server);
                        if (serverObjects.length == servers.length && callback) {
                            callback(serverObjects);
                        }
                    });
                }));
                return serverObjects;
            }
        }, getRepositoryObjects:function (callback) {
            var repositoryObjects = [];
            var repositories = this.getValues(this.REPOSITORIES);
            if (repositories && repositories.length > 0) {
                this.listConfig("repositories", lang.hitch(this, function (list) {
                    for (var i in list) {
                        var entry = list[i];
                        var id = entry.id ? entry.id : "" + i;
                        var repository = RepositoryConfig.createRepositoryConfig(id);
                        lang.mixin(repository, {_attributes:entry});
                        repositoryObjects.push(repository);
                    }
                    if (callback) {
                        callback(repositoryObjects);
                    }
                }), "true");
                return repositoryObjects;
            } else {
                if (callback) {
                    callback(repositoryObjects);
                }
                return repositoryObjects;
            }
        }, getSupportWorkflowNotification:function () {
            return this.getValues(this.SUPPORT_WORKFLOW_NOTIFICATION);
        }, setSupportWorkflowNotification:function (values) {
            this.setValues(this.SUPPORT_WORKFLOW_NOTIFICATION, values);
        }, getPreventCreateNewSearch:function () {
            return this.getValues(this.PREVENT_CREATE_NEW_SEARCH);
        }, setPreventCreateNewSearch:function (values) {
            this.setValues(this.PREVENT_CREATE_NEW_SEARCH, values);
        }, getPreventCreateNewUnifiedSearch:function () {
            return this.getValues(this.PREVENT_CREATE_NEW_UNIFIED_SEARCH);
        }, setPreventCreateNewUnifiedSearch:function (values) {
            this.setValues(this.PREVENT_CREATE_NEW_UNIFIED_SEARCH, values);
        }, getMaxNumberDocToAdd:function () {
            return (this.getValue(this.MAX_NUMBER_DOC_TO_ADD) ? this.getValue(this.MAX_NUMBER_DOC_TO_ADD) : 50);
        }, setMaxNumberDocToAdd:function (value) {
            this.setValue(this.MAX_NUMBER_DOC_TO_ADD, value);
        }, getMaxNumberDocToModify:function () {
            return (this.getValue(this.MAX_NUMBER_DOC_TO_MODIFY) ? this.getValue(this.MAX_NUMBER_DOC_TO_MODIFY) : 50);
        }, setMaxNumberDocToModify:function (value) {
            this.setValue(this.MAX_NUMBER_DOC_TO_MODIFY, value);
        }, setApplicationSpacesLabelsParam:function (values, ids) {
            this.applicationSpacesLabels = values;
            this.applicationSpacesIds = ids;
        }, getApplicationSpacesLabelValues:function () {
            return this.applicationSpacesLabels;
        }, getApplicationSpacesLabelIds:function () {
            return this.applicationSpacesIds;
        }, getApplicationSpaceLabels:function () {
            return this.getValues(this.APPLICATION_SPACE_LABELS);
        }, setApplicationSpaceLabels:function (values) {
            this.setValues(this.APPLICATION_SPACE_LABELS, values);
        }, getCheckoutOnOpenDoc:function () {
            return this.getValue(this.CHECKOUT_ON_OPEN_DOC);
        }, setCheckoutOnOpenDoc:function (checkoutOnOpenDoc) {
            this.setValue(this.CHECKOUT_ON_OPEN_DOC, checkoutOnOpenDoc);
        }, getPromptCloseOfficeIfDocCheckout:function () {
            return this.getValue(this.PROMPT_CLOSING_OFFICE);
        }, setPromptCloseOfficeIfDocCheckout:function (promptCloseOffice) {
            this.setValue(this.PROMPT_CLOSING_OFFICE, promptCloseOffice);
        }, getDeleteLocalOnAdd:function () {
            return this.getValue(this.DELETE_LOCAL_ON_ADD);
        }, setDeleteLocalOnAdd:function (deleteLocalOnAdd) {
            this.setValue(this.DELETE_LOCAL_ON_ADD, deleteLocalOnAdd);
        }, getDeleteLocalOnSave:function () {
            return this.getValue(this.DELETE_LOCAL_ON_SAVE);
        }, setDeleteLocalOnSave:function (deleteLocalOnSave) {
            this.setValue(this.DELETE_LOCAL_ON_SAVE, deleteLocalOnSave);
        }, getAddWithEntryTemplateOnly:function () {
            return this.getValue(this.ADD_WITH_ENTRY_TEMPLATE_ONLY);
        }, setAddWithEntryTemplateOnly:function (addWithEntryTemplateOnly) {
            this.setValue(this.ADD_WITH_ENTRY_TEMPLATE_ONLY, addWithEntryTemplateOnly);
        }, getPromptForPropsOnAdd:function () {
            return this.getValue(this.PROMPT_FOR_PROPERTIES_ON_ADD);
        }, setPromptForPropsOnAdd:function (promptForPropsOnAdd) {
            this.setValue(this.PROMPT_FOR_PROPERTIES_ON_ADD, promptForPropsOnAdd);
        }, getDeleteEmailOnAdd:function () {
            return this.getValue(this.DELETE_EMAIL_ON_ADD);
        }, setDeleteEmailOnAdd:function (deleteEmailOnAdd) {
            this.setValue(this.DELETE_EMAIL_ON_ADD, deleteEmailOnAdd);
        }, getSendEmailAsLinkOnly:function () {
            return this.getValue(this.SEND_EMAIL_AS_LINK_ONLY);
        }, setSendEmailAsLinkOnly:function (sendEmailAsLinkOnly) {
            this.setValue(this.SEND_EMAIL_AS_LINK_ONLY, sendEmailAsLinkOnly);
        }, getEnablePropMappingForAdd:function () {
            return this.getValue(this.ENABLE_PROP_MAPPING_FOR_ADD);
        }, setEnablePropMappingForAdd:function (enablePropMappingOnAdd) {
            this.setValue(this.ENABLE_PROP_MAPPING_FOR_ADD, enablePropMappingOnAdd);
        }, getMobileAppAccess:function () {
            return this.getValue(this.MOBILE_APP_ACCESS, false);
        }, setMobileAppAccess:function (mobileAppAccess) {
            this.setValue(this.MOBILE_APP_ACCESS, mobileAppAccess);
        }, getAddPhotoFromMobile:function () {
            return this.getValue(this.ADD_PHOTO_FROM_MOBILE, false);
        }, setAddPhotoFromMobile:function (addPhotoFromMobile) {
            this.setValue(this.ADD_PHOTO_FROM_MOBILE, addPhotoFromMobile);
        }, getAddDocFoldersToRepo:function () {
            return this.getValue(this.ADD_DOC_FOLDERS_TO_REPO, false);
        }, setAddDocFoldersToRepo:function (addDocFoldersToRepo) {
            this.setValue(this.ADD_DOC_FOLDERS_TO_REPO, addDocFoldersToRepo);
        }, getOpenDocFromOtherApp:function () {
            return this.getValue(this.OPEN_DOC_FROM_OTHER_APP, false);
        }, setOpenDocFromOtherApp:function (openDocFromOtherApp) {
            this.setValue(this.OPEN_DOC_FROM_OTHER_APP, openDocFromOtherApp);
        }, setMobileFeatures:function (features) {
            this.features = features;
        }, getMobileFeatures:function () {
            return this.features;
        }, getMobileFeaturesInterfaceText:function () {
            return this.mobileTexts;
        }, setMobileFeaturesInterfaceText:function (mobileTexts) {
            this.mobileTexts = mobileTexts;
        }, updateFeaturesList:function (featuresData, featuresInterfaceTestData, callback) {
            var data = {"mobileFeaturesData":featuresData, "mobileFeaturesInterfaceTextData":featuresInterfaceTestData};
            var params = lang.mixin({action:"updateMobileFeatures", id:this.id, configuration:this.name}, this.default_params);
            var request = ecm.model.Request.postService("admin/configuration", null, params, "text/json", dojojson.toJson(data), lang.hitch(this, function (response) {
                if (callback) {
                    callback(response);
                }
            }));
            return this;
        }, setAuthenticationType:function (authType) {
            this.setValue(this.AUTHENTICATION_TYPE, authType);
        }, getAuthenticationType:function () {
            return this.getValue(this.AUTHENTICATION_TYPE, false);
        }, setDefaultDataSource:function (defaultDataSource) {
            this.setValue(this.DEFAULT_DATA_SOURCE, defaultDataSource);
        }, getDefaultDataSource:function () {
            return this.getValue(this.DEFAULT_DATA_SOURCE, false);
        }, getDataSources:function () {
            return this.getValues(this.DATA_SOURCES);
        }, setDataSources:function (dataSources) {
            return this.setValues(this.DATA_SOURCES, dataSources);
        }, isAccessControlEnabled:function () {
            return this.getValue(this.ACCESS_CONTROL_ENABLED);
        }, setAccessControlEnabled:function (enabled) {
            this.setValue(this.ACCESS_CONTROL_ENABLED, enabled);
        }});
        DesktopConfig.createDesktopConfig = function (id) {
            return new DesktopConfig(id, "DesktopConfig");
        };
        return DesktopConfig;
    });
}, "ecm/model/admin/AdminConfig":function () {
    define("ecm/model/admin/AdminConfig", ["dojo/_base/declare", "../../LoggerMixin"], function (declare, LoggerMixin) {
        var AdminConfig = declare("ecm.model.admin.AdminConfig", [LoggerMixin], {FOLDER_DEFAULT_FIXED_COLS:"folderDefFixedCols", DOCUMENT_SYSTEM_PROPERTIES:"documentSystemProperties", FOLDER_SYSTEM_PROPERTIES:"folderSystemProperties", OPERATORS:"operators", SEARCH_MAX_RESULTS:"searchMaxResults", TIMEOUT_IN_SECONDS:"timeoutInSeconds", NUMBER_OF_SEARCHES_TO_DISPLAY:"numberOfSearchesToDisplay", OPERATOR_DATETIME:"datetimeOp", OPERATOR_INTEGER:"integerOp", OPERATOR_FLOAT:"floatOp", OPERATOR_STRING:"stringOp", OPERATOR_BOOLEAN:"booleanOp", OPERATOR_OBJECT:"objectOp", OPERATOR_ID:"idOp", OPERATOR_USER:"userOp", constructor:function (id) {
        }, _noOp:null});
        AdminConfig.createAdminConfig = function (type) {
            switch (type.toUpperCase()) {
              case "P8":
                dojo["require"]("ecm.model.admin.P8AdminConfig");
                return new ecm.model.admin.P8AdminConfig();
              case "CM":
                dojo["require"]("ecm.model.admin.CMAdminConfig");
                return new ecm.model.admin.CMAdminConfig();
              case "CMIS":
                dojo["require"]("ecm.model.admin.CMISAdminConfig");
                return new ecm.model.admin.CMISAdminConfig();
              case "OD":
                dojo["require"]("ecm.model.admin.ODAdminConfig");
                return new ecm.model.admin.ODAdminConfig();
              default:
                return null;
            }
        };
        AdminConfig.PSEUDO_NAME = "{NAME}";
        return AdminConfig;
    });
}, "idx/main":function () {
    define(["require", "dojo/_base/lang", "dojo/_base/kernel", "dojo/_base/window", "dojo/dom-class"], function (dRequire, dLang, dKernel, dWindow, dDomClass) {
        var iMain = dLang.getObject("idx", true);
        var applyDojoVersionClass = function () {
            var bodyNode = dWindow.body();
            var versionClass = "idx_dojo_" + dKernel.version.major + "_" + dKernel.version.minor;
            dDomClass.add(bodyNode, versionClass);
        };
        var majorVersion = dKernel.version.major;
        var minorVersion = dKernel.version.minor;
        if ((majorVersion < 2) && (minorVersion < 7)) {
            dojo.addOnLoad(applyDojoVersionClass);
        } else {
            dRequire(["dojo/domReady!"], applyDojoVersionClass);
        }
        return iMain;
    });
}, "ecm/model/SearchTemplateFolder":function () {
    define("ecm/model/SearchTemplateFolder", ["dojo/_base/declare", "./_ModelObject", "./ContentItem"], function (declare, _ModelObject, ContentItem) {
        return declare("ecm.model.SearchTemplateFolder", [_ModelObject], {description:null, repository:null, teamspace:null, clearSearchTemplates:function () {
            this._templates = null;
            if (this.id == "all") {
                if (this.teamspace) {
                    this.teamspace.clearSearchTemplates();
                } else {
                    this.repository.clearSearchTemplates();
                }
            }
        }, retrieveSearchTemplates:function (callback) {
            if (this.id == "all") {
                var request = null;
                if (this.teamspace) {
                    request = this.teamspace.retrieveSearchTemplates(callback);
                } else {
                    request = this.repository.retrieveSearchTemplates(callback);
                }
            } else {
                var self = this;
                if (this._templates) {
                    if (callback) {
                        callback(this._templates);
                    }
                } else {
                    var request = ecm.model.Request.invokeService("openCabinet", this.repository.type, {repositoryId:this.repository.id, cabinet_name:this.name}, function (response) {
                        self._retrieveSearchTemplatesCompleted(response, callback);
                    });
                }
            }
            return request;
        }, _retrieveSearchTemplatesCompleted:function (response, callback) {
            var items = response.rows;
            this._templates = [];
            for (var i in items) {
                var template = ContentItem.createFromJSON(items[i], this.repository);
                this._templates.push(template);
            }
            if (callback) {
                callback(this._templates);
            }
        }});
    });
}, "ecm/model/_OpenedSearchesMixin":function () {
    define("ecm/model/_OpenedSearchesMixin", ["dojo/_base/declare"], function (declare) {
        return declare("ecm.model._OpenedSearchesMixin", null, {getOpenedSearches:function () {
            if (!this._openedSearches) {
                return {};
            } else {
                return this._openedSearches;
            }
        }, addOpenedSearch:function (searchTemplate) {
            if (!searchTemplate) {
                return;
            }
            if (!this._openedSearches) {
                this._openedSearches = {};
            }
            if (!this._openedSearches[searchTemplate.UUID]) {
                this._openedSearches[searchTemplate.UUID] = searchTemplate;
                this.onOpenedSearchesUpdated(searchTemplate);
            }
        }, removeOpenedSearch:function (searchTemplate) {
            if (!searchTemplate || !this._openedSearches) {
                return;
            }
            if (this._openedSearches[searchTemplate.UUID]) {
                delete this._openedSearches[searchTemplate.UUID];
                this.onOpenedSearchesUpdated(searchTemplate);
            }
        }, isSearchOpened:function (searchTemplate) {
            var opened = false;
            if (searchTemplate) {
                uuid = searchTemplate.generateUUID();
                for (var i in this.getOpenedSearches()) {
                    if (i.indexOf(uuid) > -1) {
                        opened = true;
                        break;
                    }
                }
            }
            return opened;
        }, onOpenedSearchesUpdated:function (searchTemplate) {
        }});
    });
}, "ecm/model/WorkItem":function () {
    define("ecm/model/WorkItem", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/json", "./Item", "./ContentItem", "./ContentClass", "./AttributeDefinition", "./ResultSet", "./UserGroup", "./User"], function (declare, lang, array, dojojson, Item, ContentItem, ContentClass, AttributeDefinition, ResultSet, UserGroup, User) {
        var WorkItem = declare("ecm.model.WorkItem", [Item], {connectionPoint:null, contentItem:null, objectStore:null, workClass:null, queueName:"", workflowVersion:"", workclass_name:"", sheet_name:"", step_name:"", EDS_Service:null, queue_type:null, can_return:false, can_reassign:false, can_view_history:false, can_view_status:false, F_StepBaseurl:null, F_StepLocation:null, F_StepTemplate:null, F_StepHeight:null, F_StepWidth:null, F_VWVersion:null, F_AttachmentId:null, F_InitiatingAttachment:null, showCheckoutForReservation:false, getObjectStore:function () {
            if (!this.objectStore) {
                this.objectStore = this.objectStoreId ? {id:this.objectStoreId, symbolicName:this.objectStoreName, displayName:this.objectStoreDisplayName} : null;
            }
            return this.objectStore;
        }, getContentItem:function () {
            return this.contentItem;
        }, setAttachmentId:function (id) {
            this.F_AttachmentId = id;
        }, setSubject:function (subject) {
            this.setValue("F_Subject", subject);
        }, isAttributeHidden:function (attributeId) {
            return false;
        }, retrieveAttributes:function (callback) {
            try {
                this.getContentClass();
                this.onChange([this]);
            }
            catch (e) {
            }
            if (callback) {
                callback(this);
            }
        }, onChange:function (item) {
            if (this.resultSet) {
                this.resultSet.onChange(item);
            }
            ecm.model.desktop.onChange(item);
        }, getWorkClass:function () {
            return this.workClass;
        }, getContentClass:function () {
            if (this._contentClass) {
                return this._contentClass;
            }
            this._contentClass = new ContentClass({id:"Worklist", name:"Worklist", repository:this.repository, pseudoClass:true, allowsInstances:false});
            var attributes = [];
            var subject = new AttributeDefinition({id:"F_Subject", name:ecm.messages.process_info_subject, repositoryType:this.repository.type, dataType:"xs:string", system:true, settability:"", contentClass:this._contentClass});
            this.attributeSystemProperty["F_Subject"] = "true";
            this.attributeLabels["F_Subject"] = ecm.messages.process_info_subject;
            attributes.push(subject);
            var stepName = new AttributeDefinition({id:"F_StepName", name:ecm.messages.process_info_stepname, repositoryType:this.repository.type, dataType:"xs:string", system:true, settability:"", contentClass:this._contentClass});
            this.attributeSystemProperty["F_StepName"] = "true";
            this.attributeLabels["F_StepName"] = ecm.messages.process_info_stepname;
            attributes.push(stepName);
            var isLocked = new AttributeDefinition({id:"F_Locked", name:ecm.messages.process_info_is_locked, repositoryType:this.repository.type, dataType:"xs:boolean", system:true, settability:"", contentClass:this._contentClass});
            this.attributeSystemProperty["F_Locked"] = "true";
            this.attributeLabels["F_Locked"] = ecm.messages.process_info_is_locked;
            attributes.push(isLocked);
            var enqueueTime = new AttributeDefinition({id:"F_EnqueueTime", name:ecm.messages.process_info_received_on, repositoryType:this.repository.type, dataType:"xs:timestamp", system:true, settability:"", contentClass:this._contentClass});
            this.attributeSystemProperty["F_EnqueueTime"] = "true";
            this.attributeLabels["F_EnqueueTime"] = ecm.messages.process_info_received_on;
            attributes.push(enqueueTime);
            var overdue = new AttributeDefinition({id:"F_Overdue", name:ecm.messages.process_info_overdue, repositoryType:this.repository.type, dataType:"xs:string", system:true, settability:"", contentClass:this._contentClass});
            this.attributeSystemProperty["F_Overdue"] = "true";
            this.attributeLabels["F_Overdue"] = ecm.messages.process_info_overdue;
            attributes.push(overdue);
            var lockedUser = new AttributeDefinition({id:"F_LockedUser", name:ecm.messages.process_info_locked_by_user, repositoryType:this.repository.type, dataType:"xs:string", system:true, settability:"", contentClass:this._contentClass});
            this.attributeSystemProperty["F_LockedUser"] = "true";
            this.attributeLabels["F_LockedUser"] = ecm.messages.process_info_locked_by_user;
            attributes.push(lockedUser);
            var wobNum = new AttributeDefinition({id:"wobNum", name:ecm.messages.process_work_object_number, repositoryType:this.repository.type, dataType:"xs:string", system:true, settability:"", contentClass:this._contentClass});
            this.attributeSystemProperty["wobNum"] = "true";
            this.attributeLabels["wobNum"] = ecm.messages.process_work_object_number;
            attributes.push(wobNum);
            this._contentClass.attributeDefinitions = attributes;
            return this._contentClass;
        }, isWorkItem:function () {
            return true;
        }, isDeclaredAsRecord:function () {
            return false;
        }, retrieveLaunchParameters:function (callback) {
            this.logInfo("retrieveLaunchParameters", "launch_version = " + this.workflowVersion + ", attachmentId = " + this.F_AttachmentId);
            var self = this;
            var mode = this.F_Mode;
            if (mode == null) {
                mode = "";
            }
            var objectStore = this.getObjectStore();
            var request = ecm.model.Request.invokeService("getLaunchParameters", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:objectStore ? objectStore.id : "", launch_version:encodeURIComponent(this.workflowVersion || ""), attachmentId:this.F_AttachmentId, propertyMap:this.F_PropertyMap, workClassName:encodeURIComponent(this.workclass_name || ""), mode:mode}, function (response) {
                self.id = response.wobNum;
                self.name = response.Name;
                self._retrieveParametersCompleted(response, callback);
            });
        }, retrieveStepParameters:function (callback, lockItem) {
            this.logInfo("retrieveStepParameters", "queue_name = " + this.queueName + ", wob_num = " + this.id);
            var lockStepItem = true;
            if (lockItem != undefined) {
                lockStepItem = lockItem;
            }
            var self = this;
            var params = {repositoryId:this.repository.id};
            if (this.repository.type == "cm") {
                params.workItemId = this.id;
            } else {
                params.connection_point = this.connectionPoint;
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
                params.wob_num = this.id;
                params.queue_name = this.queueName ? encodeURIComponent(this.queueName) : "";
                params.step_lock_item = lockStepItem ? "true" : "false";
            }
            var request = ecm.model.Request.invokeService("getStepParameters", this.repository.type, params, function (response) {
                self._retrieveParametersCompleted(response, callback);
            });
        }, _retrieveParametersCompleted:function (response, callback) {
            this.workClass = new ContentClass({id:"WorkClass", name:"WorkClass", repository:this.repository, pseudoClass:true, allowsInstances:false});
            var attributeDefinitions = [];
            this.customactionAttr = [];
            for (var i in response.criterias) {
                var attribute = response.criterias[i];
                var attributeId = attribute.name;
                if (attribute.dataType == "xs:group") {
                    this.attributes[attributeId] = this._createUserGroupAttributeValue(attribute);
                } else {
                    this.attributes[attributeId] = attribute.value;
                }
                if (attribute.dataType || attribute.dataType == "") {
                    this.attributeTypes[attributeId] = attribute.dataType;
                }
                if (attribute.format || attribute.format == "") {
                    this.attributeFormats[attributeId] = attribute.format;
                }
                if (attribute.initiatingAttachment) {
                    this.F_InitiatingAttachment = attribute.initiatingAttachment;
                }
                if (attribute.customaction != undefined) {
                    this.customactionAttr.push(attribute);
                }
                attributeDefinitions.push(this._createAttributeDefinition(attribute));
            }
            if (this.repository.type == "p8") {
                this.queue_type = response.queue_type;
                this.step_name = response.step_name;
                this.sheet_name = response.sheet_name;
                this.workclass_name = response.workclass_name;
                if (response.EDS_Service) {
                    this.EDS_Service = respopnse.EDS_Service;
                }
                this.can_return = response.can_return;
                this.can_reassign = response.can_reassign;
                this.can_view_history = response.can_view_history;
                this.can_view_status = response.can_view_status;
            } else {
                this.step_name = response.processStep;
                this.workclass_name = response.process_name;
            }
            this.workClass.attributeDefinitions = attributeDefinitions;
            this.workClass.attributeDefinitionsById = {};
            array.forEach(this.workClass.attributeDefinitions, lang.hitch(this, function (attrDef) {
                this.workClass.attributeDefinitionsById[attrDef.id] = attrDef;
            }));
            this.onChange([this]);
            if (callback) {
                callback(this);
            }
        }, retrieveAttachments:function (callback) {
            this.logInfo("retrieveAttachments", "queue_name = " + this.queueName + ", wob_num = " + this.id);
            if (this.resultSet && this.resultSet.setType == "attachmentItems") {
                this.logInfo("retrieveAttachments", "Returning cached result set of attachments");
                callback(this.resultSet);
            } else {
                var self = this;
                this.logInfo("retrieveAttachments", "Calling getStepAttachments action");
                var request = null;
                if (this.repository.type == "cm") {
                    request = ecm.model.Request.invokeService("getStepAttachments", this.repository.type, {repositoryId:this.repository.id, workItemId:this.id, step_lock_item:"false"}, function (response) {
                        self._retrieveAttachmentsCompleted(response, callback);
                    });
                } else {
                    request = ecm.model.Request.invokeService("getStepAttachments", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:this.objectStore ? this.objectStore.id : "", wob_num:this.id, queue_name:this.queueName ? encodeURIComponent(this.queueName) : "", launch_version:this.workflowVersion ? encodeURIComponent(this.workflowVersion) : "", attachmentId:this.F_AttachmentId ? this.F_AttachmentId : "", step_lock_item:"false"}, function (response) {
                        self._retrieveAttachmentsCompleted(response, callback);
                    });
                }
            }
        }, _retrieveAttachmentsCompleted:function (response, callback) {
            this.logInfo("_retrieveAttachmentsCompleted", "Returning new result set of attachments");
            response.repository = this.repository;
            response.parentFolder = this;
            response.setType = "attachmentItems";
            var results = new ecm.model.ResultSet(response);
            this.resultSet = results;
            if (response.docid) {
                this.id = response.docid;
            }
            if (callback) {
                callback(results);
            }
        }, retrieveTransferedWorkflows:function (callback, item, filterClassNames) {
            var self = this;
            var request = ecm.model.Request.invokeService("getTransferedWorkflows", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, docid:item ? item.id : "", filter_criteria:filterClassNames ? encodeURIComponent(dojojson.stringify(filterClassNames)) : ""}, function (response) {
                self._retrieveTransferedWorkflowsCompleted(response, callback);
            });
        }, _retrieveTransferedWorkflowsCompleted:function (response, callback) {
            if (response.workclass_name) {
                this.workclass_name = response.workclass_name;
                this.workclass_name_exists = response.workclass_name_exists;
            }
            if (callback) {
                callback(response.items);
            }
        }, transferWorkflow:function (callback, item, workClassName) {
            this.workclass_name = workClassName;
            var self = this;
            var request = ecm.model.Request.invokeService("transferWorkflow", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, docid:item.id, workclass_name:encodeURIComponent(workClassName || "")}, function (response) {
                self._transferWorkflowCompleted(response, callback);
            });
        }, _transferWorkflowCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
        }, createAttachmentId:function (item) {
            var attachmentId = null;
            var name = item.name;
            var objectStoreName = item.getObjectStore().displayName;
            if (item.isFolder()) {
                var id = item.getValue("Id");
                attachmentId = name + "||2|3|" + objectStoreName + "|" + id;
            } else {
                var vsId = item.vsId;
                attachmentId = name + "||3|3|" + objectStoreName + "|" + vsId;
            }
            this.logInfo("createAttachmentId", "Created attachmentId = " + attachmentId);
            return attachmentId;
        }, createSubject:function (item) {
            var subject = "";
            subject = this.name + " " + ecm.messages.suspend_for_duration_label + " " + item.name;
            return subject;
        }, _createUserGroupAttributeValue:function (attribute) {
            var participants = [];
            for (var j in attribute.value) {
                var value = attribute.value[j];
                if (value.isGroup) {
                    var group = new UserGroup(value);
                    participants.push(group);
                } else {
                    var user = new User(value);
                    participants.push(user);
                }
            }
            return participants;
        }, _createAttributeDefinition:function (attribute) {
            var attributeDefinition = new AttributeDefinition({id:attribute.name, name:attribute.label, repositoryType:this.repository.type, dataType:attribute.dataType, format:attribute.format ? attribute.format : "", defaultValue:"", required:attribute.required, readOnly:attribute.readOnly, hidden:attribute.hidden, system:attribute.system, settability:"", allowedValues:attribute.validValues, maxLength:attribute.maxEntry, minLength:attribute.minEntry, minValue:attribute.minValue, maxValue:attribute.maxValue, cardinality:attribute.cardinality, choiceList:attribute.choiceList, contentClass:this.workClass, serachable:false, nullable:attribute.nullable ? attribute.nullable : true, hasDependentAttributes:attribute.hasDependentAttributes, formatDescription:attribute.formatDescription ? attribute.formatDescription : ""});
            if (attribute.dataType == "xs:group") {
                if (attribute.votingParameter) {
                    attributeDefinition.setMetaData("votingParameter", attribute.votingParameter);
                    attributeDefinition.setMetaData("votingNumber", attribute.votingNumber);
                }
            }
            return attributeDefinition;
        }, retrieveDependentParameters:function (attributes, callback) {
            var self = this;
            var modifiedAttributes = [];
            var attributeDefinitions = this.workClass.attributeDefinitions;
            for (var i in attributeDefinitions) {
                var attributeDefinition = attributeDefinitions[i];
                modifiedAttributes.push(this._getModifiedParameters(attributeDefinition, attributes[attributeDefinition.id]));
            }
            var params = {repositoryId:this.repository.id};
            var attributeParameters = {"Name":this.name, "wobNum":this.id, "workclass_name":this.workclass_name, "step_name":this.step_name, criterias:modifiedAttributes};
            if (this.repository.type == "p8") {
                params.connection_point = this.connectionPoint;
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
                params.wob_num = this.id;
                params.queue_name = this.queueName ? encodeURIComponent(this.queueName) : "";
                attributeParameters.sheet_name = this.sheet_name;
                if (this.EDS_Service) {
                    attributeParameters.EDS_Service = this.EDS_Service;
                }
                if (this.queueName) {
                    attributeParameters.queueName = this.queueName;
                } else {
                    attributeParameters.queueName = "";
                }
            }
            var request = null;
            request = ecm.model.Request.postService("getDependentParameters", this.repository.type, params, "text/json", dojojson.stringify(attributeParameters), function (response) {
                self._retrieveDependentParametersCompleted(response, callback);
            });
            return request;
        }, hasDependentAttributes:function () {
            if (!this.workClass || !this.workClass.attributeDefinitions) {
                return false;
            }
            var hasDependentAttributes = false;
            for (var i in this.workClass.attributeDefinitions) {
                if (this.workClass.attributeDefinitions[i].hasDependentAttributes) {
                    hasDependentAttributes = true;
                    break;
                }
            }
            return hasDependentAttributes;
        }, _getModifiedParameters:function (attributeDefinition, value) {
            if (attributeDefinition.system) {
                value = this.getValue(attributeDefinition.id);
            } else {
                if (attributeDefinition.dataType == "xs:attachment") {
                    value = this.getValue(attributeDefinition.id);
                }
            }
            if (!value) {
                value = "";
            }
            var attributeDef = {"name":attributeDefinition.id, "label":attributeDefinition.name, "dataType":attributeDefinition.dataType, "required":attributeDefinition.required, "readOnly":attributeDefinition.readOnly, "hidden":attributeDefinition.hidden, "system":attributeDefinition.system, "cardinality":attributeDefinition.cardinality, "hasDependentAttributes":attributeDefinition.hasDependentAttributes, "value":value};
            var validValues = attributeDefinition.allowedValues;
            if (validValues) {
                attributeDef.validValues = validValues;
            } else {
                attributeDef.validValues = "";
            }
            var maxValue = attributeDefinition.maxValue;
            if (maxValue) {
                attributeDef.maxValue = maxValue;
            } else {
                attributeDef.maxValue = "";
            }
            var minValue = attributeDefinition.minValue;
            if (minValue) {
                attributeDef.minValue = minValue;
            } else {
                attributeDef.minValue = "";
            }
            var maxEntry = attributeDefinition.maxLength;
            if (maxEntry) {
                attributeDef.maxEntry = maxEntry;
            } else {
                attributeDef.maxEntry = "";
            }
            return attributeDef;
        }, _retrieveDependentParametersCompleted:function (response, callback) {
            var attributeDefinitions = [];
            for (var i in response.criterias) {
                var attribute = response.criterias[i];
                var attributeId = attribute.name;
                if (attribute.dataType == "xs:group") {
                    this.attributes[attributeId] = this._createUserGroupAttributeValue(attribute);
                } else {
                    this.attributes[attributeId] = attribute.value;
                }
                if (attribute.dataType || attribute.dataType == "") {
                    this.attributeTypes[attributeId] = attribute.dataType;
                }
                if (attribute.format || attribute.format == "") {
                    this.attributeFormats[attributeId] = attribute.format;
                }
                var attributeDefinition = this._createAttributeDefinition(attribute);
                attributeDefinition.defaultValue = attribute.value;
                attributeDefinitions.push(attributeDefinition);
            }
            this.workClass.attributeDefinitions = attributeDefinitions;
            if (callback) {
                callback(attributeDefinitions);
            }
        }, completeStep:function (attributes, dispatch, callback) {
            this.logInfo("completeStep", "queue_name = " + this.queueName + ", wob_num = " + this.id, ", step_dispatch = ", +dispatch);
            var self = this;
            var data = attributes;
            var params = {repositoryId:this.repository.id, step_dispatch:dispatch};
            if (this.repository.type == "cm") {
                params.workItemId = this.id;
            } else {
                params.connection_point = this.connectionPoint;
                params.objectStoreId = this.objectStore ? this.objectStore.id : "";
                params.wob_num = this.id;
                params.queue_name = this.queueName ? encodeURIComponent(this.queueName) : "";
                params.launch_version = this.workflowVersion ? encodeURIComponent(this.workflowVersion) : "";
                params.attachmentId = this.F_AttachmentId ? this.F_AttachmentId : "";
            }
            var request = ecm.model.Request.postService("completeStep", this.repository.type, params, "text/json", dojojson.stringify(data), lang.hitch(this, function (response) {
                self._completeStepCompleted(response, callback);
            }));
        }, _completeStepCompleted:function (response, callback) {
            if (callback) {
                if (response && response.fieldErrors) {
                    this.logInfo("_completeStepCompleted", "Response contains field validation errors");
                }
                callback(this, response);
            }
        }, unlockStep:function (abort, callback) {
            if (this.repository.type == "p8") {
                this.logInfo("unlockStep", "queue_name = " + this.queueName + ", wob_num = " + this.id);
                var self = this;
                var request = ecm.model.Request.invokeService("unlockStep", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:this.objectStore ? this.objectStore.id : "", wob_num:this.id, queue_name:this.queueName ? encodeURIComponent(this.queueName) : "", step_abort_item:abort}, function (response) {
                    self._setUnlockStepCompleted(response, callback);
                });
            } else {
                if (callback) {
                    callback(this);
                }
            }
        }, _setUnlockStepCompleted:function (response, callback) {
            if (callback) {
                callback(this);
            }
        }, retrieveProcessorInformation:function (type, callback, objectId, objectStoreName) {
            this.logInfo("retrieveProcessorInformation", "queue_name = " + this.queueName + ", wob_num = " + this.id);
            if (this && this.F_StepLocation) {
                callback(this);
                return;
            }
            var self = this;
            var params = {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:this.objectStore ? this.objectStore.id : "", step_type:type};
            if (type && type == "launch") {
                if (objectId != null) {
                    params.docid = objectId;
                } else {
                    params.docid = this.id;
                }
                if (params.docid == null) {
                    params.vsId = this.vsId;
                }
                if (objectStoreName != null) {
                    params.object_store = objectStoreName;
                } else {
                    params.object_store = this.repository.objectStoreName;
                }
                if (this.workclass_name != null) {
                    params.workClassName = this.workclass_name;
                }
            } else {
                params.wob_num = this.id;
                params.queue_name = encodeURIComponent(this.queueName);
                params.step_id = this.F_StepProcId;
                params.step_name = this.attributes.F_StepName;
            }
            var request = ecm.model.Request.invokeService("getProcessorInformation", this.repository.type, params, function (response) {
                self._retrieveProcessorInformationCompleted(response, callback);
            });
        }, _retrieveProcessorInformationCompleted:function (response, callback) {
            this.F_StepBaseurl = response.step_baseurl;
            this.logInfo("_retrieveProcessorInformationCompleted", "BaseUrl = " + this.F_StepBaseurl);
            this.F_StepLocation = response.step_location;
            this.logInfo("_retrieveProcessorInformationCompleted", "Location = " + this.F_StepLocation);
            this.F_StepTemplate = decodeURIComponent(response.step_template);
            this.logInfo("_retrieveProcessorInformationCompleted", "Template = " + this.F_StepTemplate);
            this.F_StepHeight = response.step_height;
            this.F_StepWidth = response.step_width;
            if (response.vwversion) {
                this.F_VWVersion = response.vwversion;
            }
            if (response.workClassName) {
                this.workclass_name = response.workClassName;
            }
            if (callback) {
                callback(this);
            }
        }, retrieveSubscriptions:function (callback) {
            var self = this;
            var request = ecm.model.Request.invokeService("getSubscriptions", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:this.objectStore ? this.objectStore.id : "", docid:this.id}, function (response) {
                self._retrieveSubscriptionsCompleted(response, callback);
            });
        }, _retrieveSubscriptionsCompleted:function (response, callback) {
            this.F_AttachmentId = response.attachmentId;
            this._subscriptions = response.datastore.items;
            if (callback) {
                callback(this, this._subscriptions);
            }
        }, retrieveTrackerParameters:function (callback) {
            this.logInfo("retrieveTrackerParameters", "queue_name = " + this.queueName + ", wob_num = " + this.id);
            var self = this;
            var request = ecm.model.Request.invokeService("getTrackerParameters", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:this.objectStore ? this.objectStore.id : "", wob_num:this.id, queue_name:this.queueName ? encodeURIComponent(this.queueName) : "", step_lock_item:"true"}, function (response) {
                self._retrieveTrackerParametersCompleted(response, callback);
            });
        }, _retrieveTrackerParametersCompleted:function (response, callback) {
            var attributeDefinitions = [];
            for (var i in response.criterias) {
                var attribute = response.criterias[i];
                var attributeId = attribute.name;
                if (attribute.dataType == "xs:group") {
                    this.attributes[attributeId] = this._createUserGroupAttributeValue(attribute);
                } else {
                    this.attributes[attributeId] = attribute.value;
                }
                if (attribute.dataType || attribute.dataType == "") {
                    this.attributeTypes[attributeId] = attribute.dataType;
                }
                if (attribute.format || attribute.format == "") {
                    this.attributeFormats[attributeId] = attribute.format;
                }
                if (attribute.initiatingAttachment) {
                    this.F_InitiatingAttachment = attribute.initiatingAttachment;
                }
                attributeDefinitions.push(this._createAttributeDefinition(attribute));
            }
            this.queue_type = response.queue_type;
            this.step_name = response.step_name;
            this.sheet_name = response.sheet_name;
            this.workclass_name = response.workclass_name;
            this.onChange([this]);
            if (callback) {
                callback(this);
            }
        }, retrieveTrackerHistory:function (callback) {
            var self = this;
            if (this._trackerHistory) {
                callback(this._trackerHistory);
            } else {
                var request = ecm.model.Request.invokeService("getTrackerHistory", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, wob_num:this.id, queue_name:this.queueName ? encodeURIComponent(this.queueName) : ""}, function (response) {
                    self._trackerHistory = response;
                    self._retrieveTrackerHistoryCompleted(response, callback);
                });
            }
        }, _retrieveTrackerHistoryCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
        }, retrieveTrackerMilestones:function (callback, milestoneLevel) {
            var self = this;
            var request = ecm.model.Request.invokeService("getTrackerMilestones", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, wob_num:this.id, queue_name:this.queueName ? encodeURIComponent(this.queueName) : "", milestone_level:milestoneLevel}, function (response) {
                self._retrieveTrackerMilestonesCompleted(response, callback);
            });
        }, _retrieveTrackerMilestonesCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
        }, retrieveMilestones:function (callback, milestoneLevel) {
            var self = this;
            var request = ecm.model.Request.invokeService("getTrackerMilestones", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, work_space_id:this.workSpaceId, work_class_id:this.workClassId, workflow_number:this.id, milestone_level:milestoneLevel}, function (response) {
                self._retrieveMilestonesCompleted(response, callback);
            });
        }, _retrieveMilestonesCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
        }, deleteTracker:function (lock, callback) {
            this.logInfo("deleteTracker", "queue_name = " + this.queueName + ", wob_num = " + this.id);
            var self = this;
            var request = ecm.model.Request.invokeService("deleteTracker", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, wob_num:this.id, queue_name:this.queueName ? encodeURIComponent(this.queueName) : "", step_lock_item:lock}, callback);
        }, moveToInbox:function (callback, items) {
            this.logInfo("moveToInbox", "queue_name = " + this.queueName);
            var wobNums = null;
            if (items == undefined) {
                wobNums = this._buildWobNumArray(this);
            } else {
                wobNums = this._buildWobNumArray(items);
            }
            var self = this;
            var request = ecm.model.Request.invokeService("moveToInbox", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:this.objectStore ? this.objectStore.id : "", wob_num:wobNums, queue_name:this.queueName ? encodeURIComponent(this.queueName) : "", step_lock_item:"true"}, function (response) {
                self._moveToInboxCompleted(response, callback);
            });
        }, _moveToInboxCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
        }, returnToSender:function (callback) {
            this.logInfo("returnToSender", "queue_name = " + this.queueName + ", wob_num = " + this.id);
            var request = ecm.model.Request.invokeService("returnToSender", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:this.objectStore ? this.objectStore.id : "", wob_num:this.id, queue_name:this.queueName ? encodeURIComponent(this.queueName) : "", step_lock_item:"true"}, callback);
        }, reassign:function (user, displayName, delegate, callback, items) {
            this.logInfo("reassign", "queue name = " + this.queueName + ", new user = " + displayName);
            var wobNums = null;
            if (items == undefined) {
                wobNums = this._buildWobNumArray(this);
            } else {
                wobNums = this._buildWobNumArray(items);
            }
            var self = this;
            var request = ecm.model.Request.invokeService("reassign", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, objectStoreId:this.objectStore ? this.objectStore.id : "", wob_num:wobNums, queue_name:this.queueName ? encodeURIComponent(this.queueName) : "", step_lock_item:"true", user_name:user, user_display_name:displayName, delegate_flag:delegate}, function (response) {
                self._reassignCompleted(response, callback);
            });
        }, _reassignCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
        }, _buildWobNumArray:function (items) {
            var wobNums = [];
            if (items instanceof String) {
                wobNums.push(items);
            } else {
                if (lang.isArray(items)) {
                    for (var i in items) {
                        var item = items[i];
                        if (item instanceof String) {
                            wobNums.push(item);
                        } else {
                            wobNums.push(item.id);
                        }
                    }
                } else {
                    wobNums.push(items.id);
                }
            }
            return wobNums;
        }, launchWorkflow:function (item, callback) {
            this.logInfo("launchWorkflow", "workflowObjectStoreName = " + this.objectStoreName + ", workflowId = " + this.id + ", workflowVsId = " + this.vsId);
            var request = null;
            if (this.repository._isP8()) {
                var self = this;
                var workflowId = this.id;
                if (!workflowId) {
                    workflowId = "";
                } else {
                    if (workflowId.indexOf(",") > 0) {
                        workflowId = workflowId.split(",")[2];
                    }
                }
                var params = {repositoryId:this.repository.id, connection_point:this.connectionPoint, workflowObjectStoreName:this.objectStoreName, workflowId:workflowId, workflowVsId:this.vsId, workflowStyle:this.styleName};
                if (item != null) {
                    params.docid = item.getValue("Id");
                    params.objectStoreName = item.repository.objectStoreName;
                    params.attachmentId = this.createAttachmentId(item);
                    params.subject = this.createSubject(item);
                    this.logInfo("launchWorkflow", "objectStoreName = " + params.objectStoreName + ", docid = " + params.docid + ", attachmentId = " + params.attachmentId);
                }
                request = ecm.model.Request.invokeService("launchWorkflow", this.repository.type, params, function (response) {
                    self._launchWorkflowCompleted(response, callback);
                });
            }
            return request;
        }, _launchWorkflowCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
        }, startWorkflow:function (items, callback) {
            var request = null;
            if (this.repository._isCM()) {
                var docidJson = "{";
                for (var i in items) {
                    docidJson = docidJson + "\"" + "docid" + i + "\":\"" + items[i].id + "\",";
                }
                docidJson = docidJson.substring(0, docidJson.length - 1) + "}";
                var params = lang.mixin(dojojson.parse(docidJson), {repositoryId:this.repository.id, process_name:this.workflowName, process_owner:this.owner, process_priority:this.priority});
                var self = this;
                request = ecm.model.Request.invokeService("startWorkflow", this.repository.type, params, function (response) {
                    self._startWorkflowCompleted(response, callback);
                }, true);
            }
            return request;
        }, _startWorkflowCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
        }, editWorkflow:function (items, callback) {
            var request = null;
            if (this.repository._isCM()) {
                var docidJson = "{";
                for (var i in items) {
                    docidJson = docidJson + "\"" + "workItemId" + i + "\":\"" + items[i].id + "\",";
                }
                docidJson = docidJson.substring(0, docidJson.length - 1) + "}";
                var params = lang.mixin(dojojson.parse(docidJson), {repositoryId:this.repository.id, process_name:this.workflowName, process_owner:this.owner, process_priority:this.priority});
                var self = this;
                request = ecm.model.Request.invokeService("editWorkflow", this.repository.type, params, function (response) {
                    self._editWorkflowCompleted(response, callback);
                }, true);
            }
            return request;
        }, _editWorkflowCompleted:function (response, callback) {
            if (callback) {
                callback(response);
            }
        }, isWorkflowRunning:function (item, callback) {
            this.logInfo("isWorkflowRunning", "objectStoreName = " + item.repository.objectStoreName + ", docid = " + item.getValue("Id"));
            var self = this;
            var request = ecm.model.Request.invokeService("isWorkflowRunning", this.repository.type, {repositoryId:this.repository.id, connection_point:this.connectionPoint, docid:item.getValue("Id"), objectStoreName:item.repository.objectStoreName}, function (response) {
                self._isWorkflowRunningCompleted(response, callback);
            });
            return request;
        }, _isWorkflowRunningCompleted:function (response, callback) {
            if (callback) {
                callback(response.workflowRunning);
            }
        }, openFolderContent:function (callback, orderBy, descending) {
            var request = ecm.model.Request.invokeService("openFolder", this.repository.type, {repositoryId:this.repository.id, docid:this.docid, filter_type:""}, lang.hitch(this, function (response) {
                this._openFolderContentCompleted(response, callback);
            }));
            return request;
        }, _openFolderContentCompleted:function (response, callback) {
            response.repository = this.repository;
            response.parentFolder = this;
            response.setType = "contentItems";
            var results = new ecm.model.ResultSet(response);
            callback(results);
        }, hasContent:function () {
            return !ecm.model.ContentItem.NoContentMimeTypes[this.mimetype];
        }, isSystemItem:function () {
            return false;
        }});
        WorkItem.createFromJSON = function (itemJSON, repository, resultSet, parent) {
            var attributes = {};
            var attributeTypes = {};
            var attributeFormats = {};
            var attributeDisplayValues = {};
            for (var i in itemJSON.attributes) {
                var attr = itemJSON.attributes[i];
                attributes[i] = attr[0];
                if (attr.length > 1) {
                    attributeTypes[i] = attr[1];
                }
                if (attr.length > 2) {
                    attributeFormats[i] = attr[2];
                }
                if (attr.length > 3) {
                    attributeDisplayValues[i] = attr[3];
                }
            }
            lang.mixin(itemJSON, {repository:repository, connectionPoint:parent ? parent.connectionPoint : "", resultSet:resultSet, parent:parent, attributes:attributes, attributeTypes:attributeTypes, attributeFormats:attributeFormats, attributeDisplayValues:attributeDisplayValues});
            var item = new WorkItem(itemJSON);
            if (repository._isCM()) {
                itemJSON.id = itemJSON.docid;
            }
            item.contentItem = new ecm.model.ContentItem(itemJSON);
            return item;
        };
        return WorkItem;
    });
}, "ecm/model/admin/MobileFeatureConfig":function () {
    define(["dojo/_base/declare", "ecm/model/admin/_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var MobileFeatureConfig = declare("ecm.model.admin.MobileFeatureConfig", ecm.model.admin._ConfigurationObject, {DISPLAY:"display", ICON_FILE:"iconFile", NAME:"name", URL:"url", DESKTOP_ID:"desktopId", constructor:function (id, name) {
        }, getDisplay:function () {
            return this.getValue(this.DISPLAY);
        }, setDisplay:function (display) {
            this.setValue(this.DISPLAY, display);
        }, getIconFile:function () {
            return this.getValue(this.ICON_FILE);
        }, setIconFile:function (iconFile) {
            this.setValue(this.ICON_FILE, iconFile);
        }, getName:function () {
            return this.getValue(this.NAME);
        }, setName:function (name) {
            this.setValue(this.NAME, name);
        }, getUrl:function () {
            return this.getValue(this.URL);
        }, setUrl:function (url) {
            this.setValue(this.URL, url);
        }, getDesktopId:function () {
            return this.getValue(this.DESKTOP_ID);
        }, setDesktopId:function (destkopId) {
            this.setValue(this.DESKTOP_ID, desktopId);
        }});
        MobileFeatureConfig.createMobileFeatureConfig = function (id) {
            return new MobileFeatureConfig(id, "MobileFeatureConfig");
        };
        return MobileFeatureConfig;
    });
}, "ecm/model/admin/ViewerMappingConfig":function () {
    define("ecm/model/admin/ViewerMappingConfig", ["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var ViewerMappingConfig = declare("ecm.model.admin.ViewerMappingConfig", [_ConfigurationObject], {CONTENT_TYPES:"contentTypes", SERVER_TYPE:"serverType", VIEWER_NAME:"viewerName", constructor:function (id, name) {
        }, getContentTypes:function () {
            var contentTypes = this.getValue(this.CONTENT_TYPES);
            if (contentTypes instanceof Array) {
                return contentTypes;
            } else {
                if (contentTypes) {
                    return [contentTypes];
                } else {
                    return [];
                }
            }
        }, setContentTypes:function (contentTypes) {
            this.setValue(this.CONTENT_TYPES, contentTypes);
        }, getServerType:function () {
            return this.getValue(this.SERVER_TYPE);
        }, setServerType:function (serverType) {
            this.setValue(this.SERVER_TYPE, serverType);
        }, getViewerName:function () {
            return this.getValue(this.VIEWER_NAME);
        }, setViewerName:function (viewerName) {
            this.setValue(this.VIEWER_NAME, viewerName);
        }, getServerTypeString:function () {
            var type = this.getServerType();
            if (type == "od") {
                return this.messages.ondemand;
            } else {
                if (type == "cm") {
                    return this.messages.content_manager;
                } else {
                    if (type == "p8") {
                        return this.messages.filenet_p8;
                    } else {
                        if (type == "ci") {
                            return this.messages.content_integrator;
                        } else {
                            if (type == "cmis") {
                                return this.messages.cmis;
                            } else {
                                return type;
                            }
                        }
                    }
                }
            }
        }, getViewerMappingConfig:function (callback) {
            this.getConfig(callback);
            return this;
        }});
        ViewerMappingConfig.createViewerMappingConfig = function (id) {
            return new ViewerMappingConfig({id:id, name:"ViewerMappingConfig"});
        };
        return ViewerMappingConfig;
    });
}, "ecm/model/admin/PluginConfig":function () {
    define(["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var PluginConfig = declare("ecm.model.admin.PluginConfig", [_ConfigurationObject], {CONFIGURATION:"configuration", CONFIGCLASS:"configClass", NAME:"name", FILENAME:"filename", VERSION:"version", DATA_SOURCE_NAMES:"dataSourceNames", ACTIONS:"actions", VIEWERS:"viewers", FEATURES:"features", LAYOUTS:"layouts", CLASSNAME:"classname", constructor:function (id, name) {
        }, getName:function () {
            return this.getValue(this.NAME);
        }, setName:function (name) {
            this.setValue(this.NAME, name);
        }, getFileName:function () {
            return this.getValue(this.FILENAME);
        }, setFileName:function (name) {
            this.setValue(this.FILENAME, name);
        }, getClassName:function () {
            return this.getValue(this.CLASSNAME);
        }, setClassName:function (name) {
            this.setValue(this.CLASSNAME, name);
        }, getConfiguration:function () {
            return this.getValue(this.CONFIGURATION);
        }, setConfiguration:function (configuration) {
            this.setValue(this.CONFIGURATION, configuration);
        }, getConfigClass:function () {
            return this.getValue(this.CONFIGCLASS);
        }, setConfigClass:function (configClass) {
            this.setValue(this.CONFIGCLASS, configClass);
        }, getVersion:function () {
            return this.getValue(this.VERSION);
        }, setVersion:function (version) {
            this.setValue(this.VERSION, version);
        }, getDataSourceNames:function () {
            return this.getValue(this.DATA_SOURCE_NAMES);
        }, setDataSourceNames:function (dataSourceNames) {
            this.setValue(this.DATA_SOURCE_NAMES, dataSourceNames);
        }, getPluginConfig:function (callback) {
            this.getConfig(callback);
        }});
        PluginConfig.createPluginConfig = function (id) {
            return new PluginConfig(id, "PluginConfig");
        };
        return PluginConfig;
    });
}, "ecm/model/ChildComponentDefinition":function () {
    define("ecm/model/ChildComponentDefinition", ["dojo/_base/array", "dojo/_base/declare", "./_ModelObject"], function (array, declare, _ModelObject) {
        return declare("ecm.model.ChildComponentDefinition", [_ModelObject], {repository:null, attributeDefinitions:null, minCardinality:0, maxCardinality:0, setAttributeDefinitions:function (attributeDefinitions) {
            this.attributeDefinitions = attributeDefinitions;
            this.hasDependentAttributes = this._determineIfHasDependentAttributes();
        }, getAttributeDefinitions:function () {
            return this.attributeDefinitions;
        }, hasAttributes:function () {
            return (this.attributeDefinitions != null && this.attributeDefinitions.length > 0);
        }, _determineIfHasDependentAttributes:function () {
            if (!this.attributeDefinitions) {
                return true;
            }
            var hasDependentAttributes = false;
            for (var i in this.attributeDefinitions) {
                if (this.attributeDefinitions[i].hasDependentAttributes) {
                    hasDependentAttributes = true;
                }
            }
            return hasDependentAttributes;
        }, unloadAttributeDefinitions:function () {
            this.attributeDefinitions = null;
        }, clone:function () {
            var clone = new ecm.model.ChildComponentDefinition({id:this.id, name:this.name, repository:this.repository, attributeDefinitions:this.hasAttributes() ? array.map(this.attributeDefinitions, function (attrib) {
                return attrib.clone();
            }) : null, minCardinality:this.minCardinality, maxCardinality:this.maxCardinality, hasDependentAttributes:this.hasDependentAttributes});
            return clone;
        }});
    });
}, "ecm/model/Worklist":function () {
    define("ecm/model/Worklist", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/json", "./_ModelObject", "./ResultSet"], function (declare, lang, dojojson, _ModelObject, ResultSet) {
        return declare("ecm.model.Worklist", [_ModelObject], {description:null, repository:null, retrieveWorkItems:function (callback, orderBy, descending) {
            var request = ecm.model.Request.invokeService("getWorkItems", this.repository.type, {repositoryId:this.repository.id, worklist_name:this.id, order_by:this._orderBy ? orderBy : "", order_descending:this._descending ? "true" : "false"}, lang.hitch(this, function (response) {
                this._retrieveWorkItemsCompleted(response, callback);
            }));
            return request;
        }, _retrieveWorkItemsCompleted:function (response, callback) {
            response.repository = this.repository;
            response.parentFolder = this;
            response.setType = "workItems";
            var results = new ecm.model.ResultSet(response);
            callback(results);
        }, _getWorkItemIDsParam:function (workItems) {
            var workIDsParam = "{";
            for (var i in workItems) {
                workIDsParam = workIDsParam + "\"workItemId" + i + "\":\"" + workItems[i].id + "\",";
            }
            workIDsParam = workIDsParam.substring(0, workIDsParam.length - 1) + "}";
            return workIDsParam;
        }, continueWorkflow:function (workItems, callback) {
            var repository = workItems[0].repository;
            var workItemIDsParam = this._getWorkItemIDsParam(workItems);
            var continueWorkflowParam = lang.mixin(dojojson.fromJson(workItemIDsParam), {repositoryId:repository.id});
            ecm.model.Request.invokeService("continueWorkflow", repository.type, continueWorkflowParam, lang.hitch(this, function (response) {
                this._continueWorkflowCompleted(response, callback);
            }));
        }, _continueWorkflowCompleted:function (response, callback) {
            this.onRefreshWorklist(this);
            if (callback) {
                callback();
            }
        }, suspendWorkflow:function (workItems, callback) {
            var repository = workItems[0].repository;
            var workItemIDsParam = this._getWorkItemIDsParam(workItems);
            var suspendWorkflowParam = lang.mixin(dojojson.fromJson(workItemIDsParam), {repositoryId:repository.id, radioSuspend:"Until Resumption"});
            ecm.model.Request.invokeService("suspendWorkflow", repository.type, suspendWorkflowParam, lang.hitch(this, function (response) {
                this._suspendWorkflowCompleted(response, callback);
            }));
        }, _suspendWorkflowCompleted:function (response, callback) {
            this.onRefreshWorklist(this);
            if (callback) {
                callback();
            }
        }, resumeWorkflow:function (workItems, callback) {
            var repository = workItems[0].repository;
            var workItemIDsParam = this._getWorkItemIDsParam(workItems);
            var resumeWorkflowParam = lang.mixin(dojojson.fromJson(workItemIDsParam), {repositoryId:repository.id});
            ecm.model.Request.invokeService("resumeWorkflow", repository.type, resumeWorkflowParam, lang.hitch(this, function (response) {
                this._resumeWorkflowCompleted(response, callback);
            }));
        }, _resumeWorkflowCompleted:function (response, callback) {
            this.onRefreshWorklist(this);
            if (callback) {
                callback();
            }
        }, removeWorkflow:function (workItems, callback) {
            var repository = workItems[0].repository;
            var workItemIDsParam = this._getWorkItemIDsParam(workItems);
            var removeWorkflowParam = lang.mixin(dojojson.fromJson(workItemIDsParam), {repositoryId:repository.id});
            ecm.model.Request.invokeService("removeFromWorkflow", repository.type, removeWorkflowParam, lang.hitch(this, function (response) {
                this._removeWorkflowCompleted(response, callback);
            }));
        }, _removeWorkflowCompleted:function (response, callback) {
            this.onRefreshWorklist(this);
            if (callback) {
                callback();
            }
        }, onRefreshWorklist:function (worklist) {
        }});
    });
}, "ecm/LoggerMixin":function () {
    define("ecm/LoggerMixin", ["dojo/_base/declare", "dojo/_base/lang", "./Logger"], function (declare, lang, logger) {
        return declare("ecm.LoggerMixin", null, {isLogError:function () {
            return ecm.logger.getLogLevel() >= 1;
        }, isLogWarning:function () {
            return ecm.logger.getLogLevel() >= 2;
        }, isLogInfo:function () {
            return ecm.logger.getLogLevel() >= 3;
        }, isLogDebug:function () {
            return ecm.logger.getLogLevel() >= 4;
        }, logError:function (functionName, message, extra) {
            lang.hitch(this, ecm.logger.logError(this.declaredClass + "." + functionName, message, extra));
        }, logWarning:function (functionName, message, extra) {
            lang.hitch(this, ecm.logger.logWarning(this.declaredClass + "." + functionName, message, extra));
        }, logInfo:function (functionName, message, extra) {
            lang.hitch(this, ecm.logger.logInfo(this.declaredClass + "." + functionName, message, extra));
        }, logDebug:function (functionName, message, extra) {
            lang.hitch(this, ecm.logger.logDebug(this.declaredClass + "." + functionName, message, extra));
        }, logEntry:function (functionName, message) {
            lang.hitch(this, ecm.logger.logEntry(this.declaredClass + "." + functionName, message));
        }, logExit:function (functionName, message) {
            lang.hitch(this, ecm.logger.logExit(this.declaredClass + "." + functionName, message));
        }});
    });
}, "ecm/model/admin/ViewerDefConfig":function () {
    define("ecm/model/admin/ViewerDefConfig", ["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var ViewerDefConfig = declare("ecm.model.admin.ViewerDefConfig", [_ConfigurationObject], {LAUNCH_URL:"launchUrl", VIEWER_NAME:"viewerName", LABEL:"label", SERVER_TYPES:"serverTypes", constructor:function (id, name) {
        }, getName:function () {
            return this.id;
        }, getLaunchUrl:function () {
            return this.getValue(this.LAUNCH_URL);
        }, setLaunchUrl:function (launchUrl) {
            this.setValue(this.LAUNCH_URL, launchUrl);
        }, getViewerName:function () {
            return this.getValue(this.VIEWER_NAME);
        }, setViewerName:function (viewerName) {
            this.setValue(this.VIEWER_NAME, viewerName);
        }, getLabel:function () {
            return this.getValue(this.LABEL);
        }, setLabel:function (label) {
            this.setValue(this.LABEL, label);
        }, getServerTypes:function () {
            var types = this.getValue(this.SERVER_TYPES);
            if (types instanceof Array) {
                return types;
            } else {
                if (types) {
                    return [types];
                } else {
                    return [];
                }
            }
        }, supportsServerType:function (serverType, allServers) {
            var array = this.getServerTypes();
            if (array) {
                if (serverType == " ") {
                    if (allServers.length == array.length) {
                        return true;
                    }
                } else {
                    for (var i in array) {
                        if (array[i] == serverType) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }});
        ViewerDefConfig.createViewerDefConfig = function (id) {
            return new ViewerDefConfig(id, "ViewerDefConfig");
        };
        return ViewerDefConfig;
    });
}, "ecm/model/SearchConfiguration":function () {
    define("ecm/model/SearchConfiguration", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "./_ModelObject", "./AttributeDefinition", "./admin/AdminConfig"], function (declare, lang, array, _ModelObject, AttributeDefinition, AdminConfig) {
        var SearchConfiguration = declare("ecm.model.SearchConfiguration", [_ModelObject], {DATA_TYPE:{BOOLEAN:"xs:boolean", DATE:"xs:date", TIME:"xs:time", TIME_STAMP:"xs:timestamp", DECIMAL:"xs:decimal", DOUBLE:"xs:double", SHORT:"xs:short", INTEGER:"xs:integer", LONG:"xs:long", STRING:"xs:string", STRING_ALPHA:"xs:string:alpha", STRING_ALPHA_NUM:"xs:string:alphanum", STRING_CLOB:"xs:string:clob", STRING_EXT:"xs:string:ext", STRING_NUM:"xs:string:num", STRING_CMISID:"xs:string:cmisid", BINARY:"xs:binary", OBJECT:"xs:object", GUID:"xs:guid", USER:"xs:user"}, OPERATOR:{EQUAL:"EQUAL", NOT_EQUAL:"NOTEQUAL", LIKE:"LIKE", NOT_LIKE:"NOTLIKE", LESS:"LESS", LESS_OR_EQUAL:"LESSOREQUAL", GREATER:"GREATER", GREATER_OR_EQUAL:"GREATEROREQUAL", BETWEEN:"BETWEEN", NOT_BETWEEN:"NOTBETWEEN", IN:"IN", IN_ANY:"INANY", NOT_IN:"NOTIN", NULL:"NULL", NOT_NULL:"NOTNULL", CONTAINS:"CONTAINS", STARTS_WITH:"STARTSWITH", ENDS_WITH:"ENDSWITH"}, OBJECT_TYPE:{DOCUMENT:"document", FOLDER:"folder", COMMON:"common", ALL:"all"}, TEXT_SEARCH_TYPE:{CASCADE:"cascade", VERITY:"verity", BASIC:"basic"}, CAPABILITY_QUERY:{NONE:"none", METADATA_ONLY:"metadataonly", FULLTEXT_ONLY:"fulltextonly", BOTH_SEPERATE:"bothseparate", BOTH_COMBINED:"bothcombined"}, USER_PROPERTIES:{cm:["createdBy", "modifiedBy"], p8:["Creator", "LastModifier", "Owner"]}, FOLDER_DEFAULT_COLUMNS:{p8:[AdminConfig.PSEUDO_NAME, "LastModifier", "DateLastModified"], cmis:[AdminConfig.PSEUDO_NAME, "cmis:createdBy", "cmis:creationDate", "cmis:lastModifiedBy", "cmis:lastModificationDate", "cmis:objectId", "cmis:objectTypeId"]}, DOCUMENT_DEFAULT_COLUMNS:{p8:[AdminConfig.PSEUDO_NAME, "LastModifier", "DateLastModified"], cmis:[AdminConfig.PSEUDO_NAME, "cmis:createdBy", "cmis:creationDate", "cmis:lastModifiedBy", "cmis:lastModificationDate", "cmis:contentStreamMimeType", "cmis:contentStreamLength", "cmis:objectId", "cmis:objectTypeId"]}, NAME_PROPERTY:{cm:AdminConfig.PSEUDO_NAME, cmis:"cmis:name"}, constructor:function () {
            this._cache = {};
        }, getRepositoryConfig:function () {
            if (this.repository) {
                this.repositoryConfig = this.repository.getRepositoryConfig();
            }
        }, hasSearchFolders:function () {
            return this.repository.type == "od";
        }, canBuildSearches:function () {
            if (this.repository.type == "od") {
                return false;
            }
            if ((!this.teamspace && !ecm.model.desktop.preventCreateNewSearch) || (this.teamspace && this.teamspace.getPrivilege("createNewSearches"))) {
                return true;
            } else {
                return false;
            }
        }, canBuildUnifiedSearches:function () {
            return (!this.teamspace && !ecm.model.desktop.preventCreateNewUnifiedSearch) && !this.repository._isCmis();
        }, canSaveSearches:function () {
            return this.repository.getPrivilege("addSearch") && (!this.teamspace || this.teamspace.getPrivilege("addNewSearches"));
        }, canSaveUnifiedSearches:function () {
            return !this.teamspace && this.repositoryConfig && this.repositoryConfig.getUnifiedSearchesEnabled() && this.repository.getPrivilege("addUnifiedSearch");
        }, getDefaultAttributeDefinitionId:function (objectType) {
            var id = null;
            if (this.repository.type == "p8") {
                id = objectType == this.OBJECT_TYPE.DOCUMENT ? "DocumentTitle" : "FolderName";
            }
            return id;
        }, getRootClassId:function (objectType) {
            var id = null;
            var repositoryType = this.repository.type;
            if (repositoryType == "p8" || repositoryType == "cm") {
                id = objectType == this.OBJECT_TYPE.DOCUMENT ? "Document" : "Folder";
            } else {
                if (repositoryType == "cmis") {
                    id = objectType == this.OBJECT_TYPE.DOCUMENT ? "cmis:document" : "cmis:folder";
                } else {
                    id = "Document";
                }
            }
            return id;
        }, getOperators:function (dataType, cardinality, choiceList, textSearchable, nullable, usesLongColumn, hasDependentAttributes) {
            var operators;
            if (this.repository._isCM()) {
                operators = this._getCMOperators(dataType, textSearchable, nullable, hasDependentAttributes);
            } else {
                if (this.repository._isCmis()) {
                    operators = this._getCMISOperators(dataType, cardinality, choiceList, usesLongColumn, textSearchable);
                } else {
                    if (this.repository._isP8()) {
                        operators = this._getP8Operators(dataType, cardinality, choiceList, usesLongColumn, textSearchable);
                    } else {
                        this.logWarning("getOperators", "Unsupported repository type " + this.repository.type);
                        operators = new Array();
                    }
                }
            }
            if (dataType != this.DATA_TYPE.USER) {
                if (this.repositoryConfig) {
                    var filteredOperators = this.repositoryConfig.getSearchFilteredOperators(this._convertOperatorType(dataType));
                    if (filteredOperators) {
                        var self = this;
                        for (var i = operators.length - 1; i >= 0; i--) {
                            array.some(filteredOperators, function (filteredOperator) {
                                if (self._convertOperator(operators[i]) == filteredOperator) {
                                    operators.splice(i, 1);
                                    return true;
                                }
                            }, this);
                        }
                    }
                }
            }
            return operators;
        }, getOperatorSelectOptions:function (dataType, cardinality, choiceList, textSearchable, nullable, usesLongColumn, hasDependentAttributes) {
            var selectOptions = [];
            var operators = this.getOperators(dataType, cardinality, choiceList, textSearchable, nullable, usesLongColumn, hasDependentAttributes);
            for (var i in operators) {
                var op = operators[i];
                selectOptions.push({value:op, label:ecm.messages["operator_" + op]});
            }
            return selectOptions;
        }, getSelectOptionsForOperators:function (operators) {
            var selectOptions = null;
            if (operators) {
                selectOptions = [];
                for (var i in operators) {
                    var op = operators[i];
                    selectOptions.push({value:op, label:ecm.messages["operator_" + op]});
                }
            }
            return selectOptions;
        }, getNameProperty:function (objectType) {
            if (this.repository._isP8()) {
                var name;
                if (this.repositoryConfig) {
                    if (objectType == this.OBJECT_TYPE.DOCUMENT) {
                        name = this.repositoryConfig.getDocNameProperty();
                    } else {
                        name = this.repositoryConfig.getFolderNameProperty();
                    }
                }
                if (!name) {
                    name = this.getDefaultAttributeDefinitionId(objectType);
                }
                return name;
            } else {
                if (this.repository._isCmis()) {
                    if (objectType == this.OBJECT_TYPE.DOCUMENT) {
                        return this.NAME_PROPERTY.cmis;
                    } else {
                        return this.NAME_PROPERTY.cmis;
                    }
                } else {
                    if (this.repository._isCM()) {
                        return this.NAME_PROPERTY.cm;
                    } else {
                        return AdminConfig.PSEUDO_NAME;
                    }
                }
            }
        }, getSearchDefaultColumns:function (objectType) {
            if (this.repository._isP8()) {
                if (objectType == this.OBJECT_TYPE.DOCUMENT) {
                    var columns;
                    if (this.repositoryConfig) {
                        columns = this.repositoryConfig.getSearchDefaultColumns();
                    }
                    if (!columns) {
                        columns = this.DOCUMENT_DEFAULT_COLUMNS.p8;
                    }
                    return columns;
                } else {
                    return this.FOLDER_DEFAULT_COLUMNS.p8;
                }
            } else {
                if (this.repository._isCmis()) {
                    if (objectType == this.OBJECT_TYPE.DOCUMENT) {
                        var columns;
                        if (this.repositoryConfig) {
                            columns = this.repositoryConfig.getSearchDefaultColumns();
                        }
                        if (!columns) {
                            columns = this.DOCUMENT_DEFAULT_COLUMNS.cmis;
                        }
                        return columns;
                    } else {
                        return this.FOLDER_DEFAULT_COLUMNS.cmis;
                    }
                } else {
                    if (this.repository._isCM()) {
                        return this.repositoryConfig ? this.repositoryConfig.getSearchDefaultColumns() : [ecm.model.admin.AdminConfig.PSEUDO_NAME];
                    } else {
                        return [AdminConfig.PSEUDO_NAME];
                    }
                }
            }
        }, getSearchMagazineDefaultColumns:function (objectType) {
            if (this.repository._isP8()) {
                if (objectType == this.OBJECT_TYPE.DOCUMENT) {
                    var columns;
                    if (this.repositoryConfig) {
                        columns = this.repositoryConfig.getSearchMagazineDefaultColumns();
                    }
                    if (!columns || columns.length == 0) {
                        columns = ["LastModifier", "DateLastModified"];
                    }
                    return columns;
                } else {
                    return ["LastModifier", "DateLastModified"];
                }
            } else {
                if (this.repository._isCmis()) {
                    if (objectType == this.OBJECT_TYPE.DOCUMENT) {
                        var columns;
                        if (this.repositoryConfig) {
                            columns = this.repositoryConfig.getSearchMagazineDefaultColumns();
                        }
                        if (!columns || columns.length == 0) {
                            columns = ["cmis:contentStreamLength", "cmis:lastModifiedBy", "cmis:lastModificationDate"];
                        }
                        return columns;
                    } else {
                        return columns = ["cmis:createdBy", "cmis:creationDate", "cmis:lastModifiedBy"];
                    }
                } else {
                    if (this.repository._isCM()) {
                        return this.repositoryConfig ? this.repositoryConfig.getSearchMagazineDefaultColumns() : [ecm.model.admin.AdminConfig.PSEUDO_NAME];
                    } else {
                        return [AdminConfig.PSEUDO_NAME];
                    }
                }
            }
        }, getFilteredProperties:function (objectType) {
            if (this.repositoryConfig) {
                if (objectType == this.OBJECT_TYPE.DOCUMENT) {
                    return this.repositoryConfig.getSearchFilteredDocumentProperties();
                } else {
                    return this.repositoryConfig.getSearchFilteredFolderProperties();
                }
            } else {
                return [];
            }
        }, _getCMOperators:function (dataType, textSearchable, nullable, hasDependentAttributes) {
            var operators = [];
            if (hasDependentAttributes && hasDependentAttributes == true) {
                operators.push(this.OPERATOR.EQUAL);
                operators.push(this.OPERATOR.NOT_EQUAL);
                operators.push(this.OPERATOR.LESS);
                operators.push(this.OPERATOR.LESS_OR_EQUAL);
                operators.push(this.OPERATOR.GREATER);
                operators.push(this.OPERATOR.GREATER_OR_EQUAL);
            } else {
                if (textSearchable) {
                    operators.push(this.OPERATOR.CONTAINS);
                }
                switch (dataType) {
                  case this.DATA_TYPE.USER:
                    operators.push(this.OPERATOR.EQUAL);
                    operators.push(this.OPERATOR.NOT_EQUAL);
                    operators.push(this.OPERATOR.IN_ANY);
                    operators.push(this.OPERATOR.NOT_IN);
                    break;
                  case this.DATA_TYPE.STRING_CLOB:
                    operators.push(this.OPERATOR.STARTS_WITH);
                    operators.push(this.OPERATOR.ENDS_WITH);
                    operators.push(this.OPERATOR.LIKE);
                    operators.push(this.OPERATOR.NOT_LIKE);
                    break;
                  case this.DATA_TYPE.STRING:
                  case this.DATA_TYPE.STRING_ALPHA:
                  case this.DATA_TYPE.STRING_ALPHA_NUM:
                  case this.DATA_TYPE.STRING_EXT:
                  case this.DATA_TYPE.STRING_NUM:
                    operators.push(this.OPERATOR.STARTS_WITH);
                    operators.push(this.OPERATOR.ENDS_WITH);
                    operators.push(this.OPERATOR.LIKE);
                    operators.push(this.OPERATOR.NOT_LIKE);
                    operators.push(this.OPERATOR.EQUAL);
                    operators.push(this.OPERATOR.NOT_EQUAL);
                    operators.push(this.OPERATOR.LESS);
                    operators.push(this.OPERATOR.LESS_OR_EQUAL);
                    operators.push(this.OPERATOR.GREATER);
                    operators.push(this.OPERATOR.GREATER_OR_EQUAL);
                    operators.push(this.OPERATOR.BETWEEN);
                    operators.push(this.OPERATOR.NOT_BETWEEN);
                    operators.push(this.OPERATOR.IN_ANY);
                    operators.push(this.OPERATOR.NOT_IN);
                    break;
                  case this.DATA_TYPE.DATE:
                  case this.DATA_TYPE.TIME:
                  case this.DATA_TYPE.TIME_STAMP:
                    operators.push(this.OPERATOR.EQUAL);
                    operators.push(this.OPERATOR.NOT_EQUAL);
                    operators.push(this.OPERATOR.LESS);
                    operators.push(this.OPERATOR.LESS_OR_EQUAL);
                    operators.push(this.OPERATOR.GREATER);
                    operators.push(this.OPERATOR.GREATER_OR_EQUAL);
                    operators.push(this.OPERATOR.BETWEEN);
                    operators.push(this.OPERATOR.NOT_BETWEEN);
                    operators.push(this.OPERATOR.IN_ANY);
                    operators.push(this.OPERATOR.NOT_IN);
                    break;
                  case this.DATA_TYPE.DECIMAL:
                  case this.DATA_TYPE.DOUBLE:
                  case this.DATA_TYPE.INTEGER:
                  default:
                    operators.push(this.OPERATOR.EQUAL);
                    operators.push(this.OPERATOR.NOT_EQUAL);
                    operators.push(this.OPERATOR.LESS);
                    operators.push(this.OPERATOR.LESS_OR_EQUAL);
                    operators.push(this.OPERATOR.GREATER);
                    operators.push(this.OPERATOR.GREATER_OR_EQUAL);
                    operators.push(this.OPERATOR.BETWEEN);
                    operators.push(this.OPERATOR.NOT_BETWEEN);
                    operators.push(this.OPERATOR.IN_ANY);
                    operators.push(this.OPERATOR.NOT_IN);
                }
                if (nullable) {
                    operators.push(this.OPERATOR.NULL);
                    operators.push(this.OPERATOR.NOT_NULL);
                }
            }
            return operators;
        }, _isRangeSupportedDataType:function (dataType) {
            return dataType == this.DATA_TYPE.DATE || dataType == this.DATA_TYPE.TIME || dataType == this.DATA_TYPE.TIME_STAMP || dataType == this.DATA_TYPE.DECIMAL || dataType == this.DATA_TYPE.DOUBLE || dataType == this.DATA_TYPE.SHORT || dataType == this.DATA_TYPE.INTEGER || dataType == this.DATA_TYPE.LONG;
        }, _getCMISOperators:function (dataType, cardinality, choiceList, usesLongColumn, textSearchable) {
            var operators = [];
            if (dataType == this.DATA_TYPE.STRING && textSearchable) {
                operators.push(this.OPERATOR.CONTAINS);
            }
            if (dataType == this.DATA_TYPE.STRING && !choiceList) {
                operators.push(this.OPERATOR.STARTS_WITH);
                operators.push(this.OPERATOR.ENDS_WITH);
                operators.push(this.OPERATOR.LIKE);
                operators.push(this.OPERATOR.NOT_LIKE);
            }
            if (cardinality == "LIST" || cardinality == "multi") {
                operators.push(this.OPERATOR.IN);
            } else {
                if (dataType == this.DATA_TYPE.BOOLEAN) {
                    operators.push(this.OPERATOR.EQUAL);
                } else {
                    if (dataType == this.DATA_TYPE.GUID || dataType == this.DATA_TYPE.OBJECT || dataType == this.DATA_TYPE.STRING_CMISID) {
                        operators.push(this.OPERATOR.EQUAL);
                        operators.push(this.OPERATOR.NOT_EQUAL);
                    } else {
                        if (dataType == this.DATA_TYPE.USER) {
                            operators.push(this.OPERATOR.EQUAL);
                            operators.push(this.OPERATOR.NOT_EQUAL);
                        } else {
                            if (dataType != this.DATA_TYPE.STRING || !usesLongColumn) {
                                operators.push(this.OPERATOR.EQUAL);
                                operators.push(this.OPERATOR.NOT_EQUAL);
                                operators.push(this.OPERATOR.LESS);
                                operators.push(this.OPERATOR.LESS_OR_EQUAL);
                                operators.push(this.OPERATOR.GREATER);
                                operators.push(this.OPERATOR.GREATER_OR_EQUAL);
                            }
                            if (!choiceList && this._isRangeSupportedDataType(dataType)) {
                                operators.push(this.OPERATOR.BETWEEN);
                                operators.push(this.OPERATOR.NOT_BETWEEN);
                            }
                        }
                    }
                }
            }
            if (dataType != this.DATA_TYPE.OBJECT) {
                operators.push(this.OPERATOR.IN_ANY);
                operators.push(this.OPERATOR.NOT_IN);
            }
            if (cardinality == "SINGLE") {
                operators.push(this.OPERATOR.NULL);
                operators.push(this.OPERATOR.NOT_NULL);
            }
            return operators;
        }, _getP8Operators:function (dataType, cardinality, choiceList, usesLongColumn, textSearchable) {
            var operators = [];
            if (dataType == this.DATA_TYPE.STRING && textSearchable) {
                operators.push(this.OPERATOR.CONTAINS);
            }
            if (dataType == this.DATA_TYPE.STRING && !choiceList) {
                operators.push(this.OPERATOR.STARTS_WITH);
                operators.push(this.OPERATOR.ENDS_WITH);
                operators.push(this.OPERATOR.LIKE);
                operators.push(this.OPERATOR.NOT_LIKE);
            }
            if (cardinality == "LIST") {
                operators.push(this.OPERATOR.IN);
            } else {
                if (dataType == this.DATA_TYPE.BOOLEAN || dataType == this.DATA_TYPE.GUID || dataType == this.DATA_TYPE.OBJECT) {
                    operators.push(this.OPERATOR.EQUAL);
                    operators.push(this.OPERATOR.NOT_EQUAL);
                } else {
                    if (dataType == this.DATA_TYPE.USER) {
                        operators.push(this.OPERATOR.EQUAL);
                        operators.push(this.OPERATOR.NOT_EQUAL);
                    } else {
                        if (dataType != this.DATA_TYPE.STRING || !usesLongColumn) {
                            operators.push(this.OPERATOR.EQUAL);
                            operators.push(this.OPERATOR.NOT_EQUAL);
                            operators.push(this.OPERATOR.LESS);
                            operators.push(this.OPERATOR.LESS_OR_EQUAL);
                            operators.push(this.OPERATOR.GREATER);
                            operators.push(this.OPERATOR.GREATER_OR_EQUAL);
                        }
                        if (!choiceList && this._isRangeSupportedDataType(dataType)) {
                            operators.push(this.OPERATOR.BETWEEN);
                            operators.push(this.OPERATOR.NOT_BETWEEN);
                        }
                    }
                }
            }
            if (dataType != this.DATA_TYPE.OBJECT) {
                operators.push(this.OPERATOR.IN_ANY);
                operators.push(this.OPERATOR.NOT_IN);
            }
            if (cardinality == "SINGLE") {
                operators.push(this.OPERATOR.NULL);
                operators.push(this.OPERATOR.NOT_NULL);
            }
            return operators;
        }, isTextSearchTypeSupported:function (type) {
            return (this.repository.type == "cm" && type == this.TEXT_SEARCH_TYPE.BASIC) || type == this.TEXT_SEARCH_TYPE.CASCADE || type == this.TEXT_SEARCH_TYPE.VERITY;
        }, isCmisCapabilityQueryBothSeperated:function (type) {
            return (type != null && type == this.CAPABILITY_QUERY.BOTH_SEPERATE);
        }, isCmisCapabilityTextOnly:function (type) {
            return (type != null && type == this.CAPABILITY_QUERY.FULLTEXT_ONLY);
        }, isResultsDisplaySupported:function () {
            return this.repository._isP8() || this.repository._isCM();
        }, isResultsAppendSupported:function () {
            return this.repository.type == "od";
        }, isUserProperty:function (name, repositoryType) {
            var properties = this.USER_PROPERTIES[repositoryType || (this.repository ? this.repository.type : "")];
            return properties ? array.indexOf(properties, name) != -1 : false;
        }, _convertOperatorType:function (type) {
            if (type == "xs:boolean") {
                return "booleanOp";
            } else {
                if (type == "xs:date" || type == "xs:time" || type == "xs:timestamp") {
                    return "datetimeOp";
                } else {
                    if (type == "xs:decimal" || type == "xs:double") {
                        return "floatOp";
                    } else {
                        if (type == "xs:short" || type == "xs:integer" || type == "xs:long") {
                            return "integerOp";
                        } else {
                            if (type == "xs:string" || type == "xs:string:alpha" || type == "xs:string:alphanum" || type == "xs:string:num" || type == "xs:string:clob" || type == "xs:string:ext" || type == "xs:string:cmisid") {
                                return "stringOp";
                            } else {
                                if (type == "xs:object") {
                                    return "objectOp";
                                } else {
                                    if (type == "xs:guid") {
                                        return "idOp";
                                    } else {
                                        throw "Invalid operator:" + type;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }, _convertOperator:function (operator) {
            switch (operator) {
              case this.OPERATOR.EQUAL:
                return "EQ";
              case this.OPERATOR.NOT_EQUAL:
                return "!EQ";
              case this.OPERATOR.LIKE:
                return "LK";
              case this.OPERATOR.NOT_LIKE:
                return "!LK";
              case this.OPERATOR.LESS:
                return "LT";
              case this.OPERATOR.LESS_OR_EQUAL:
                return "LE";
              case this.OPERATOR.GREATER:
                return "GT";
              case this.OPERATOR.GREATER_OR_EQUAL:
                return "GE";
              case this.OPERATOR.BETWEEN:
                return "BT";
              case this.OPERATOR.NOT_BETWEEN:
                return "!BT";
              case this.OPERATOR.IN:
                return "IN";
              case this.OPERATOR.IN_ANY:
                return "IA";
              case this.OPERATOR.NOT_IN:
                return "!IN";
              case this.OPERATOR.NULL:
                return "NL";
              case this.OPERATOR.NOT_NULL:
                return "!NL";
              case this.OPERATOR.CONTAINS:
                return "CT";
              case this.OPERATOR.STARTS_WITH:
                return "SW";
              case this.OPERATOR.ENDS_WITH:
                return "EW";
            }
        }, getMatchAll:function () {
            if (this.repositoryConfig) {
                var matchAll = this.repositoryConfig.getMatchAll();
                return (matchAll == null || matchAll == "true" || matchAll == true);
            } else {
                return true;
            }
        }, retrieveNameAndDescriptionMaxLength:function (callback) {
            var repositoryType = this.repository.type;
            if (repositoryType != "cm" && repositoryType != "p8") {
                callback(null);
            } else {
                if (this._cache.nameAndDescriptionMaxLength && this._cache.nameAndDescriptionMaxLength[repositoryType]) {
                    callback(this._cache.nameAndDescriptionMaxLength[repositoryType]);
                } else {
                    var name = repositoryType == "cm" ? "clbName" : "DocumentTitle";
                    var description = repositoryType == "cm" ? "clbDescription" : "Description";
                    var contentClass = this.repository.getContentClass(repositoryType == "cm" ? "ICMSearch" : "StoredSearch");
                    contentClass.retrieveAttributeDefinitionsForSearches(lang.hitch(this, function (attributes) {
                        var obj = new Object();
                        for (var i = 0; i < attributes.length; i++) {
                            if (attributes[i].id == name) {
                                obj.nameMaxLength = attributes[i].maxLength;
                            } else {
                                if (attributes[i].id == description) {
                                    obj.descriptionMaxLength = attributes[i].maxLength;
                                }
                            }
                            if ("nameMaxLength" in obj && "descriptionMaxLength" in obj) {
                                break;
                            }
                        }
                        if (!this._cache.nameAndDescriptionMaxLength) {
                            this._cache.nameAndDescriptionMaxLength = new Object();
                        }
                        this._cache.nameAndDescriptionMaxLength[repositoryType] = obj;
                        callback(obj);
                    }));
                }
            }
        }, filterAttributeDefinitions:function (attributeDefinitions, options) {
            options = options || {};
            var filteredProperties = options.objectType ? this.getFilteredProperties(options.objectType) : [];
            return array.filter(attributeDefinitions, function (attrib) {
                if (attrib.isInstanceOf && attrib.isInstanceOf(AttributeDefinition)) {
                    if (attrib.dataType == "xs:reference") {
                        return false;
                    }
                    if (!attrib.searchable) {
                        return false;
                    }
                    if (attrib.hidden && !options.allowHidden) {
                        return false;
                    }
                    if (array.indexOf(filteredProperties, attrib.id) != -1) {
                        return false;
                    }
                }
                return true;
            });
        }, getDataTypeLabel:function (dataType) {
            switch (dataType) {
              case this.DATA_TYPE.BOOLEAN:
                return this.messages.data_type_boolean;
              case this.DATA_TYPE.DATE:
                return this.messages.data_type_date;
              case this.DATA_TYPE.TIME:
                return this.messages.data_type_time;
              case this.DATA_TYPE.TIME_STAMP:
                return this.messages.data_type_timestamp;
              case this.DATA_TYPE.DECIMAL:
                return this.messages.data_type_decimal;
              case this.DATA_TYPE.DOUBLE:
                return this.messages.data_type_double;
              case this.DATA_TYPE.SHORT:
                return this.messages.data_type_short;
              case this.DATA_TYPE.INTEGER:
                return this.messages.data_type_integer;
              case this.DATA_TYPE.LONG:
                return this.messages.data_type_long;
              case this.DATA_TYPE.STRING:
                return this.messages.data_type_string;
              case this.DATA_TYPE.STRING_ALPHA:
                return this.messages.data_type_string_alpha;
              case this.DATA_TYPE.STRING_ALPHA_NUM:
                return this.messages.data_type_string_alphanum;
              case this.DATA_TYPE.STRING_EXT:
                return this.messages.data_type_string_ext;
              case this.DATA_TYPE.STRING_NUM:
                return this.messages.data_type_string_num;
              case this.DATA_TYPE.BINARY:
                return this.messages.data_type_binary;
              case this.DATA_TYPE.OBJECT:
                return this.messages.data_type_object;
              case this.DATA_TYPE.GUID:
                return this.messages.data_type_guid;
              case this.DATA_TYPE.USER:
                return this.messages.data_type_user;
              default:
                return "";
            }
        }});
        SearchConfiguration.getSearchConfiguration = function (args) {
            var searchConfig = new SearchConfiguration(args);
            if (searchConfig && searchConfig.repository && !searchConfig.repository._isOnDemand()) {
                searchConfig.getRepositoryConfig();
            }
            return searchConfig;
        };
        return SearchConfiguration;
    });
}, "ecm/model/admin/IconConfig":function () {
    define(["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var IconConfig = declare("ecm.model.admin.IconConfig", [_ConfigurationObject], {ID:"id", NAME:"name", FILE_NAME:"fileName", CLASS_NAME:"className", CONTENT_TYPES:"contentTypes", constructor:function (id, name) {
        }, getName:function () {
            return this.getValue(this.NAME);
        }, setName:function (name) {
            this.setValue(this.NAME, name);
        }, getFileName:function () {
            return this.getValue(this.FILE_NAME);
        }, setFileName:function (name) {
            this.setValue(this.FILE_NAME, name);
        }, getClassName:function () {
            return this.getValue(this.CLASS_NAME);
        }, setClassName:function (name) {
            this.setValue(this.CLASS_NAME, name);
        }, getContentTypes:function () {
            return this.getValues(this.CONTENT_TYPES);
        }, setContentTypes:function (contentTypes) {
            this.setValue(this.CONTENT_TYPES, contentTypes);
        }});
        IconConfig.createIconConfig = function (id) {
            return new IconConfig(id, "IconConfig");
        };
        return IconConfig;
    });
}, "ecm/model/_SearchTemplateBase":function () {
    define("ecm/model/_SearchTemplateBase", ["dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", "ecm/model/_ModelStore", "ecm/model/ContentItem", "ecm/model/ResultSet", "ecm/model/SearchConfiguration", "ecm/model/SearchCriterion"], function (array, declare, lang, _ModelStore, ContentItem, ResultSet, SearchConfiguration, SearchCriterion) {
        var _SearchTemplateBase = declare("ecm.model._SearchTemplateBase", ContentItem, {description:null, autoRun:false, showInTree:false, searchCriteria:null, andSearch:true, resultsDisplay:null, autoResolved:false, UUID:undefined, searchConfig:null, parentFolderId:null, permissions:null, constructor:function () {
            this._init();
            this.searchConfig = SearchConfiguration.getSearchConfiguration({repository:this.repository});
        }, _init:function () {
            this.description = this.description || this._getAttributeValue("Description") || this._getAttributeValue("clbDescription");
            var autoRun1 = this._getAttributeValue("IcnAutoRun");
            var autoRun2 = this._getAttributeValue("clbAutoRun");
            this.autoRun = autoRun1 ? autoRun1 : false || autoRun2 ? autoRun2 === 1 : false;
            this.showInTree = this._getAttributeValue("IcnShowInTree") || this._getAttributeValue("clbShowInTree") === 1;
            this.mimetype = this.getContentType();
        }, _getAttributeValue:function (attribute) {
            var value = this.attributes[attribute];
            if (value instanceof Array) {
                value = value.length > 0 ? value[0] : null;
            }
            return value;
        }, isAutoRun:function () {
            return this.autoRun;
        }, isShowInTree:function () {
            return this.showInTree;
        }, isNew:function () {
            return (!this.id || !this.id.length || this.id.indexOf("NewSearch_") == 0);
        }, isNavigatorSavedSearch:function () {
            return true;
        }, isAttributeHidden:function (attributeId) {
            return array.indexOf(_SearchTemplateBase.HIDDEN_ATTRIBUTES, attributeId) > -1;
        }, save:function (callback) {
            var request = ecm.model.Request.postService("updateSearchTemplate", this.repository.type, {repositoryId:this.repository.id, docid:this.id}, "text/json", this.toJson(), lang.hitch(this, function (response) {
                this.update(ContentItem.createFromJSON(response.rows[0], this.repository, null));
                if (callback) {
                    callback(this);
                }
            }));
        }, update:function (item, skipOnChange) {
            var uuid = this.UUID;
            this.inherited(arguments);
            this.UUID = uuid;
            this._init();
        }, generateUUID:function () {
            return this.isNew() ? this.id : this.repository.id + "_" + (this.vsId || this.id);
        }, equals:function (object) {
            if (!object || !object.isInstanceOf || !object.isInstanceOf(ContentItem) || object.isFolder() || this.repository != object.repository) {
                return false;
            }
            if (this.repository._isP8() && this.vsId && this.vsId === object.vsId) {
                return true;
            }
            return this.id === object.id;
        }, containsEqualCriteria:function (searchTemplate) {
            if (this.searchCriteria instanceof Array != searchTemplate.searchCriteria instanceof Array) {
                return false;
            }
            if (this.searchCriteria instanceof Array) {
                if (this.searchCriteria.length != searchTemplate.searchCriteria.length) {
                    return false;
                }
                if (!array.every(this.searchCriteria, function (criterion, i) {
                    return criterion.equals(searchTemplate.searchCriteria[i]);
                })) {
                    return false;
                }
            }
            if (new Boolean(this.resultsDisplay).valueOf() != new Boolean(searchTemplate.resultsDisplay).valueOf()) {
                return false;
            }
            if (this.resultsDisplay) {
                if (this.resultsDisplay.sortBy != searchTemplate.resultsDisplay.sortBy) {
                    return false;
                }
                if (this.resultsDisplay.sortAsc != searchTemplate.resultsDisplay.sortAsc) {
                    return false;
                }
                if (this.resultsDisplay.columns.length != searchTemplate.resultsDisplay.columns.length) {
                    return false;
                }
                if (!array.every(this.resultsDisplay.columns, function (column, i) {
                    return column == searchTemplate.resultsDisplay.columns[i];
                })) {
                    return false;
                }
                if (this.resultsDisplay.magazineColumns) {
                    if (this.resultsDisplay.magazineColumns.length != searchTemplate.resultsDisplay.magazineColumns.length) {
                        return false;
                    }
                    if (!array.every(this.resultsDisplay.magazineColumns, function (column, i) {
                        return column == searchTemplate.resultsDisplay.magazineColumns[i];
                    })) {
                        return false;
                    }
                }
            }
            return true;
        }, toJson:function (searching) {
            var json = {id:this.id, name:this.name, description:this.description || "", autoRun:this.autoRun || false, showInTree:this.showInTree || false, andSearch:this.andSearch, resultsDisplay:this.resultsDisplay || null, parentFolderId:this.parentFolderId, permissions:this.permissions || []};
            json.searchCriteria = array.map(this.searchCriteria, lang.hitch(this, function (criterion) {
                if (criterion.declaredClass == "ecm.model.ChildComponentSearchCriteria") {
                    return {template_name:criterion.id, searchCriteria:array.map(criterion.searchCriteria, lang.hitch(this, "_searchCriterionToJson"))};
                } else {
                    return this._searchCriterionToJson(criterion, searching);
                }
            }));
            return json;
        }, _searchCriterionToJson:function (criterion, searching) {
            var dataType = criterion.dataType;
            var operator = criterion.selectedOperator;
            var values = criterion.values;
            if (dataType == "xs:user" || this.searchConfig.isUserProperty(criterion.id)) {
                dataType = "xs:string";
                values = array.map(values, function (value) {
                    return value.shortName;
                });
            } else {
                if ((operator == "BETWEEN" || operator == "NOTBETWEEN") && values.length == 2 && values[0] && values[1]) {
                    var value1 = values[0];
                    var value2 = values[1];
                    var value1IsGreater;
                    if (dataType == "xs:integer" || dataType == "xs:short" || dataType == "xs:decimal" || dataType == "xs:double") {
                        value1 = parseFloat(value1);
                        value2 = parseFloat(value2);
                        value1IsGreater = (value1 > value2);
                    } else {
                        if (dataType == "xs:long") {
                            value1IsGreater = (_ModelStore.longComparator(value1, value2) == 1);
                        } else {
                            value1IsGreater = (value1 > value2);
                        }
                    }
                    if (value1IsGreater) {
                        if (this.repository.type == "od" && ((dataType == "xs:date" && criterion.format == "MM/dd/yy") || (dataType == "xs:timestamp" && criterion.format == "MM/dd/yy HH:mm"))) {
                            if (values[0].length > 0 && values[1].length > 0 && values[0].substring(0, 2) == "19" && values[1].substring(0, 2) == "19" && values[0].substring(0, 4) > values[1].substring(0, 4)) {
                                values[1] = "20" + values[1].substring(2);
                            } else {
                                values = [value2.toString(), value1.toString()];
                            }
                        } else {
                            values = [value2.toString(), value1.toString()];
                        }
                    }
                }
            }
            for (var i in values) {
                values[i] = values[i] == null ? "" : values[i] + "";
            }
            return {id:criterion.id, name:criterion.name, selectedOperator:operator, values:values, dataType:dataType, cardinality:criterion.cardinality, itemId:criterion.itemId};
        }, clone:function () {
            var clone = new this.constructor({id:this.id, name:this.name});
            lang.mixin(clone, this);
            clone.attributes = lang.clone(this.attributes);
            clone.searchCriteria = this.searchCriteria ? array.map(this.searchCriteria, function (criterion) {
                return criterion.clone();
            }) : null;
            clone.resultsDisplay = lang.clone(this.resultsDisplay);
            clone.permissions = lang.clone(this.permissions);
            return clone;
        }, onUnsupportedSearchCriteriaRetrieved:function (searchTemplate) {
        }, onSearchCriteriaRetrieved:function (searchTemplate) {
        }, onSearchCompleted:function (results) {
        }});
        _SearchTemplateBase.HIDDEN_ATTRIBUTES = ["ApplicationName", "clbSearchType", "clbAutoRun", "clbShowInTree", "clbSearchingRepositories"];
        return _SearchTemplateBase;
    });
}, "ecm/model/Teamspace":function () {
    define(["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/json", "./_ModelObject", "./_OpenedSearchesMixin", "./_RecentSearchesMixin", "./ContentItem", "./User", "./UserGroup", "./EntryTemplate", "./ContentClass", "./Role", "./SearchTemplate", "./SearchTemplateFolder"], function (declare, lang, array, dojojson, _ModelObject, _OpenedSearchesMixin, _RecentSearchesMixin, ContentItem, User, UserGroup, EntryTemplate, ContentClass, Role, SearchTemplate, SearchTemplateFolder) {
        var Teamspace = declare("ecm.model.Teamspace", [_ModelObject, _OpenedSearchesMixin, _RecentSearchesMixin], {teamspaceTemplateName:"", repository:null, desc:"", type:null, className:null, templateJSON:null, folders:null, searchTemplates:null, contentClasses:null, entryTemplates:null, roles:null, state:"published", members:null, lastModified:"", lastModifiedUser:"", usesClasses:true, defaultClass:null, defaultEntryTemplate:null, currentUserPrivileges:null, permissions:null, columnProperties:null, openedSearches:null, team:null, constructor:function () {
            if (!this.folders) {
                this.folders = [];
            }
            if (!this.searchTemplates) {
                this.searchTemplates = [];
            }
            if (!this.contentClasses) {
                this.contentClasses = [];
            }
            if (!this.entryTemplates) {
                this.entryTemplates = [];
            }
            if (!this.roles) {
                this.roles = [];
            }
            if (!this.members) {
                this.members = [];
            }
            if (!this.currentUserPrivileges) {
                this.currentUserPrivileges = [];
            }
            if (this.props) {
                this.templateJSON = dojojson.toJson(this.props);
                if (this.props.usesClasses) {
                    this.usesClasses = this.props.usesClasses == "true";
                }
                if (this.props.columnProperties) {
                    this.columnProperties = this.props.columnProperties;
                }
                delete this.props;
            }
            if (this.currentUser) {
                this.currentUserPrivileges = this.currentUser.maxPrivs;
                delete this.curentUser;
            }
            this._setTeam(this.team);
        }, getValue:function (attribute) {
            return this[attribute];
        }, getDisplayValue:function (attribute) {
            var type = attribute == "lastModified" ? "xs:timestamp" : "xs:string";
            return ecm.model.desktop.valueFormatter.formatValue(this.getValue(attribute), type);
        }, _setTeam:function (team) {
            this.team = [];
            if (team) {
                array.forEach(team, function (obj) {
                    if (obj) {
                        if (obj.type == 2) {
                            var group = new UserGroup(obj);
                            this.team.push(group);
                        } else {
                            if (!obj.emailAddress) {
                                obj.emailAddress = obj.name;
                            }
                            var user = new User(obj);
                            this.team.push(user);
                        }
                    }
                }, this);
            }
        }, reset:function () {
            this.teamspaceTemplateName = "";
            this.searchTemplates = [];
            this.contentClasses = [];
            this.entryTemplates = [];
            this.roles = [];
            this.team = [];
            this.members = [];
            this.state = "published";
            this.templateJSON = null;
            this.foldersMetaData = {};
            this.name = "";
            this.desc = "";
            this.className = "";
            this.onChange(this);
        }, getMimeClass:function () {
            if (this.type == "template") {
                return "ecmTeamspaceTemplateIcon";
            } else {
                return "ecmTeamspaceIcon";
            }
        }, getLastModified:function () {
            return ecm.model.desktop.valueFormatter.formatValue(this.lastModified, "xs:timestamp");
        }, onNameChange:function (modelObject) {
        }, addRole:function (id, role) {
            this.roles[id] = role;
            this.onChange();
        }, removeRole:function (id) {
            this.roles.splice(id);
            this.onChange();
        }, toJson:function () {
            var ts = {};
            ts.id = this.id;
            ts.name = this.name;
            ts.type = this.type;
            ts.state = this.state;
            ts.desc = this.desc;
            ts.templateName = this.teamspaceTemplateName;
            ts.usesClasses = this.usesClasses + "";
            if (!this.columnProperties) {
                ts.columnProperties = "";
            } else {
                ts.columnProperties = this.columnProperties;
            }
            if (this.type == "instance") {
                ts.folders = [];
                for (var i in this.folders) {
                    var item = this.folders[i];
                    var jsonItem = {name:item.name, path:item.path, type:item.type, IsCopy:item.IsCopy ? true : false};
                    if (item["rowProperties"] && item.rowProperties["_value"]) {
                        var properties = item.rowProperties._value["properties"];
                        if (properties) {
                            jsonItem.properties = properties;
                        }
                    }
                    ts.folders.push(jsonItem);
                }
            } else {
                ts.folders = dojojson.toJson(this.folders);
            }
            ts.entryTemplates = [];
            ts.permissions = this.permissions || [];
            for (var i in this.entryTemplates) {
                var entryTemplate = this.entryTemplates[i];
                var jsonEntryTemplates = {};
                jsonEntryTemplates.id = entryTemplate.id;
                jsonEntryTemplates.name = entryTemplate.name;
                jsonEntryTemplates.description = entryTemplate.description;
                jsonEntryTemplates["default"] = entryTemplate.teamspaceDefault ? this.messages.workspacebuilder_classes_columns_default : "";
                if (entryTemplate.teamspaceDefault == true) {
                    ts.defaultEntryTemplate = entryTemplate.id;
                }
                ts.entryTemplates.push(jsonEntryTemplates);
            }
            ts.contentClasses = [];
            for (var i in this.contentClasses) {
                var contentClass = this.contentClasses[i];
                var jsonContentClasses = {};
                jsonContentClasses.id = contentClass.id;
                jsonContentClasses.name = contentClass.name;
                jsonContentClasses["default"] = contentClass.teamspaceDefault ? this.messages.workspacebuilder_classes_columns_default : "";
                if (contentClass.teamspaceDefault == true) {
                    ts.defaultClass = contentClass.id;
                }
                ts.contentClasses.push(jsonContentClasses);
            }
            ts.searchTemplates = [];
            for (var i in this.searchTemplates) {
                var searchTemplate = this.searchTemplates[i];
                var jsonSearchTemplates = {};
                jsonSearchTemplates.id = searchTemplate.id;
                jsonSearchTemplates.name = searchTemplate.name;
                jsonSearchTemplates.description = searchTemplate.description;
                ts.searchTemplates.push(jsonSearchTemplates);
            }
            ts.roles = [];
            for (var i in this.roles) {
                var role = this.roles[i];
                ts.roles.push(role.toJSON());
            }
            ts.members = this.members;
            var json = dojojson.toJson(ts);
            return json;
        }, getStateClass:function (state) {
            var stateClass = ecm.model.Item.StateToCssClass[state];
            if (!stateClass) {
                stateClass = "";
            }
            return stateClass;
        }, createFromTemplateJson:function (jsonTeamspaceString) {
            var method = "createFromTemplateJson";
            this.templateJSON = jsonTeamspaceString;
            var jsonTeamspace = dojojson.fromJson(jsonTeamspaceString);
            this.id = jsonTeamspace["id"];
            this.defaultClass = jsonTeamspace["defaultClass"];
            this.defaultEntryTemplate = jsonTeamspace["defaultEntryTemplate"];
            this.teamspaceTemplateName = jsonTeamspace["templateName"];
            var usesClasses = jsonTeamspace["usesClasses"];
            if (usesClasses) {
                var usesClasses = usesClasses == "true";
                this.usesClasses = usesClasses;
            } else {
                this.usesClasses = true;
            }
            var entryTemplates = jsonTeamspace["entryTemplates"];
            var arrayList = [];
            if (entryTemplates) {
                for (var i = 0; i < entryTemplates.length; i++) {
                    var entryTemplate = new EntryTemplate({id:entryTemplates[i].id, name:entryTemplates[i].name, description:entryTemplates[i].description, repository:this.repository});
                    var defaultValue = entryTemplates[i]["default"] != "" ? true : false;
                    entryTemplate.teamspaceDefault = defaultValue;
                    arrayList.push(entryTemplate);
                }
            }
            this.entryTemplates = arrayList;
            var contentClasses = jsonTeamspace["contentClasses"];
            var arrayList = [];
            if (contentClasses) {
                for (var i = 0; i < contentClasses.length; i++) {
                    var contentClass = new ContentClass({id:contentClasses[i].id, name:contentClasses[i].name, repository:this.repository});
                    var defaultValue = contentClasses[i]["default"] != "" ? true : false;
                    contentClass.teamspaceDefault = defaultValue;
                    arrayList.push(contentClass);
                }
            }
            this.contentClasses = arrayList;
            var searchTemplates = jsonTeamspace["searchTemplates"];
            arrayList = [];
            if (searchTemplates) {
                for (var i = 0; i < searchTemplates.length; i++) {
                    var searchTemplate = new SearchTemplate({id:searchTemplates[i].id, name:searchTemplates[i].name, repository:this.repository, description:searchTemplates[i].description});
                    arrayList.push(searchTemplate);
                }
            }
            this.searchTemplates = arrayList;
            var roles = jsonTeamspace["roles"];
            arrayList = [];
            if (roles) {
                for (var i = 0; i < roles.length; i++) {
                    var r = roles[i];
                    if (r.desc) {
                        r.description = r.desc;
                    }
                    if (r.privs) {
                        r.privileges = r.privs;
                    }
                    var role = new Role(r);
                    arrayList.push(role);
                }
            }
            this.roles = arrayList;
            this.members = jsonTeamspace["members"];
            var folders = jsonTeamspace["folders"];
            if (folders && lang.isString(folders)) {
                folders = dojojson.fromJson(folders);
            }
            this.folders = folders;
            if (jsonTeamspace["columnProperties"]) {
                this.columnProperties = jsonTeamspace["columnProperties"];
            }
        }, getPrivilege:function (privilege) {
            if (this.currentUserPrivileges) {
                var position = array.indexOf(this.currentUserPrivileges, privilege);
                var hasPriv = position != -1;
                return hasPriv;
            }
            return false;
        }, hasPrivilege:function (privilege) {
            return this.getPrivilege(privilege);
        }, initFromJson:function () {
            var id = this.id;
            var json = this.templateJSON;
            this.createFromTemplateJson(json);
            this.id = id;
        }, retrieveUserPrivileges:function (callback) {
            if (this.currentUserPrivileges && this.currentUserPrivileges.length > 0) {
                callback(this.currentUserPrivileges);
            } else {
                var self = this;
                var request = ecm.model.Request.invokeService("getUserPermissions", this.repository.type, {docid:self.id, workspaceType:self.type, repositoryId:this.repository.id}, function (response) {
                    self._retrieveUserPrivileges(response, callback);
                });
            }
        }, _retrieveUserPrivileges:function (response, callback) {
            this.currentUserPrivileges = [];
            if (!response.useClasses) {
                this.usesClasses = true;
            } else {
                this.usesClasses = (response.useClasses == "true" || response.useClasses == true);
            }
            this.state = response.state;
            for (var i in response.user_permissions) {
                var permissions = response.user_permissions[i];
                this.currentUserPrivileges.push(permissions);
            }
            if (callback) {
                callback(this.currentUserPrivileges);
            }
            this.onUserPrivilegesRetrieved(this);
        }, onUserPrivilegesRetrieved:function () {
        }, retrieveSearchTemplateFolders:function (callback) {
            if (this._templateFolders) {
                if (callback) {
                    callback(this._templateFolders);
                }
            } else {
                this._templateFolders = [];
                if (!this._allSearchTemplatesFolder) {
                    this._allSearchTemplatesFolder = new SearchTemplateFolder({id:"all", name:ecm.messages.all_search_templates, description:"", repository:this.repository, teamspace:this});
                }
                this._templateFolders.push(this._allSearchTemplatesFolder);
                if (callback) {
                    callback(this._templateFolders);
                }
                this.onSearchTemplateFoldersRetrieved(this);
            }
        }, onSearchTemplateFoldersRetrieved:function (repository) {
        }, retrieveSearchTemplates:function (callback, filter) {
            if (this.searchTemplates && this.searchTemplates.length > 0) {
                if (callback) {
                    callback(this.searchTemplates);
                }
            } else {
                var self = this;
                var request = ecm.model.Request.invokeService("getSearchTemplates", self.repository.type, {workspaceId:self.id, repositoryId:self.repository.id, filtertype:filter}, function (response) {
                    self._retrieveSearchTemplatesCompleted(response, callback);
                });
                this.searchTemplatesFilter = filter;
            }
        }, _retrieveSearchTemplatesCompleted:function (response, callback) {
            this.searchTemplates = [];
            var items = response.rows ? response.rows : response.datastore.items;
            for (var i in items) {
                var template = ContentItem.createFromJSON(items[i], this.repository);
                template.teamspaceId = this.id;
                this.searchTemplates.push(template);
            }
            if (callback) {
                callback(this.searchTemplates);
            }
            this.onRetrieveSearchTemplatesCompleted(this.searchTemplates);
        }, onRetrieveSearchTemplatesCompleted:function (searchTemplates) {
        }, clearSearchTemplates:function () {
            this.searchTemplates = null;
        }, retrieveContentClasses:function (callback) {
            if (this.contentClasses && this.contentClasses.length > 0) {
                if (callback) {
                    callback(this.contentClasses);
                }
            } else {
                if (this._retrieveContentClassesCallbacks) {
                    this._retrieveContentClassesCallbacks.push(callback);
                } else {
                    this._retrieveContentClassesCallbacks = [callback];
                    var request = ecm.model.Request.invokeService("getContentClasses", this.repository.type, {workspaceId:this.id, repositoryId:this.repository.id}, lang.hitch(this, function (response) {
                        this._retrieveContentClassesCompleted(response);
                    }), false, false, lang.hitch(this, function () {
                        delete this._retrieveContentClassesCallbacks;
                    }));
                }
            }
        }, _retrieveContentClassesCompleted:function (response) {
            this.contentClasses = [];
            for (var i in response.datastore.items) {
                var templateJSON = response.datastore.items[i];
                var template = null;
                if (templateJSON[0]) {
                    template = new ContentClass({id:templateJSON[0], name:templateJSON[1] || templateJSON[0], repository:this.repository});
                } else {
                    templateJSON.id = templateJSON.template_name;
                    templateJSON.name = templateJSON.template_label;
                    templateJSON.repository = this.repository;
                    if (this.repository._isCM()) {
                        templateJSON.allowsInstances = true;
                        template = new ContentClass(templateJSON);
                    } else {
                        template = new ContentClass(templateJSON);
                    }
                }
                this.contentClasses.push(template);
            }
            var retrieveContentClassesCallbacks = this._retrieveContentClassesCallbacks;
            delete this._retrieveContentClassesCallbacks;
            for (var i in retrieveContentClassesCallbacks) {
                retrieveContentClassesCallbacks[i](this.contentClasses);
            }
        }, retrieveBaseFolder:function (callback) {
            if (this._baseFolder) {
                if (callback) {
                    callback(this._baseFolder);
                }
            } else {
                var self = this;
                this.repository.retrieveItem(this.id, function (item) {
                    self._baseFolder = item;
                    if (callback) {
                        callback(item);
                    }
                });
            }
        }, addSearchTemplate:function (searchTemplate, callback) {
            var self = this;
            var request = ecm.model.Request.postService("addSearchTemplate", this.repository.type, {repositoryId:this.repository.id, workspaceId:self.id, templatedescription:searchTemplate.description, template_name:searchTemplate.name}, "text/json", searchTemplate.toJson(), function (response) {
                self._searchTemplateAdded(response, searchTemplate, callback);
            });
        }, _searchTemplateAdded:function (response, searchTemplate, callback) {
            var itemJSON = response.rows.length > 0 ? response.rows[0] : response.datastore.items[0];
            var properties = itemJSON;
            searchTemplate.id = properties.id;
            lang.mixin(searchTemplate, properties);
            searchTemplate.permissions = null;
            this.searchTemplates.push(searchTemplate);
            this.repository.clearSearchTemplates();
            if (callback) {
                callback(searchTemplate);
            }
            this.onSearchTemplateAdded(searchTemplate);
            this.onChange(searchTemplate);
        }, onSearchTemplateAdded:function (searchTemplate) {
        }, searchTemplatesDeleted:function (searchTemplates) {
            this.removeRecentSearches(searchTemplates);
            array.forEach(searchTemplates, function (searchTemplate) {
                this._searchTemplateDeleted(searchTemplate.id);
            }, this);
        }, _searchTemplateDeleted:function (searchTemplateId) {
            if (this.searchTemplates) {
                for (var i = 0; i < this.searchTemplates.length; i++) {
                    if (this.searchTemplates[i].id == searchTemplateId) {
                        this.searchTemplates.splice(i, 1);
                        break;
                    }
                }
            }
            if (this.openedSearches) {
                for (var i in this.openedSearches) {
                    var searchTemplate = this.openedSearches[i];
                    if (searchTemplate.id == searchTemplateId) {
                        delete this.openedSearches[i];
                    }
                }
            }
            this.onSearchTemplateDeleted(searchTemplateId);
        }, onSearchTemplateDeleted:function (searchTemplateId) {
        }, clearSearchTemplates:function () {
            this.searchTemplates = [];
            this.onChange(this);
        }});
        Teamspace.INSTANCE = "instance";
        Teamspace.TEMPLATE = "template";
        Teamspace.RUNTIME = "runtime";
        Teamspace.STATE_OFFLINE = "offline";
        Teamspace.STATE_PUBLISHED = "published";
        Teamspace.NAME_ATTRIBUTE = "ClbTeamspaceName";
        Teamspace.TITLE_ATTRIBUTE = "clbTitle";
        Teamspace.TEAMSPACE_CONTENTCLASS_CM8 = "ICMTeamspace";
        Teamspace.TEAMSPACE_CONTENTCLASS_P8 = "ClbTeamspace";
        return Teamspace;
    });
}, "ecm/model/SecurityPolicy":function () {
    define("ecm/model/SecurityPolicy", ["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "./_ModelObject", "./SecurityTemplate", "./Permission"], function (declare, lang, array, _ModelObject, SecurityTemplate, Permission) {
        return declare("ecm.model.SecurityPolicy", [_ModelObject], {_RELEASED_ID:"{95AD7AED-DFA0-4459-AE95-2CA2FC041602}", _IN_PROCESS_ID:"{E76E4F72-545C-4180-97C1-8449883B83CF}", _SUPERSEDED_ID:"{A0A5A26E-D19F-4415-8451-6795386AD1BB}", _RESERVATION_ID:"{F9ED916D-CCB7-4D7E-8CC1-563F1692C67C}", displayName:null, preserveDirectPermissions:null, securityTemplates:null, constructor:function (params) {
            if (params && params.securityTemplates) {
                var securityTemplates = [];
                array.forEach(params.securityTemplates, function (securityTemplate, index) {
                    securityTemplate.permissions = Permission.createFromJSON(securityTemplate.acl);
                    securityTemplate.name = securityTemplate.displayName;
                    securityTemplates.push(new SecurityTemplate(securityTemplate));
                }, this);
                this.securityTemplates = securityTemplates;
            }
        }, getReleasedTemplate:function () {
            return this._getTemplate(this._RELEASED_ID);
        }, getInProcessTemplate:function () {
            return this._getTemplate(this._IN_PROCESS_ID);
        }, getReservationTemplate:function () {
            return this._getTemplate(this._RESERVATION_ID);
        }, getSupersededTemplate:function () {
            return this._getTemplate(this._SUPERSEDED_ID);
        }, _getTemplate:function (templateId) {
            if (this.securityTemplates) {
                var filteredTemplate = array.filter(this.securityTemplates, function (securityTemplate) {
                    return securityTemplate.applyStateId == templateId;
                });
                if (filteredTemplate.length > 0) {
                    return filteredTemplate[0];
                } else {
                    return null;
                }
            }
            return null;
        }, getReleasedTemplatePermissions:function () {
            return this._getTemplatePermissions(this._RELEASED_ID);
        }, getInProcessTemplatePermissions:function () {
            return this._getTemplatePermissions(this._IN_PROCESS_ID);
        }, getReservationTemplatePermissions:function () {
            return this._getTemplatePermissions(this._RESERVATION_ID);
        }, getSupersededTemplatePermissions:function () {
            return this._getTemplatePermissions(this._SUPERSEDED_ID);
        }, _getTemplatePermissions:function (templateId) {
            var permissions = null;
            var securityTemplate = this._getTemplate(templateId);
            if (securityTemplate) {
                if (securityTemplate.isEnabled) {
                    permissions = securityTemplate.permissions;
                }
            }
            return permissions;
        }});
    });
}, "ecm/model/Permission":function () {
    define(["dojo/_base/declare", "./_ModelObject", "./UserGroup", "./User"], function (declare, _ModelObject, UserGroup, User) {
        var Permission = declare("ecm.model.Permission", [_ModelObject], {granteeType:null, accessMask:null, accessType:null, inheritableDepth:null, permissionSource:null, roleName:null, grantee:null, constructor:function () {
            if (this.granteeName) {
                this.name = this.granteeName;
                delete this.granteeName;
            }
            if (this.granteeType == "2000") {
                this.grantee = new User({id:this.id, name:this.name, shortName:this.name, displayName:this.displayName});
            } else {
                this.grantee = new UserGroup({id:this.id, name:this.name, shortName:this.name, displayName:this.displayName});
            }
        }, isSecurityProxyPermission:function () {
            return this.permissionSource == ecm.model.Permission.PERMISSION_SOURCE.SECURITY_PROXY;
        }, json:function () {
            var jsonPermission = {};
            jsonPermission.granteeName = this.grantee.name;
            jsonPermission.accessType = this.accessType;
            jsonPermission.accessMask = this.accessMask;
            jsonPermission.granteeType = this.granteeType;
            jsonPermission.inheritableDepth = this.inheritableDepth;
            if (this.roleName) {
                jsonPermission.roleName = this.roleName;
            } else {
                jsonPermission.roleName = null;
            }
            return jsonPermission;
        }, _nop:null});
        Permission.createFromJSON = function (permissionsJSON) {
            var permissions = [];
            for (var i in permissionsJSON) {
                var permissionJSON = permissionsJSON[i];
                permissionJSON.displayName = permissionJSON.id == UserGroup.AUTHENTICATED_USERS ? ecm.messages.authenticated_users : permissionJSON.displayName;
                permissions.push(new Permission(permissionJSON));
            }
            return permissions;
        };
        Permission.GRANTEE_TYPE = {USER:2000, GROUP:2001};
        Permission.ACCESS_TYPE = {ALLOW:1, DENY:2};
        Permission.PERMISSION_SOURCE = {CLASS:0, DIRECT:1, POLICY:2, INHERITED:3, SECURITY_PROXY:255};
        return Permission;
    });
}, "ecm/model/admin/IconStatusConfig":function () {
    define("ecm/model/admin/IconStatusConfig", ["dojo/_base/declare", "./_ConfigurationObject"], function (declare, _ConfigurationObject) {
        var IconStatusConfig = declare("ecm.model.admin.IconStatusConfig", [_ConfigurationObject], {ID:"id", LABEL:"label", FILE_NAME:"fileName", CLASS_NAME:"className", SERVERS:"servers", constructor:function (id, name) {
        }, getLabel:function () {
            return this.getValue(this.LABEL);
        }, setLabel:function (name) {
            this.setValue(this.LABEL, name);
        }, getFileName:function () {
            return this.getValue(this.FILE_NAME);
        }, setFileName:function (name) {
            this.setValue(this.FILE_NAME, name);
        }, getClassName:function () {
            return this.getValue(this.CLASS_NAME);
        }, setClassName:function (name) {
            this.setValue(this.CLASS_NAME, name);
        }, getServers:function () {
            return this.getValues(this.SERVERS);
        }, setServers:function (servers) {
            this.setValue(this.SERVERS, servers);
        }});
        IconStatusConfig.createIconStatusConfig = function (id) {
            return new IconStatusConfig(id, "IconStatusConfig");
        };
        return IconStatusConfig;
    });
}, "*now":function (r) {
    r(["dojo/i18n!*preload*ecm/nls/ecm*[\"ar\",\"cs\",\"da\",\"de\",\"el\",\"en\",\"en-ca\",\"en-gb\",\"es\",\"fi\",\"fr\",\"fr-ca\",\"he\",\"hr\",\"hu\",\"it\",\"ja\",\"ko\",\"nb-no\",\"nl\",\"no\",\"pl\",\"pt\",\"pt-br\",\"ru\",\"ro\",\"sk\",\"sl\",\"sv\",\"th\",\"tr\",\"zh\",\"zh-cn\",\"zh-tw\",\"ROOT\"]"]);
}}});
define("ecm/ecm", ["dijit", "dojo", "dojox", "dojo/require!ecm/Logger,ecm/LoggerMixin,ecm/Messages,ecm/model/_ModelObject,ecm/model/Request,ecm/model/_ModelStore,ecm/model/ContentClass,ecm/model/Desktop,ecm/model/EntryTemplate,ecm/model/EntryTemplateOption,ecm/model/EntryTemplatePropertyOptions,ecm/model/FavoritesTreeModel,ecm/model/FolderTreeModel,ecm/model/Item,ecm/model/Message,ecm/model/Repository,ecm/model/ResultSet,ecm/model/SearchCriterion,ecm/model/SearchTemplate,ecm/model/SearchTemplateFolder,ecm/model/SearchTemplateTreeModel,ecm/model/SearchFolder,ecm/model/User,ecm/model/UserGroup,ecm/model/Role,ecm/model/Viewer,ecm/model/ViewerMapping,ecm/model/WorkItem,ecm/model/Worklist,ecm/model/WorklistFolder,ecm/model/WorklistsTreeModel,ecm/model/Directory,ecm/model/SearchConfiguration"], function (dijit, dojo, dojox) {
    dojo.require("ecm.Logger");
    dojo.require("ecm.LoggerMixin");
    dojo.require("ecm.Messages");
    dojo.require("ecm.model._ModelObject");
    dojo.require("ecm.model.Request");
    dojo.require("ecm.model._ModelStore");
    dojo.require("ecm.model.ContentClass");
    dojo.require("ecm.model.Desktop");
    dojo.require("ecm.model.EntryTemplate");
    dojo.require("ecm.model.EntryTemplateOption");
    dojo.require("ecm.model.EntryTemplatePropertyOptions");
    dojo.require("ecm.model.FavoritesTreeModel");
    dojo.require("ecm.model.FolderTreeModel");
    dojo.require("ecm.model.Item");
    dojo.require("ecm.model.Message");
    dojo.require("ecm.model.Repository");
    dojo.require("ecm.model.ResultSet");
    dojo.require("ecm.model.SearchCriterion");
    dojo.require("ecm.model.SearchTemplate");
    dojo.require("ecm.model.SearchTemplateFolder");
    dojo.require("ecm.model.SearchTemplateTreeModel");
    dojo.require("ecm.model.SearchFolder");
    dojo.require("ecm.model.User");
    dojo.require("ecm.model.UserGroup");
    dojo.require("ecm.model.Role");
    dojo.require("ecm.model.Viewer");
    dojo.require("ecm.model.ViewerMapping");
    dojo.require("ecm.model.WorkItem");
    dojo.require("ecm.model.Worklist");
    dojo.require("ecm.model.WorklistFolder");
    dojo.require("ecm.model.WorklistsTreeModel");
    dojo.require("ecm.model.Directory");
    dojo.require("ecm.model.SearchConfiguration");
});

