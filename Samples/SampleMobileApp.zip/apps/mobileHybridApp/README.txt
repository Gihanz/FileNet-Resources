
This app demonstrates usage of ICN middleware javascript API
------------------------------------------------------------



General structure.
-----------------

The app is structured and developed as dojo mobile Worklight application.
App design following the MVC pattern.
App is designed for iPhone only.

<common> folder contains all the code and resources
Under the <common> folder <view> folder contains the dojo based <views>, <js/controller> contains the respective js controllers
and <mila> has ICN model API.
Rest of the folders contain infrastructures, css and libraries.

-mobileHybridApp.html is the main html loaded by Worklight.

To run and deploy the app consult relevant Worklight
      http://www.ibm.com/developerworks/mobile/worklight/getting-started.html
   and dojo mobile
      http://dojotoolkit.org/features/mobile
   documentation


Packaging app ICN plugin.
------------------------

App can be packaged as ICN plugin, in this case packaged as SampleMobilePlugin.jar.
<buid/build.xml> plugin target can be run to generate a jar.
Consult ICN documentation for deploying ICN plugin.
Packaged as plugin app has very similar set of capabilities, for details consult SampleMobilePlugin documentation describing the plugin.
Once deployed accessing ICN from iPhone browser (Safari, Chrome) will show the mobile layout.


Customization technical notes.
-----------------------------

-Dojo require statements
Require statements done in two phases, this is in order to support app with "Use ICN plugin" setting switch enabled.
With this enabled most of the app code is downloaded once logged into the ICN desktop and the desktop has SampleMobilePlugin deployed.
In the firs phase most of the infrastructure code and javascript involved with fist few independent screens is "required", the rest of the
code since can be used either from local app storage or "browsed" on the ICN plugin is "required" with MenuController.js.
If you intend to develop the app you need to be aware of this.

-Generic capabilities exposed with few infrastructure classes under <transitions> folder, BaseController, ControllersManager and mobileHybrisApp
These include view transition API, controller stack, busy indicator, alerts, debug, events etc...

-Note that for being able running from Worklight simulator on chrome need to start chrome with --args --disable-web-security
and set Desktop address manually in the <desktop/common.js> since dynamic Desktop creation that relies on JSON Store is not
supported with Worklight simulator
Replace address and credentials as needed th following lines
				                daddress: "http://host:port/navigator",
				            	duser:"user",
				            	dpassword:"password",

To read more about customization options consult...

