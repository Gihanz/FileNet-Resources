package clustering.bean;


public interface Session
{
   void test();
}
