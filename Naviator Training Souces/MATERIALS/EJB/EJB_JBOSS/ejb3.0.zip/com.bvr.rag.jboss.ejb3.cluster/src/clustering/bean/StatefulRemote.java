package clustering.bean;



public interface StatefulRemote
{
   void increment();
}
