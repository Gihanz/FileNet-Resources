package timer.bean;



public interface ExampleTimer
{
   void scheduleTimer(long milliseconds);
}
