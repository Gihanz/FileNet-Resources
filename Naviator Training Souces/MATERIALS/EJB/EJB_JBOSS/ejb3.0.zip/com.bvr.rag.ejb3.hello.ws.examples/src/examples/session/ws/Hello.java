package examples.session.ws;


/**
 * This is the Hello business interface.
 */


public interface Hello {

    public String hello();

    public void foo();
    
}
