/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/dom-style",
	"dojo/dom-attr",
	"dojo/dom-geometry",
	"dojo/data/ItemFileWriteStore",
	"dijit/_Widget",
	"dijit/_TemplatedMixin",
	"dijit/_WidgetsInTemplateMixin",
	"dijit/tree/ForestStoreModel",
	"idx/html",
	"ecm/model/Message",
	"ecm//Messages",
	"ecm/widget/FilterTextBox",
	"sampleSearchChoiceListPluginDojo/ChoiceGrid",
	"dojo/text!sampleSearchChoiceListPluginDojo/templates/SearchChoicePane.html"
],

function(declare, //
lang, //
domStyle, //
domAttr, //
domGeom, //
ItemFileWriteStore, //
_Widget, //
_TemplatedMixin, //
_WidgetsInTemplateMixin, //
ForestStoreModel, //
idxHtml, //
Message, //
Messages, //
FilterTextBox, //
ChoiceGrid, //
template) {

	/**
	 * @name ecm.widget.MultiValueChoicePane
	 * @class Provides a widget that is used to select multiple values from a choice list. This widget is used for IBM
	 *        FileNet Content Manager repositories.
	 * @augments dijit._Widget
	 */
	return declare("sampleSearchChoiceListPluginDojo.SearchChoicePane", [
		_Widget,
		_TemplatedMixin,
		_WidgetsInTemplateMixin
	], {
		/** @lends ecm.widget.MultiValueChoicePane.prototype */

		templateString: template,
		widgetsInTemplate: true,
		/**
		 * Choice list to be displayed as the available data. This has a <code>displayName</code> and choices.
		 */
		availableData: null,
		
		/**
		 * The selected value.
		 */
		selectedValue: null,
		/**
		 * Boolean indicating if duplicate values are allowed. If set to <code>false</code>, then value will be the
		 * identifier.
		 */
		allowDuplicateValues: true,
		/**
		 * Boolean indicating if the widget supports sorting. If set to <code>false</code>, then the move up down
		 * buttons/container is non-displayed.
		 */
		hasSorting: true,
		/**
		 * If set to <code>true</code>, when an available item is added to the selected list, it is hidden in the
		 * available list.
		 */
		hideAvailableOnAdd: false,
		/**
		 * Boolean indicating if the available list is a tree or grid.
		 */
		isTree: false,
		/**
		 * Boolean indicating if the data is editable.
		 */
		editable: true,

		messages: ecm.messages,
		_availableDataMap: null,
		_previousFilter: "",

		/**
		 * Markings that are in the selected data that the user does not have permission to remove.
		 */
		_fixedMarkings: {},

		constructor: function() {

		},

		postCreate: function() {
			this.inherited(arguments);

			this._separator = ecm.model.desktop.valueFormatter.getSeparator();

			if (this.allowDuplicateValues) {
				this.hideAvailableOnAdd = false; // hideAvailableOnAdd is only allowed if using unique/non-duplicate values
			}
			this._ChoiceGrid.tooltipClass = this;
			this._ChoiceGrid.hasSorting = this.hasSorting;
			this._ChoiceGrid.hideAvailableOnAdd = this.hideAvailableOnAdd;
			this._ChoiceGrid.setEditable(this.editable);

			this._ChoiceGrid.validateRemove = dojo.hitch(this, "_validateRemove");

			this._filter.set('disabled', !this.editable);
			this._availableDataMap = {};

			this._loadAvailableValues();
			this._loadFixedMarkings();
			this._displayWarning("");
		},

		destroy: function() {
			if (this._availableDataMap)
				delete this._availableDataMap;
			this.inherited(arguments);
		},

		/**
		 * When the widget is shown, clears the filter and loads the {@link ChoiceGrid} widget.
		 */
		onShow: function() {
			this._displayWarning("");
			this._filter.set('value', '');
		},

		onHide: function() {
			if (this._ChoiceGrid)
				this._ChoiceGrid.onHide();
		},

		/**
		 * Callback from the ChoiceGrid. Loads the grid tooltip.
		 * 
		 * @param grid
		 *            The grid.
		 * @param item
		 *            The item.
		 */
		getGridTooltipText: function(grid, item) {
			if (item) {
				var toolTip = [];
				toolTip.push("<div><span class='tooltipLabel'>" + this.messages.name + "</span> ");
				toolTip.push("<span class='tooltipValue'>");
				var label = grid.store.getValue(item, 'label');
				toolTip.push(idxHtml.escapeHTML(label));
				toolTip.push("</span></div>");
				toolTip.push("<div><span class='tooltipLabel'>" + this.messages.value_label + "</span> ");
				toolTip.push("<span class='tooltipValue'>");
				var value = grid.store.getValue(item, 'value');
				toolTip.push(idxHtml.escapeHTML(value));
				toolTip.push("</span></div>");
				return toolTip.join("");
			} else {
				return "";
			}
		},

		/**
		 * Callback from the ChoiceGrid. Loads the tree node's tooltip.
		 * 
		 * @param treeModel
		 *            The <code>treeModel</code>.
		 * @param treeNode
		 *            The tree node.
		 */
		getTreeTooltipText: function(treeModel, treeNode) {
			var item = treeNode.item;
			if (item && item.value) {
				var toolTip = [];
				toolTip.push("<div><span class='tooltipLabel'>" + this.messages.name + "</span> ");
				toolTip.push("<span class='tooltipValue'>");
				var label = treeModel.store.getValue(item, 'label');
				toolTip.push(idxHtml.escapeHTML(label));
				toolTip.push("</span></div>");
				toolTip.push("<div><span class='tooltipLabel'>" + this.messages.value_label + "</span> ");
				toolTip.push("<span class='tooltipValue'>");
				var value = treeModel.store.getValue(item, 'value');
				toolTip.push(idxHtml.escapeHTML(value));
				toolTip.push("</span></div>");
				toolTip.push("<div><span class='tooltipLabel'>" + this.messages.path_label + "</span> ");
				toolTip.push("<span class='tooltipValue'>");
				var path = treeNode.getTreePath();
				var pathStr = "";
				for ( var i = 0; i < path.length - 1; i++) {
					if (i != 0) {
						pathStr += " > ";
					}
					pathStr += path[i].label;
				}
				toolTip.push(idxHtml.escapeHTML(pathStr));
				toolTip.push("</span></div>");
				return toolTip.join("");
			} else {
				return ecm.messages.properties_not_selectable_tooltip;
			}
		},

		/**
		 * @private On initialization of this widget, add all of its selected marking values, assumed to be persisted in
		 *          the repository, to a fixed values list, to be flagged later if the user attempts to remove them.
		 */
		_loadFixedMarkings: function() {
			this._fixedMarkings = {};
			if (this.availableData.markings) {

			}
		},

		/**
		 * @private Loads the available values.
		 */
		_loadAvailableValues: function() {
			var store = new ItemFileWriteStore({
				data: {
					items: this._getAvailableItems(this.availableData.choices)
				}
			});
			if (this.isTree) {
				domStyle.set(this._filterDiv, "display", "none");
				var model = new ForestStoreModel({
					store: store,
					rootLabel: this.availableData.displayName,
					childrenAttrs: [
						"children"
					],
					labelAttr: "label"
				});
				this._ChoiceGrid.setAvailableTreeModel(model);

			} else {
				this._ChoiceGrid.availableLabel = ""; // no extra label for grid
				domStyle.set(this._filterDiv, "display", "");
				var structure = [
					{
						field: "label",
						name: ecm.messages.available_heading,
						width: "100%"
					}
				];
				this._ChoiceGrid.setAvailableGridModel(store, structure);
				this._ChoiceGrid.filter({
					label: "*"
				});
				this.connect(this._filter, "_onInput", "_filterData");
				this.connect(this._filter, "_setValueAttr", "_filterData");
			}
		},

		/**
		 * @private Returns the available items.
		 */
		_getAvailableItems: function(choices) {
			var itemsArray = [];
			if (this.availableData) {
				for ( var i = 0; i < choices.length; i++) {
					var choice = choices[i];
					var label = choice.displayName;
					var value = choice.value;

					var item = {
						label: label
					};
					if (value) {
						item.value = value;
						this._availableDataMap[value] = label;
					}
					itemsArray.push(item);

					if (choice.choices) {
						var childrenArray = this._getAvailableItems(choice.choices);
						item.children = childrenArray;
					}
				}
			}
			return itemsArray;
		},

		/**
		 * @private Filters the data.
		 */
		_filterData: function() {
			var value = this._filter.get("value");
			if (this._previousFilter != value) {
				this._previousFilter = value;
				this._ChoiceGrid.filter({
					label: "*" + value + "*"
				});
			}
		},

		_validateRemove: function(selection) {
			var validated = true;

			/*
			 *  This code detects when a marking is being removed, that the user does not have permission to remove.
			 */
			if (this.availableData.markings) {
				var selected = selection.getSelected();
				var grid = selection.grid;
				var cantRemoveCount = {};
				var cantRemove = [];
				var cantRemoveValues = "";

				for ( var i in selected) {
					var value = selected[i].value[0];
					if (this._fixedMarkings[value] === true) {
						if (cantRemoveCount[value] == undefined) {
							cantRemoveCount[value] = -1;
							cantRemove.push(value);
						} else {
							--cantRemoveCount[value];
						}
					}
				}

				if (cantRemove.length > 0) {
					for ( var i = 0; i < grid.rowCount; i++) {
						var value = grid.getItem(i).value[0];
						if (cantRemoveCount[value] != undefined) {
							++cantRemoveCount[value];
						}
					}

					for ( var i in cantRemove) {
						if (cantRemoveCount[cantRemove[i]] <= 0) {
							if (cantRemoveValues != "") {
								cantRemoveValues = cantRemoveValues + ", ";
							}
							cantRemoveValues = cantRemoveValues + cantRemove[i];
						}
					}

					if (cantRemoveValues != "") {
						this._displayWarning(lang.replace(ecm.messages.cannot_remove_markings, [
							cantRemoveValues
						]));
						validated = false;
					}
				}
			}

			return validated;
		},

		/**
		 * @private
		 */
		_displayWarning: function(message) {
			var warningMessage = idxHtml.escapeHTML(message);
			this._infoText.innerHTML = warningMessage;
			domAttr.set(this._infoImage, "alt", warningMessage);
			if (message.length > 0) {
				domStyle.set(this._infoPane, "display", "block");
			} else {
				domStyle.set(this._infoPane, "display", "none");
			}

			var dropDownDialog = this.getParent();
			if (dropDownDialog && dropDownDialog.scheduleResize) {
				dropDownDialog.scheduleResize();
			}
		},

		/**
		 * Called when the user clicks the <code>Save</code> or <code>OK</code> button to save the changes. Gets the
		 * selected values from the ChoiceGrid.
		 */
		onSave: function() {
			var item = this._ChoiceGrid._availableData.selection.getSelected();
			if (item.length > 0) {
				var value = this._ChoiceGrid._availableData.store.getValue(item[0], "value");
				this.selectedValue = value;
			} else {
				this.selectedValue = "";
			}

		},
		
		/**
		 * Returns the label string for the selected values.
		 * 
		 * @return The full label string. When multiple values are selected, the label for each selected value is
		 *         appended to the label string. The <code>_separator</code> character is used to separate multiple
		 *         labels in the label string.
		 */
		getLabel: function() {
			var label = "";
			var value = this.selectedValue;
			var lab = this._availableDataMap[value] ? this._availableDataMap[value] : value;
			if (lab != null)
				label += lab;
			return label;
		},

		/**
		 * Returns the value.
		 * 
		 * @return An array of the selected values in the selected values sloshBucket.
		 */
		getValue: function() {
			return this.selectedValue;
		},
		
		/**
		 * Resizes the ChoiceGrid.
		 * 
		 * @param changeSize
		 *            The changed size. See the {@link ChoiceGrid} method <code>resize</code>.
		 */
		resize: function(changeSize) {
			this._ChoiceGrid.resize(changeSize);
		}
	});
});
