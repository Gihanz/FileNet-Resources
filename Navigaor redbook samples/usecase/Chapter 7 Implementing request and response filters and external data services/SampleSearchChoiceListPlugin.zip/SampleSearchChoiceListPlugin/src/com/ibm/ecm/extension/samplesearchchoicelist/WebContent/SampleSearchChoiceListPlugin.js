require(["dojo/_base/declare",
         "dojo/_base/lang",
         "ecm/widget/SinglePropertyEditorFactory",
         "sampleSearchChoiceListPluginDojo/SearchChoicePane"
         ], 
function(declare, lang, SinglePropertyEditorFactory, SearchChoicePane) {		
	/**
	 * Use this function to add any global JavaScript methods your plug-in requires.
	 */
	SinglePropertyEditorFactory.prototype.createSinglePropertyEditor = function(kwArgs) {
		var methodName = "createSinglePropertyEditor";
		this.logEntry(methodName, "name: " + kwArgs.name + " label: " + kwArgs.label + " type: " + kwArgs.dataType + " required: " + kwArgs.required);
		if (!kwArgs.minMaxValues) {
			kwArgs.minMaxValues = this.getMinMax(kwArgs.minValue, kwArgs.maxValue, kwArgs.dataType, kwArgs.dataFormat); // call this before getPromptText
		}
		var baseConstraints = {
			name: kwArgs.name || "",
			label: kwArgs.label || "",
			dataType: kwArgs.dataType,
			readOnly: kwArgs.readOnly,
			id: kwArgs.id,
			promptText: this.getPromptText(kwArgs),
			required: kwArgs.required
		};

		var editor = null;
		kwArgs.cardinality = kwArgs.cardinality.toUpperCase();
		if (kwArgs.cardinality && (kwArgs.cardinality == "LIST" || kwArgs.cardinality == "MULTI")) {
			editor = this._createMultiValueEditor(baseConstraints, kwArgs);
		} else if (kwArgs.cardinality && kwArgs.cardinality == "SINGLE" && kwArgs.choiceList && kwArgs.choiceListNested) {
			editor = this._createSingleChoiceTreeEditor(baseConstraints, kwArgs);
		} else if ((kwArgs.cardinality && kwArgs.cardinality == "SEARCHCHOICE" && kwArgs.choiceList)) {
			editor = this._createSearchChoiceListEditor(baseConstraints, kwArgs);
		} else if ((kwArgs.cardinality && kwArgs.cardinality == "SINGLE" && kwArgs.choiceList) || (kwArgs.valueOptions && kwArgs.valueOptions.length > 0)) {
				editor = this._createSingleChoiceListEditor(baseConstraints, kwArgs);
		} else if (kwArgs.dataType == "xs:date" || kwArgs.dataType == "xs:timestamp") {
			editor = this._createDateTimestampEditor(baseConstraints, kwArgs);
		} else if (kwArgs.dataType == "xs:time") {
			editor = this._createTimeEditor(baseConstraints, kwArgs);
		} else if (kwArgs.dataType == "xs:guid") {
			editor = this._createGuidEditor(baseConstraints, kwArgs);
		} else if (kwArgs.dataType == "xs:reference") {
			editor = this._createReferenceEditor(baseConstraints, kwArgs);
		} else if (kwArgs.dataType == "xs:object") {
			editor = this._createObjectEditor(baseConstraints, kwArgs);
		} else if (kwArgs.dataType == "xs:integer" || kwArgs.dataType == "xs:short" || kwArgs.dataType == "xs:long" || kwArgs.dataType == "xs:decimal" || kwArgs.dataType == "xs:double") {
			editor = this._createNumberEditor(baseConstraints, kwArgs);
		} else if (kwArgs.dataType == "xs:group") { // user and group
			editor = this._createGroupEditor(baseConstraints, kwArgs);
		} else if (kwArgs.dataType == "xs:user") { // user
			editor = this._createUserEditor(baseConstraints, kwArgs);
		} else {
			editor = this._createTextEditor(baseConstraints, kwArgs);
		}

		if (baseConstraints.label && editor) {
			editor.set("title", baseConstraints.label);
			editor.set("alt", baseConstraints.label);
		}
		this.logExit(methodName);
		return editor;
	},
	
	/**
	 * @private Creates the search choice list editor.
	 */
	SinglePropertyEditorFactory.prototype._createSearchChoiceListEditor = function(baseConstraints, kwArgs) {

		var availableData = kwArgs.choiceList;

		var SearchChoice = new SearchChoicePane({
			availableData: availableData,
			selectedValues: kwArgs.values,
			isTree: kwArgs.choiceListNested,
			editable: !kwArgs.readOnly,
			hasSorting: !kwArgs.uniqueValues,
			hideAvailableOnAdd: kwArgs.uniqueValues,
			allowDuplicateValues: !kwArgs.uniqueValues
		});
		lang.mixin(baseConstraints, {
			"label": SearchChoice.getLabel(),
			width: kwArgs.width || "",
			dropDown: SearchChoice
		});
		var editor = new ecm.widget.DropDownInput(baseConstraints);
		editor.set("value", SearchChoice.getValue());
		editor.startup();
		
		return editor;
	};
});
