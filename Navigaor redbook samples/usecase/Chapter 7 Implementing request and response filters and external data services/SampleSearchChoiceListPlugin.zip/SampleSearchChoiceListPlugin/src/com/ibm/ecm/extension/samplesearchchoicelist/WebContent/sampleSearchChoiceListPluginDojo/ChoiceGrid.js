/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/array",
	"dojo/_base/event",
	"dojo/_base/lang",
	"dojo/keys",
	"dojo/dom-class",
	"dojo/dom-attr",
	"dojo/dom-construct",
	"dojo/dom-geometry",
	"dojo/dom-style",
	"dojox/grid/DataGrid",
	"dijit/_TemplatedMixin",
	"dijit/_WidgetsInTemplateMixin",
	"dijit/form/Button",
	"dijit/layout/ContentPane",
	"dijit/registry",
	"dijit/Tooltip",
	"dijit/Tree",
	"ecm/MessagesMixin",
	"ecm/LoggerMixin",
	"ecm/widget/TreeSelector",
	"dojo/text!sampleSearchChoiceListPluginDojo/templates/ChoiceGrid.html" 
], //
function(declare, //
array, //
event, //
lang, //
keys, //
domClass, //
domAttr, //
domConstruct, //
domGeom, //
domStyle, //
DataGrid, //
_TemplatedMixin, //
_WidgetsInTemplateMixin, //
Button, //
ContentPane, //
registry, //
Tooltip, //
Tree, //
MessagesMixin, //
LoggerMixin, //
TreeSelector, //
template) {
	/**
	 * @name ChoiceGrid
	 * @class Provides a widget that is used to pick a subset of unique items from a larger set of items.
	 *        <p>
	 *        The widget contains two single column lists. One list contains the available items and the other list
	 *        contains the selected items. The <strong>Add</strong> button and a <strong>Remove</strong> button that
	 *        are used to move items from one list to the other appear between the columns. Optionally, the widget
	 *        includes an <strong>Up</strong> button and a <strong>Down</strong> button that are used to order the
	 *        selected items.
	 *        </p>
	 * @augments dijit._Widget
	 */
	return declare("sampleSearchChoiceListPluginDojo.ChoiceGrid", [
		ContentPane,
		_TemplatedMixin,
		_WidgetsInTemplateMixin,
		MessagesMixin,
		LoggerMixin

	], {
		/** @lends ecm.widget.ChoiceGrid.prototype */

		templateString: template,
		widgetsInTemplate: true,

		/**
		 * If set to <code>false</code>, then the move up and move down buttons and container are not displayed.
		 */
		hasSorting: true,
		/**
		 * If set to <code>true</code>, when an available item is added to the selected list it is hidden in the
		 * available list.
		 */
		hideAvailableOnAdd: false,
		/**
		 * This object implements the <code>getTooltipText</code> method which returns the tooltip text for a row.
		 * Tooltip text is displayed when the user hovers the mouse over a row.
		 */
		tooltipClass: null,
		/**
		 * The tooltip position.
		 */
		tooltipPosition: [
			"after",
			"before",
			"above",
			"below"
		], // adding above & below due to long tooltip with no spaces causing issues when only before & after
		/**
		 * The label above the available grid or tree.
		 */
		availableLabel: "",

		/**
		 * If defined, this function will be called to perform validation before removing items from the slosh bucket.
		 * selection is passed as the first parameter to validateRemove. The function defined should return true if it
		 * is okay to proceed with the remove. Required for P8 markings use case.
		 */
		validateRemove: null,

		/**
		 * @private Boolean indicating if the ChoiceGrid is editable.
		 */
		_editable: true,
		/**
		 * @private Boolean indicating if the available list is a tree.
		 */
		_isTree: false,


		postCreate: function() {
			this.inherited(arguments);

			this.connect(Tooltip.containerNode, "onkeypress", lang.hitch(this, function(evt) {
				if (evt.keyCode == keys.ESCAPE) {
					this._prevTooltipCellNode = null;
					Tooltip.hide(evt.target);
					event.stop(evt);
				}
			}));

			this.connect(Tooltip.containerNode, "onmouseout", lang.hitch(this, function(evt) {
				if (this._prevTooltipCellNode) {
					Tooltip.hide(this._prevTooltipCellNode);
					this._prevTooltipCellNode = null;
				}
			}));

			var keyboardEventNode = this.focusNode || this.domNode;
			this.connect(keyboardEventNode, "keydown", lang.hitch(this, "_onKey"));
		},

		_onKey: function(/*Event*/e) {
			if (e.keyCode == keys.ESCAPE) {
				Tooltip.hide(this._prevTooltipCellNode);
			}
			this.inherited(arguments);
		},

		/* make sure the tooltips get destroyed */
		destroy: function() {
			if (this._prevTooltipCellNode)
				Tooltip.hide(this._prevTooltipCellNode);
			this.inherited(arguments);
		},

		onHide: function() {
			if (this._prevTooltipCellNode)
				Tooltip.hide(this._prevTooltipCellNode);
		},

		/**
		 * Sets the store and layout on the available (left) grid. Use either <code>setAvailableGridModel</code> if
		 * the available list is a grid, or use <code>setAvailableTreeModel</code> if the available list is a tree.
		 * 
		 * @param store
		 *            The store for the available DataGrid.
		 * @param layout
		 *            The structure for the available DataGrid.
		 */
		setAvailableGridModel: function(store, layout) {
			if (this._availableData) {
				this._availableData.destroy();
			}
			this._isTree = false;
			var displayIt = (this.availableLabel.length > 0) ? "" : "none";
			domStyle.set(this._availableLabel, "display", displayIt);
			domStyle.set(this._availableContentPane, "top", "0");
			this._availableStore = store;
			this._availableData = new DataGrid({
				canSort: function() {
					return false;
				},
				store: store,
				structure: layout
			});
			domConstruct.place(this._availableData.domNode, this._availableDataContainer, "only");
			this._availableData.startup();

			this.connect(this._availableData, "onKeyDown", lang.hitch(this, function(evt) {
				if (evt.ctrlKey && evt.keyCode == 65) { // Ctrl A
					event.stop(evt);
					this._availableData.selection.selectRange(0, this._availableData.get('rowCount') - 1);
				}
			}));

			this.connect(this._availableData, "onRowDblClick", lang.hitch(this, function(evt) {
				Tooltip.hide(evt.target);
				if (this._editable) {
					var item = this._availableData.getItem(evt.rowIndex);
					this._addItem(item);
					if (this.hideAvailableOnAdd) {
						if (this._isTree) {
							this._availableData.dndController.selectNone();
						} else {
							this._availableData._refresh();
							this._availableData.selection.clear();
						}
					}
				}
			}));

			this._addGridTooltipConnect(this._availableData);
		},

		/**
		 * Sets the tree model for the available (left) tree. Use either <code>setAvailableGridModel</code> if the
		 * available list is a grid, or use <code>setAvailableTreeModel</code> if the available list is a tree.
		 * 
		 * @param treeModel
		 *            The tree model for the available tree.
		 * @param showRoot
		 *            Boolean indicating if the root should or should not be shown.
		 */
		setAvailableTreeModel: function(treeModel, showRoot) {
			if (this._availableData) {
				this._availableData.destroy();
			}
			this._isTree = true;
			domStyle.set(this._availableLabel, "display", "");
			domStyle.set(this._availableContentPane, "top", "17px");
			this._availableStore = treeModel.store;
			this._availableData = new Tree({
				model: treeModel,
				showRoot: showRoot == undefined ? true : showRoot,
				dndController: "ecm.widget.TreeSelector",
				getRowClass: lang.hitch(this, this._getTreeRowClass),
				onLoad: lang.hitch(this, this._treeLoaded),
				autoExpand: true, // loads all the tree nodes - in reset we can hide all the tree nodes that are already in the values list for hideAvailableOnAdd
				openOnClick: true
			});
			domConstruct.place(this._availableData.domNode, this._availableDataContainer, "only");
			this._availableData.startup();

			// Ctrl F1 opens the hover help drop down dialog - Escape closes it
			this.connect(this._availableData.domNode, "onkeypress", lang.hitch(this, function(evt) {
				if (evt.ctrlKey && evt.charOrCode == keys.F1) {
					var treeNode = registry.getEnclosingWidget(evt.target);
					this._showTooltipForTreeNode(registry.getEnclosingWidget(evt.target));
					event.stop(evt);
				}
			}));
			this.connect(this._availableData.domNode, "onmouseover", lang.hitch(this, function(evt) {
				this._showTooltipForTreeNode(registry.getEnclosingWidget(evt.target));
			}));
			this.connect(this._availableData.domNode, "onmouseout", lang.hitch(this, function(evt) {
				Tooltip.hide(evt.target);
			}));
			this.connect(this._availableData, "_onDblClick", lang.hitch(this, function(treeNode, evt) {
				Tooltip.hide(evt.target);
				if (this._editable && this._availableData.dndController._isSelectable(treeNode)) {
					this._addItem(treeNode.item);
					if (this.hideAvailableOnAdd) {
						this._availableData.dndController.selectNone();
					}
				}
			}));
		},

		/**
		 * @private Show the tooltip for the input tree node.
		 */
		_showTooltipForTreeNode: function(treeNode) {
			if (treeNode) {
				var tooltipText = this.tooltipClass.getTreeTooltipText(treeNode.tree.model, treeNode);
				if (tooltipText && tooltipText.length > 0) {
					this._prevTooltipCellNode = treeNode.domNode;
					Tooltip.show(tooltipText, treeNode.domNode);
				}
			}
		},

		/**
		 * When the available tree is loaded, collapse all nodes.
		 */
		_treeLoaded: function() {
			this._collapseAll(this._availableData.rootNode);
		},

		/**
		 * Collapse all nodes under the input node.
		 * 
		 * @param node
		 *            The node to collapse.
		 */
		_collapseAll: function(node) {
			if (node) {
				var children = node.getChildren();
				if (children) {
					for ( var i = 0; i < children.length; i++) {
						this._collapseAll(children[i]);
						this._availableData._collapseNode(children[i]);
					}
				}
			}
		},

		/**
		 * Return the CSS class for the tree node. If there is no value on the item, then set the CSS class to
		 * <code>NotSelectable</code>.
		 * 
		 * @param item
		 *            The item.
		 * @param opened
		 *            If the item is opened.
		 */
		_getTreeRowClass: function(/* dojo.data.Item */item, /* Boolean */opened) {
			return (!item.value) ? "NotSelectable" : "";
		},

		/**
		 * On mouse over the grid, display the tooltip. On mouse out, hide the tooltip.
		 * 
		 * @param grid
		 *            The DataGrid in which to add the <code>onRowMouseOver</code> and <code>OnRowMouseOut</code>
		 *            events.
		 */
		_addGridTooltipConnect: function(grid) {
			if (this.tooltipClass && this.tooltipClass.getGridTooltipText) {
				// Ctrl F1 opens the hover help drop down dialog - Escape closes it
				this.connect(grid.domNode, "onkeypress", lang.hitch(this, function(evt) {
					if (evt.ctrlKey && evt.charOrCode == keys.F1) {
						var node = evt.target;
						while (true) {
							if (!node || domClass.contains(node, "dojoxGridRow")) {
								break;
							}
							node = node.parentNode;
						}
						if (node && node.gridRowIndex != undefined) {
							var item = grid.getItem(node.gridRowIndex);
							var tooltipText = this.tooltipClass.getGridTooltipText(grid, item);
							if (!this._prevTooltipCellNode || this._prevTooltipCellNode != evt.target) {
								try {
									if (evt.target)
										Tooltip.show(tooltipText, evt.target, this.tooltipPosition);
									this._prevTooltipCellNode = evt.cellNode;
								} catch (e) {
									Tooltip.hide(this._prevTooltipCellNode);
								}
							}
							event.stop(evt);
						}
					}
				}));
				this.connect(grid, "onRowMouseOver", lang.hitch(this, function(evt) {
					var item = grid.getItem(evt.rowIndex);
					var tooltipText = this.tooltipClass.getGridTooltipText(grid, item);
					if (!this._prevTooltipCellNode || this._prevTooltipCellNode != evt.cellNode) {
						try {
							if (evt.cellNode)
								Tooltip.show(tooltipText, evt.cellNode, this.tooltipPosition);
							this._prevTooltipCellNode = evt.cellNode;
						} catch (e) {
							Tooltip.hide(this._prevTooltipCellNode);
						}
					}
				}));
				this.connect(grid, "onRowMouseOut", lang.hitch(this, function(evt) {
					this._prevTooltipCellNode = null;
					Tooltip.hide(evt.cellNode);
				}));
			}
		},

		/**
		 * @private
		 */
		_isFixedValue: function(value) {
			// Javascript array object indexOf is not supported in IE8 and earlier. Use the dojo array module wrapper for indexOf.
			return (this._fixedSelectedValues ? (array.indexOf(this._fixedSelectedValues, value) >= 0) : false);
		},

		/**
		 * @private
		 */
		_setFixedValues: function(fixedValues) {

		},


		/**
		 * Boolean that sets the slosh bucket as editable or read only.
		 * 
		 * @param editable
		 *            {Boolean} Set to <code>true</code> to make the slosh bucket editable and <code>false</code> to
		 *            make it read only.
		 */
		setEditable: function(editable) {
			this._editable = editable;
			if (editable) {
				domClass.remove(this.domNode, "readOnly");
			} else {
				domClass.add(this.domNode, "readOnly");
			}
		},

		/**
		 * Filters the available data using the passed in filter structure.
		 * 
		 * @param struct
		 *            The filter structure for the DataGrid.
		 */
		filter: function(struct) {
			this._availableData.selection.clear();
			if (this.hideAvailableOnAdd) {
				struct.displayit = "true";
			}
			this._availableData.queryOptions = {
				ignoreCase: true
			};
			this._availableData.filter(struct);
		},

		/**
		 * Resizes the pane.
		 * 
		 * @param changeSize
		 *            The changed size.
		 */
		resize: function(changeSize) {
			this.inherited(arguments);

			var availableLabelBox = domGeom.getMarginBox(this._availableLabel);
			var availableMarginBox = domGeom.getMarginBox(this._availableDataContainer);
			var height = availableMarginBox.h - availableLabelBox.h;
			if (height <= 0) {
				return;
			}

			if (this._availableData) {
				var h = (this._availableData.isInstanceOf && this._availableData.isInstanceOf(Tree)) ? height - 32 : height;
				domGeom.setMarginBox(this._availableDataBorder, {
					h: h
				});
				this._availableData.resize({
					h: h,
					w: availableMarginBox.w
				});
			}
		},

		/**
		 * Registers a custom add function.
		 * 
		 * @param customAdd
		 *            Custom add function.
		 */
		registerCustomAddFunc: function(customAdd) {
			this.customAdd = customAdd;
		},

		/**
		 * Registers a custom remove function.
		 * 
		 * @param customRemove
		 *            Custom remove function.
		 */
		registerCustomRemoveFunc: function(customRemove) {
			this.customRemove = customRemove;
		}
	});
});
