package com.ibm.ecm.extension.lync;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.ibm.ecm.extension.lync.exception.LyncException;
import com.ibm.json.java.JSON;
import com.ibm.json.java.JSONObject;

public class LyncSession {

	private String appUrl = null;
	private String baseUrl = null;
	private String oAuth;
	private String selfEmail;
	private String lookupEmail = "";
	private String sessionId;

	private String emailId;
	private String callback = null;
	private boolean logined = false;

	public boolean isLogined() {
		return this.logined;
	}
	
	private String jsonResponse = "";
	
	public void setLogined(boolean logined) {
		this.logined = logined;
	}
	
	public String getSessionId() {
		return this.sessionId;
	}

	public LyncSession(String baseUrl, String oAuth)
	throws Exception
	{
		this.baseUrl = baseUrl;
		this.oAuth = oAuth;
		if (!isLogined()) {
			jsonResponse = loginToLync(baseUrl, oAuth);
			if (!jsonResponse.startsWith("{")) {
				throw new LyncException(new Exception("invalid response: " + jsonResponse.substring(0, 30)), -1);
			}
			logined = true;
			setupSession(jsonResponse);
		}
	}
	
	public String getoAuth() {
		return oAuth;
	}

	public void setoAuth(String oAuth) {
		this.oAuth = oAuth;
	}

	public void setAppUrl(String appUrl) {
		this.appUrl = appUrl;
	}

	public String getLookupEmail() {
		return this.lookupEmail;
	}

	public void setLookupEmail(String lookupEmail) {
		this.lookupEmail = lookupEmail;
	}

	public String getCallback() {
		return callback;
	}

	public void setCallback(String callback) {
		this.callback = callback;
	}

	public String getSelfEmail() {
		return selfEmail;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String loginToLync(String appUrl, String oAuth) 
	throws Exception 
	{
 		//if(true) return "{appUrl: \"" + appUrl + "\", oAuth: \"" + oAuth + "\"}";
		this.appUrl = appUrl;
		String url = appUrl;
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
 
		//add reuqest header
		con.setRequestMethod("POST");
		con.setRequestProperty("Authorization", oAuth);
		con.setRequestProperty("Accept", "application/json");
		con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
		String urlParameters = "{\"userAgent\":\"UCWA Samples\",\"endpointId\":\"" + Constants.ENDPOINT_ID + "\",\"culture\":\"en-US\"}";
 
		int responseCode = -1;
		try {
			// Send post request
			con.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(urlParameters);
			wr.flush();
			wr.close();
 
			responseCode = con.getResponseCode();
			/*
			System.out.println("\nSending 'POST' request to URL : " + url);
			System.out.println("Post parameters : " + urlParameters);
			System.out.println("Response Code : " + responseCode);
			*/

			BufferedReader in = new BufferedReader(
					new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			return response.toString();
		}
		catch (IOException ex) {
			logined = false;
			throw new LyncException(ex, responseCode);
		}
 
	}

	private void setupSession(String json) 
	throws Exception
	{
		if (json.indexOf("{\"error\"") >= 0) {
			return;
		}
		JSONObject obj = (JSONObject) JSON.parse(json);
		String iBaseUrl = getChildJsonValue(obj, "_links", "self", "href");
		String sessionId = iBaseUrl.substring(iBaseUrl.lastIndexOf("/") + 1);
		setBaseUrl(this.appUrl, sessionId);
		setToken(oAuth);
		String iSelfEmail = getChildJsonValue(obj, "_embedded", "me", "uri").substring("sip:".length());
		setSelfEmail(iSelfEmail);
		String emailId = extractEmailId(iSelfEmail);
		setEmailId(emailId);
	}
	
	public String getSessionInfo()
	throws Exception
	{
		JSONObject obj = (JSONObject) JSON.parse(getJsonResponse());
		obj.put("baseUrl", getBaseUrl());
		obj.put("email", getSelfEmail());
		obj.put("emailId", getEmailId());
		obj.put("sessionId", getSessionId());
		obj.put("oAuth", oAuth);
		return obj.serialize();
	}

	public String getChildJsonValue(JSONObject json, String key1, String key2, String key3)
	{
		Object val = ((JSONObject) ((JSONObject) ((JSONObject) json.get(key1)).get(key2))).get(key3);
		//Object val = obj.get("_links.self.href");
		return val == null ? "" : (String) val;
	}
	
	public void setBaseUrl(String iBaseUrl, String sessionId)
	{
		this.sessionId = sessionId;
		// ensure the url ends with '/'
		String uniformedUrl = 
			iBaseUrl.endsWith("/") ? 
			iBaseUrl : iBaseUrl + "/";
		baseUrl = 
			iBaseUrl.endsWith(".jsp")? 
			iBaseUrl : uniformedUrl + sessionId;
	}
	
	public String getBaseUrl()
	{
		return baseUrl;
	}
	
	public void setToken(String token)
	{
		oAuth = token;
	}
	
	public String getToken()
	{
		return oAuth;
	}
	
	public void setSelfEmail(String iEmail)
	{
		selfEmail = iEmail;
	}

	/*
	 * email: a Lync email address
	 *        e.g. "amya1234@gotuc.net";
	 * return: email id
	 *        e.g. "1234"
	 */
	private static String extractEmailId(String email)
	{
		//var email = 
		int startIndex = -1, endIndex = -1;
		for(int i = 0; i < email.length(); i++) {
			if(startIndex == -1 && email.charAt(i) >= '0' && email.charAt(i) <= '9') {
			  startIndex = i;
			  break;
			}
		}
		endIndex = email.indexOf("@");
		return email.substring(startIndex, endIndex);
	}
	
	public void setEmailId(String iEmailId)
	{
		emailId = iEmailId;
	}
	
	public String getEmailId()
	{
		return emailId;
	}

	public String getJsonResponse() {
		return jsonResponse;
	}

	public void setJsonResponse(String jsonResponse) {
		this.jsonResponse = jsonResponse;
	}

	public String getPersonInfo(String email) 
	throws Exception 
	{
		return UserInfo.getPersonInfo(email, this);
	}
	
	public static void debug(String message)
	{
		System.out.println(message);
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) 
	throws Exception 
	{
		String oAuth = "Bearer cwt=AAEBHAEFAAAAAAAFFQAAAJETUyiWZo0v_Pup1YMFAACBEO5FCgPWI0dWjidZXCapsQOCArjfgyBanR1bD-w3xUWH7ZG75PEYh8a8e_6gYbZAjLv7iGt3loYI7NsaQHya0AgNEE2tjE-T29Jfmt6q60DTuZo";
		//String appUrl = "https://ocsrp.gotuc.net/ucwa/oauth/v1/applications";
		//String appUrl = "http://ocsrp.gotuc.net/ucwa/oauth/v1/applications";
		String appUrl = "http://www.ibm.com";
		String outString;
		try {
			LyncSession session = new LyncSession(appUrl, oAuth);
			String email = "fernando";
			debug("ready to get Person info");
			outString = UserInfo.getPersonInfo(email, session);
			/*
			System.out.println(session.getSessionInfo());
			String peopleContacts = LyncService.getService("/people/contacts", session);
			System.out.println("contacts: " + peopleContacts);
			*/
		}
		catch (Exception ex) {
			if (ex instanceof LyncException) {
				outString = ((LyncException) ex).getErrorJson();
			}
			else {
				outString = ex.toString();
			}
		}
		System.out.println(outString);
	}

}
