/*
Licensed Materials - Property of IBM

(c) Copyright IBM Corp. 2012 All Rights Reserved.

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.

DISCLAIMER OF WARRANTIES :                                             
                                                                       
Permission is granted to copy and modify this  Sample code, and to           
distribute modified versions provided that both the copyright        
notice, and this permission notice and warranty disclaimer appear
in all copies and modified versions. 

THIS SAMPLE CODE IS LICENSED TO YOU AS-IS. IBM AND ITS SUPPLIERS AND
LICENSORS DISCLAIM ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, IN SUCH SAMPLE
CODE, INCLUDING THE WARRANTY OF NON-INFRINGEMENT AND THE IMPLIED WARRANTIES
OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT WILL
IBM OR ITS LICENSORS OR SUPPLIERS BE LIABLE FOR ANY DAMAGES ARISING OUT OF
THE USE OF OR INABILITY TO USE THE SAMPLE CODE, DISTRIBUTION OF THE SAMPLE
CODE, OR COMBINATION OF THE SAMPLE CODE WITH ANY OTHER CODE. IN NO EVENT
SHALL IBM OR ITS LICENSORS AND SUPPLIERS BE LIABLE FOR ANY LOST REVENUE,
LOST PROFITS OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
OF LIABILITY, EVEN IF IBM OR ITS LICENSORS OR SUPPLIERS HAVE BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGES.                                     
*/

package com.ibm.ecm.extension.profile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.filenet.api.core.Connection;
import com.filenet.api.core.Factory;
import com.filenet.api.security.User;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.serviceability.Logger;
import com.ibm.json.java.JSON;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class LyncLookupService extends PluginService {

	public String getId() {
		return "lyncLookupService";
	}

	public static String baseUrl, uid, action, oAuth;
	
	public static void init(String ibaseUrl, String iuid, String ioAuth) {
		baseUrl = ibaseUrl;
		uid = iuid;
		oAuth = ioAuth;
	}

	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "execute";
		Logger.logEntry(this, methodName, request);
        JSONObject result = new JSONObject();
		
		try {
			String uid = request.getParameter("uid");
			if (uid == null) {//https://ocsrp.gotuc.net/ucwa/oauth/v1/applications/103104929920/me/makeMeAvailable
				uid = "103410213747";
			}

			String sid = request.getParameter("sid");
			if (uid == null) { //saraj828@gotuc.net
				uid = "828";
			}

			String oAuth = request.getParameter("oAuth");
			if (oAuth == null) {
				oAuth = "Bearer cwt=AAEBHAEFAAAAAAAFFQAAAJETUyiWZo0v_Pup1S0OAACBEO5FCgPWI0dWjidZXCapsQOCAlsJgyCAJPPCjwp6ZAQpa46W920PKiYGBmVfeywwQsfwe4UWpIYIRJQXYi-U0AgNEE2tjE-T29Jfmt6q60DTuZo";
			}

			String action = request.getParameter("laction");
			if (action == null) {
				action = "/me/phones";
			}
			
			String baseUrl = request.getParameter("baseUrl");
			if (baseUrl == null) {
				baseUrl = "https://ocsrp.gotuc.net/ucwa/oauth/v1/applications/";
			}
			
			init(baseUrl, uid, oAuth);
			
//			if (action.startsWith("/email/")) {
//				String email = action.substring(7);
//				String personInfo = getPersonInfo(email);
//				out.println(personInfo);
//				return;
//			}

			String json = getService(action);
//			if (json != null && !"".equals(json) && action.endsWith("/note")) {
//				json = getNote(json);
//			}
//			if (json != null && !"".equals(json) && action.endsWith("/supportedMedia")) {
//				json = getMedia(json);
//			}
			/*
			String photo = baseUrl + uid + "/photos/saraj" + sid + "@gotuc.net";
			result.put("shortname", "clou");
			result.put("displayName", "Chad Lou");
			result.put("email",	"chadlou@us.ibm.com");
			result.put("status", "testing");
			result.put("presence", "online");
			result.put("photo", photo);
			*/
			
			result = (JSONObject) JSON.parse(json);

    		result.serialize(response.getWriter());
    	}
    	catch(Exception ex)
    	{
    	    // TODO: proper error logging support
    	    ex.printStackTrace();
    	    
    	    JSONObject errResult = null;
    	        errResult = handleErrorResponse(ex);
    	    
            errResult.serialize(response.getWriter());
			Logger.logError( this, methodName, request, ex);
		}
		
		Logger.logExit(this, methodName, request);
	}

	protected final JSONObject handleErrorResponse(Exception ex)
    {
        JSONObject body = new JSONObject();
        JSONArray errArry = new JSONArray();
        JSONObject err1 = new JSONObject();
        // TODO: define key constants
        // TODO: Using userResponse for adminResponse currently.  Not sure adminResponse
        // is needed currently.
        Throwable cause = ex.getCause();
        String causeMessage = cause == null ? "n/a" : cause.toString();
        err1.put("moreInformation", null);
        err1.put("explanation", causeMessage);
        err1.put("text", ex.getMessage());
        err1.put("messageProductId", "FNRPA");
        errArry.add(err1);
        body.put("errors", errArry);
        return body;
    }

	public static String getService(String action) 
	throws Exception
	{
		StringBuilder sb = null;
		boolean isXframeRestricted = false;

		HttpURLConnection connection = null;
		OutputStreamWriter wr = null;
		BufferedReader rd = null;
		String line = null;

		String url = baseUrl + uid + action;
        URL urlurl = new URL(url);
        HttpURLConnection urlconn = (HttpURLConnection)urlurl.openConnection();
        urlconn.setRequestProperty("Accept-Language","en-us,en;q=0.5");
        urlconn.setRequestProperty("Accept-Charset","ISO-8859-1,utf-8;q=0.7,*;q=0.7");
        urlconn.setRequestProperty("User-Agent","Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16");
		urlconn.setRequestProperty("Authorization", oAuth);

        urlconn.connect();
        //read the result from the server
        try {
        	rd  = new BufferedReader(new InputStreamReader(urlconn.getInputStream()));
        }
        catch (IOException ex) {
        	rd = null;
        }
        sb = new StringBuilder();  
        while (rd != null && (line = rd.readLine()) != null)
        {
            sb.append(line + '\n');
        }
        String json = sb.toString();
        return json;
	}
	
	public static String getNote(String json)
	throws Exception
	{
		//String json = getService("/people/" + email + "/note");
		if (json == null || "".equals(json.trim())) return "";
		try {
			JSONObject obj = (JSONObject) JSON.parse(json);
			Object val = obj.get("message");
			if (val != null) {
				json = (String) val;
			}
	    }
	    catch (Exception ex) {
	    	throw new Exception("invalid json: " + json);
	    }
	    return json;
	}
	
	public static String getPresence(String email)
	throws Exception
	{
		String json = getService("/people/" + email + "/presence");
		if (json == null || "".equals(json.trim())) return "";
        JSONObject obj = (JSONObject) JSON.parse(json);
        Object val = obj.get("availability");
        if (val != null) {
	        json = (String) val;
	    }
	    return json;
	}
	
	public static String getName(String email)
	throws Exception
	{
		String json = getService("/people/" + email);
        JSONObject obj = (JSONObject) JSON.parse(json);
        Object val = obj.get("name");
        if (val != null) {
	        json = (String) val;
	    }
	    return json;
	}
	
	public static String getPersonInfo(String email) 
	throws Exception
	{
		String note = getService("/people/" + email + "/note");
		//if (true) return "invalid note: AAA" + note + "ZZZ with size of " + "".equals(note.trim());
		note = getNote(note);
		String media = "media"; //getService("/people/" + email + "/supportedMedia");
		//media = getMediaAsString(media);
		String location = "Costa Mesa"; //getService("/people/" + email + "/location");
		String photoUrl = baseUrl + uid + "/photos/" + email;
		String presence = getPresence(email);
		String name = getName(email);
		return "{note: '" + note + "', email: {internet: '" + email + "'}, fn: '" + name + "', presence: '" + presence + "', media: '" + media + "', location: '" + location + "', photo: '" + photoUrl + "'}";
	}
	
	// returns the string value of json object
	public static String getMediaAsString(String json)
	throws Exception
	{
		json = getMedia(json);
        JSONObject obj = (JSONObject) JSON.parse(json);
        Object val = obj.get("media");
        if (val != null) {
        	json = (String) val;
        }
        return json;
	}
	
	// returns a json object
	public static String getMedia(String json)
	throws Exception
	{
        JSONObject obj = (JSONObject) JSON.parse(json);
        Object val = obj.get("modalities");
        if (val != null) {
	        JSONArray jsons = (JSONArray) val;
	        json = "";
	        for (int i = 0; i < jsons.size(); i++) {
	        	String jso = (String) jsons.get(i);
	        	if ( i > 0) {
	        		json += "AAA";
	        	}
	        	json += jso.toString();
	        }
	        return "{media: \"" + json + "\"}";
		    //return jsons.serialize();
	    }
	    return "{media: 'NoValue'}";
	}
}
