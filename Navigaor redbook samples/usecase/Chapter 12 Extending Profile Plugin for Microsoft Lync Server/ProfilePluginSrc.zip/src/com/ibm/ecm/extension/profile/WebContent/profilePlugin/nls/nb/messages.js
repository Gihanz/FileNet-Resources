/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(nb) Links",
	"button.send.email": "(nb) Send Email",
	
	"connections.profiles": "(nb) Profiles",
	"connections.communities": "(nb) Communities",
	"connections.blogs": "(nb) Blogs",
	"connections.forums": "(nb) Forums",
	"connections.wikis": "(nb) Wikis",
	"connections.files": "(nb) Files",
	"connections.dogear": "(nb) Dogear",
	"connections.activities": "(nb) Activities",
	
	server_input_label: "(nb) IBM Connections profile service URL:",
	server_input_hover: "(nb) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(nb) IBM Sametime Web API URL:",
	st_input_hover: "(nb) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(nb) Context Root for Proxy Server:",
	proxyURI_hover: "(nb) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(nb) Test",
	test_result_label: "(nb) Test result",
	showDisplayName_input_label: "(nb) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(nb) Decide whether to show the original login name or the display name",
	testResultValid: "(nb) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(nb) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
