package com.ibm.ecm.extension.lync.service;

import com.ibm.ecm.extension.lync.LyncSession;
import com.ibm.json.java.JSON;
import com.ibm.json.java.JSONObject;

public class UserName extends LyncService {

	public static String getName(String email, LyncSession session)
	throws Exception
	{
		String json = getService("/people/" + email, session);
        JSONObject obj = (JSONObject) JSON.parse(json);
        Object val = obj.get("name");
        if (val != null) {
	        json = (String) val;
	    }
	    return json;
	}
	
	
}
