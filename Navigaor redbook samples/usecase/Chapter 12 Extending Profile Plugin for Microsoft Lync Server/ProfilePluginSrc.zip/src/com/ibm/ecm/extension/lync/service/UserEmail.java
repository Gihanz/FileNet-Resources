package com.ibm.ecm.extension.lync.service;

import com.ibm.ecm.extension.lync.Constants;
import com.ibm.ecm.extension.lync.LyncSession;

public class UserEmail {

	private static String[] userMapSource = {"p8admin", "fernando", "amy", "sarah"};
	private static String[] userMapTarget = {"fernandoc", "fernandoc", "amya", "sarahj"};
	
	private static String mapUser(String shortname) 
	{
		for(int i = 0; i < userMapSource.length; i++) {
			if (userMapSource[i].equals(shortname)) {
				return userMapTarget[i];
			}
		}
		return userMapTarget[0];
	}
	
	public static String getLyncEmail(String email, LyncSession session)
	{
		if (email.endsWith(Constants.emailDomain)) return email;
		int idx = email.indexOf("@");
		if (idx > 0) { // remove all existing email domain, such as @uss.com or @emc.ibm.com
		    email = email.substring(0, idx);
		}
		String lyncShortname = mapUser(email);
		String lyncEmail = lyncShortname + session.getEmailId() + Constants.emailDomain;
		return lyncEmail;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
