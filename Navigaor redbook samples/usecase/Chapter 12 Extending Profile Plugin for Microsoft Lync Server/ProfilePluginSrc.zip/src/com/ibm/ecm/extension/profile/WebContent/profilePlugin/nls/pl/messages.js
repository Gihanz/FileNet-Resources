/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(pl) Links",
	"button.send.email": "(pl) Send Email",
	
	"connections.profiles": "(pl) Profiles",
	"connections.communities": "(pl) Communities",
	"connections.blogs": "(pl) Blogs",
	"connections.forums": "(pl) Forums",
	"connections.wikis": "(pl) Wikis",
	"connections.files": "(pl) Files",
	"connections.dogear": "(pl) Dogear",
	"connections.activities": "(pl) Activities",
	
	server_input_label: "(pl) IBM Connections profile service URL:",
	server_input_hover: "(pl) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(pl) IBM Sametime Web API URL:",
	st_input_hover: "(pl) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(pl) Context Root for Proxy Server:",
	proxyURI_hover: "(pl) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(pl) Test",
	test_result_label: "(pl) Test result",
	showDisplayName_input_label: "(pl) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(pl) Decide whether to show the original login name or the display name",
	testResultValid: "(pl) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(pl) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
