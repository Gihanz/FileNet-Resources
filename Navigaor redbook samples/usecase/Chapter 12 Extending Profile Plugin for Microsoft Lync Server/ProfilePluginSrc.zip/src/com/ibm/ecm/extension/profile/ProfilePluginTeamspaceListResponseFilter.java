/*
Licensed Materials - Property of IBM

(c) Copyright IBM Corp. 2012 All Rights Reserved.

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.

DISCLAIMER OF WARRANTIES :                                             
                                                                       
Permission is granted to copy and modify this  Sample code, and to           
distribute modified versions provided that both the copyright        
notice, and this permission notice and warranty disclaimer appear
in all copies and modified versions. 

THIS SAMPLE CODE IS LICENSED TO YOU AS-IS. IBM AND ITS SUPPLIERS AND
LICENSORS DISCLAIM ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, IN SUCH SAMPLE
CODE, INCLUDING THE WARRANTY OF NON-INFRINGEMENT AND THE IMPLIED WARRANTIES
OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT WILL
IBM OR ITS LICENSORS OR SUPPLIERS BE LIABLE FOR ANY DAMAGES ARISING OUT OF
THE USE OF OR INABILITY TO USE THE SAMPLE CODE, DISTRIBUTION OF THE SAMPLE
CODE, OR COMBINATION OF THE SAMPLE CODE WITH ANY OTHER CODE. IN NO EVENT
SHALL IBM OR ITS LICENSORS AND SUPPLIERS BE LIABLE FOR ANY LOST REVENUE,
LOST PROFITS OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
OF LIABILITY, EVEN IF IBM OR ITS LICENSORS OR SUPPLIERS HAVE BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGES.                                     
*/

package com.ibm.ecm.extension.profile;

import javax.servlet.http.HttpServletRequest;

import com.ibm.ecm.extension.PluginResponseFilter;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

/**
 * This filter modifies the search results json to add a custom property formatter.  Custom property formatters can be used to provide an alternate HTML for
 * the property values in the content list.  The custom property formatter for this is in com.ibm.ecm.extension.profile.WebContent.profilePlugin.EmailPropertyFormatter.js   
 */
public class ProfilePluginTeamspaceListResponseFilter extends PluginResponseFilter {

	public String[] getFilteredServices() {
		return new String[] {"/p8/getWorkspaces", "/cm/getWorkspaces"};
	}
	
	public void filter(String serverType, PluginServiceCallbacks callbacks, HttpServletRequest request, JSONObject jsonResponse) throws Exception {
		JSONObject structure = (JSONObject) jsonResponse.get("columns");
		JSONArray cells = (JSONArray) structure.get("cells");
		if (cells.get(0) instanceof JSONArray) {
			cells = (JSONArray) cells.get(0);
		}

		int i = 0;
		for (i = 0; i < cells.size(); i++) {
			JSONObject column = (JSONObject) cells.get(i);
			String columnName = (String) column.get("field");

			if (columnName != null && columnName.equals("lastModifiedUser")) {
				column.put("decorator", "businessHoverCardDecorator");
				column.put("widgetsInCell", true);
				column.put("setCellValue", "businessHoverCardCellValue");
				column.put("width", "8.0em");
			}
		}
		
		JSONArray magazineColumns = (JSONArray) jsonResponse.get("magazineColumns");
		for (i = 0; i < magazineColumns.size(); i++) {
			JSONObject column = (JSONObject) magazineColumns.get(i);
			String columnName = (String) column.get("field");
			
			if (columnName != null && columnName.equals("content")) {
				column.put("decorator", "businessHoverCardTeamspaceMagazineDecorator");
				column.put("widgetsInCell", true);
				column.put("setCellValue", "businessHoverCardTeamspaceMagazineCellValue");
			}
		}
	}
}