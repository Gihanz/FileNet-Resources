define({
	root:

	({
	// NLS_CHARSET=UTF-8
	
	"button.links": "Links",
	"button.send.email": "Send Email",
	
	"connections.profiles": "Profiles",
	"connections.communities": "Communities",
	"connections.blogs": "Blogs",
	"connections.forums": "Forums",
	"connections.wikis": "Wikis",
	"connections.files": "Files",
	"connections.dogear": "Dogear",
	"connections.activities": "Activities",
	
	server_input_label: "IBM Connections profile service URL:",
	server_input_hover: "URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "IBM Sametime web API URL:",
	st_input_hover: "URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "Context root for proxy server:",
	proxyURI_hover: "Context root to the IBM Ajax proxy server. Example: /AjaxProxy",
	test_button_label: "Test",
	test_result_label: "Test result",
	showDisplayName_input_label: "Show display name instead of login name:",
	showDisplayName_input_hover: "Decide whether to show the original login name or the display name",
	testResultValid: "Sametime URI and proxy context root are valid",
	testResultInvalid: "Sametime URI or proxy context root is invalid",
	sametime_polling_label: "Sametime Proxy Server polling:",
	sametime_polling_hover: "Specify how sametime status is displayed",
	invalidHostName: "The hostname in the URL for your browser must be a fully qualified url, for example, host1.icm.ibm.com",
	sametime_option_disabled: "Disabled",
	sametime_option_always: "Display Sametime status automatically",
	sametime_option_clicked: "Display Sametime status after a click option",

	"nop": null
	}),
	"ar": true,
	"cs": true,
	"da": true,
	"de": true,
	"es": true,
	"fi": true,
	"fr": true,
	"he": true,
	"hu": true,
	"it": true,
	"ja": true,
	"ko": true,
	"nb": true,
	"nl": true,
	"no": true,
	"pl": true,
	"pt-br": true,
	"ro": true,
	"ru": true,
	"sk": true,
	"sv": true,
	"tr": true,
	"zh": true,
	"zh-tw": true
});
