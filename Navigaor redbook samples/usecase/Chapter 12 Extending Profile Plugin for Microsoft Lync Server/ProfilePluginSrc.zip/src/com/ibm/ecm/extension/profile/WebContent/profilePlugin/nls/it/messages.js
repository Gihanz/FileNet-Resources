/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(it) Links",
	"button.send.email": "(it) Send Email",
	
	"connections.profiles": "(it) Profiles",
	"connections.communities": "(it) Communities",
	"connections.blogs": "(it) Blogs",
	"connections.forums": "(it) Forums",
	"connections.wikis": "(it) Wikis",
	"connections.files": "(it) Files",
	"connections.dogear": "(it) Dogear",
	"connections.activities": "(it) Activities",
	
	server_input_label: "(it) IBM Connections profile service URL:",
	server_input_hover: "(it) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(it) IBM Sametime Web API URL:",
	st_input_hover: "(it) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(it) Context Root for Proxy Server:",
	proxyURI_hover: "(it) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(it) Test",
	test_result_label: "(it) Test result",
	showDisplayName_input_label: "(it) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(it) Decide whether to show the original login name or the display name",
	testResultValid: "(it) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(it) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
