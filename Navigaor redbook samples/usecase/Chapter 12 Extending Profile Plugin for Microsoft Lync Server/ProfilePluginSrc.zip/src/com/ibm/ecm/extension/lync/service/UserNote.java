package com.ibm.ecm.extension.lync.service;

import com.ibm.ecm.extension.lync.LyncSession;
import com.ibm.json.java.JSON;
import com.ibm.json.java.JSONObject;

public class UserNote extends LyncService {

	public static String getNoteByEmail(String email, LyncSession session)
	throws Exception
	{
		String note = getService("/people/" + email + "/note", session);
		//if (true) return "invalid note: AAA" + note + "ZZZ with size of " + "".equals(note.trim());
		return getNote(note);
	}

	private static String getNote(String json)
	throws Exception
	{
		//String json = getService("/people/" + email + "/note");
		if (json == null || "".equals(json.trim())) return "";
		try {
			JSONObject obj = (JSONObject) JSON.parse(json);
			Object val = obj.get("message");
			if (val != null) {
				json = (String) val;
			}
	    }
	    catch (Exception ex) {
	    	throw new Exception("invalid json: " + json);
	    }
	    return json;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
