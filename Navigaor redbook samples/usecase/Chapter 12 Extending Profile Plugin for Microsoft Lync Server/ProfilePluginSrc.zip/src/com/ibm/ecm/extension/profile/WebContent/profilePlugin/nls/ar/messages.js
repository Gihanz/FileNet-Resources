/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(ar) Links",
	"button.send.email": "(ar) Send Email",
	
	"connections.profiles": "(ar) Profiles",
	"connections.communities": "(ar) Communities",
	"connections.blogs": "(ar) Blogs",
	"connections.forums": "(ar) Forums",
	"connections.wikis": "(ar) Wikis",
	"connections.files": "(ar) Files",
	"connections.dogear": "(ar) Dogear",
	"connections.activities": "(ar) Activities",
	
	server_input_label: "(ar) IBM Connections profile service URL:",
	server_input_hover: "(ar) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(ar) IBM Sametime Web API URL:",
	st_input_hover: "(ar) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(ar) Context Root for Proxy Server:",
	proxyURI_hover: "(ar) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(ar) Test",
	test_result_label: "(ar) Test result",
	showDisplayName_input_label: "(ar) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(ar) Decide whether to show the original login name or the display name",
	testResultValid: "(ar) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(ar) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
