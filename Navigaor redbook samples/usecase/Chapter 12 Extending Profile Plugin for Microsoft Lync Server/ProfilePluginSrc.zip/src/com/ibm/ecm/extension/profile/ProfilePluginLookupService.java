/*
Licensed Materials - Property of IBM

(c) Copyright IBM Corp. 2012 All Rights Reserved.

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.

DISCLAIMER OF WARRANTIES :                                             
                                                                       
Permission is granted to copy and modify this  Sample code, and to           
distribute modified versions provided that both the copyright        
notice, and this permission notice and warranty disclaimer appear
in all copies and modified versions. 

THIS SAMPLE CODE IS LICENSED TO YOU AS-IS. IBM AND ITS SUPPLIERS AND
LICENSORS DISCLAIM ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, IN SUCH SAMPLE
CODE, INCLUDING THE WARRANTY OF NON-INFRINGEMENT AND THE IMPLIED WARRANTIES
OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT WILL
IBM OR ITS LICENSORS OR SUPPLIERS BE LIABLE FOR ANY DAMAGES ARISING OUT OF
THE USE OF OR INABILITY TO USE THE SAMPLE CODE, DISTRIBUTION OF THE SAMPLE
CODE, OR COMBINATION OF THE SAMPLE CODE WITH ANY OTHER CODE. IN NO EVENT
SHALL IBM OR ITS LICENSORS AND SUPPLIERS BE LIABLE FOR ANY LOST REVENUE,
LOST PROFITS OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
OF LIABILITY, EVEN IF IBM OR ITS LICENSORS OR SUPPLIERS HAVE BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGES.                                     
*/

package com.ibm.ecm.extension.profile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.filenet.api.core.Connection;
import com.filenet.api.core.Factory;
import com.filenet.api.security.User;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.serviceability.Logger;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class ProfilePluginLookupService extends PluginService {

	public String getId() {
		return "profilePluginLookupService";
	}

	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "execute";
		Logger.logEntry(this, methodName, request);
        JSONObject result = new JSONObject();
		
		try {
			String repositoryId = request.getParameter("repositoryId");
			if(repositoryId == null) {
				repositoryId = "ECM";
			}
			Connection conn = callbacks.getP8Connection(repositoryId);
			User user = conn == null ? null : Factory.User.fetchCurrent(conn, null);
			
			String shortName = request.getParameter("shortname");
			user = (conn == null ? null : Factory.User.fetchInstance(conn, shortName, null));
			String message = "repo id: " + repositoryId + " connection is: " + conn + "\nuser: " + user.get_DisplayName() + " email: " + user.get_Email();
			message += "\n" + shortName + " is " + user.get_DisplayName() + " email: " + user.get_Email();
			Logger.logDebug( this, methodName, request, message);
			String email = user.get_Email();
			String displayName = user.get_DisplayName();
			// fetch shortName again due to cases where passed in short name is a display name
			shortName = user.get_ShortName();
			result.put("shortname", shortName);
			result.put("displayName", displayName);
			result.put("email",	email);
			result.put("repositoryId", repositoryId);

    		result.serialize(response.getWriter());
    	}
    	catch(Exception ex)
    	{
    	    // TODO: proper error logging support
    	    ex.printStackTrace();
    	    
    	    JSONObject errResult = null;
    	        errResult = handleErrorResponse(ex);
    	    
            errResult.serialize(response.getWriter());
			Logger.logError( this, methodName, request, ex);
		}
		
		Logger.logExit(this, methodName, request);
	}

	protected final JSONObject handleErrorResponse(Exception ex)
    {
        JSONObject body = new JSONObject();
        JSONArray errArry = new JSONArray();
        JSONObject err1 = new JSONObject();
        // TODO: define key constants
        // TODO: Using userResponse for adminResponse currently.  Not sure adminResponse
        // is needed currently.
        Throwable cause = ex.getCause();
        String causeMessage = cause == null ? "n/a" : cause.toString();
        err1.put("moreInformation", null);
        err1.put("explanation", causeMessage);
        err1.put("text", ex.getMessage());
        err1.put("messageProductId", "FNRPA");
        errArry.add(err1);
        body.put("errors", errArry);
        return body;
    }
}
