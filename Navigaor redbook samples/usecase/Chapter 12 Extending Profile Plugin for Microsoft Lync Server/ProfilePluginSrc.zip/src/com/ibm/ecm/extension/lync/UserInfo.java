package com.ibm.ecm.extension.lync;

import com.ibm.ecm.extension.lync.service.UserEmail;
import com.ibm.ecm.extension.lync.service.UserName;
import com.ibm.ecm.extension.lync.service.UserNote;
import com.ibm.ecm.extension.lync.service.UserPresence;

public class UserInfo {
	public static String getPersonInfo(String email, LyncSession session) 
	throws Exception
	{
		String lyncEmail = UserEmail.getLyncEmail(email, session);
		String note = UserNote.getNoteByEmail(lyncEmail, session);
		String media = "media"; //getService("/people/" + lyncEmail + "/supportedMedia");
		//media = getMediaAsString(media);
		String location = "Costa Mesa"; //getService("/people/" + lyncEmail + "/location");
		String photoUrl = session.getBaseUrl() + "/photos/" + lyncEmail;
		String presence = UserPresence.getPresence(lyncEmail, session);
		String name = UserName.getName(lyncEmail, session);
		//return "{\"note\": \"" + note + "\", \"email\": {\"internet\": \"" + lyncEmail + "\"}, \"fn\": \"" + name + "\", \"presence\": \"" + presence + "\", \"media\": \"" + media + "\", \"location\": \"" + location + "\", \"photo\": \"" + photoUrl + "\"}";
		String outString = 
"{" +
"    \"queryTerms\": \"p8admin\"," +
"    \"email\": {" +
"        \"internet\": \"" + lyncEmail + "\"" +
"    }," +
"    \"status\": \"" + note + "\"," +
"    \"org\": \"" + note + "\"," +
"    \"fn\": \"{username}\"," +
"    \"title\": \"" + presence + "\"," +
"    \"tel\": {\"work\": \"{phone}\"}," +
"    \"presence\": \"" + presence + "\"," +
"    \"media\": \"media\"," +
"    \"adr\": \"" + location + "\"," +
"    \"photo0\": \"" + photoUrl + "\"," +
"    \"photo\": \"/navigator/plugin/ProfilePlugin/getResource/profilePlugin/photos/{userimg}.png\"" +
"}";
		String username;
		String userimg;
		String phone;
		if (email.startsWith("sarah")) {
			username = "Sarah Jones";
			userimg = "sarahs";
			phone = "714-555-1234";
		}
		else if (email.startsWith("fernando") || email.startsWith("tester")) {
			username = "Fernando Caro";
			userimg = "fernandos";
			phone = "212-666-1234";
		}
		else if (email.startsWith("amy")) {
			username = "Amy Alberts";
			userimg = "amys";
			phone = "310-777-1234";
		}
		else {
			// catch all, default
			username = "P8 Administrator";
			userimg = "p8admins";
			phone = "714-222-1234";
		}
		outString = outString.replace("p8admin", email);
		outString = outString.replace("{username}", username);
		outString = outString.replace("{userimg}", userimg);
		outString = outString.replace("{phone}", phone);
		outString = outString.replaceAll("/", "\\\\/");
		String callback = session.getCallback();
		if (callback != null) {
			outString = callback + "(" + outString + ");";
		}
		return outString;
	}

}
