/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(da) Links",
	"button.send.email": "(da) Send Email",
	
	"connections.profiles": "(da) Profiles",
	"connections.communities": "(da) Communities",
	"connections.blogs": "(da) Blogs",
	"connections.forums": "(da) Forums",
	"connections.wikis": "(da) Wikis",
	"connections.files": "(da) Files",
	"connections.dogear": "(da) Dogear",
	"connections.activities": "(da) Activities",
	
	server_input_label: "(da) IBM Connections profile service URL:",
	server_input_hover: "(da) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(da) IBM Sametime Web API URL:",
	st_input_hover: "(da) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(da) Context Root for Proxy Server:",
	proxyURI_hover: "(da) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(da) Test",
	test_result_label: "(da) Test result",
	showDisplayName_input_label: "(da) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(da) Decide whether to show the original login name or the display name",
	testResultValid: "(da) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(da) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
