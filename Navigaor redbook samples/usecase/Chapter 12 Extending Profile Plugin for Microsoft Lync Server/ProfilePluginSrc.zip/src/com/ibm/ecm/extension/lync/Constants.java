package com.ibm.ecm.extension.lync;

public class Constants {
	public static String emailDomain = "@gotuc.net";
	public static final String ENDPOINT_ID = "78f0ae6e-140f-427e-8dbf-cb2c40a4ec20";
}
