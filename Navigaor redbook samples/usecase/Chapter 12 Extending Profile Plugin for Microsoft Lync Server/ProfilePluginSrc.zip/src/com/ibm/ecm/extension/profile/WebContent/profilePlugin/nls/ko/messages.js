/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(ko) Links",
	"button.send.email": "(ko) Send Email",
	
	"connections.profiles": "(ko) Profiles",
	"connections.communities": "(ko) Communities",
	"connections.blogs": "(ko) Blogs",
	"connections.forums": "(ko) Forums",
	"connections.wikis": "(ko) Wikis",
	"connections.files": "(ko) Files",
	"connections.dogear": "(ko) Dogear",
	"connections.activities": "(ko) Activities",
	
	server_input_label: "(ko) IBM Connections profile service URL:",
	server_input_hover: "(ko) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(ko) IBM Sametime Web API URL:",
	st_input_hover: "(ko) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(ko) Context Root for Proxy Server:",
	proxyURI_hover: "(ko) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(ko) Test",
	test_result_label: "(ko) Test result",
	showDisplayName_input_label: "(ko) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(ko) Decide whether to show the original login name or the display name",
	testResultValid: "(ko) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(ko) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
