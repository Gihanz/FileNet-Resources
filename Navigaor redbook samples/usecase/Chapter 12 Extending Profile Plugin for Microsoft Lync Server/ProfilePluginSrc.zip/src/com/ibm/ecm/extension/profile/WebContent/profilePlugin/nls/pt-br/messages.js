/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(pt-br) Links",
	"button.send.email": "(pt-br) Send Email",
	
	"connections.profiles": "(pt-br) Profiles",
	"connections.communities": "(pt-br) Communities",
	"connections.blogs": "(pt-br) Blogs",
	"connections.forums": "(pt-br) Forums",
	"connections.wikis": "(pt-br) Wikis",
	"connections.files": "(pt-br) Files",
	"connections.dogear": "(pt-br) Dogear",
	"connections.activities": "(pt-br) Activities",
	
	server_input_label: "(pt-br) IBM Connections profile service URL:",
	server_input_hover: "(pt-br) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(pt-br) IBM Sametime Web API URL:",
	st_input_hover: "(pt-br) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(pt-br) Context Root for Proxy Server:",
	proxyURI_hover: "(pt-br) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(pt-br) Test",
	test_result_label: "(pt-br) Test result",
	showDisplayName_input_label: "(pt-br) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(pt-br) Decide whether to show the original login name or the display name",
	testResultValid: "(pt-br) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(pt-br) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
