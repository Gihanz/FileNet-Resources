/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(zh-tw) Links",
	"button.send.email": "(zh-tw) Send Email",
	
	"connections.profiles": "(zh-tw) Profiles",
	"connections.communities": "(zh-tw) Communities",
	"connections.blogs": "(zh-tw) Blogs",
	"connections.forums": "(zh-tw) Forums",
	"connections.wikis": "(zh-tw) Wikis",
	"connections.files": "(zh-tw) Files",
	"connections.dogear": "(zh-tw) Dogear",
	"connections.activities": "(zh-tw) Activities",
	
	server_input_label: "(zh-tw) IBM Connections profile service URL:",
	server_input_hover: "(zh-tw) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(zh-tw) IBM Sametime Web API URL:",
	st_input_hover: "(zh-tw) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(zh-tw) Context Root for Proxy Server:",
	proxyURI_hover: "(zh-tw) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(zh-tw) Test",
	test_result_label: "(zh-tw) Test result",
	showDisplayName_input_label: "(zh-tw) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(zh-tw) Decide whether to show the original login name or the display name",
	testResultValid: "(zh-tw) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(zh-tw) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
