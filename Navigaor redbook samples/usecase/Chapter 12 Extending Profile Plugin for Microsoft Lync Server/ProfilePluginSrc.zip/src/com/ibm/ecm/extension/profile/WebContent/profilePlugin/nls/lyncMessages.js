define({
	root:

	({
	// NLS_CHARSET=UTF-8
	
	lync_server_input_label: "Micorsoft Lync service URL:",
	lync_server_input_hover: "URL to the Microsoft Lync server. Example: https://ocsrp.gotuc.net/ucwa/oauth/v1/applications/",
	oAuth_label: "oAuth token from Lync service:",
	oAuth_hover: "oAuth token obtained from Lync service, such as after logging in to Lync sandbox",

	"nop": null
	}),
	"ar": true,
	"cs": true,
	"da": true,
	"de": true,
	"es": true,
	"fi": true,
	"fr": true,
	"he": true,
	"hu": true,
	"it": true,
	"ja": true,
	"ko": true,
	"nb": true,
	"nl": true,
	"no": true,
	"pl": true,
	"pt-br": true,
	"ro": true,
	"ru": true,
	"sk": true,
	"sv": true,
	"tr": true,
	"zh": true,
	"zh-tw": true
});
