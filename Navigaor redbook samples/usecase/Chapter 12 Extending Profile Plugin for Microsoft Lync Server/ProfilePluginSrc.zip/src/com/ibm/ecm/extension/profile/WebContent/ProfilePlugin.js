/*
 * Licensed Materials - Property of IBM (c) Copyright IBM Corp. 2012 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 * 
 * DISCLAIMER OF WARRANTIES :
 * 
 * Permission is granted to copy and modify this Sample code, and to distribute modified versions provided that both the
 * copyright notice, and this permission notice and warranty disclaimer appear in all copies and modified versions.
 * 
 * THIS SAMPLE CODE IS LICENSED TO YOU AS-IS. IBM AND ITS SUPPLIERS AND LICENSORS DISCLAIM ALL WARRANTIES, EITHER
 * EXPRESS OR IMPLIED, IN SUCH SAMPLE CODE, INCLUDING THE WARRANTY OF NON-INFRINGEMENT AND THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL IBM OR ITS LICENSORS OR SUPPLIERS BE LIABLE FOR
 * ANY DAMAGES ARISING OUT OF THE USE OF OR INABILITY TO USE THE SAMPLE CODE, DISTRIBUTION OF THE SAMPLE CODE, OR
 * COMBINATION OF THE SAMPLE CODE WITH ANY OTHER CODE. IN NO EVENT SHALL IBM OR ITS LICENSORS AND SUPPLIERS BE LIABLE
 * FOR ANY LOST REVENUE, LOST PROFITS OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE
 * DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, EVEN IF IBM OR ITS LICENSORS OR SUPPLIERS HAVE
 * BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 */

require(["dojo/_base/lang",
         "dojo/_base/connect",
         "dojo/_base/array",
         "dojo/dom-construct",
         "dojo/_base/sniff",
         "dojo/dom-style",
         "profilePlugin/PersonCard",
         "profilePlugin/PersonCardDecorator",
         "profilePlugin/SametimeAwareness",
         "ecm/model/Desktop",
         "ecm/model/Request",
		 "ecm/widget/TeamList"], 
function(
	lang, 
	connect,
	dojo_array,
	domConstruct, 
	has,
	domStyle,
	PersonCard, 
	PersonCardDecorator, 
	SametimeAwareness, 
	Desktop, 
	Request, 
	TeamList) {
	if (!window.profilePlugin || !window.profilePlugin.configuration) { 
		lang.setObject("profilePlugin.configuration", "");
	}
	if (!profilePlugin.userHash) {
		lang.setObject("profilePlugin.userHash", {});
	}

	profilePlugin.getEmail = function (shortName) {
		var userObject = profilePlugin.userHash[shortName]; 
		return userObject ? userObject.email : null; 
	};
	
	profilePlugin.getDisplayNameFromCache = function (shortName) {
		var userObject = profilePlugin.userHash[shortName]; 
		return userObject ? userObject.displayName : shortName;
	};
	
	profilePlugin.getNameToDisplay = function (shortName, displayName) {
		if (!displayName) {
			displayName = profilePlugin.getDisplayNameFromCache(shortName);
		}
		if (!displayName) return shortName;
		if (!shortName) return displayName;
		if (shortName === displayName) return displayName;
		return profilePlugin.configuration.showDisplayName ? displayName : shortName; 
	};
	
	profilePlugin._fieldsForSametime = 
		[
		 "modifiedBy",
		 "createdBy",
		 "LastModifier",
		 "Creator",
		 "cmis:lastModifiedBy",
		 "cmis:createdBy"
		];

	profilePlugin.isUserNameField = function(columnName) {
		if (!columnName)
			return false;
		var index = dojo_array.indexOf(profilePlugin._fieldsForSametime, columnName);
		return index >= 0;
	};

	profilePlugin.processNode = function(targetNode, shortName, userDisplayName, bAppendToExisting) {
		if (!bAppendToExisting) {
			targetNode.innerHTML = "";
		}
		domConstruct.create("span", 
				{
					userId: shortName, 
					"class": "awareness", 
					innerHTML: userDisplayName
				}, targetNode);
	};
	
	profilePlugin.getRepositoryId = function() {
		return Desktop.getDefaultRepository().id;
	};
	
	profilePlugin.getRepository = function() {
		return Desktop.getDefaultRepository();
	};
	
	profilePlugin.showDisplayName = function(shortName, targetNode, repository, callback) {
		if (!callback) {
			callback = profilePlugin.processNode;
		}
		if (lang.isFunction(repository)) {
			// to accommodate existing ICM calls with callback only and without repository
			callback = repository;
			repository = null;
		}
		if (profilePlugin.configuration && !profilePlugin.configuration.showDisplayName) {
			// if 'show Display name' is not checked, just show short name
    		callback(targetNode, shortName, shortName);
			return;
		}
		if (!repository) { 
			// when both repository and callback are empty, or repository was a callback function
			repository = Desktop.getDefaultRepository();
		}
		var userObj = this.userHash[shortName];
		var userDisplayName;
        if (userObj) {
        	userDisplayName = userObj.displayName;
       		callback(targetNode, shortName, userDisplayName);
        } else {  
        	if (repository.type == "p8") {
	        	Request.invokePluginService("ProfilePlugin", "profilePluginLookupService", {
					requestParams: {
						repositoryId: repository.id, 
						shortname: shortName
					},
					requestCompleteCallback: lang.hitch(this, function(response) { // success
						userObj = profilePlugin._lookupComplete(shortName, response);
			        	userDisplayName = userObj.displayName;
			        	callback(targetNode, shortName, userDisplayName);
	                }),
	                requestFailedCallback : lang.hitch(this,function(response) {   
	                	profilePlugin._lookupFailed(response);
	                	callback(targetNode, shortName, shortName);
	                }),
	                backgroundRequest: true
	            });
        	} else {
        		callback(targetNode, shortName, shortName);
        	}
        }
	};
	
	connect.connect(ecm.model.desktop, "onLogin", function() {
		if (Desktop.id == "admin" || Desktop.repositories.length == 0) {
			// do nothing in admin desktop
			return;
		}
		Request.invokePluginService("ProfilePlugin", "profilePluginService", {
			requestCompleteCallback: function(response) { // success
				if (response) {
					lang.setObject("profilePlugin.configuration", response);
					profilePlugin.initSametime();
				}
			},
			requestFailedCallback : dojo.hitch(this,function(response) {   
				console.log("initial service return: " + response);
			}),
			backgroundRequest: true
		});
	});
	
	profilePlugin.isSametimeAvailable = function() {
		if (!profilePlugin.Sametime || !profilePlugin.configuration) return false;
		if (profilePlugin.configuration.sametimePolling == profilePlugin.Sametime.SAMETIME_DISABLED) {
			return false;
		}
		return true;
	};
	
	profilePlugin.createLiveName = function(shortName, targetNode, repository) {
		if (!profilePlugin.Sametime) profilePlugin.initSametime();
		if (profilePlugin.Sametime && profilePlugin.configuration.profile_server) {
			profilePlugin.createHoverCard(null, shortName, targetNode, repository);
		} else if (profilePlugin.isSametimeAvailable()) {
			profilePlugin.Sametime.createLiveName(shortName, targetNode, repository);
		} else if (profilePlugin.configuration && profilePlugin.configuration.showDisplayName){// fall back to showing display name
			profilePlugin.showDisplayName(shortName, targetNode, repository);
		} else {
			// simply show short name
			targetNode.innerHTML = shortName;
		}
	};
	
	profilePlugin.loginOk = function(response) {
		console.dir(["Sametime login success", response]);
	};
	
	profilePlugin.loginFailed = function(reason, error) {
		console.error("Sametime login failed: " + reason + " with: " + error);
	};
	
	profilePlugin.initSametime = function() {
		if (profilePlugin.configuration.sametimePolling === SametimeAwareness.SAMETIME_DISABLED) {
			return;
		}
		var currentUser = Desktop.userId;
		if (profilePlugin.Sametime && profilePlugin.configuration.sametime) {
			console.log("sametime already instantiated, login again as " + currentUser);
			profilePlugin.Sametime.loginByShortname(currentUser);
			return;
		}
		if (profilePlugin.configuration.sametime && profilePlugin.configuration.sametime.length > 0 && !window["sametime_loadAwareness"]) {
			console.log("instantiating SametimeAwareness() as " + currentUser);

			var proxyContextRoot = profilePlugin.configuration.proxyContextRoot; 
			if(!proxyContextRoot) proxyContextRoot = "/AjaxProxy";
			var tunnelHtmlUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
			tunnelHtmlUrl += "plugin/ProfilePlugin/getResource/profilePlugin/tunnel.html";

			var sametimeConfig = {
				"STProxyURL": profilePlugin.configuration.sametime, 
				"proxyContextRoot": proxyContextRoot,
				"tunnelHtmlUrl": tunnelHtmlUrl,
				"currentUser": currentUser,
				"displayMode": profilePlugin.configuration.sametimePolling
			};
			profilePlugin.Sametime = new SametimeAwareness(sametimeConfig);
		} else {
			console.log("sametime url not specified in Profile plugin configuration"); 
		}
	};
	
	_createPersonCardErrorEntry = function(teamEntry, teamList) {
		var mainDiv = domConstruct.create("div", {
			"class": "idxPersonCard",
			role: "Member"
		}, teamList.teamArea);
		
		var div = domConstruct.create("div", {
			'class': 'idxPersonCardContainer',
			tabindex: 0
		}, mainDiv);
		
		if (teamEntry.isInstanceOf && teamEntry.isInstanceOf(ecm.model.User)) {
			domConstruct.create("img", {
				"class": "idxPersonCardPhoto",
				src: Desktop.getServicesUrl() + "/ecm/widget/resources/images/NoPhotoGroup64.png"
			}, div);
		} else {
			domConstruct.create("img", {
				"class": "idxPersonCardPhoto",
				src: Desktop.getServicesUrl() + "/ecm/widget/resources/images/NoPhotoPerson64.png"
			}, div);
		}
		
		var name = teamEntry.name;
		var displayName = teamEntry.displayName;
		if (!displayName || displayName.length == 0)
			displayName = name;
		domConstruct.create("div", {
			"class": "idxPersonCardFn",
			innerHTML: displayName
		}, div);

		domConstruct.create("div", {
			"class": "idxPersonCardRole",
			innerHTML: teamList.getRoleNames(teamEntry)
		}, div);
	};
	
	// Override teamspace user list create, so that it includes Sametime and Profile business cards
	TeamList.prototype._createTeamList = function() {
		this._team.sort(function(a, b) {
			return a.name.toUpperCase().localeCompare(b.name.toUpperCase());
		});
		if (!(has("ie") < 9)) {
			domStyle.set(this.domNode, "overflow-y", "auto");
		}
		
		// Add users and/or groups to the list
		dojo_array.forEach(this._team, lang.hitch(this, function(teamEntry) {
			if (teamEntry.isInstanceOf(ecm.model.User)) {
				if (!profilePlugin.configuration.profile_server && profilePlugin.configuration.sametime) {
					var div = domConstruct.create("div", {
						'class': 'entryContainer'
					}, this.teamArea);

					if (teamEntry.isInstanceOf && teamEntry.isInstanceOf(ecm.model.User)) {
						domConstruct.create("div", {
							'class': 'entryUser'
						}, div);
					} else {
						domConstruct.create("div", {
							'class': 'entryGroup'
						}, div);
					}

					var div2 = domConstruct.create("div", {
						'class': 'entryInfo'
					}, div);
					var divName = domConstruct.create("div", {
						'class': 'entryName'
					}, div2);

					var name = teamEntry.name;
					var displayName = teamEntry.displayName;
					if (!displayName || displayName.length == 0)
						displayName = name;

					attachNode = domConstruct.create("a", {userId: name, "class": "awareness", innerHTML: "&nbsp;"}, divName);
					profilePlugin.Sametime.createLiveName(name, attachNode, this.teamspace.repository);

					var divRoles = domConstruct.create("div", {
						'class': 'entryRoles',
						innerHTML: this.getRoleNames(teamEntry)
					}, div2);
				} else if (profilePlugin.configuration.profile_server) {
					var query = {
						email: teamEntry.name
					};
					var roleNames = this.getRoleNames(teamEntry);
					
					var specList = [ "photo", "fn", "role", "sametime.awareness" ];
					var pCard = new PersonCard({
						repository: this.teamspace.repository,
						query: query,
						url: profilePlugin.configuration.profile_server,
						jsonp: "callback",
						spec: specList,
						placeHolder: teamEntry.name,
						role: roleNames,
						valueCallback: lang.hitch(this, function(value) {
							if (value && value.email) {
								this.teamArea.appendChild(pCard.domNode);
							} else {
								_createPersonCardErrorEntry(teamEntry, this);
							}
						}),
						errorCallback: lang.hitch(this, function(error) {
							_createPersonCardErrorEntry(teamEntry, this);
						})
					});
				} else { // default: show shortname
					this._createEntry(teamEntry);
				}
			} else {
				this._createEntry(teamEntry);
			}
		}));
	}
});