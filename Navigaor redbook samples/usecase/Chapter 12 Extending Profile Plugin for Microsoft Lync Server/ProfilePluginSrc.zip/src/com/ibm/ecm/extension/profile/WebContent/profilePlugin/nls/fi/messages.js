/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(fi) Links",
	"button.send.email": "(fi) Send Email",
	
	"connections.profiles": "(fi) Profiles",
	"connections.communities": "(fi) Communities",
	"connections.blogs": "(fi) Blogs",
	"connections.forums": "(fi) Forums",
	"connections.wikis": "(fi) Wikis",
	"connections.files": "(fi) Files",
	"connections.dogear": "(fi) Dogear",
	"connections.activities": "(fi) Activities",
	
	server_input_label: "(fi) IBM Connections profile service URL:",
	server_input_hover: "(fi) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(fi) IBM Sametime Web API URL:",
	st_input_hover: "(fi) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(fi) Context Root for Proxy Server:",
	proxyURI_hover: "(fi) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(fi) Test",
	test_result_label: "(fi) Test result",
	showDisplayName_input_label: "(fi) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(fi) Decide whether to show the original login name or the display name",
	testResultValid: "(fi) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(fi) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
