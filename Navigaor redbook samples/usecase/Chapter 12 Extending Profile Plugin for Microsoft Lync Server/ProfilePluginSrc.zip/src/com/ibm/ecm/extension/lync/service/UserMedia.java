package com.ibm.ecm.extension.lync.service;

import com.ibm.json.java.JSON;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class UserMedia extends LyncService {

	// returns the string value of json object
	public static String getMediaAsString(String json)
	throws Exception
	{
		json = getMedia(json);
        JSONObject obj = (JSONObject) JSON.parse(json);
        Object val = obj.get("media");
        if (val != null) {
        	json = (String) val;
        }
        return json;
	}
	
	// returns a json object
	public static String getMedia(String json)
	throws Exception
	{
        JSONObject obj = (JSONObject) JSON.parse(json);
        Object val = obj.get("modalities");
        if (val != null) {
	        JSONArray jsons = (JSONArray) val;
	        json = "";
	        for (int i = 0; i < jsons.size(); i++) {
	        	String jso = (String) jsons.get(i);
	        	if ( i > 0) {
	        		json += "AAA";
	        	}
	        	json += jso.toString();
	        }
	        return "{media: \"" + json + "\"}";
		    //return jsons.serialize();
	    }
	    return "{media: 'NoValue'}";
	}
}
