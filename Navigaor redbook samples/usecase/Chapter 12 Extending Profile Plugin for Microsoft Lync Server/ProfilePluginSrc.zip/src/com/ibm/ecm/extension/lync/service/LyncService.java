package com.ibm.ecm.extension.lync.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import com.ibm.ecm.extension.lync.LyncSession;
import com.ibm.ecm.extension.lync.exception.LyncException;

public class LyncService {

	public static String getService(String action, LyncSession session) 
	throws Exception
	{
		StringBuilder sb = null;
		boolean isXframeRestricted = false;

		HttpURLConnection connection = null;
		OutputStreamWriter wr = null;
		BufferedReader rd = null;
		String line = null;

		String baseUrl = session.getBaseUrl();
		String url = baseUrl + action;
		if (baseUrl.endsWith(".jsp")) {
			url = baseUrl + "?action=" + action + "&email=" + session.getLookupEmail();
		}
        URL urlurl = new URL(url);
        HttpURLConnection urlconn = (HttpURLConnection)urlurl.openConnection();
        urlconn.setRequestProperty("Accept-Language","en-us,en;q=0.5");
        urlconn.setRequestProperty("Accept-Charset","ISO-8859-1,utf-8;q=0.7,*;q=0.7");
        urlconn.setRequestProperty("User-Agent","Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16");
		urlconn.setRequestProperty("Authorization", session.getoAuth());

        urlconn.connect();
        int responseCode = urlconn.getResponseCode();
        if (responseCode >= 300) { // unsuccessful
        	 throw new LyncException(new Exception("Server error"), responseCode);
        }
        //read the result from the server
        try {
        	rd  = new BufferedReader(new InputStreamReader(urlconn.getInputStream()));
        }
        catch (IOException ex) {
        	rd = null;
        }
        sb = new StringBuilder();  
        while (rd != null && (line = rd.readLine()) != null)
        {
            sb.append(line + '\n');
        }
        String json = sb.toString();
        return json;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
