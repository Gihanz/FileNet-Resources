package com.ibm.ecm.extension.profile;

import java.util.Locale;

import com.ibm.ecm.extension.PluginService;

public class LyncPlugin extends ProfilePlugin {

	public String getName(Locale locale) {
		return "ICN for Microsoft Lync Server Plug-in";
	}

	public String getConfigurationDijitClass() {
		return "profilePlugin.LyncConfigurationPane";
	}
    
    public PluginService[] getServices() {
        return new PluginService[] {
        	new ProfilePluginService(),
        	new LyncStatusService(),
        	new ProfilePluginLookupService()
        };
    }

    public String getScript() {
        return "LyncPlugin.js";
    }
    
    public String getVersion() {
        return "2.0.2.1";
    }
}
