/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(hu) Links",
	"button.send.email": "(hu) Send Email",
	
	"connections.profiles": "(hu) Profiles",
	"connections.communities": "(hu) Communities",
	"connections.blogs": "(hu) Blogs",
	"connections.forums": "(hu) Forums",
	"connections.wikis": "(hu) Wikis",
	"connections.files": "(hu) Files",
	"connections.dogear": "(hu) Dogear",
	"connections.activities": "(hu) Activities",
	
	server_input_label: "(hu) IBM Connections profile service URL:",
	server_input_hover: "(hu) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(hu) IBM Sametime Web API URL:",
	st_input_hover: "(hu) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(hu) Context Root for Proxy Server:",
	proxyURI_hover: "(hu) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(hu) Test",
	test_result_label: "(hu) Test result",
	showDisplayName_input_label: "(hu) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(hu) Decide whether to show the original login name or the display name",
	testResultValid: "(hu) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(hu) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
