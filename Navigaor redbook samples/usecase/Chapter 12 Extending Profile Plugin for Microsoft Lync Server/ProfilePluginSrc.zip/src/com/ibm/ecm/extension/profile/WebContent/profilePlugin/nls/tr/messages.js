/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(tr) Links",
	"button.send.email": "(tr) Send Email",
	
	"connections.profiles": "(tr) Profiles",
	"connections.communities": "(tr) Communities",
	"connections.blogs": "(tr) Blogs",
	"connections.forums": "(tr) Forums",
	"connections.wikis": "(tr) Wikis",
	"connections.files": "(tr) Files",
	"connections.dogear": "(tr) Dogear",
	"connections.activities": "(tr) Activities",
	
	server_input_label: "(tr) IBM Connections profile service URL:",
	server_input_hover: "(tr) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(tr) IBM Sametime Web API URL:",
	st_input_hover: "(tr) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(tr) Context Root for Proxy Server:",
	proxyURI_hover: "(tr) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(tr) Test",
	test_result_label: "(tr) Test result",
	showDisplayName_input_label: "(tr) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(tr) Decide whether to show the original login name or the display name",
	testResultValid: "(tr) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(tr) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
