/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(sv) Links",
	"button.send.email": "(sv) Send Email",
	
	"connections.profiles": "(sv) Profiles",
	"connections.communities": "(sv) Communities",
	"connections.blogs": "(sv) Blogs",
	"connections.forums": "(sv) Forums",
	"connections.wikis": "(sv) Wikis",
	"connections.files": "(sv) Files",
	"connections.dogear": "(sv) Dogear",
	"connections.activities": "(sv) Activities",
	
	server_input_label: "(sv) IBM Connections profile service URL:",
	server_input_hover: "(sv) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(sv) IBM Sametime Web API URL:",
	st_input_hover: "(sv) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(sv) Context Root for Proxy Server:",
	proxyURI_hover: "(sv) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(sv) Test",
	test_result_label: "(sv) Test result",
	showDisplayName_input_label: "(sv) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(sv) Decide whether to show the original login name or the display name",
	testResultValid: "(sv) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(sv) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
