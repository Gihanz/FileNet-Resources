package com.ibm.ecm.extension.lync.exception;

public class LyncException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	int responseCode;
	Exception originalException;
	
	public LyncException (Exception ex, int responseCode) {
		this.originalException = ex;
		this.responseCode = responseCode;
	}
	
	public int getResponseCode() {
		return responseCode;
	}
	
	public String getErrorJson() {
		String explanation = "Please check if your oAuth token has expired and supply a valid oAuth token.";
		String outString = 
"{" +
"\"error\": \"" + getResponseCode() + "\"," +
"    \"queryTerms\": \"p8admin\"," +
"    \"email\": {" +
"        \"internet\": \"p8admin\"" +
"    }," +
"    \"org\": \"" + explanation + "\"," +
"    \"fn\": \"Invalid Setting\"," +
"    \"tel\": {\"work\": \"1-800-IBM-HELP\"}," +
"    \"title\": \"Error code: " + responseCode + "\"," +
"    \"exception\": \"" + originalException.toString() + "\"," +
"    \"photo\": \"http://test08st.usca.ibm.com/lync/photos/fernandos.png\"" +
"}";
		return outString;
	}
}
