/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(sk) Links",
	"button.send.email": "(sk) Send Email",
	
	"connections.profiles": "(sk) Profiles",
	"connections.communities": "(sk) Communities",
	"connections.blogs": "(sk) Blogs",
	"connections.forums": "(sk) Forums",
	"connections.wikis": "(sk) Wikis",
	"connections.files": "(sk) Files",
	"connections.dogear": "(sk) Dogear",
	"connections.activities": "(sk) Activities",
	
	server_input_label: "(sk) IBM Connections profile service URL:",
	server_input_hover: "(sk) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(sk) IBM Sametime Web API URL:",
	st_input_hover: "(sk) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(sk) Context Root for Proxy Server:",
	proxyURI_hover: "(sk) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(sk) Test",
	test_result_label: "(sk) Test result",
	showDisplayName_input_label: "(sk) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(sk) Decide whether to show the original login name or the display name",
	testResultValid: "(sk) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(sk) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
