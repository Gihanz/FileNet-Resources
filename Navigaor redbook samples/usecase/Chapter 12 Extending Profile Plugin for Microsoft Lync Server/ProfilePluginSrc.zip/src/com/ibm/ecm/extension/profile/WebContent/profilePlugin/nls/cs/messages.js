/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(cs) Links",
	"button.send.email": "(cs) Send Email",
	
	"connections.profiles": "(cs) Profiles",
	"connections.communities": "(cs) Communities",
	"connections.blogs": "(cs) Blogs",
	"connections.forums": "(cs) Forums",
	"connections.wikis": "(cs) Wikis",
	"connections.files": "(cs) Files",
	"connections.dogear": "(cs) Dogear",
	"connections.activities": "(cs) Activities",
	
	server_input_label: "(cs) IBM Connections profile service URL:",
	server_input_hover: "(cs) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(cs) IBM Sametime Web API URL:",
	st_input_hover: "(cs) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(cs) Context Root for Proxy Server:",
	proxyURI_hover: "(cs) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(cs) Test",
	test_result_label: "(cs) Test result",
	showDisplayName_input_label: "(cs) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(cs) Decide whether to show the original login name or the display name",
	testResultValid: "(cs) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(cs) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
