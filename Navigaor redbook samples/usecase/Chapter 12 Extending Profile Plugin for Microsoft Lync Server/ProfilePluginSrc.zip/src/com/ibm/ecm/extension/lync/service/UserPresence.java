package com.ibm.ecm.extension.lync.service;

import com.ibm.ecm.extension.lync.LyncSession;
import com.ibm.json.java.JSON;
import com.ibm.json.java.JSONObject;

public class UserPresence extends LyncService {

	private static String mapPresence(String presence) 
	throws Exception
	{
		if ("DoNotDisturb".equals(presence)) return "Do not disturb";
		else if ("BeRightBack".equals(presence)) return "Be right back";
		else return presence;
	}
	
	public static String getPresence(String email, LyncSession session)
	throws Exception
	{
		String json = getService("/people/" + email + "/presence", session);
		if (json == null || "".equals(json.trim())) return "";
        JSONObject obj = (JSONObject) JSON.parse(json);
        Object val = obj.get("availability");
        if (val != null) {
	        json = (String) val;
	    }
	    json = mapPresence(json);
	    return json;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
