/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(de) Links",
	"button.send.email": "(de) Send Email",
	
	"connections.profiles": "(de) Profiles",
	"connections.communities": "(de) Communities",
	"connections.blogs": "(de) Blogs",
	"connections.forums": "(de) Forums",
	"connections.wikis": "(de) Wikis",
	"connections.files": "(de) Files",
	"connections.dogear": "(de) Dogear",
	"connections.activities": "(de) Activities",
	
	server_input_label: "(de) IBM Connections profile service URL:",
	server_input_hover: "(de) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(de) IBM Sametime Web API URL:",
	st_input_hover: "(de) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(de) Context Root for Proxy Server:",
	proxyURI_hover: "(de) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(de) Test",
	test_result_label: "(de) Test result",
	showDisplayName_input_label: "(de) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(de) Decide whether to show the original login name or the display name",
	testResultValid: "(de) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(de) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
