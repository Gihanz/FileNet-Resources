/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(no) Links",
	"button.send.email": "(no) Send Email",
	
	"connections.profiles": "(no) Profiles",
	"connections.communities": "(no) Communities",
	"connections.blogs": "(no) Blogs",
	"connections.forums": "(no) Forums",
	"connections.wikis": "(no) Wikis",
	"connections.files": "(no) Files",
	"connections.dogear": "(no) Dogear",
	"connections.activities": "(no) Activities",
	
	server_input_label: "(no) IBM Connections profile service URL:",
	server_input_hover: "(no) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(no) IBM Sametime Web API URL:",
	st_input_hover: "(no) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(no) Context Root for Proxy Server:",
	proxyURI_hover: "(no) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(no) Test",
	test_result_label: "(no) Test result",
	showDisplayName_input_label: "(no) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(no) Decide whether to show the original login name or the display name",
	testResultValid: "(no) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(no) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
