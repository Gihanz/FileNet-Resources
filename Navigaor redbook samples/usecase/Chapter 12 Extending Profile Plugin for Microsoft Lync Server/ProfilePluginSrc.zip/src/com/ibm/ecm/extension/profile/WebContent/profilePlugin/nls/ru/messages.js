/*
IBM Confidential

OCO Source Materials

5725A15

© Copyright IBM Corp. 2010, 2012

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/
define(({
	"button.links": "(ru) Links",
	"button.send.email": "(ru) Send Email",
	
	"connections.profiles": "(ru) Profiles",
	"connections.communities": "(ru) Communities",
	"connections.blogs": "(ru) Blogs",
	"connections.forums": "(ru) Forums",
	"connections.wikis": "(ru) Wikis",
	"connections.files": "(ru) Files",
	"connections.dogear": "(ru) Dogear",
	"connections.activities": "(ru) Activities",
	
	server_input_label: "(ru) IBM Connections profile service URL:",
	server_input_hover: "(ru) URL to the IBM Connections server profile server. Example: https://localhost/profiles/json/profile.do",
	st_input_label: "(ru) IBM Sametime Web API URL:",
	st_input_hover: "(ru) URL to the IBM Sametime web API. Example: http://localhost:59449/stwebapi",
	proxyURI_label: "(ru) Context Root for Proxy Server:",
	proxyURI_hover: "(ru) Context Root to the IBM Ajax Proxy Server. Example: /AjaxProxy",
	test_button_label: "(ru) Test",
	test_result_label: "(ru) Test result",
	showDisplayName_input_label: "(ru) Show Display Name instead of Login Name:",
	showDisplayName_input_hover: "(ru) Decide whether to show the original login name or the display name",
	testResultValid: "(ru) Sametime URI and Proxy Context Root are valid",
	testResultInvalid: "(ru) Sametime URI or Proxy Context Root is invalid",

	nop: null
}));
