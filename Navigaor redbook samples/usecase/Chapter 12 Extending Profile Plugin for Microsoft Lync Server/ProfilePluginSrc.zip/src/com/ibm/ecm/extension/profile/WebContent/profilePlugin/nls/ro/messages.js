define({

	// NLS_CHARSET=UTF-8
	"button.links": "Legături",
	"button.send.email": "Trimitere e-mail",
	"connections.profiles": "Profiluri",
	"connections.communities": "Comunităţi",
	"connections.blogs": "Bloguri",
	"connections.forums": "Forumuri",
	"connections.wikis": "Wiki-uri",
	"connections.files": "Fişiere",
	"connections.dogear": "Dogear",
	"connections.activities": "Activităţi",
	"nop": null
});

