define([
	"dojo/_base/declare",
	"dijit/_TemplatedMixin",
	"dijit/_WidgetsInTemplateMixin",
	"dijit/layout/StackContainer",
	"dijit/layout/BorderContainer",
	"dijit/layout/ContentPane",
	"ecm/widget/layout/BaseLayout",
	"ecm/model/Feature",
	"ecm/widget/listView/gridModules/RowContextMenu",
	"ecm/widget/listView/modules/Breadcrumb",
	"ecm/widget/listView/modules/Bar",
	"ecm/widget/listView/modules/Toolbar",
	"ecm/widget/listView/modules/DocInfo",
	"ecm/widget/listView/gridModules/DndRowMoveCopy",
	"ecm/widget/listView/gridModules/DndFromDesktopAddDoc",
	"ecm/widget/listView/modules/ViewDetail",
	"ecm/widget/listView/modules/ViewMagazine",
	"ecm/widget/listView/ContentList",
	"ecm/model/Desktop",
	"dojo/_base/lang",
	"dojo/text!./templates/ContentListLayout.html", "dojo/domReady!",
	],
	function(declare, _TemplatedMixin, _WidgetsInTemplateMixin, StackContainer, BorderContainer, ContentPane, BaseLayout, Feature, RowContextMenu,Breadcrumb, Bar, Toolbar, DocInfo, DndRowMoveCopy, DndFromDesktopAddDoc, ViewDetail, ViewMagazine, ContentList, Desktop,lang, template) {

	/**
	 * @name layoutPluginDojo.ContentListLayout
	 * @class  
	 * @augments ecm.widget.layout.BaseLayout, dijit._TemplatedMixin, dijit._WidgetsInTemplateMixin
	 */
	return declare("layoutPluginDojo.ContentListLayout", [ BaseLayout, _TemplatedMixin, _WidgetsInTemplateMixin ], {
	/** @lends layoutPluginDojo.ContentListLayout.prototype */

		templateString: template,

		// Set this to true if your widget contains other widgets
		widgetsInTemplate: true,
		postCreate : function() {
			this.inherited(arguments);		
			this.contentList.setContentListModules(
				this.getContentListModules());
			this.contentList.setGridExtensionModules( 
				this.getContentListGridModules());
			this.displayRoot();
		},
	

		getAvailableFeatures: function() {
			return [
				new Feature({
					id: "favorites",
					name: "favorites",
					featureClass: "ecm.widget.layout.FavoritesPane",
				})
			];
		},
		getContentListGridModules : function() {
			var array = [];
			array.push(DndRowMoveCopy);
			array.push(DndFromDesktopAddDoc);
			array.push(RowContextMenu);
			return array;
		},

		getContentListModules : function() {
			var viewModules = [];
			viewModules.push(ViewDetail);
			viewModules.push(ViewMagazine);
			var array = [];
			array.push({
				moduleClass : Bar,
				top : [ [ [ {
					moduleClass : Toolbar
				}, {
					moduleClasses : viewModules,
					"className" : "BarViewModules"
				} ] ], [ [ {
					moduleClass : Breadcrumb
				} ] ] ]
			});
			array.push(DocInfo);
			return array;
		},

		displayRoot : function() {
			var repository = ecm.model.desktop.getDefaultRepository();
			if (repository) {
				repository.retrieveItem("/", 
					lang.hitch(this, function(rootItem) {
						rootItem.retrieveFolderContents(false,
							lang.hitch(this, function(resultSet) {
								this.contentList.setResultSet(resultSet, rootItem);
						}));
				}));
			}
		}
		
	});
});
