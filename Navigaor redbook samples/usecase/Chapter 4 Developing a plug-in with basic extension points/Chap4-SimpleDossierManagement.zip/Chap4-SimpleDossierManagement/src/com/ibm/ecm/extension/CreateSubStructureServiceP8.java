package com.ibm.ecm.extension;

import java.util.Iterator;
import java.util.StringTokenizer;

import javax.security.auth.Subject;

import com.filenet.api.collection.FolderSet;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.UserContext;
import com.ibm.ecm.json.JSONMessage;
import com.ibm.ecm.json.JSONResponse;

public class CreateSubStructureServiceP8 {
	public static void execute(PluginServiceCallbacks callbacks, JSONResponse jsonResults, String dossierId,
			String templateFolderStructurePath, String icnRepositoryId) {
		Subject subject = callbacks.getP8Subject(icnRepositoryId);
		UserContext.get().pushSubject(subject);
		try {
			ObjectStore objectStore = callbacks.getP8ObjectStore(icnRepositoryId);
			StringTokenizer dossierIdTok = new StringTokenizer(dossierId, ",");
			String classID = (dossierIdTok.hasMoreTokens() ? dossierIdTok.nextToken() : null);
			String objectStoreID = (dossierIdTok.hasMoreTokens() ? dossierIdTok.nextToken() : null);
			String dossierObjectId = (dossierIdTok.hasMoreTokens() ? dossierIdTok.nextToken() : null);
			Folder dossierFolder = Factory.Folder.fetchInstance(objectStore, dossierObjectId, null);
			Folder templateRootFolder = Factory.Folder.fetchInstance(objectStore, templateFolderStructurePath, null);
			createDossierSubstructureP8(dossierFolder, templateRootFolder, objectStore);
			JSONMessage infoMessage = new JSONMessage(1000, "Successfully created dossier substructure", "",
					"Successfully created dossier substructure for Dosser " + dossierFolder.get_Name(), "", "");
			jsonResults.addInfoMessage(infoMessage);
		} finally {
			UserContext.get().popSubject();
		}
	}

	private static void createDossierSubstructureP8(Folder dossierFolder, Folder templateRootFolder, ObjectStore os) {
		FolderSet subFolders = templateRootFolder.get_SubFolders();
		Iterator it = subFolders.iterator();
		while (it.hasNext()) {
			Folder templateFolder = (Folder) it.next();
			String subFolderName = templateFolder.get_FolderName();
			Folder subFolder = dossierFolder.createSubFolder(subFolderName);
			subFolder.save(RefreshMode.REFRESH);
			// call recursively
			createDossierSubstructureP8(subFolder, templateFolder, os);
		}
	}
}