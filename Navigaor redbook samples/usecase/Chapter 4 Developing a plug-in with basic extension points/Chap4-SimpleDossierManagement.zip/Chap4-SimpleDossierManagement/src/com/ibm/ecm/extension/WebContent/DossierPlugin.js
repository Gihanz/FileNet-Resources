require(["dojo/_base/declare","dojo/_base/lang",
"ecm/widget/dialog/AddContentItemDialog",
"ecm/model/Request","dossierPluginDojo/OpenDossierAction"],
function(declare, lang, AddContentItemDialog, Request,
	OpenDossierAction) {
	lang.setObject("createDossierAction", function(repository, items) {
		Request.invokePluginService("DossierPlugin",
			"GetConfigurationService",{
			requestCompleteCallback: function(response) {
				var dossierRootFolder = response.configuration[1].value;
				var dossierFolderClass =response.configuration[0].value;
				var templateDossierStructure =response.configuration[2].value;
				var _createFolderSubStructure = function(dossierFolder){
					var serviceParams = {
						icnRepository : repository.id,
						serverType : repository.type,
						dossierId : dossierFolder.id,
						templateFolderStructure: templateDossierStructure
					};
					Request.invokePluginService("DossierPlugin", "CreateSubStructureService", {
						requestParams: serviceParams,
						requestCompleteCallback: function(response) {
							var newFolders = [];
							newFolders.push(dossierFolder);
							var openDossier = new OpenDossierAction();
							openDossier.performAction(repository, newFolders, null);
						}
					});
				};
				repository.retrieveItem(dossierRootFolder,
				function(dossierRootFolderItem) {
					var addContentItemDialog = new AddContentItemDialog();
					addContentItemDialog.setDefaultContentClass(dossierFolderClass);
					addContentItemDialog.show(repository, dossierRootFolderItem,
						false, false, _createFolderSubStructure, null, false, null);
					addContentItemDialog.set("title","Create new Dossier");
					addContentItemDialog.setIntroText("This folder will be the top level folder of your dossier.");
				});
			} //requestCompleteCallback
		});
	});
});