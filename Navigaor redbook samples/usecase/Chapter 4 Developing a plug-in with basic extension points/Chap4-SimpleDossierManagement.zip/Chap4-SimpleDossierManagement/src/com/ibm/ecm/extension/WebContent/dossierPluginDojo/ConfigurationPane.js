define(["dojo/_base/declare","dijit/_TemplatedMixin",
"dijit/_WidgetsInTemplateMixin","ecm/widget/ValidationTextBox",
"ecm/widget/admin/PluginConfigurationPane",
"dojo/text!./templates/ConfigurationPane.html"],
function(declare, _TemplatedMixin, _WidgetsInTemplateMixin,ValidationTextBox,
PluginConfigurationPane, template) {
return declare("dossierPluginDojo.ConfigurationPane",
[PluginConfigurationPane, _TemplatedMixin, _WidgetsInTemplateMixin], {
	templateString: template,
	widgetsInTemplate: true,
	load: function(callback){
		if(this.configurationString){
			var jsonConfig = JSON.parse(this.configurationString);
			this.dossierFolderClassField.set('value',jsonConfig.configuration[0].value);
			this.dossierRootField.set('value',jsonConfig.configuration[1].value);
			this.templateFolderStructureField.set('value',jsonConfig.configuration[2].value);
		}	
	},
	_onParamChange: function() {
		var configArray = new Array();
		var configString = {
				name: "dossierFolderClass",
				value: this.dossierFolderClassField.get('value')
		};
		configArray.push(configString);
		configString = {
				name: "dossierRoot",
				value: this.dossierRootField.get('value')
		};
		configArray.push(configString);
		configString = {
				name: "templateFolderStructure",
				value: this.templateFolderStructureField.get('value')
		};
		configArray.push(configString);
		var configJson = {
				"configuration" : configArray
		};
		this.configurationString = JSON.stringify(configJson);
		this.onSaveNeeded(true);
	},
	validate: function() {
		if(!this.dossierFolderClassField.isValid()
				|| !this.dossierRootField.isValid()
				|| !this.templateFolderStructureField.isValid() )
			return false;
		return true;
	}
	});
});	
