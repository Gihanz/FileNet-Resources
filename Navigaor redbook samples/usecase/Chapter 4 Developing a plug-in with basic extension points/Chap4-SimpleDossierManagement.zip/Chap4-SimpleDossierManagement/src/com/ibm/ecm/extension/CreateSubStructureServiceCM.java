package com.ibm.ecm.extension;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.ecm.json.JSONMessage;
import com.ibm.ecm.json.JSONResponse;
import com.ibm.mm.sdk.common.DKAttrDefICM;
import com.ibm.mm.sdk.common.DKConstant;
import com.ibm.mm.sdk.common.DKConstantICM;
import com.ibm.mm.sdk.common.DKDDO;
import com.ibm.mm.sdk.common.DKDatastoreDefICM;
import com.ibm.mm.sdk.common.DKException;
import com.ibm.mm.sdk.common.DKFolder;
import com.ibm.mm.sdk.common.DKItemTypeDefICM;
import com.ibm.mm.sdk.common.DKRetrieveOptionsICM;
import com.ibm.mm.sdk.common.DKSequentialCollection;
import com.ibm.mm.sdk.common.DKUsageError;
import com.ibm.mm.sdk.common.dkIterator;
import com.ibm.mm.sdk.server.DKDatastoreICM;

public class CreateSubStructureServiceCM {
	public static void execute(PluginServiceCallbacks callbacks, JSONResponse jsonResults, String dossierId,
			String templateFolderStructurePath, String icnRepositoryId) throws DKUsageError, DKException, Exception {
		DKDatastoreICM datastore = callbacks.getCMDatastore(icnRepositoryId);
		DKDDO ddoDossier = datastore.createDDOFromPID(dossierId);
		String dossierName = getRepresentsItemAttribute(ddoDossier, datastore);
		DKDDO ddoTemplate = datastore.createDDOFromPID(templateFolderStructurePath);
		createDossierSubstructureCM8(ddoDossier, ddoTemplate, datastore);
		JSONMessage infoMessage = new JSONMessage(1000, "Successfully created dossier substructure", "",
				"Successfully created dossier substructure for Dosser " + dossierName, "", "");
		jsonResults.addInfoMessage(infoMessage);
	}

	private static String getRepresentsItemAttribute(DKDDO item, DKDatastoreICM datastore) throws Exception {
		String objectType = item.getPidObject().getObjectType();
		DKDatastoreDefICM dataStoreDef = (DKDatastoreDefICM) datastore.datastoreDef();
		DKItemTypeDefICM itemType = (DKItemTypeDefICM) dataStoreDef.retrieveEntity(objectType);
		DKSequentialCollection attrCol = (DKSequentialCollection) itemType.listAllAttributes();
		dkIterator iter = attrCol.createIterator();
		while (iter.more()) {
			DKAttrDefICM attr = (DKAttrDefICM) iter.next();
			if (attr.isRepresentative()) {
				return attr.getName();
			}
		}
		// no name found
		return item.getPidObject().getPrimaryId().toString();
	}

	private static void createDossierSubstructureCM8(DKDDO dossierFolder, DKDDO templateRootFolder, DKDatastoreICM datastore)
			throws Exception {
		List<DKDDO> subFolders = getSubfolder(templateRootFolder, datastore);
		System.out.println("got number subFolders: " + subFolders.size());
		Iterator<DKDDO> it = subFolders.iterator();
		while (it.hasNext()) {
			DKDDO templateFolder = it.next();
			DKRetrieveOptionsICM retrieveOptions = DKRetrieveOptionsICM.createInstance(datastore);
			retrieveOptions.baseAttributes(true);
			templateFolder.retrieve(retrieveOptions.dkNVPair());
			String attributeName = getRepresentsItemAttribute(templateFolder, datastore);
			System.out.println("got attributeName: " + attributeName);
			String subFolderName = (String) getAttributeValue(attributeName, templateFolder);
			System.out.println("create Subfolder ... : " + subFolderName);
			String itemType = templateFolder.getObjectType();
			DKDDO subFolder = createChildFolder(datastore, dossierFolder, subFolderName, attributeName, itemType);
			// call recursively
			createDossierSubstructureCM8(subFolder, templateFolder, datastore);
		}
	}

	private static List<DKDDO> getSubfolder(DKDDO folder, DKDatastoreICM datastore) throws Exception {
		DKRetrieveOptionsICM dkRetrieveOptions = DKRetrieveOptionsICM.createInstance(datastore);
		dkRetrieveOptions.baseAttributes(true);
		dkRetrieveOptions.linksOutbound(true);
		dkRetrieveOptions.linksTypeFilter(DKConstantICM.DK_ICM_LINKTYPENAME_DKFOLDER);
		folder.retrieve(dkRetrieveOptions.dkNVPair());
		short dataid = folder.dataId(DKConstant.DK_CM_NAMESPACE_ATTR, DKConstant.DK_CM_DKFOLDER);
		if (dataid == 0) {
			throw new Exception(
					"No DKFolder Attribute Found! DDO is either not a Folder or Folder Contents have not been explicitly retrieved.");
		}
		DKFolder dkFolder = (DKFolder) folder.getData(dataid);
		dkIterator iter = dkFolder.createIterator();
		ArrayList<DKDDO> subFolders = new ArrayList<DKDDO>();
		while (iter.more()) {
			DKDDO ddo = (DKDDO) iter.next();
			subFolders.add(ddo);
		}
		return subFolders;
	}

	private static DKDDO createChildFolder(DKDatastoreICM datastore, DKDDO parentFolder, String subFolderName, String attributeName,
			String itemType) throws Exception {
		DKDDO newDDOFolder = datastore.createDDO(itemType, DKConstant.DK_CM_FOLDER);
		short dataId = newDDOFolder.dataId(DKConstant.DK_CM_NAMESPACE_ATTR, attributeName);
		newDDOFolder.setData(dataId, subFolderName);
		newDDOFolder.addProperty(DKConstantICM.DK_ICM_PROPERTY_PARENT_FOLDER, parentFolder);
		newDDOFolder.add();
		System.out.println("subFolder added:" + subFolderName);
		return newDDOFolder;
	}

	private static Object getAttributeValue(String attributeName, DKDDO item) {
		Object value = null;
		try {
			// user defined attributes
			short dataId = item.dataId(DKConstant.DK_CM_NAMESPACE_ATTR, attributeName);
			if (dataId == 0) {
				// system attributes
				dataId = item.propertyId(attributeName);
				if (dataId == 0) {
					System.out.println("Cannot find the attribute: " + attributeName + "for object " + item.getPidObject().getIdString());
					return "no value found";
				} else {
					value = item.getProperty(dataId);
				}
			} else {
				value = item.getData(dataId);
			}
		} catch (DKUsageError e) {
			System.out.println("Cannot find the attribute: " + attributeName + "for object " + item.getPidObject().getIdString()
					+ " error: " + e.getMessage());
			return "no value found";
		}
		return value;
	}
}