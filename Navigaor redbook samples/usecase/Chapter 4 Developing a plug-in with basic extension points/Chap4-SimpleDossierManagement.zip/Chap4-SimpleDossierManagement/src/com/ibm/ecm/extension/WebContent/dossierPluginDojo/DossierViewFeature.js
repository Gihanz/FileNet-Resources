define(["dojo/_base/declare","ecm/widget/layout/BrowsePane"],
function(declare,BrowsePane) {
	return declare("dossierPluginDojo.DossierViewFeature",
		[BrowsePane], {
	});
});