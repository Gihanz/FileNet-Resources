define([ "dojo/_base/declare", "ecm/model/Action","ecm/model/Request" ], function(declare, Action,Request) {
	return declare("dossierPluginDojo.OpenDossierAction", [ Action ],{
		dossierFolderClass:null,
		isEnabled: function(repository, listType, items, teamspace, resultSet) {
			var enabled = this.inherited(arguments);
			if (items && items[0].isFolder && items[0].getContentClass) {
				if (!this.dossierFolderClass) {
						Request.invokePluginService("DossierPlugin", 	
							"GetConfigurationService",
							{
								requestCompleteCallback: dojo.hitch(this, 
									function(response) {
									this.dossierFolderClass = 
										response.configuration[0].value;
								})
							});
					}
				var sameClass = (items[0].getContentClass().name==this.dossierFolderClass);
				return enabled && items[0].isFolder() && sameClass;
			}
		return false;
		},
		isVisible : function(repository, listType) {
			return this.inherited(arguments);
		},
		performAction: function(repository, itemList, callback, teamspace,
			resultSet, parameterMap) {
			this.logEntry("performAction", "items=" + itemList);
			var newDossier = itemList[0];
			var layout = ecm.model.desktop.getLayout();
			var featureIdToSwitch = "DossierViewFeature";
			var button = layout.launchBarContainer.getButtonByID(featureIdToSwitch);
				var params = {};
				params.repository=repository;
				layout.launchBarContainer.selectContentPane(button,featureIdToSwitch, params);
				var browseFeature = layout.launchBarContainer.getContentPaneByID(featureIdToSwitch);
				this.setBrowseRootFolder(newDossier,browseFeature);
				this.logExit("performAction");
			},
		setBrowseRootFolder : function(newRootFolder, browseFeature) {
			browseFeature.folderTree.setFolder(newRootFolder);
			// optionally set content list to the first child.
		}
	});
});