define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/dom-construct",
	"idx/layout/BorderContainer",
	"dijit/layout/ContentPane",
	"dojo/json", 
	"dojo/store/Memory",
    "dijit/tree/ObjectStoreModel", 
	"dijit/Tree",	
	"ecm/model/Request",
	"ecm/model/ResultSet",
	"ecm/widget/layout/_LaunchBarPane",
	"ecm/widget/layout/_RepositorySelectorMixin",
	"ecm/widget/listView/ContentList",
	"ecm/widget/listView/gridModules/RowContextMenu",
	"ecm/widget/listView/modules/Toolbar",
	"ecm/widget/listView/modules/Breadcrumb",
	"ecm/widget/listView/modules/InlineMessage",
	"ecm/widget/listView/modules/TotalCount",
	"ecm/widget/listView/modules/FilterData",
	"ecm/widget/listView/modules/DocInfo",
	"ecm/widget/listView/gridModules/DndRowMoveCopy",
	"ecm/widget/listView/gridModules/DndFromDesktopAddDoc",
	"ecm/widget/listView/modules/Bar",
	"ecm/widget/listView/modules/ViewDetail",
	"ecm/widget/listView/modules/ViewMagazine",
	"ecm/widget/listView/modules/ViewFilmStrip",
	"dojo/text!./templates/VirtualFolderBrowsePane.html"
],

function(declare,
		lang,
		domConstruct,
		idxBorderContainer,
		ContentPane,
		json,
		Memory,
		ObjectStoreModel,
		Tree,	
		Request,
		ResultSet,
		_LaunchBarPane,
		_RepositorySelectorMixin,
		ContentList,
		RowContextMenu,
		Toolbar,
		Breadcrumb,
		InlineMessage,
		TotalCount,
		FilterData,
		DocInfo,
		DndRowMoveCopy,
		DndFromDesktopAddDoc,
		Bar,
		ViewDetail,
		ViewMagazine,
		ViewFilmStrip,
		template) {

	/**
	 * @name customSearchPluginDojo.VirtualFolderBrowsePane
	 * @class 
	 * @augments ecm.widget.layout._LaunchBarPane
	 */
	return declare("customSearchPluginDojo.VirtualFolderBrowsePane", [
		_LaunchBarPane,
		_RepositorySelectorMixin
	], {
		/** @lends customSearchPluginDojo.VirtualFolderBrowsePane.prototype */

		templateString: template,
		widgetsInTemplate: true,
		classnames:[],
		mainfolders:[],
		createdTreeItems:false,

		postCreate: function() {
			this.logEntry("postCreate");
			this.inherited(arguments);
			this.defaultLayoutRepositoryComponent = "others";			
			this.setRepositoryTypes("cm,p8");			
			this.createRepositorySelector();
			this.doRepositorySelectorConnections();	
			
			// If there is more than one repository in the list, show the selector to the user.
			if (this.repositorySelector.getNumRepositories() > 1) {
				domConstruct.place(this.repositorySelector.domNode, this.repositorySelectorArea, "only");
			}			
			this.logExit("postCreate");
		},
		
		/**
		 * Returns the content list grid modules used by this view.
		 * 
		 * @return Array of grid modules.
		 */
		getContentListGridModules: function() {
			var array = [];
			array.push(DndRowMoveCopy);
			array.push(DndFromDesktopAddDoc);
			array.push(RowContextMenu);
			return array;
		},

		/**
		 * Returns the content list modules used by this view.
		 * 
		 * @return Array of content list modules.
		 */
		getContentListModules: function() {
			var viewModules = [];
			viewModules.push(ViewDetail);
			viewModules.push(ViewMagazine);
			if (ecm.model.desktop.showViewFilmstrip) {
				viewModules.push(ViewFilmStrip);
			}

			var array = [];
			array.push(DocInfo);
			array.push({
				moduleClass: Bar,
				top: [
						[
							[
								{
									moduleClass: Toolbar
								},
								{
									moduleClass: FilterData
								},
								{
									moduleClasses: viewModules,
									"className": "BarViewModules"
								}
							]
						],
						[
							[
								{
									moduleClass: Breadcrumb,
									rootPrefix:  "Virtual folder"
								}
							]
						],
						[
							[
								{
									moduleClass: InlineMessage,
									"className": "inlineMessage"
								}
							]
						]
					],
					bottom: [
						[
							[
								{
									moduleClass: TotalCount
								}
							]
						]
					]
			});
			return array;
		},

		/**
		 * Loads the content of the pane. This is a required method to insert a pane into the LaunchBarContainer.
		 */
		loadContent: function() {
			this.logEntry("loadContent");
			if (!this.repository) {
				this.setPaneDefaultLayoutRepository();
			}
			var data ="{\"name\": \"Multiple Demension Tree\",\"id\": \"root\",\"children\": [{\"name\": \"My Navigator\",\"id\": \"my_navigator\", \"children\":[]}]}";			
			this.TreeStore = new Memory({
		        data: [ json.parse(data) ],
		        getChildren: lang.hitch(this,function(object){
                      return object.children;
		        })
		    });
			this._resetTree();
			this.navTree.placeAt(dijit.byId("navTreePane").containerNode);				
    		var callbackGetFolders = lang.hitch(this, function(resultset)
    		{
        		this.mainfolders=[];
    			for(row in resultset.items)
    			{
    				var element= {
    						value:resultset.items[row].id,
    						label:resultset.items[row].name,
    						name:"Folder: "+resultset.items[row].name,
    						id:resultset.items[row].id,
    						criterionType:"Folder",
    						children:[]
    				}
    				this.mainfolders.push(element);
    			}
    			this.setupNavTree();
    		});			
    		var callbackGetClasses = lang.hitch(this, function(contentClasses)
    	    	{
    				this.classnames=[];
    	    		for(docclass in contentClasses)
    	    		{
    	    			var element= {
    	    					value:contentClasses[docclass].id,
    	    					label:contentClasses[docclass].name,
    	    					name:"Class: "+contentClasses[docclass].name,
    	    					id:contentClasses[docclass].id,
    	    					criterionType:"Class",
    	    					children:[]	        						
    	    			}
    	    			this.classnames.push(element);
    	    		}
    	    	});
			
			if (this.repository && this.repository.canListFolders()) {
				var rootItemId = this.repository.rootFolderId || "/";
				var _this = this;
				this.repository.retrieveContentClasses(callbackGetClasses);				
				this.repository.retrieveItem(rootItemId, lang.hitch(this, function(rootFolder) {
					this.repository.rootFolder=rootFolder;
					rootFolder.retrieveFolderContents(true, callbackGetFolders);
				}), null, null, null, this._objectStore ? this._objectStore.id : "");
			}			
			this.isLoaded = true;
			this.needReset = false;
			this.logExit("loadContent");
		},
		_resetTree:function()
		{
			if(this.navTree)
				this.navTree.destroy();
			TreeModel = new ObjectStoreModel({
		        store: this.TreeStore,
		        query: {id: 'root'},
		        mayHaveChildren: function(item){
		            return "children" in item;
		        }
		    });				
			this.navTree = new Tree({
				model: TreeModel,
				onOpenClick: true,
				persist: false,
				getIconClass: lang.hitch(this, function(item,opened)
					{
						if(item.id != "root" && item.id !="my_navigator")
							return (opened ? "searchFolderOpenIcon" : "searchFolderCloseIcon");
						else
							return (opened ? "dijitFolderOpened" : "dijitFolderClosed");
					})
			}, "divTree");
			this.navTree.domNode.style.height="100%";
			this.navTree.placeAt(dijit.byId("navTreePane").containerNode);
			this.createdTreeItems=false;
			this.connect(this.navTree, "onClick", lang.hitch(this, function(item) {
				 if(item.id != "root" && item.id !="my_navigator")
				{
					this.executeSearch(item);
				}
			}));			
		},		
		setupNavTree:function()
		{
			if(!this.createdTreeItems)
			{
				var firstLayer=this.mainfolders;
				var secondlayer=this.classnames;
				if(secondlayer.length>0)
				{
					for(j in firstLayer)
					{
						firstLayer[j].children=secondlayer;
					}
				}
				this.TreeStore.data[0].children[0].children=firstLayer;//it's the path of "my navigator";
				this.createdTreeItems=true;
			}		
		},		
		executeSearch:function(item){
			var node = this.navTree.getNodesByItem(item);
			var path = node[0].tree.path;
			var docClassName="";
			var mainFolderID="";
			for(i=2;path[i]!=undefined;i++)
			{
				if(path[i].criterionType=="Class")
				{
					docClassName=path[i].value;
				}else if(path[i].criterionType == "Folder")
				{
					mainFolderID=path[i].value;
				}
			}
			this.runSearch(docClassName,mainFolderID);
		},
		/**
		 * Sets the repository being used for search.
		 * 
		 * @param repository
		 * 			An instance of {@link ecm.model.Repository}
		 */
		setRepository: function(repository) {
			this.repository = repository;
			if (this.repositorySelector && this.repository) {
				this.repositorySelector.getDropdown().set("value", this.repository.id);
			}
			this.navResult.reset();
			this.loadContent();
		},
		runSearch:function(docClassName,mainFolderID,attributeName,attributeValue){
			var requestParams = {};
			requestParams.repositoryId = this.repository.id;
			requestParams.repositoryType = this.repository.type;
			if( this.repository.type == "cm" ){
				var scoperule="/* ";
				var baserulestart='[(@SEMANTICTYPE IN (1))';
				var ruleEnd="]"
				var folderrule='INBOUNDLINK[@LINKTYPE = "DKFolder"]/@SOURCEITEMREF = ';
				var attributerule="";
				if(docClassName!="")
					scoperule='/'+docClassName+" ";
				var query = scoperule+baserulestart;
				if(attributeName!="" && attributeName!=undefined)
				{
					attributerule='((@' +attributeName+" = "+attributeValue +'))'
					query = query +" AND "+attributerule;
				}
				if(mainFolderID!="")
				{
	                itemid =mainFolderID.split(" ")[6];
	                mainFolderID =itemid.substr(0, itemid.length-2);
					folderrule = folderrule+'"'+mainFolderID+'"';
					query = query +" AND "+folderrule;
				}
				query +=ruleEnd;
				requestParams.query = query;
			}else if(this.repository.type=="p8"){
				var query = "Select * from ";
				if ( docClassName && docClassName.length > 0 ){
					query += docClassName;
				}else{
					query += "DOCUMENT ";
				}
				if( mainFolderID || ( attributeName && attributeValue) ){
					query += " where "
				}
				if( mainFolderID && mainFolderID.length >0 ){
					var folderID = mainFolderID.substr(  mainFolderID.length-38, mainFolderID.length );
					query += " this INFOLDER " + folderID ;
				}
				requestParams.query=query;
			}

			
			Request.invokePluginService("CustomSearchPlugin", "SearchService",
				{
					requestParams: requestParams,
					requestCompleteCallback: lang.hitch(this, function(response) {	// success
						response.repository = this.repository;
						var resultSet = new ResultSet(response);
						this.navResult.setContentListModules(this.getContentListModules());
						this.navResult.setGridExtensionModules(this.getContentListGridModules());	
						this.navResult.setResultSet(resultSet);
						
						var inlineMessageModule = this.navResult.getContentListModule( "inlineMessage" );
						if (inlineMessageModule){
							inlineMessageModule.clearMessage();
							inlineMessageModule.setMessage("Result set items length is: " +resultSet.items.length, "info");
						}
					})
				}
			);			
		}
	});
});

