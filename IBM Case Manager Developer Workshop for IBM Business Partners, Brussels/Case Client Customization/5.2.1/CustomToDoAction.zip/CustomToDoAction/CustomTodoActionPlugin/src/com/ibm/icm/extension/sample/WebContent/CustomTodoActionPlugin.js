console.log("Getting custom Todo action plugin scope");

var CustomTodoActionContextRoot = "/CustomTodoAction";

var loadCSS = function(cssFileUrl){
	if (dojo.isIE) {
		document.createStyleSheet(cssFileUrl);
	} else {
		var head = document.getElementsByTagName("head")[0];
		var link = document.createElement("link");
		link.rel = "stylesheet";
		link.type = "text/css";
		link.href = cssFileUrl;
		head.appendChild(link);
	}
};

var loadJS = function(scriptUri){
	try{
		dojo._loadUri(scriptUri);
	}catch(e){
		console.log("Custom Todo Action Plugin loading script fail ... "+scriptUri);
	}
};

var jsFileUris = [
                  //"dojo/dojo-all.js"
                  ];

for(var i in jsFileUris){
	var jsFileUri = jsFileUris[i];
	loadJS(jsFileUri);
}

//setup customTodoAction runtime
dojo.setObject("customTodoAction.contextRoot", CustomTodoActionContextRoot);

var paths = {
		"customTodoAction":"/CustomTodoAction/customTodoAction"
	};
require({paths:paths});

console.log("Custom Todo Action Plugin  plugin scope: start to require files");

//is debug mode?
var currentLocation = location.href;
var isDebug = false;
if(currentLocation.indexOf("debug=true") > 0) {
	isDebug = true;
}

var cssFileUris;

if(!isDebug) {
	cssFileUris = [
"./dojox/form/resources/RangeSlider.css",
		CustomTodoActionContextRoot + "/customTodoAction/css/customTodoAction.css"
    ];
} else {
	cssFileUris = [
"./dojox/form/resources/RangeSlider.css",
		CustomTodoActionContextRoot + "/customTodoAction/css/customTodoAction.css"
    ];
}
				   
for(var i in cssFileUris){
	var cssFileUri = cssFileUris[i];
	loadCSS(cssFileUri);
}

if(!isDebug) {

} else {		

}

