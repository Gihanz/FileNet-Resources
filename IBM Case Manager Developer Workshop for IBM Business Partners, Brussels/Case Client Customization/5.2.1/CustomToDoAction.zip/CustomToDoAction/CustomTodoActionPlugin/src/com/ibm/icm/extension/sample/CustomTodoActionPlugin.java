package com.ibm.icm.extension.sample;

import java.util.Locale;

import com.ibm.ecm.extension.Plugin;
import com.ibm.ecm.extension.PluginAction;
import com.ibm.icm.extension.sample.actions.todo.CustomCompleteToDoTaskAction;
import com.ibm.icm.extension.sample.actions.todo.CustomFollowUpToDoTaskAction;

public class CustomTodoActionPlugin extends Plugin {

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return "CustomTodoActionPlugin";
	}

	@Override
	public String getName(Locale locale) {
		// TODO Auto-generated method stub
		String name = NLSResources.getMessage(locale, "icm.plugin.name");
		return name;
	}

	@Override
	public String getVersion() {
		// TODO Auto-generated method stub
		return "1.0";
	}

	@Override
	public PluginAction[] getActions() {
		return new PluginAction[] { 
				new CustomCompleteToDoTaskAction(), 
				new CustomFollowUpToDoTaskAction()
				};
	}

	@Override
	public String getScript() {
		return "CustomTodoActionPlugin.js";
	}

}
