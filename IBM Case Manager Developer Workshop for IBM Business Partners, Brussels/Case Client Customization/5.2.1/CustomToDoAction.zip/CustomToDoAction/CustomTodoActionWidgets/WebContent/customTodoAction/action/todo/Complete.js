define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/connect",
	"dojo/_base/array",
	"icm/action/Action",
	"customTodoAction/dialog/tododialog/ToDoDialog",
	"icm/base/Constants",
	'dojo/date/locale',
	"icm/model/UpdatingBatch"
	],function(declare, lang, connect, array, Action, ToDoDialog,  
		ICMConstants,
		dojoLocale,
		UpdatingBatch) {

		return declare("customTodoAction.action.todo.Complete", [Action], {
			
			executing: false,
			discard: false,
			
			setDiscard: function(discard)
			{
				this.discard = discard;
			},
			
			getDiscard: function()
			{
				return this.discard;
			},

				isVisible: function() 
		{
			var todoTask = this.getActionContext("ToDoEditable");
			if(todoTask === null && todoTask.length === 0){
				return false;
			}
			
			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}
			
			var taskState = todoTask[0].getTask().getTaskState();
			var disabledState = todoTask[0].getTask().disabledState;
			
			//only can work in 'Working' state.
			if(taskState === 4){
				if(disabledState === 0){
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		},		

		isEnabled: function()
		{
			if (this.executing)
			{
				return false;
			}
			
			var todoTask = this.getActionContext("ToDoEditable");
			if(todoTask === null && todoTask.length === 0){
				return false;
			}
			
			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}
			
			var taskState = todoTask[0].getTask().getTaskState();
			var disabledState = todoTask[0].getTask().disabledState;
			
			//only can work in 'Working' state.
			if(taskState === 4){
				if(disabledState === 0){
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		},	
			
			
		inputComment: function(todoTask, results, next, skip){
				var title = null;
				var showDialog = false;
				var dialog = null;
				var buttonsCollection = {};
				
				var OKButtonObj = {};
				OKButtonObj.buttonLabel = "OK";
				
				OKButtonObj.onExecute = lang.hitch(this, function() {
						//Add Case Comment
						var currentTime = dojoLocale.format(new Date(), {datePattern: 'EEE, dd MMM yyyy'});
						var commentText = "ToDoTask Name: " 
						+ todoTask.getTaskName()
						+ "; Action: " + "Complete"
						+ "; Action Time: " + currentTime
						+ "; Comment: " + dialog.reason.get("value");

						this.caseEditable.getCase().addCaseComment(ICMConstants.CommentContext.CASE, 
							commentText, null);	
						console.log("Added Case Comment: " + commentText);
						this.lastComment = dialog.reason.get("value") || "";
						next();
										});
				buttonsCollection.OK = OKButtonObj;

				text="Please specify reason for change.";
				
				dialog = new ToDoDialog({
							title: "Complete", // DEV: to be localized
							text: text,
							buttonsCollection: buttonsCollection,
							onCancel: lang.hitch(this, function() {
								this.executing = false;
								this.setEnabled(true);
								skip();
						})
				});
				dialog.show();
				
			},
			

 			isViewModified:function (){
			
			if(this.widget.viewNode){
					if(this.widget._view && !this.widget._view.get("readOnly") && this.widget._view.someProperty({callback: lang.hitch(this, function(prop){ //only set dirty for the changes on the properties which are in view.
						return prop.controller.isModified(this.widget._widgetLoadTime || new Date());
					})})){
						
  							 return true;

					}else {
						     return false;
					}
				}else {

					  return false;
				}
 			},


		execute: function()
		{
			this.logInfo("execute", "Complete Todo.");	
			var todoTask = this.getActionContext("ToDoEditable");
			
			this.lastComment ="";
			 
			if(todoTask === null && todoTask.length === 0){
				return;
			}
			
			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}
			
			var caseEditable = null;
			if(this.getActionContext("CaseEditable") && this.getActionContext("CaseEditable").length > 0){
				caseEditable = this.getActionContext("CaseEditable")[0];
			}
			
			this.caseEditable = caseEditable;
			
			var taskState = todoTask[0].getTask().getTaskState();
			if(taskState !== 4){
				this.logInfo("execute", "The task state is not ready or working, not fit for complete.");	
				return;
			}
			var context = [];
            context[this.icmBaseConst.TODOTASK] = true;
			context[this.icmBaseConst.CASE] = true;
			context[this.icmBaseConst.TODOTASKTYPE] = todoTask[0].getTaskTypeName();
			context[this.icmBaseConst.TODOTASKID] = todoTask[0].getTaskId();
			
			// disable action during execution
			this.executing = true;
			this.setEnabled(false);
			
			coordination[0].step(this.icmBaseConst.COMMIT, 
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "complete todo, in commit step callback, results");
	        			this.logInfo("execute", results);
	        			next();
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "complete todo, in commit step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})
	        	).step(this.icmBaseConst.VALIDATE,
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "complete todo, in validate step callback, results");
	        			this.logInfo("execute", results);
	        			next();
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "complete todo, in validate step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedFailureVailidate", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})
				).step(this.icmBaseConst.BEFORESAVE,
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in beforeSave step callback, results");
	        			this.logInfo("execute", results)
	        			next();
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in beforeSave step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})
			
			   ).step(this.icmBaseConst.TODO_BEFORECOMPLETE,
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in beforeCOMPLETE step callback, results");
	        			this.logInfo("execute", results);

						if(this.isViewModified())
						{
							this.inputComment(todoTask[0], results, next, skip);
						}
						else
						{
							next();
						}


        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in beforeCOMPLETE step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})
	        	).step(this.icmBaseConst.TODO_COMPLETE,
	        	    lang.hitch(this, function(results, next, skip){
						//complete to-do
						var repo = todoTask[0].repository;
						var taskState = todoTask[0].getTask().getTaskState();
						if(taskState == 3 ||  taskState == 4){			  
							
							var todoStatusProperty = todoTask[0].getProperty("F_CaseTask",this.widget.solution.getPrefix()+"_ToDoStatus");

							var currentStatus = todoStatusProperty.getValue();
							// if the current status is Follow Up or Pend Repair
							// then set its status to Pend Review
							if(currentStatus == "4" || currentStatus == "1"){
								todoStatusProperty.setValue("3");
							}
							// if the current status is Pend Review
							// then set its status to Reviewed and Completed
							if(currentStatus == "3"){
								todoTask[0].setCompleted();
								todoStatusProperty.setValue("0");
							}
							
							

						 	var lastCommentProperty = todoTask[0].getProperty("F_CaseTask",this.widget.solution.getPrefix()+"_LastComment");
							//to set last comment
						 	lastCommentProperty.setValue(this.lastComment);

							var updatingBatch = UpdatingBatch.createNew(repo, 'refresh');
							updatingBatch.addCase(caseEditable);
							updatingBatch.addTask(todoTask[0]);
							updatingBatch.updateBatch(
								lang.hitch(this, function(ub) {
		                	    this.publishEvent(
		                	        "icm.ToDoTaskCompleted",
		                	         {
		                		        'CaseEditable': caseEditable,
										'ToDoTaskEditable': todoTask[0]
		                	        }
		                		);
		                	
		                	    next();
		        	       	 	}),
		        	        	lang.hitch(this, function(response, fieldErrors) {
								// enable action if failed
								this.executing = false;
								this.setEnabled(true);
								skip();
								})
							);
						}
                    }), 
                    lang.hitch(this, function(errors, next, skip){
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})
				).step(this.icmBaseConst.AFTERSAVE,
	        		lang.hitch(this, function(results, next, skip){ 
    			        this.logInfo("execute", "in afterSave step callback, results");
    			        this.logInfo("execute", results);
						// enable action if success
						this.executing = false;
						this.setEnabled(true);
    			        next();
    		        }),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in afterSave step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})	
	        	).step(this.icmBaseConst.TODO_AFTERCOMPLETE,
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in afterComplete step callback, results");
	        			this.logInfo("execute", results);
						// enable action if success
						this.executing = false;
						this.setVisible(this.isVisible());
						this.setEnabled(this.isEnabled());
						this.refreshMenus();
	        			next();
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in afterComplete step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})
	        	).start(context);
		},
		
			_eoc_:null

		});
});