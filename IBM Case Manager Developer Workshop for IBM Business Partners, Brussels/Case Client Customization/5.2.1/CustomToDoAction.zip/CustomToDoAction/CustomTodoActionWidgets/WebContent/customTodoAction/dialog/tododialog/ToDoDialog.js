/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([ "dojo/_base/declare", 
		"dojo/_base/connect", 
		"dojo/_base/lang", 
		"dojo/dom-class", 
		"dojo/dom-attr", 
		"dojo/dom-style", 
		"ecm/widget/dialog/BaseDialog", 
		"dojo/text!./templates/ToDoDialogContent.html" ], //
function(declare, 
		 connect, 
		 lang, 
		 domClass, 
		 domStyle, 
		 domAttr, 
		 BaseDialog, 
		 template) {


	return declare("customTodoAction.dialog.tododialog.ToDoDialog", [ BaseDialog ], {
	

		text: "confirm?",
		buttonLabel: ecm.messages.yes,
		contentString: template,
		cancelButtonDefault: false,
		containReason: true,

		postCreate: function() {
			this.inherited(arguments);
			domAttr.set(this.domNode, "aria-describedby", this.description.id);
			this.setTitle(this.title || this.buttonLabel);
			
			if(!this.containReason){
				domStyle.set(this.reasonArea, "style", "display:none");
			}else{
				domStyle.set(this._starArea, "style", "display:none");
			}
			
			var button;
			var buttonObj = null;
			for(button in this.buttonsCollection){
				if(this.buttonsCollection.hasOwnProperty(button)){
					buttonObj = this.buttonsCollection[button];
					var b1 = this.addButton(buttonObj.buttonLabel, buttonObj.onExecute, buttonObj.disabled||false, !this.cancelButtonDefault);
					connect.connect(b1, "onClick", lang.hitch(this, function(){this.hide();}));
					if(this.reason && buttonObj.disabled){
						domStyle.set(this._starArea, "style", "display:inline");
						connect.connect(this.reason, "onKeyUp", lang.hitch(this, function(b1){
							if(this.reason.get("value").length > 0){
								b1.set("disabled", false);
							}else{
								b1.set("disabled", true);
							}
						}, b1));
					}
					
				}
			}
			
			this.cancelButton.set("label", this.cancelButtonLabel);

			// Make the cancel button the default if requested.
			if (this.cancelButtonDefault) {
				this.autofocus = false;
				connect.connect(this, "onKeyDown", this, function(event) {
					if (event.keyCode == 13)
						this[onCancel]();
				});
			}
		},

		show: function() {
			this.inherited(arguments);
			if (this.cancelButtonDefault) {
				setTimeout(lang.hitch(this, function() {
					this.cancelButton.focus();
				}, 300));
			}
		}
	});
});
