IBM Redbooks publication
Customizing and Extending IBM Content Navigator, SG24-8055

Sample code and resources extracted from 
Chapter 09 "Using Content Navigator widgets in other application"


Directory Content 
===================

1) LayoutPlugin.zip

2) ContainerSimulation.zip

3) Externalized ContentList widget of IBM Content Navigator:


Installation
==================
You can import the projects in your workspace.

1)  Chap09-LayoutPlugin.zip
    Import the projects using the following steps:
	1. Open the Eclipse Environment.
	2. Select Import--> Select Existing Projects into Workspace.
	3. Select archive file and choose the zip you want to import.
	4. Click Finish.
	
2)  ContainerSimulation.zip
    Import the projects using the following steps:
	1. Open the Eclipse Environment.
	2. Select Import--> Select Existing Projects into Workspace.
	3. Select archive file and choose the zip you want to import.
	4. Click Finish.

